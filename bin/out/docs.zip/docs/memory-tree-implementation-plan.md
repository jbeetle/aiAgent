# coqi-claw 记忆树 (Memory Tree) 实现方案

> **设计原则**: 遵循项目 AGENTS.md 编码哲学（先思考再编码、简洁优先、外科手术式变更）
> **复用现有设施**: better-sqlite3-multiple-ciphers / database/ 沙箱 / 工具系统 / 技能系统
> **渐进式交付**: 3 个 Phase，每个独立可用

---

## 一、现状分析

### 1.1 已有的基础设施

| 现有能力 | 位置 | 可复用性 |
|----------|------|:---:|
| SQLite 数据库 | `src/sessions/manager.js` (better-sqlite3-multiple-ciphers) | ✅ 直接复用 |
| database/ 沙箱目录 | `src/security/sandbox-layout.js` → `database/` | ✅ 专为此用途设计 |
| 工具注册机制 | `src/tools/index.js` → `buildTool()` | ✅ 新增工具零摩擦 |
| 技能系统 | `src/skills/SkillManager.js` | ✅ 可配合 auto-fetch |
| Agent 循环 | `src/core/agent.js` → `AgentExecutor` | ✅ 注入记忆上下文 |
| Prompt 构建 | `src/core/prompt-builder.js` | ✅ 添加记忆段 |
| 错误分类 | `src/utils/errors.js` → `Errors.*` | ✅ 统一错误处理 |
| 输出格式 | 全工具统一 `outputFormat: json/text` | ✅ 保持一致性 |

### 1.2 当前差距

```
coqi-claw 现状:
  用户: "今天有什么重要的事？"
  Agent: [无记忆] → "请告诉我今天发生了什么"

OpenHuman 能力:
  用户: "今天有什么重要的事？"
  Agent: [记忆树已构建] → "PR#42 rate limiting P0今天上线 + 3pm牙医..."
```

### 1.3 设计目标

| 目标 | 衡量标准 |
|------|----------|
| **最小侵入** | 不修改 Agent 主循环，仅扩展 prompt 构建 |
| **渐进可用** | Phase 1 即可独立使用 |
| **Token 高效** | 记忆注入控制在 500 tokens 以内 |
| **本地优先** | 全部数据存 SQLite，无需外部服务 |
| **可扩展** | Skill 可通过 `exec_skill` 贡献记忆 |

---

## 二、架构设计

### 2.1 整体数据流

```
┌──────────────────────────────────────────────────────────┐
│                      数据来源                              │
│                                                            │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐  │
│  │ 用户手动  │  │ 工具产出  │  │ Skill拉取 │  │ 对话摘要  │  │
│  │ memory   │  │ web_fetch│  │ exec_skil│  │ 自动      │  │
│  │ add 工具  │  │ 保存结果  │  │ l 结果   │  │ 轮次摘要  │  │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘  │
│       │              │              │              │        │
└───────┼──────────────┼──────────────┼──────────────┼────────┘
        │              │              │              │
        ▼              ▼              ▼              ▼
┌──────────────────────────────────────────────────────────┐
│               MemoryStore (src/memory/store.js)           │
│                                                            │
│  ┌────────────────────────────────────────────────────┐  │
│  │              SQLite (database/memory.db)            │  │
│  │                                                    │  │
│  │  memory_nodes: id/parent_id/content/score/category  │  │
│  │  memory_summaries: id/level/content/generated_at    │  │
│  └────────────────────────────────────────────────────┘  │
│                                                            │
│  ingest(content, metadata) → chunk → score → store        │
│  query(userId, limit)       → top-K scored chunks         │
│  summarize(level)           → LLM 折叠生成摘要            │
└───────────────────────────┬──────────────────────────────┘
                            │ 每次对话时
                            ▼
┌──────────────────────────────────────────────────────────┐
│         Context Injector (src/memory/injector.js)         │
│                                                            │
│  从 MemoryStore 取 top-10 高分段                           │
│  → 格式化为 [Memory Context] 块                            │
│  → 注入 System Prompt 末尾 (≤500 tokens)                  │
└───────────────────────────┬──────────────────────────────┘
                            │
                            ▼
                   ┌────────────────┐
                   │  LLM 上下文     │
                   │  + 记忆注入     │
                   └────────────────┘
```

### 2.2 目录结构

```
src/memory/
├── store.js            # SQLite 存储层 (CRUD)
├── scorer.js           # 评分算法 (时间衰减/来源权重)
├── injector.js         # 上下文注入器 (构建 prompt 记忆段)
├── summarizer.js       # LLM 驱动的树折叠 (Phase 2)
├── model.js            # 数据模型定义
└── tools/
    ├── memory-add.js   # 工具: 手动添加记忆
    ├── memory-search.js # 工具: 搜索记忆
    └── memory-summary.js # 工具: 查看记忆摘要 (Phase 2)

database/
└── memory.db           # 自动创建 (sandbox 目录下)
```

### 2.3 数据模型

```sql
-- 记忆片段表
CREATE TABLE IF NOT EXISTS memory_nodes (
  id          TEXT PRIMARY KEY,          -- UUID
  parent_id   TEXT,                      -- 父节点 (树结构, Phase 2)
  category    TEXT NOT NULL DEFAULT 'general',  -- work/code/personal/...
  title       TEXT NOT NULL,             -- 简短标题
  content     TEXT NOT NULL,             -- ≤500 tokens Markdown
  content_hash TEXT NOT NULL,            -- SHA256 (去重用)
  score       REAL NOT NULL DEFAULT 0,   -- 动态评分
  source      TEXT NOT NULL,             -- 'manual' | 'web_fetch' | 'skill:xxx' | 'summary'
  source_url  TEXT,                      -- 原始来源 URL
  tags        TEXT DEFAULT '[]',         -- JSON 数组
  importance  INTEGER DEFAULT 0,         -- 用户手动标星 (0-5)
  created_at  INTEGER NOT NULL,          -- Unix ms
  expires_at  INTEGER,                   -- 可选 TTL
  access_count INTEGER DEFAULT 0,        -- 被检索次数
  last_accessed_at INTEGER               -- 最后被检索时间
);

-- 索引
CREATE INDEX IF NOT EXISTS idx_memory_category ON memory_nodes(category);
CREATE INDEX IF NOT EXISTS idx_memory_score ON memory_nodes(score DESC);
CREATE INDEX IF NOT EXISTS idx_memory_created ON memory_nodes(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_memory_hash ON memory_nodes(content_hash);

-- 层级摘要表 (Phase 2)
CREATE TABLE IF NOT EXISTS memory_summaries (
  id          TEXT PRIMARY KEY,
  level       INTEGER NOT NULL,          -- 0=根 1=分类 2=子分类
  category    TEXT,
  content     TEXT NOT NULL,             -- LLM 生成的摘要 (≤300 tokens)
  child_count INTEGER DEFAULT 0,
  avg_score   REAL DEFAULT 0,
  generated_at INTEGER NOT NULL
);
```

---

## 三、分阶段实现计划

### Phase 1: 手动记忆 (最小可行产品)

**目标**: 用户可手动添加/搜索记忆，对话时自动注入相关记忆

**新增文件 (4个)**:
```
src/memory/
├── store.js          # ~120 行
├── scorer.js         # ~60 行
├── injector.js       # ~40 行
└── tools/
    ├── memory-add.js    # ~80 行
    └── memory-search.js # ~80 行
```

**修改文件 (2个)**:
```
src/tools/index.js         # +3 行 (注册2个新工具)
src/core/prompt-builder.js # +15 行 (注入记忆段)
```

#### 核心实现

##### 1. MemoryStore (`src/memory/store.js`)

```javascript
import Database from 'better-sqlite3-multiple-ciphers';
import path from 'path';
import { randomUUID, createHash } from 'crypto';
import { getSandboxBaseDir } from '../security/sandbox-layout.js';
import { calculateInitialScore, calculateEffectiveScore } from './scorer.js';
import { logger } from '../utils/logger.js';

const MAX_CONTENT_CHARS = 2000;  // 约 500 tokens

let db = null;

function getDbPath() {
  return path.join(getSandboxBaseDir(), 'database', 'memory.db');
}

function getDb() {
  if (db) return db;
  const dbPath = getDbPath();
  db = new Database(dbPath);
  db.pragma('journal_mode = WAL');
  db.exec(`
    CREATE TABLE IF NOT EXISTS memory_nodes (
      id TEXT PRIMARY KEY, category TEXT NOT NULL DEFAULT 'general',
      title TEXT NOT NULL, content TEXT NOT NULL,
      content_hash TEXT NOT NULL, score REAL NOT NULL DEFAULT 0,
      source TEXT NOT NULL, source_url TEXT,
      tags TEXT DEFAULT '[]', importance INTEGER DEFAULT 0,
      created_at INTEGER NOT NULL, expires_at INTEGER,
      access_count INTEGER DEFAULT 0, last_accessed_at INTEGER
    );
    CREATE INDEX IF NOT EXISTS idx_memory_score ON memory_nodes(score DESC);
    CREATE INDEX IF NOT EXISTS idx_memory_category ON memory_nodes(category);
    CREATE INDEX IF NOT EXISTS idx_memory_hash ON memory_nodes(content_hash);
  `);
  return db;
}

export class MemoryStore {
  /**
   * 添加记忆片段。相同 hash 的内容不重复存储，仅更新时间和访问计数。
   */
  static add({ title, content, category = 'general', source = 'manual',
               sourceUrl = null, tags = [], importance = 0 }) {
    const db = getDb();
    const id = randomUUID();
    const hash = createHash('sha256').update(content).digest('hex');
    const now = Date.now();

    const existing = db.prepare(
      'SELECT id FROM memory_nodes WHERE content_hash = ?'
    ).get(hash);
    if (existing) {
      db.prepare(
        'UPDATE memory_nodes SET created_at=?, access_count=access_count+1 WHERE id=?'
      ).run(now, existing.id);
      return existing.id;
    }

    const truncated = content.length > MAX_CONTENT_CHARS
      ? content.slice(0, MAX_CONTENT_CHARS) + '\n\n[内容已截断]'
      : content;

    const score = calculateInitialScore({ importance, source, tags });

    db.prepare(`INSERT INTO memory_nodes
      (id,title,content,content_hash,score,category,source,source_url,tags,importance,created_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?)`).run(
      id, title, truncated, hash, score, category,
      source, sourceUrl, JSON.stringify(tags), importance, now
    );

    logger.info(`Memory added: "${title}" (score: ${score.toFixed(1)})`);
    return id;
  }

  /**
   * 搜索相关记忆 (全文匹配 + 标签匹配 + 动态评分排序)
   */
  static search({ query = null, category = null, limit = 10, minScore = 0 }) {
    const db = getDb();
    const now = Date.now();

    let sql = `SELECT * FROM memory_nodes
               WHERE (expires_at IS NULL OR expires_at > ?)`;
    const params = [now];

    if (category) { sql += ` AND category = ?`; params.push(category); }
    if (query) {
      sql += ` AND (title LIKE ? OR content LIKE ?)`;
      params.push(`%${query}%`, `%${query}%`);
    }
    if (minScore > 0) { sql += ` AND score >= ?`; params.push(minScore); }

    sql += ` ORDER BY score DESC LIMIT ?`;
    params.push(Math.min(limit, 20));

    const rows = db.prepare(sql).all(...params);

    return rows.map(r => ({
      ...r,
      effectiveScore: calculateEffectiveScore(r, now),
      tags: JSON.parse(r.tags || '[]')
    })).sort((a, b) => b.effectiveScore - a.effectiveScore);
  }

  /**
   * 获取 Top-K 高价值记忆 (注入上下文用)
   */
  static getTop(limit = 10) {
    return this.search({ limit });
  }

  /**
   * 删除记忆
   */
  static delete(id) {
    getDb().prepare('DELETE FROM memory_nodes WHERE id = ?').run(id);
  }

  /**
   * 获取统计
   */
  static stats() {
    return getDb().prepare(`
      SELECT COUNT(*) as total, COUNT(DISTINCT category) as categories,
             AVG(score) as avg_score,
             SUM(CASE WHEN source='manual' THEN 1 ELSE 0 END) as manual_count,
             SUM(CASE WHEN source!='manual' THEN 1 ELSE 0 END) as auto_count
      FROM memory_nodes
    `).get();
  }
}
```

##### 2. 评分器 (`src/memory/scorer.js`)

```javascript
/**
 * 来源基础权重。用户手动添加 > 对话摘要 > 技能拉取 > 自动抓取
 */
const SOURCE_WEIGHTS = {
  'manual':     8.0,
  'conversation': 6.0,
  'summary':    7.0,
  'skill':      5.0,
  'web_fetch':  3.0,
  'default':    2.0,
};

/**
 * 计算初始评分
 * formula: source_weight + importance*1.5 + tags*0.5
 */
export function calculateInitialScore({ importance = 0, source = 'manual', tags = [] }) {
  let score = SOURCE_WEIGHTS[source] || SOURCE_WEIGHTS['default'];
  score += importance * 1.5;       // 0-5级 star，最高 +7.5
  score += (tags || []).length * 0.5;  // 每个tag +0.5
  return score;
}

/**
 * 动态评分 (每次检索时重新计算)
 * formula: base_score × time_decay × importance_bonus × access_bonus
 *
 * - time_decay: 7天半衰期
 * - importance_bonus: 手动标星越高，衰减越慢
 * - access_bonus: 被检索越频繁，排名越高
 */
export function calculateEffectiveScore(node, now = Date.now()) {
  const ageInDays = (now - node.created_at) / 86400000;
  const timeDecay = 1.0 / (1 + ageInDays / 7);
  const importanceBonus = 1 + (node.importance || 0) * 0.2;
  const accessBonus = 1 + Math.min(node.access_count || 0, 10) * 0.05;

  return node.score * timeDecay * importanceBonus * accessBonus;
}
```

##### 3. 上下文注入器 (`src/memory/injector.js`)

```javascript
import { MemoryStore } from './store.js';

const MAX_MEMORY_TOKENS = 500;

/**
 * 构建记忆上下文块，注入到 system prompt。
 * 取 top-10 记忆，摘要截断，总 token 控制在 500 以内。
 */
export function buildMemoryContext() {
  const memories = MemoryStore.getTop(10);
  if (memories.length === 0) return '';

  let text = '## 记忆库\n';
  let estimatedTokens = 20; // 标题开销

  for (const m of memories) {
    const categoryTag = m.category !== 'general' ? `[${m.category}] ` : '';
    const snippet = m.content.length > 200
      ? m.content.slice(0, 200).replace(/\n/g, ' ') + '...'
      : m.content.replace(/\n/g, ' ');

    const line = `- **${categoryTag}${m.title}**: ${snippet}\n`;
    estimatedTokens += line.length / 4;  // 粗略 token 估算

    if (estimatedTokens > MAX_MEMORY_TOKENS) break;
    text += line;
  }

  return text;
}
```

##### 4. 工具: memory_add (`src/memory/tools/memory-add.js`)

```javascript
import { Errors } from '../../utils/errors.js';
import { MemoryStore } from '../store.js';

export const name = 'memory_add';

export const description = `持久化记忆——保存在本地知识库中，后续对话自动注入上下文。

用途: 保存重要发现、用户偏好、项目上下文，或任何值得记住的信息。
Categories: "work" (工作), "code" (代码), "personal" (个人), "general" (通用, 默认)。
Importance (0-5): 越高则留存越久、检索优先级越高。Tags 用于分类搜索。`;

export const parameters = {
  type: 'object',
  properties: {
    title: {
      type: 'string',
      description: '简短标题，用于检索匹配。例: "PR#42 auth 中间件"'
    },
    content: {
      type: 'string',
      description: '记忆内容，支持 Markdown。例: "PR#42 需要添加 rate limiting 中间件，P0 今天上线，由 @刘经理 指派"'
    },
    category: {
      type: 'string',
      enum: ['general', 'work', 'code', 'personal'],
      default: 'general',
      description: '分类组织'
    },
    importance: {
      type: 'number',
      minimum: 0,
      maximum: 5,
      default: 3,
      description: '重要性: 0=琐事, 3=重要, 5=关键'
    },
    tags: {
      type: 'array',
      items: { type: 'string' },
      description: '标签，方便搜索。例: ["rust", "security", "p0"]'
    }
  },
  required: ['title', 'content']
};

export async function execute(args) {
  const { title, content, category, importance, tags } = args;

  if (!title?.trim()) throw Errors.validation('title', 'Title is required');
  if (!content?.trim()) throw Errors.validation('content', 'Content is required');

  const id = MemoryStore.add({ title, content, category, importance, tags });

  return JSON.stringify({
    success: true,
    id,
    title,
    message: `记忆 "${title}" 已保存，将在后续对话中自动可用`
  }, null, 2);
}
```

##### 5. 工具: memory_search (`src/memory/tools/memory-search.js`)

```javascript
import { Errors } from '../../utils/errors.js';
import { MemoryStore } from '../store.js';

export const name = 'memory_search';

export const description = `搜索本地记忆知识库。基于全文匹配 + 动态评分排序 (时效 × 重要性 × 来源权重)。

用于查找之前保存的上下文、用户偏好或项目特定信息。
支持按 category 过滤，结果按有效评分降序排列。`;

export const parameters = {
  type: 'object',
  properties: {
    query: {
      type: 'string',
      description: '搜索关键词 (匹配标题和内容)'
    },
    category: {
      type: 'string',
      enum: ['general', 'work', 'code', 'personal'],
      description: '可选：按分类过滤'
    },
    limit: {
      type: 'number',
      default: 10,
      description: '最大返回数 (上限20)'
    }
  },
  required: ['query']
};

export async function execute(args) {
  const { query, category, limit } = args;

  if (!query?.trim()) throw Errors.validation('query', 'Search query is required');

  const results = MemoryStore.search({ query, category, limit });

  if (results.length === 0) {
    return JSON.stringify({
      query,
      count: 0,
      results: [],
      hint: '未找到匹配记忆。用 memory_add 添加新的记忆。'
    }, null, 2);
  }

  const formatted = results.map(r => ({
    id: r.id,
    title: r.title,
    category: r.category,
    snippet: r.content.length > 200 ? r.content.slice(0, 200) + '...' : r.content,
    score: r.effectiveScore.toFixed(1),
    importance: r.importance,
    tags: r.tags,
    source: r.source,
    created: new Date(r.created_at).toISOString()
  }));

  return JSON.stringify({
    query,
    count: formatted.length,
    results: formatted
  }, null, 2);
}
```

#### Phase 1 效果演示

```
用户: "记住：PR#42是auth rate limiting中间件，P0今天上线，刘经理指派"
Agent: [调用 memory_add] → "记忆已保存"

用户: "记住：这个项目是React+Tauri桌面应用，Rust核心用JSON-RPC通信"
Agent: [调用 memory_add] → "记忆已保存"

用户: "记住：用户偏好——中文回答，代码注释用英文，别用emoji"
Agent: [调用 memory_add] → "记忆已保存"

--- 新一轮对话 ---

System Prompt 末尾自动注入:
  ## 记忆库
  - [code] PR#42 auth rate limiting: P0任务，今天上线前完成，由刘经理指派...
  - [work] 项目架构: React+Tauri桌面应用，Rust核心通过JSON-RPC与前端通信...
  - [personal] 语言偏好: 回答用中文，代码注释英文，不使用emoji...

用户: "今天什么事最重要？"
Agent: 根据记忆，PR#42的auth rate limiting是P0今天上线。需要我帮你review代码吗？
  [自动使用了中文，代码注释用英文，无emoji ✓]
```

---

### Phase 2: 自动摘要与树折叠

**目标**: 记忆积累到一定数量后，自动生成分类摘要，减少注入 token 数

**新增 (2个)**:
```
src/memory/summarizer.js      # ~80 行
src/memory/tools/memory-summary.js  # ~60 行
```

```javascript
// summarizer.js 核心逻辑
export class MemorySummarizer {
  /**
   * 对指定分类的记忆进行 LLM 摘要折叠
   * 将 N 个叶子节点 → 1 个摘要节点
   */
  static async summarizeCategory(llmClient, category, options = {}) {
    const nodes = MemoryStore.search({ category, limit: 50 });

    if (nodes.length <= 5) return null; // 太少不值得摘要

    const prompt = `将以下 ${nodes.length} 条关于 "${category}" 的记忆压缩为一条简洁摘要 (≤200词)。
保留关键事实、日期、人名和待办事项。

${nodes.map(n => `- ${n.title}: ${n.content.slice(0, 300)}`).join('\n')}

摘要:`;

    const result = await llmClient.complete(prompt, { maxTokens: 300 });
    return result;
  }
}
```

---

### Phase 3: Skill 驱动的 Auto-Fetch

**目标**: 通过定时 Skill 自动从外部服务拉取数据写入记忆库

**新增 Skill** (`skills/memory-sync/`):
```
skills/memory-sync/
├── SKILL.md
├── scripts/
│   └── sync-example.js     # 示例：拉取数据 → memory_add
└── references/
    └── setup.md             # 配置说明
```

用户通过 cron / 手动触发：
```bash
npm start "用memory-sync技能拉取最新数据到记忆库"
```

---

## 四、Token 预算控制

| 阶段 | 注入内容 | Token 预算 |
|------|----------|:---:|
| Phase 1 | Top-10 记忆摘要 (每条 ≤50 tokens) | **≤500** |
| Phase 2 | 分类摘要 (≤200 tokens) + Top-5 最新 (每条 ≤50 tokens) | **≤450** |
| Phase 3 | 根摘要 (≤150 tokens) + 分类摘要 (≤200 tokens) + Top-3 紧迫项 | **≤500** |

控制策略：
- `MAX_MEMORY_TOKENS = 500` 硬上限
- 优先保留 importance ≥ 3 的记忆
- 超出时自动截断低分项

---

## 五、与 OpenHuman 的对比

| 维度 | OpenHuman | coqi-claw Phase 3 方案 |
|------|-----------|----------------------|
| **存储** | SQLite + Obsidian .md | SQLite (复用 better-sqlite3) |
| **数据来源** | 118+ OAuth 自动拉取 | 手动 + 工具产出 + Skill 拉取 |
| **拉取频率** | 每20分钟 cron | 按需 + 可选 cron skill |
| **压缩层** | TokenJuice (全局中间件) | 每工具独立截断 (≤500 tokens/片) |
| **评分算法** | 多因子动态评分 | 时间衰减 + 重要性 + 来源权重 |
| **树折叠** | LLM 自动摘要 | Phase 2 手动触发 + 可选自动 |
| **可编辑性** | Obsidian 直接编辑 | 通过工具 CRUD |
| **依赖** | 托管后端服务 | 仅依赖自身 LLM |
| **Token 成本** | 80% 压缩 (TokenJuice) | 截断控制 (≤500 tokens) |

---

## 六、实现优先级与工作量估算

| Phase | 文件数 | 代码量 | 工作量 | 可独立交付 |
|-------|:---:|:---:|:---:|:---:|
| **Phase 1** | 6 个 (4新+2改) | ~380 行 | 1-2 天 | ✅ |
| **Phase 2** | 2 个 (1新+1改) | ~140 行 | 0.5 天 | ✅ |
| **Phase 3** | 4 个 Skill 文件 | ~200 行 | 1 天 | ✅ |
| **合计** | 12 个文件 | ~720 行 | 2.5-3.5 天 | — |

---

## 七、关键设计决策

| 决策点 | 选择 | 理由 |
|--------|------|------|
| 存储引擎 | `better-sqlite3-multiple-ciphers` | 项目已有，零新依赖 |
| 数据库位置 | `database/memory.db` | 沙箱标准目录，语义正确 |
| 注入方式 | prompt-builder 末尾追加 | 最小侵入，不碰 Agent 主循环 |
| 去重策略 | SHA256 content hash | 简单高效，防重复存储 |
| 评分算法 | 四因子 (来源+重要性+时间+频率) | 平衡时效性与重要性 |
| Token 预算 | 硬上限 500 tokens | LLM 上下文宝贵，记忆不喧宾夺主 |
| Phase 切分 | 3个独立可用 Phase | 每个 Phase 交付后即可使用，降低风险 |
| 工具拆分 | memory_add / memory_search 独立 | 单一职责，LLM 调用清晰 |

---

## 八、Phase 1 快速启动检查清单

- [ ] 创建 `src/memory/` 目录结构
- [ ] 实现 `store.js` (SQLite CRUD + 自动建表)
- [ ] 实现 `scorer.js` (评分算法)
- [ ] 实现 `injector.js` (上下文注入)
- [ ] 实现 `tools/memory-add.js` (工具定义 + execute)
- [ ] 实现 `tools/memory-search.js` (工具定义 + execute)
- [ ] 在 `src/tools/index.js` 注册 `memory_add` 和 `memory_search`
- [ ] 在 `src/core/prompt-builder.js` 的 `buildSystemPrompt()` 末尾调用 `buildMemoryContext()`
- [ ] 验证: `node --check src/memory/**/*.js`
- [ ] 功能测试: 添加记忆 → 搜索记忆 → 新对话查看 System Prompt 是否含记忆段
