# Web UI 动态环境变量配置实现计划

> 最后更新：2026-07-10

## Context

coqi-claw 目前所有环境变量在启动时通过 `.env` 一次性加载，各功能模块（主 LLM、Matcher、Audit、Background Extractor、Vision、Tool LLM 等）在 `BootstrapManager.initializeAgent()` 中按固定流程实例化。随着 Web UI 上线，用户希望在网页上动态配置这些参数，例如切换模型、开关思考模式、调整 temperature 等。

本次改造的核心诉求是**兼容现有 `.env` 机制**：
- 保持现有启动流程不变；
- 若某模块所需环境变量未配置，则**暂不初始化**该模块；
- 用户通过 Web UI 补齐配置后，**运行时启动**该模块并缓存；
- 模块启动后，热参数实时生效，连接池/接入点凭证等变更提示重启。

**扩展性要求**：配置 schema 未来由独立运维后台通过 HTTP API 管理，coqi-claw 运行时拉取 schema 动态装配。因此 schema 不能硬编码在后端代码中，需要可外部化。

## 推荐方案：Lazy-Init + Runtime Config Service

采用 **Schema 可外部化 + 模块懒初始化 + 运行时配置服务 + 热更新分发** 的分层架构。

### 架构分层

| 层级 | 职责 | 关键文件 |
|------|------|----------|
| Schema 获取层 | 从本地 JSON / 远程 HTTP API 获取配置定义，运行时装配 | `src/utils/config/schema-provider.js` |
| 策略推导层 | 从 schema + key 命名规则推导 `webEditable`/`restartRequired`/`moduleId` | `src/utils/config/web-config-policy.js` |
| 持久化层 | 维护 `.env` / `.env.runtime`；RSA 加解密；guarded 签名保护 | `src/utils/config/env-writer.js`, `src/utils/config-decrypt.js` |
| 模块生命周期层 | 按需初始化、启动、停止、重建各 LLM/Agent/Extractor 模块 | `src/services/module-lifecycle.js` |
| 运行时配置层 | 统一视图：当前值、默认值、元数据、是否已初始化、是否需要重启、是否可编辑 | `src/services/config-service.js`, `src/utils/config/runtime-config.js` |
| 热更新层 | 把变更同步到 `process.env`、config cache、LLMClient、Agent、ContextManager、Logger 等 | `src/core/llm/client.js`, `src/core/agent.js`, `src/sessions/context-manager.js`, `src/utils/logger.js` |
| API 层 | 提供 `/api/config*` REST 接口，继承现有 `apiKeyAuth` | `src/gateway/routes/config.js`, `src/gateway/router.js` |
| 前端层 | Schema 驱动表单、模块初始化状态、dirty、未保存拦截、重启提示、敏感字段脱敏 | `web/src/stores/config-store.ts`, `web/src/components/settings/EnvConfigPage.tsx` |

核心原则：
- **不改现有 `.env` 加载顺序**，CLI/TUI 启动行为保持原样。
- **模块按需初始化**：未配置则不创建对应 `LLMClient` / `AuditReviewer` / `Background Extractor`。
- **一次初始化，后续热更新**：模块启动后，模型/温度/思考模式等热参数即时生效；连接池/接入点凭证变更仅标记 `pendingRestart`。
- **Schema 可外部化**：当前从本地 `config/env-config-schema.json` + `CONFIG_SCHEMA` 合并获取；未来可切换为远程 HTTP API 拉取，前端和后端核心逻辑不变。

---

## Schema 获取机制（核心设计）

### SchemaProvider — 统一 schema 获取接口

```js
// src/utils/config/schema-provider.js

/**
 * Schema 获取策略：
 * 1. 本地模式（默认）：从 env-config-schema.json + CONFIG_SCHEMA 合并
 * 2. 远程模式：从 CONFIG_SCHEMA_URL 指定的 HTTP API 拉取
 *
 * 环境变量：
 * - CONFIG_SCHEMA_URL: 远程 schema API 地址（如 https://admin.example.com/api/config-schema）
 * - CONFIG_SCHEMA_REFRESH_INTERVAL: 远程 schema 刷新间隔（毫秒，默认 0 不刷新）
 */
export class SchemaProvider {
  constructor(options) { ... }

  /** 获取完整 schema（本地或远程） */
  async getSchema() { ... }

  /** 强制刷新（用于远程模式） */
  async refresh() { ... }
}
```

### Schema 来源优先级

```
CONFIG_SCHEMA_URL 已设置？
  ├── 是 → HTTP POST 拉取远程 schema JSON（A11n: Bearer 认证，空 JSON body）
  └── 否 → 本地合并：
            env-config-schema.json（描述/options/encrypted 补充）
          + CONFIG_SCHEMA（schema.js，运行时校验规则）
          → 合并为统一 ConfigSchema
```

### 合并规则

| 字段 | 来源 | 说明 |
|------|------|------|
| `key` | 两者 | 环境变量名，唯一标识 |
| `type` | `config/env-config-schema.json` 优先，fallback `CONFIG_SCHEMA` 推导 | string/number/boolean |
| `description` | `config/env-config-schema.json` 优先 | 中文描述 |
| `options` | `config/env-config-schema.json` | 下拉选项列表 |
| `encrypted` | `config/env-config-schema.json` | 是否 RSA 加密 |
| `default` | `CONFIG_SCHEMA` 优先 | 运行时默认值 |
| `validate/transform` | `CONFIG_SCHEMA` | 校验与转换函数（仅本地模式可用） |
| `webEditable` | `web-config-policy.js` 推导 | 不存储在 schema 中 |
| `restartRequired` | `web-config-policy.js` 推导 | 不存储在 schema 中 |
| `moduleId` | `web-config-policy.js` 推导 | 不存储在 schema 中 |

**远程模式**下 `validate/transform` 不可用（函数无法序列化），改用 schema 中声明的通用校验规则（如 `min/max/pattern/required`）。

### 远程 Schema API 契约

未来运维后台需提供的接口：

```
GET /api/config-schema
Response: {
  meta: { version, description },
  llm: { main: { LLM_MODEL: { type, description, options, ... }, ... }, ... },
  core: { ... },
  context: { ... },
  ...
}
```

格式与当前 `config/env-config-schema.json` 一致，确保本地→远程迁移零改动。

---

## 数据模型

### 后端运行时配置项（ConfigEntry）

```ts
interface ConfigEntry {
  group: string;              // 如 "llm.main"
  key: string;                // 环境变量名
  type: "string" | "number" | "boolean";
  value: string | null;       // 当前运行时值（已解密）
  defaultValue: string | null;
  description: string;
  required: boolean;
  options?: string[];
  encrypted: boolean;
  note?: string;
  restartRequired: boolean;   // 由 web-config-policy 推导
  webEditable: boolean;       // 由 web-config-policy 推导
  moduleId?: string;          // 由 web-config-policy 推导：primary/matcher/audit/background/vision/tool
  isInitialized?: boolean;    // 对应模块是否已启动
}
```

### 前端 DTO

```ts
interface ConfigItemDTO {
  key: string;
  value: string | null;
  defaultValue: string | null;
  type: "string" | "number" | "boolean";
  description: string;
  required: boolean;
  options?: string[];
  note?: string;
  restartRequired: boolean;
  webEditable: boolean;
  encrypted: boolean;
  hasValue: boolean;
  isInitialized?: boolean;
}

interface ConfigGroupDTO {
  name: string;
  label: string;
  items: ConfigItemDTO[];
}

interface ConfigResponse {
  scene: string;
  guarded: boolean;
  pendingRestartKeys: string[];
  uninitializedModules: string[];
  groups: ConfigGroupDTO[];
}
```

### 加密字段读写策略

- 读：`decryptEnvConfig()` 在启动时扫描 `{base64}` 格式并解密。API 返回加密字段时，`value` 为 `null`，`hasValue: true`。
- 写：前端提交非空字符串时，后端调用 `encryptEnvValue(plaintext, publicKey)` 生成 `{base64}` 后写入。空字符串表示"保持原值"。
- 公钥路径：`config/public-config.pem`；若缺失则回退为明文并记录 warn。

---

## 后端实现

### 新增/修改文件

| 文件 | 类型 | 说明 |
|------|------|------|
| `src/utils/config/schema-provider.js` | 新建 | Schema 获取：本地合并 / 远程 HTTP 拉取 |
| `src/utils/config/web-config-policy.js` | 新建 | 推导每个 key 的 `webEditable`、`restartRequired`、`moduleId` |
| `src/utils/config/env-writer.js` | 新建 | 安全重写 `.env` / `.env.runtime`，保留注释与顺序 |
| `src/utils/config/runtime-config.js` | 新建 | 配置项解析、校验、归一化 |
| `src/services/module-lifecycle.js` | 新建 | 各模块的 start/stop/restart 生命周期 |
| `src/services/config-service.js` | 新建 | orchestration：读写持久化、同步运行时、调用热更新 |
| `src/gateway/routes/config.js` | 新建 | REST API 路由 |
| `src/utils/config/schema.js` | 修改 | 补充缺失项的校验/默认值（如 vision/tool 系列） |
| `src/utils/config-decrypt.js` | 修改 | 增加 `encryptEnvValue()` |
| `src/core/llm/client.js` | 修改 | 增加 `setRuntimeConfig(partial)` 与内部 `reinitClient()` |
| `src/core/agent.js` | 修改 | 增加 `setRuntimeConfig(config)`；支持运行时替换主 LLMClient |
| `src/sessions/context-manager.js` | 修改 | 增加 `setRuntimeConfig(config)` |
| `src/utils/logger.js` | 修改 | 增加 `reloadLogLevel()` |
| `src/bootstrap/manager.js` | 修改 | 支持模块懒初始化；加载 `.env.runtime` overlay；暴露运行时更新钩子 |
| `src/gateway/router.js` | 修改 | 挂载 `/config` 路由 |
| `src/gateway/server.js` | 修改 | 实例化 `ConfigService` 并注入 `createRouter` |
| `docs/openapi.json` | 修改 | 新增 Config 相关 endpoints 与 schemas |

### 模块懒初始化策略

在 `BootstrapManager.initializeAgent()` 中调整：

| 模块 | 启动条件 | 未配置时行为 |
|------|----------|--------------|
| 主 LLM (`primary`) | 始终需要（`LLM_PROVIDER/API_KEY/BASE_URL/MODEL`） | TUI/CLI 模式启动失败；Web 模式降级启动（等待配置推送） |
| Matcher LLM | `MATCHER_LLM_*` 完整则独立创建，否则降级使用主 client | 缺失时降级，不报错 |
| Audit Reviewer | `ENABLE_AUDIT=true` 且 `AUDIT_LLM_*` 完整 | 未配置则跳过 |
| Background Extractor | `ENABLE_PROFILE_EXTRACTION=true` 且 `BACKGROUND_LLM_*` 完整 | 未配置则跳过 |
| Vision LLM | `VISION_LLM_*` 完整 | 未配置则跳过（read 图片分析时提示未启用） |
| Tool LLM | `TOOL_LLM_*` 完整 | 未配置则 skill 脚本调用主 LLM 或提示未启用 |

关键改动点（`src/bootstrap/manager.js`）：
- 将 `_initializeAudit()` 和 Background Extractor 启动逻辑从强制流程改为条件执行。
- 新增 `startModule(moduleId, config)` / `stopModule(moduleId)` 方法，供 `ConfigService` 在运行时调用。
- 各 `LLMClient` 初始化时若配置不完整，抛出 `ConfigError`，由调用方捕获并跳过该模块。

### API 端点

所有端点位于 `/api/config` 与 `/api/v1/config`，继承 `apiKeyAuth`。

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/config` | 当前运行时配置、未初始化模块、pendingRestartKeys |
| GET | `/api/config/schema` | 纯 schema（来自 SchemaProvider） |
| PATCH | `/api/config` | 应用一组变更；自动启动/重建对应模块 |
| POST | `/api/config/initialize` | 手动初始化指定模块（如启用 Audit） |
| POST | `/api/config/validate` | 验证指定 profile 的连通性（支持 preview 值） |
| POST | `/api/config/reset` | 将指定 key 恢复为 schema default |
| POST | `/api/config/reload` | 重新从磁盘加载 |

PATCH 处理流程：
1. 校验 key 存在且 `webEditable=true`。
2. 类型转换与校验。
3. guarded 场景拒绝修改安全键（`SECURITY_KEYS` + `DB_ENCRYPTION_KEY` + `COQI_SCENE`）。
4. 加密字段 RSA 加密后写入。
5. 写入持久化：非 guarded → `.env`；guarded → `.env.runtime`。
6. 更新 `process.env` 并 `clearConfigCache()`。
7. 若该 key 所属模块尚未初始化，尝试 `moduleLifecycle.start(moduleId)`。
8. 若模块已初始化且为热参数，调用模块 `setRuntimeConfig()`。
9. 若模块已初始化且为重启参数，加入 `pendingRestartKeys`。

### 热更新分发

| Scope | 操作 |
|-------|------|
| `primary` | 更新 `LLMClient.model/temperature/enableThinking/reasoningEffort/timeout/maxRetries`；`timeout` 变化时 `reinitClient()` |
| `matcher` | 同 primary；如原本降级使用主 client，现配置完整则新建 matcher client |
| `audit` | 配置完整但未启动 → 启动；已启动 → 重建 client；`ENABLE_AUDIT=false` → 停止 |
| `background` | 同 audit，启停 Background Extractor |
| `vision` / `tool` | 启动或重建对应 client |
| `agent` | 更新 `Agent.maxIterations` 等字段 |
| `context` | 更新 `ContextManager` 参数 |
| `logger` | `logger.reloadLogLevel()` |
| `network` / `dlp` | 调用已有的 `reloadConfig()` |

### 必须重启的参数

以下参数变更后仅加入 `pendingRestartKeys`，不热更新：
- HTTP 连接池：`LLM_HTTP_MAX_SOCKETS`, `LLM_KEEP_ALIVE_TIMEOUT` 及 matcher/audit/background 对应项
- LLM 接入点凭证：`LLM_PROVIDER`, `LLM_BASE_URL`, `LLM_API_KEY` 及各 profile 对应项
- 启动期一次性配置：`DB_ENCRYPTION_KEY`, `COQI_SCENE`, `DISABLED_TOOLS`, `SANDBOX_PATHS`, `WEB_PORT`, `WEB_HOST`

### Guarded 场景

- `BootstrapManager.loadEnvironment()` 在验证 `.env.sig` 后，若存在 `.env.runtime` 则以 `override: true` 加载。
- 非 guarded：Web 保存直接重写 `.env`。
- guarded：仅写入 `.env.runtime`，不触碰 `.env`，签名保持有效。
- guarded 下安全键 Web 不可编辑。

---

## 前端实现

### 新增/修改文件

| 文件 | 类型 | 说明 |
|------|------|------|
| `web/src/stores/config-store.ts` | 新建 | Zustand store：配置快照、pendingRestart、未初始化模块 |
| `web/src/api/rest.ts` | 修改 | 新增 `configApi` |
| `web/src/components/settings/EnvConfigPage.tsx` | 新建 | 主页面 |
| `web/src/components/settings/EnvConfigField.tsx` | 新建 | 动态字段，根据 type/options/encrypted 渲染 |
| `web/src/components/settings/RestartBanner.tsx` | 新建 | 重启提示横幅 |
| `web/src/components/settings/ModuleInitCard.tsx` | 新建 | 未初始化模块的"启用/配置"卡片 |
| `web/src/hooks/useEnvConfigForm.ts` | 新建 | 表单逻辑 |
| `web/src/components/settings/SettingsSidebar.tsx` | 修改 | 新增"系统配置"导航项 |
| `web/src/App.tsx` | 修改 | 注册 `/settings/environment` 路由 |
| `web/src/constants/strings.ts` | 修改 | 新增文案 |

### 动态表单渲染

- `type === "boolean"`：toggle/checkbox
- `options` 存在：复用 `FormSelect`
- `encrypted`：password input，placeholder "已配置（未修改请留空）"
- `type === "number"`：`<input type="number">`
- 其他：复用 `FormInput`
- 未初始化模块以 `ModuleInitCard` 提示用户补全配置后启用

### 状态管理

- 进入页面时 `GET /api/config` 拉取全量配置与模块状态。
- 保存时 `PATCH /api/config`，成功后更新 `originalValues`、`pendingRestartKeys`、`uninitializedModules`。
- 使用 `useBlocker` + `ConfirmDialog` 拦截未保存离开。

---

## OpenAPI & 类型

1. 更新 `docs/openapi.json`，新增 `Config` tag 与相关 schemas：
   - `ConfigGroup`, `ConfigItem`, `ConfigResponse`
   - `ConfigUpdateRequest`, `ConfigUpdateResponse`
   - `ConfigValidateRequest`, `ConfigValidateResponse`
   - `ConfigInitializeRequest`, `ConfigResetRequest`
2. 运行 `npm run generate-api-types` 更新 `web/src/types/api-generated.ts`。
3. 在 `web/src/types/index.ts` 中补充前端领域类型。

---

## 安全与权限

- 继承 `src/gateway/middleware/api-auth.js` 的 `X-API-Key` 认证。
- 安全键在 Web 上锁定；普通 LLM 参数可编辑。
- 加密字段 API 不回传明文，写回时自动 RSA 加密。
- 日志中使用 `getConfigSummary()` 隐藏 API key。
- guarded 下不允许 Web 修改安全键，避免绕过签名。

---

## 验证方案

### 单元/集成测试

- `test/test-schema-provider.js`：本地合并、远程拉取、fallback、schema 格式校验。
- `test/test-runtime-config.js`：policy 推导、类型转换、校验、加密 mask。
- `test/test-config-service.js`：applyChanges 写文件、更新 process.env、模块懒启动、热更新触发、guarded overlay。
- `test/test-config-routes.js`：GET/PATCH/validate/initialize/reset 端点、认证、错误响应。

### 语法与类型

- `node --check` 所有新增/修改的 JS 文件。
- `cd web && npm run type-check`。

### 端到端验证

1. 启动 `npm run web:dev`。
2. 进入 `/settings/environment`。
3. **场景 A**：修改 `LLM_MODEL` 保存，确认下一次聊天请求使用新模型。
4. **场景 B**：在未启用 Audit 时填写 `AUDIT_LLM_*` 并保存，确认 `AuditReviewer` 被启动。
5. **场景 C**：修改 `LLM_BASE_URL` 保存，确认显示"需要重启"提示。
6. **场景 D**：在 `COQI_SCENE=enterprise` 下测试：可改 `LLM_MODEL`，不可改安全键，`.env.sig` 不被破坏。
7. **场景 E**：设置 `CONFIG_SCHEMA_URL` 指向 mock 服务，验证 schema 从远程拉取并正确装配。

---

## 关键实现文件（Top 5）

1. `src/utils/config/schema-provider.js` — Schema 可外部化获取
2. `src/services/config-service.js` — 配置变更 orchestration
3. `src/services/module-lifecycle.js` — 模块懒初始化与生命周期
4. `src/gateway/routes/config.js` — REST API
5. `web/src/components/settings/EnvConfigPage.tsx` — 前端配置页

---

## 生产审查：遗漏与补丁

> 以下问题由深度代码审查发现，必须在实现前解决。

### 🔴 严重问题（6 个）

#### S1. LLMClient.initClient() 连接池泄漏

**问题**：`initClient()` 直接 `this.client = new OpenAI(...)` 覆盖旧引用，从不调用旧 client 的 `destroy()`。频繁热更新会导致旧连接池的 socket 泄漏，直到服务端超时才释放。

**补丁**：`initClient()` 开头添加：
```js
if (this.client && typeof this.client.destroy === 'function') {
  this.client.destroy();
}
```

#### S2. Agent / ContextManager 的 config 是拷贝而非引用

**问题**：`Agent` 构造函数中 `this.maxIterations = this.config.maxIterations` 是值拷贝。`ContextManager` 同理。只更新 `this.config` 对象不会让实例属性生效。

**补丁**：`setRuntimeConfig()` 必须逐一重新赋值所有拷贝的实例属性：
```js
// Agent.setRuntimeConfig()
setRuntimeConfig(newConfig) {
  this.config = newConfig;
  this.maxIterations = newConfig.maxIterations;
  this.maxMessagesSize = newConfig.maxMessagesSize;
  this.useLlmContextSummary = newConfig.useLlmContextSummary;
  this.contextSummaryMaxLength = newConfig.contextSummaryMaxLength ?? 400;
}
```

#### S3. Tool LLM 降级逻辑不存在

**问题**：方案说"未配置则 skill 脚本调用主 LLM"，但 Python 脚本的 `get_llm_config_from_env()` 不支持降级——`TOOL_LLM_API_KEY` 未设置时直接抛 `ValueError`。

**补丁**：在 Node.js 侧 skill 脚本执行入口（`src/tools/exec.js` 或 `SkillManager`）添加降级映射：当 `TOOL_LLM_*` 未配置时，将 `LLM_*` 的值注入子进程的 `process.env` 作为 `TOOL_LLM_*` 的 fallback。

#### S4. 流式请求中重建连接池会中断在途请求

**问题**：如果热更新触发 `initClient()` 重建 `undici.Agent`，正在 streaming 的请求会因旧连接池被 destroy 而中断。

**补丁**：`setRuntimeConfig()` 区分两种变更：
- **非连接参数**（model/temperature/thinking/retries）：直接更新实例字段，不调用 `initClient()`，安全。
- **连接参数**（timeout/httpMaxSockets/keepAliveTimeout）：标记为 `pendingRestart`，**不热更新**，提示用户重启。这比方案原设计更保守但更安全。

#### S5. SchemaProvider HTTP 请求绕过网络策略

**问题**：`network-policy.js` 的 `validateUrl()` 只在工具层调用，SchemaProvider 的 HTTP 请求不受限制。在 `allowlist` 模式下是安全漏洞。

**补丁**：SchemaProvider 发起 HTTP 请求前必须调用 `validateUrl(url)` 校验。`allowlist` 模式下如果 `CONFIG_SCHEMA_URL` 不在白名单中，拒绝拉取并 fallback 到本地。

#### S6. 并发写入 .env 的 lost update

**问题**：两个用户同时 PATCH 不同字段，后写者覆盖前写者的修改。

**补丁**：采用乐观并发控制——PATCH 请求携带 `If-Match` header（值为上次 GET 返回的 `.env` 文件内容 hash），服务端写回前检查文件是否被修改过。如果不匹配，返回 `409 Conflict`，前端提示用户刷新后重试。

### 🟡 需补充的遗漏（8 个）

#### M1. Audit/Background 懒初始化后需要空值守卫

`getAuditReviewer()` 返回 `null` 时，所有消费点（chat handler）必须检查。当前代码是否已有守卫需逐一排查。同理 Background Extractor。

#### M2. 模块状态需要三态而非二态

`isInitialized` 只有 true/false，缺少"启用但配置不完整"的中间状态。前端 `ModuleInitCard` 需要区分：
- `uninitialized`：从未配置
- `misconfigured`：开关打开但必填项缺失
- `running`：已启动

建议 `ConfigEntry.moduleState` 取值 `"uninitialized" | "misconfigured" | "running"`。

#### M3. Vision LLM 已天然支持懒初始化

`src/tools/read/image.js` 的 `getVisionConfig()` 在 `VISION_LLM_MODEL` 未设置时返回 `null`，`readImageFile` 跳过 AI 描述。**无需在 BootstrapManager 中管理 Vision 模块生命周期**，方案中这部分是多余的。

#### M4. .env.runtime 在 guarded 场景需过滤安全键

如果有人手动编辑 `.env.runtime` 注入 `DB_ENCRYPTION_KEY` 等安全键，`dotenv.config({ override: true })` 会覆盖 `.env` 中的值，绕过签名保护。

**补丁**：guarded 场景下加载 `.env.runtime` 后，删除 `SECURITY_KEYS` + `DB_ENCRYPTION_KEY` + `COQI_SCENE` 在 `process.env` 中的覆盖值，恢复为 `.env` 中的原始值。

#### M5. env-writer.js 必须采用逐行修改策略

**不能**采用"解析所有键值对 → 修改 → 全量重写"的策略，因为加密值 `{base64ciphertext}` 的格式信息（引号风格、是否带引号）在解析时会丢失。

**补丁**：逐行读取 `.env`，只修改目标 key 所在行的值，其他行原样保留。未找到的 key 追加到文件末尾。

#### M6. env-config-schema.json 缺少 min/max/pattern 校验字段

前端无法知道 `LLM_TEMPERATURE` 范围是 0-2、`MAX_ITERATIONS` 范围是 1-100。需要从 `CONFIG_SCHEMA` 的 `validate` 函数逆向提取为声明式规则，补充到 schema 中。

#### M7. 远程 Schema 需要超时 + fallback + 版本检查

- 首次拉取超时 5s，失败则 fallback 到本地 schema，不阻塞启动。
- 远程 schema 需携带 `schemaVersion` 字段，与本地代码版本对比，不兼容则 fallback。
- 拉取结果缓存到 `temp/schema-cache.json`，下次启动优先使用缓存。

#### M8. .env 外部修改检测

`GET /api/config` 时检查 `.env` 文件的 `mtime`，如果比上次读取时更新，自动重新加载。前端提供"刷新"按钮。

### 🟢 PATCH 响应结构明确

当部分 key 热更新成功、部分标记 pendingRestart 时：

```json
{
  "applied": ["LLM_MODEL"],
  "pendingRestart": ["LLM_BASE_URL"],
  "failed": [{ "key": "INVALID_KEY", "reason": "unknown key" }]
}
```

前端据此分别显示"已生效"和"需要重启"提示。
