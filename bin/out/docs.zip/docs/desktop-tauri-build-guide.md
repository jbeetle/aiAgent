# CoQiClaw 桌面应用打包使用教程（SEA sidecar 版）

> 方案 A 的最终形态：Tauri 壳 + SEA sidecar。**安装器免 Node，可分发到任意 Windows x64 机器。**
> 架构细节见 `docs/desktop-tauri-encapsulation-plan.md`。

## 0. 产物形态

```
安装器 (CoQiClaw_x.x.x_x64-setup.exe)
└── 安装后 → %LOCALAPPDATA%\CoQiClaw\
    ├── app.exe                    # Tauri 壳（Rust，~5MB）
    ├── uninstall.exe
    └── coqi-backend\              # SEA 后端（bundle.resources 打包，免 Node）
        ├── coqi-claw.exe          # Node 运行时 + SEA blob（~86MB）
        ├── src/ skills/ plugins/ config/ node_modules/
        ├── web/dist/              # 前端静态资源（Gateway 同源 serve）
        └── package.json
```

启动时 `app.exe` → `resolve("coqi-backend")` → spawn `coqi-claw.exe web`（自带 Node 运行时）→ Gateway 监听 `127.0.0.1:214` → serve 前端 + API → WebView 加载。目标机器**无需安装 Node.js**。

## 1. 前置环境（打包机）

| 依赖 | 要求 |
|---|---|
| Rust + cargo | ≥ 1.77 |
| Node.js | ≥ 22 |
| MSVC 生成工具 | 2019+ |
| WebView2 | Win11 自带 |
| `@tauri-apps/cli` | 2.x（已装于 `desktop/`） |

## 2. 打包流程（三步）

```bash
# 项目根
npm run build:web        # 1. 构建前端 → web/dist
npm run build:sea        # 2. 打包 SEA 后端 → dist/coqi-claw.exe + 资源（含 web/dist）

cd desktop
npx tauri build          # 3. 打包安装器（bundle.resources 把 dist/ 打进 coqi-backend/）
```

- `build:web`：`web/dist` 是 Gateway 同源 serve 的前端，**必须先构建**（缺失则页面 404）
- `build:sea`：产出免 Node 的 SEA 后端；`build-sea.js` 会校验 `web/dist` 存在
- `tauri build`：release 编译 + 把 `dist/` 打进安装器 + NSIS 打包（首次需联网下载 NSIS 工具）

快速验证（跳过 release 编译）：`npx tauri build --debug`，产物在 `target/debug/bundle/nsis/`。

## 3. 产物

```
desktop/src-tauri/target/release/bundle/nsis/CoQiClaw_2.0.1_x64-setup.exe
```

- **体积**：debug 版 ~178 MB；release 版预计 ~150 MB（887 MB SEA 后端经 NSIS 压缩 + 壳）
- **已验证**：安装后 `coqi-backend/coqi-claw.exe`（85.91 MB，与源字节一致）+ `web/dist` + `node_modules` 全部就位

## 4. 安装与首次使用

1. 双击 `CoQiClaw_x.x.x_x64-setup.exe` 安装（免 Node，无需管理员）
2. 启动 CoQiClaw → 自动 spawn SEA 后端 → 窗口加载 Web UI
3. **配置 LLM**：见下方 ⚠️ 说明

## 5. ⚠️ LLM 配置与密钥安全（分发前必读）

**安装器默认不内嵌 `.env`**（`build-sea.js` 只复制 `.env.example`），这是刻意的——避免把你的真实 `LLM_API_KEY` 打进分发的安装器。

- **分发前**：确认 `dist/` 下没有 `.env`（测试时若 `cp` 过 `.env` 到 `dist/`，打包前删掉）
- **首次使用**：目标用户需配置 LLM。当前两条路：
  - 把配好的 `.env` 放到安装目录的 `coqi-backend\` 下（含 `LLM_*` 与 `WEB_PORT=214`）
  - 或 Gateway 已支持「无配置启动 + UI 引导配置」（`/api/config/initialize`）——若后端容忍缺 `.env` 也能 listen，前端会引导配置
- **注意**：SEA exe 无 `.env` 时，Gateway bootstrap 可能失败导致 `app.exe` 探测超时退出。「开箱即用免配置」需 Gateway 支持无配置启动，属后续工作，见方案文档 §10。

## 6. 开发模式（本机调试）

```bash
cd desktop && npx tauri dev
```

`spawn_gateway` 优先找打包资源 `coqi-backend/coqi-claw.exe`；开发模式（未打包）找不到时 fallback 到项目根裸 `node src/gateway/server.js`（cwd=项目根，需 Node 22+）。需 `web/dist` 已构建。

## 7. 常见问题

| 现象 | 原因 / 处理 |
|---|---|
| 窗口长时间不出现 | SEA 后端未就绪，看终端日志；多为 `coqi-backend/` 缺 `.env` 或 LLM 网络不通 |
| 窗口空白 | `web/dist` 未构建，跑 `npm run build:web` 再 `build:sea` |
| `EACCES` 绑定 214 | 214 < 1024 特权端口，Windows 一般无碍；失败则管理员运行或改高位端口（同步改 `.env` `WEB_PORT` + `lib.rs` 常量 + `tauri.conf.json` devUrl） |
| NSIS 报 `timeout: global` | Tauri 首次需从 GitHub 下载 `nsis-3.11.zip`，重试或配 `HTTPS_PROXY` |
| `frontendDist` 路径报错 | 相对 `src-tauri/` 应为 `../../web/dist`（少一级会解析到 `desktop/web/dist`） |
| 关窗后进程残留 | `lib.rs` 关窗 kill 主进程；SEA 派生的孙进程（playwright 等）可能残留，正式版用 Job Object |
| 想快速验证打包 | `npx tauri build --debug`（debug 版，仅验证，不分发） |

## 8. 卸载

`%LOCALAPPDATA%\CoQiClaw\uninstall.exe`，或「设置 → 应用」卸载。用户数据库（`coqi-backend\database\` 等）按 NSIS 默认保留。
