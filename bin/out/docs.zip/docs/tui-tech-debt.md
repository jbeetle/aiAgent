# TUI 技术债务

## 1. `/list` 无分页

会话多了 `listSessions()` 全量输出，终端刷屏。需支持 `--page N` 或交互式滚动。

## 2. `/help` 信息简陋

目前只列几个斜杠命令名，无参数说明和使用示例。

## 3. Tab 文件路径补全

当前 `createCommandCompleter` 仅在 `/` 开头时补全斜杠命令。需增加文件路径补全：
- 提取输入行最后一个空白分隔的"词"
- 如果该词看起来像文件路径（含 `/`、`\`、或为裸文件名），用 `fs.readdir` 匹配文件/目录
- 目录补全追加路径分隔符
- 支持相对路径（`./`、`../`）、绝对路径、裸文件名
- `src/utils/repl-input.js` 的 `createCommandCompleter` 需要改为异步形式（双参数 completer）
