---
marp: true
size: 16:9
paginate: true
style: |
  section {
    background: white;
    color: #1a1a1a;
    font-family: "Segoe UI", "Noto Sans SC", system-ui, sans-serif;
    font-size: 20px;
    padding: 40px 56px;
  }
  h1 { font-size: 30px; color: #b71c1c; margin-bottom: 12px; font-weight: 600; }
  h2 { font-size: 22px; color: #333; margin-top: 10px; margin-bottom: 6px; }
  h3 { font-size: 19px; color: #555; margin: 4px 0; }
  p { margin: 4px 0; line-height: 1.4; }
  ul, ol { margin: 4px 0; padding-left: 24px; line-height: 1.35; }
  li { margin-bottom: 2px; }
  table { font-size: 16px; border-collapse: collapse; width: 100%; margin: 6px 0; }
  th { background: #b71c1c; color: white; padding: 5px 8px; text-align: left; font-weight: 500; }
  td { padding: 4px 8px; border-bottom: 1px solid #e0e0e0; }
  tr:nth-child(even) td { background: #fafafa; }
  code { font-size: 15px; background: #f5f5f5; padding: 1px 5px; border-radius: 2px; }
  pre { font-size: 14px; background: #f5f5f5; padding: 8px 12px; }
  strong { color: #b71c1c; }
  section.lead {
    background: #b71c1c;
    color: white;
    text-align: center;
    display: flex;
    flex-direction: column;
    justify-content: center;
  }
  section.lead h1 { color: white; font-size: 44px; border: none; margin: 0; }
  section.lead h2 { color: rgba(255,255,255,0.85); font-size: 24px; }
  section.lead p { color: rgba(255,255,255,0.65); font-size: 16px; margin-top: 40px; }
  .cols { display: flex; gap: 24px; }
  .cols > div { flex: 1; }
  .tag { display: inline-block; background: #b71c1c; color: white; padding: 1px 8px; border-radius: 3px; font-size: 13px; }
  .tag-green { background: #2e7d32; }
  .tag-orange { background: #e65100; }
---

<!-- _class: lead -->

# CMBI e-Agent 企业用户培训

## AI 驱动的金融企业智能助手

CMBI Technology · 2026

---

# 培训大纲

<div class="cols">
<div>

**1. 安全机制**
命令验证 · 路径沙箱 · 网络策略 · DLP · 合规审计

**2. Skills 系统**
什么是 Skill · 信任框架 · 加密保护

</div>
<div>

**3. 插件机制**
内置工具 · 插件工具 · 加载管理

**4. 使用技巧**
上下文管理 · 会话策略 · 高效执行 · 最佳实践

</div>
</div>

---

# 安全架构总览

CMBI e-Agent **五层纵深安全体系**：

| 层级 | 机制 | 关键能力 |
|------|------|---------|
| 1 | 命令验证 | 71+ 危险模式实时拦截（rm -rf、sudo、管道注入） |
| 2 | 路径沙箱 | 文件访问范围强制控制，支持 Windows 跨盘符 |
| 3 | 网络策略 | 阻断私有 IP、云元数据端点（169.254.169.254） |
| 4 | DLP 扫描 | 敏感信息自动检测与脱敏 |
| 5 | 合规审计 | LLM 前置语义审查，审计日志只增不改 |

**配置：** `ENABLE_AUDIT=true` · `SANDBOX_MODE=enforce`

---

# 文件系统沙箱

**核心机制**
- 默认仅允许访问**项目根目录**和**当前工作目录**
- `SANDBOX_PATHS` 扩展允许目录（逗号分隔绝对路径）
- 自动阻断 `..` 路径遍历和越界绝对路径
- Windows 跨盘符支持

**三种运行模式**

| 模式 | 行为 | 场景 |
|------|------|------|
| `enforce` | 阻断越界访问 | 生产环境（默认） |
| `warn` | 告警但允许通过 | 开发调试 |
| `off` | 完全关闭 | 不推荐生产使用 |

---

# 沙箱目录结构（重点）

启动时自动创建**五个标准目录**：

| 目录 | 用途 | 生命周期 |
|------|------|---------|
| `user/` | 用户上传的原始数据 | 持久保留 |
| `output/` | Agent 生成的结果（报告、图表等） | 持久保留 |
| `temp/` | 工作临时文件和缓存 | **24h 自动清理** |
| `database/` | 知识库、公共参考数据 | 持久保留 |
| `logs/` | 运行日志 | 持久保留 |

**技能脚本执行隔离：**
- 每个 Skill 在 `temp/skills/skill-{name}-{uuid}/` 独立目录运行
- cwd 锁定到隔离目录，产出自动收集到 `output/skill-{name}/`
- 残留文件 24h 自动清理 · 开关：`ENABLE_EXEC_ISOLATION=true`

---

# 网络访问控制

**默认阻断范围：**

| 类型 | 阻断范围 |
|------|---------|
| IPv4 私有网段 | 10.0.0.0/8 · 172.16.0.0/12 · 192.168.0.0/16 · 127.0.0.0/8 |
| 云元数据端点 | 169.254.0.0/16（AWS / GCP / Azure IMDS） |
| IPv6 私有/链路本地 | ::1/128 · fc00::/7 · fe80::/10 |
| 主机名 | localhost · *.local |

**配置方式：** `config/network-policy.json`，支持 blocklist 和 allowlist 两种模式，可设域名白名单 `allowedDomains`

---

# DLP 数据泄露防护

自动检测并脱敏**六类敏感信息**：

| 类别 | 检测模式 | 示例 |
|------|---------|------|
| API 密钥 | `sk-...` `pk_...` `rk_...` | 自动隐匿 |
| AWS 密钥 | AKIA 前缀 16 位 | 自动隐匿 |
| JWT / Bearer Token | Base64 三段式 | 自动隐匿 |
| 密码 | `password=xxx` `secret=xxx` | 自动隐匿 |
| 信用卡号 | Luhn 算法验证（13-19位） | 自动隐匿 |
| 内网 IP | IPv4 私有地址段 | 自动隐匿 |

**脱敏格式：** `[REDACTED:category]` · 最大输入 **1MB**（防 DoS）· 工具输出入 LLM 上下文前自动执行

---

# 合规审计体系

**前置审核流程：**
```
用户输入 → 审计 LLM 独立审查 → 审核结果 → Agent 执行（通过）/ 阻断（拒绝）
```

**三级分级管控：**

| 级别 | 行为 | 影响 |
|------|------|------|
| `APPROVED` | 放行 | 正常执行 |
| `APPROVED_WITH_WARNING` | 放行 | 记录告警日志 |
| `REJECTED` | 阻断 | 拒绝执行并记录 |

**覆盖类别：** 内幕交易 · 市场操纵 · 客户隐私 · 系统越权 · 制裁规避

**核心原则：** 审计超时 = 阻断（审计 > 可用性）
**审计日志：** `audit_events` 表 · 只增不改 · 会话删除后仍保留 · OS 用户名自动关联

---

# 什么是 Skill

**定义：** Skill 是封装专业能力的自包含模块，Agent 根据用户意图自动匹配加载

```
skills/my-skill/
├── SKILL.md          # YAML frontmatter + Markdown 工作流
├── scripts/          # Python/JS 脚本（可选）
├── references/       # 参考文档（可选）
└── assets/           # 资源文件（可选）
```

**关键特性：**
- **完全自包含** — 无外部依赖，支持隔离执行
- **LLM 语义匹配** — 自动识别相关 Skill 注入上下文
- **15 分钟缓存** — 避免重复解析，修改后自动热加载
- **线程安全加载** — 并发场景不重复解析，`_loadingPromise` 锁保护

---

# Skill 信任框架

**准入机制 — 三模式：**

| 模式 | 行为 |
|------|------|
| `off` | 关闭验证，所有 Skill 正常加载（默认） |
| `warn` | 未签名 Skill 可加载但输出警告日志 |
| `enforce` | 未签名 / 签名无效 / 已过期 Skill **拒绝加载** |

**两层保护：**

| 层级 | 机制 | 技术方案 |
|------|------|---------|
| 签名认证 | Trust Anchor | RSA-SHA256 签名 · `.skill-trust` 文件 · 公钥指纹验证 |
| 内容加密 | Content Protection | AES-256-GCM · 运行时 `SKILL_MASTER_KEY` 解密 |

**操作命令：**
```bash
node scripts/gen-keys.js                   # 生成密钥对
node scripts/skill-sign.js skills/<name>   # 签名
node scripts/skill-encrypt.js skills/<name> # 加密
```

---

# 插件机制

<div class="cols">
<div>

**内置工具（16 个）**

| 分类 | 工具 |
|------|------|
| 文件 | `read` `write` `list` `glob` `search` |
| 网络 | `web_fetch` `download` `http_request` |
| 系统 | `exec` `time` `system_info` `clipboard` `open` |
| 专用 | `archive` `python_ptc` `skill_view` |

</div>
<div>

**插件工具（5 个，动态加载）**

| 插件 | 功能 |
|------|------|
| `send_email` | SMTP 邮件发送 |
| `calendar` | Outlook/ICS 日历 |
| `chrome_automation` | 浏览器自动化（CDP） |
| `pandoc` | 文档格式转换 |
| `ripgrep` | 高性能搜索 |

</div>
</div>

**加载机制：** 启动时自动扫描 `plugins/tools/` → 检查 `package.json` 依赖 → 注册到工具表
**开关控制：** `DISABLED_TOOLS=exec,python_ptc`（逗号分隔，不区分大小写）

---

# 双模式运行

<div class="cols">
<div>

**单轮模式 `npm start`**
- 一次性任务，无状态
- 无会话持久化
- 适合：脚本化调用、定时任务、批量 CI

</div>
<div>

**多轮模式 `npm run chat`**
- 交互式 REPL，持续对话
- SQLite 持久化所有历史
- 40+ 预设投行专业角色

</div>
</div>

**会话管理命令：**

| 命令 | 功能 | 命令 | 功能 |
|------|------|------|------|
| `/new` | 创建新会话 | `/list` | 列出所有会话 |
| `/switch <id>` | 切换会话 | `/rename <title>` | 重命名 |
| `/clear` | 清空当前会话 | `/whoami` | 查看当前身份 |
| `/exit` | 退出 | | |

---

# 上下文管理机制

Agent 上下文窗口有限，CMBI e-Agent 采用 **U 型截断策略**智能管理对话历史：

```
[ 第1轮: 初始意图 ] → [ 第2-N轮: LLM摘要压缩 ] → [ 最近K轮: 完整保留 ]
      HEAD                       MIDDLE                        TAIL
```

**关键配置：**

| 参数 | 默认 | 作用 |
|------|------|------|
| `KEEP_LAST_EXCHANGES` | 10 | 最近保留的完整对话轮数 |
| `MAX_MESSAGES_SIZE` | 80 KB | 消息总大小上限，超限触发应急截断 |
| `MAX_SINGLE_MESSAGE_SIZE` | 20 KB | 单条工具返回超此值则截断 |
| `USE_LLM_CONTEXT_SUMMARY` | false | 开启 LLM 摘要替代关键词采样（推荐） |

**应急截断：** 总大小超限 → 保留 system + 首轮意图 + 最近轮次 → 中间轮次压缩或丢弃 → 每 5 轮重新评估大小

---

# 上下文感知的会话策略

**一个会话到底 vs 一个任务一个新会话？**

| 策略 | 适合场景 | 注意 |
|------|---------|------|
| 一个会话到底 | 同主题连续分析、逐步深挖 | > 10 轮后早期细节可能已截断 |
| 一个任务新会话 | 独立任务、不同主题、不同用户 | 每次需重新描述背景 |

**决策指南：**
- **同主题延续**（如 Q1→Q2→Q3 财务分析）→ 复用会话，用 `/rename` 标记
- **任务切换**（Excel 分析 → PDF 摘要）→ `/new` 新会话，防止上下文污染
- **任务分支**（同一数据做不同维度分析）→ 关键节点 `/new` 分叉
- **上下文已超 10 轮** → 及时 `/new`，或开启 `USE_LLM_CONTEXT_SUMMARY`

**操作示例：**
```
/rename 2026Q1财报分析    # 命名便于回顾
/list                      # 查看所有会话
/switch 2                  # 切换到之前的会话
```

---

# 提升执行效率与准确率

**原则 1：任务描述越具体，执行越精确**
- ✗ "分析这个 Excel" → ✗ "分析销售数据"
- ✓ "分析 `user/sales.xlsx` Sheet1，计算 Q1 各区域毛利率，输出图表到 `output/`"

**原则 2：提供充足的上下文约束**
- 指定数据范围、输出格式、质量标准
- ✓ "仅分析 2026 年数据，忽略空行，金额保留 2 位小数，使用港币"
- 金融场景：明确会计准则、货币单位、时间区间

**原则 3：先验证再放量**
- 先用小样本确认逻辑（"先处理前 10 行让我确认"）
- 验证通过后再全量执行
- 复杂公式先在对话中确认，再批量应用

**原则 4：善用增量迭代**
- 第 1 轮：描述任务 → Agent 执行；第 2 轮：检查 → 微调
- 每轮确认一个维度，比一次性给复杂指令更可靠

---

# 提升执行效率（续）

**原则 5：理解工具特性，选择最优路径**

| 场景 | 推荐工具 | 原因 |
|------|---------|------|
| 批量 Excel 处理 | `python_ptc` | 中间结果不进上下文，节省 token |
| 单页内容提取 | `web_fetch` | 纯文本提取，快速 |
| 复杂网页交互 | `chrome_automation` | 支持点击、表单、截图 |
| 大文件内容搜索 | `search`（ripgrep） | 比逐行读取快 100 倍 |
| 结构化报告生成 | Skill 脚本 | 隔离执行，产出归档 |

**原则 6：合理控制任务范围**
- **小任务**（≤ 5 步）：一次对话完成 | **中任务**（5-15 步）：分 2-3 轮确认 | **大任务**（> 15 步）：拆为独立子任务

**原则 7：长对话及时"重启"**
- 超过 10-15 轮后，早期细节已被截断 → 及时 `/new`
- 用 `/list` 回顾已完成工作，新会话描述中引用关键结论

---

# 最佳实践

**推荐做法**

- 输入放 `user/` 目录，输出从 `output/` 获取，临时文件自动清理
- 任务描述包含：**输入路径 + 输出要求 + 边界条件** 三要素
- 先用小样本验证逻辑，确认后全量执行
- **开启 `USE_LLM_CONTEXT_SUMMARY=true`** 延长有效上下文
- 合理使用 `/new` 创建新会话，避免上下文膨胀
- 多用户场景使用 `/whoami` 确认当前身份

**避免事项**

- 不访问沙箱外路径（被阻断）
- 不输入真实客户隐私数据（被 DLP 脱敏）
- 不绕过安全机制（触发审计，日志不可删除）
- 不在单轮模式做复杂多步任务（无持久化）
- 不在超长会话中混合多个无关任务（上下文污染）
- 不在 `enforce` 模式下加载未签名 Skill

---

<!-- _class: lead -->

# 总结

CMBI e-Agent — 金融企业级 AI 智能助手

**五层纵深安全** · **文件系统沙箱隔离** · **Skills 信任生态**

**16 内置 + 5 插件** · **智能上下文管理** · **高效会话策略**

项目文档：`CLAUDE.md` / `README.md` · 策略配置：`config/` · 开发规范：`.claude/rules/`
