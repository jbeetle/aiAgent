# 消息文件链接渲染与打开 — 第三方集成指南

## 概述

coqi-claw Agent 在对话中经常生成文件（如报告、图表、HTML 文档），并在消息中引用这些文件的路径。本功能自动将消息中的文件路径渲染为可点击链接，用户点击后通过后端调用系统默认程序打开文件。

**适用场景：**
- 第三方前端需要复用 coqi-claw 后端，且希望消息中的文件路径可交互
- 自定义聊天 UI 集成 `/api/open` 接口

---

## 工作流程

```
Agent 消息中的文件路径
       ↓
前端 Markdown 渲染器识别文件路径
       ↓
渲染为 <a href="#open=编码路径" class="open-link"> 链接
       ↓
用户点击 → 前端解析 href → POST /api/open
       ↓
后端调用 open 工具 → 系统默认程序打开文件
```

---

## 后端 API

### POST /api/open

使用系统默认程序打开指定文件或 URL。

#### 请求

```http
POST /api/open HTTP/1.1
Content-Type: application/json
X-API-Key: your-key        # 仅在启用 API Key 认证时需要

{
  "path": "C:\\clawSandbox\\output\\report.html"
}
```

**path 参数说明：**

| 类型 | 示例 | 处理方式 |
|------|------|---------|
| 绝对路径 | `C:\clawSandbox\output\report.html` | 直接校验沙箱 |
| 相对路径 | `output/skill-xxx/report.pdf` | 解析为沙箱绝对路径 |
| URL | `https://example.com` | 直接调用 `open` 包 |
| `file://` 协议 | `file:///C:/data/file.txt` | 解析后校验沙箱 |

#### 成功响应

```json
{
  "success": true,
  "message": "已打开"
}
```

#### 错误响应

```json
{
  "success": false,
  "error": {
    "code": "not_found",
    "message": "File: C:\\clawSandbox\\output\\report.html not found"
  }
}
```

**HTTP 状态码映射：**

| 状态码 | 场景 |
|--------|------|
| 400 | path 参数缺失或格式无效 |
| 403 | 路径越界（不在沙箱允许范围内） |
| 404 | 文件不存在 |
| 500 | 打开失败（系统无默认程序等） |
| 502 | 网络错误（URL 打开时） |
| 504 | 超时 |

#### 安全机制

`/api/open` 底层复用 `src/tools/open.js`，继承完整的安全校验链：

1. **沙箱路径校验**（`validateWorkspacePath`）：确保路径在允许目录内
2. **文件存在性检查**：拒绝打开不存在的文件
3. **文件类型校验**：确保目标是文件而非目录

---

## 前端渲染约定

### 文件路径识别规则

前端 Markdown 渲染器在以下两种位置识别文件路径：

#### 1. Markdown 链接 `[文本](路径)`

`renderer.link` 对 href 做如下判断：

- `http://` / `https://` / `ftp://` → 普通外链，浏览器新标签页打开
- `file://` / 以 `/` 开头 / Windows 盘符路径 → 文件路径，渲染为 `open-link`
- 其他（mailto、锚点等）→ 普通外链

#### 2. 内联代码 `` `路径` ``

`renderer.codespan` 对代码内容做如下判断（满足任一即视为文件路径）：

| 规则 | 示例 |
|------|------|
| `file://` 协议开头 | `file:///C:/data/file.txt` |
| 包含 `/` 或 `\` 且以文件扩展名结尾 | `C:\output\report.html`、`/user/data.csv` |
| 以标准沙箱子目录开头 | `output/skill-xxx/report.pdf`、`temp/cache.json` |

标准沙箱子目录：`output/`、`user/`、`temp/`、`database/`、`logs/`

### 渲染输出格式

文件路径被渲染为以下 HTML 结构：

```html
<!-- 来自 Markdown 链接 -->
<a href="#open=%E7%BC%96%E7%A0%81%E8%B7%AF%E5%BE%84" class="open-link" title="点击打开">
  文件描述文本
</a>

<!-- 来自内联代码 -->
<a href="#open=%E7%BC%96%E7%A0%81%E8%B7%AF%E5%BE%84" class="open-link" title="点击打开">
  <code>C:\output\report.html</code>
</a>
```

**关键点：**
- 路径使用 `encodeURIComponent` 编码后存储在 `href="#open=..."` 中
- `class="open-link"` 用于前端事件委托识别
- `e.preventDefault()` 阻止浏览器默认跳转行为

---

## 第三方集成指南

### 场景一：复用 coqi-claw 后端 + 自研前端

如果你的前端自行渲染 Markdown，只需在渲染器和点击事件中加入文件路径支持：

#### 步骤 1：Markdown 渲染器改造

以 `marked` 为例，注册自定义 renderer：

```javascript
function isFilePath(text) {
  if (!text || typeof text !== 'string') return false;
  if (/^file:\/\//i.test(text)) return true;
  if (/\.\w{2,6}$/.test(text) && /[\/\\]/.test(text)) return true;
  if (/^(?:output|user|temp|database|logs)[\/\\]/.test(text)) return true;
  return false;
}

function escapeHtml(text) {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

marked.use({
  renderer: {
    codespan({ text }) {
      if (isFilePath(text)) {
        return '<a href="#open=' + encodeURIComponent(text)
          + '" class="open-link" title="点击打开"><code>'
          + escapeHtml(text) + '</code></a>';
      }
      return '<code>' + escapeHtml(text) + '</code>';
    },
    link({ href, text }) {
      if (/^https?:\/\//i.test(href) || /^ftp:\/\//i.test(href)) {
        return '<a href="' + href + '" target="_blank" rel="noopener noreferrer">'
          + text + '</a>';
      }
      if (/^file:\/\//i.test(href) || /^\//.test(href) || /^[a-zA-Z]:[\\\/]/.test(href)) {
        return '<a href="#open=' + encodeURIComponent(href)
          + '" class="open-link" title="点击打开">' + text + '</a>';
      }
      return '<a href="' + href + '" target="_blank" rel="noopener noreferrer">'
        + text + '</a>';
    }
  }
});
```

> **注意：** 如果你的渲染器使用 DOMPurify 等 HTML 过滤器，需确保 `href` 和 `class` 属性在白名单中。

#### 步骤 2：点击事件拦截

在消息容器上使用事件委托：

```javascript
const openingRef = { current: false };

function handleMessageClick(e) {
  const link = e.target.closest('.open-link');
  if (!link) return;

  e.preventDefault();
  if (openingRef.current) return;

  const href = link.getAttribute('href');
  const match = href.match(/^#open=(.+)$/);
  if (!match) return;

  const path = decodeURIComponent(match[1]);
  openingRef.current = true;

  fetch('/api/open', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ path })
  })
    .then(async res => {
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error?.message || `HTTP ${res.status}`);
      }
    })
    .catch(err => {
      alert(`打开失败: ${err.message}`);
    })
    .finally(() => {
      setTimeout(() => { openingRef.current = false; }, 2000);
    });
}

// 绑定到消息列表容器
document.querySelector('.message-list').addEventListener('click', handleMessageClick);
```

#### 步骤 3：样式建议

建议为 `.open-link` 添加视觉区分，让用户知道这是可点击的文件链接：

```css
.open-link {
  text-decoration: underline;
  cursor: pointer;
}
.open-link:hover {
  opacity: 0.8;
}
```

### 场景二：仅调用 /api/open 接口

如果不需要渲染 Markdown，只想提供文件打开能力：

```javascript
async function openFile(path) {
  const res = await fetch('/api/open', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ path })
  });

  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error?.message || '打开失败');
  }

  return await res.json(); // { success: true, message: "已打开" }
}

// 使用
openFile('output/report.html').catch(e => console.error(e));
```

---

## 安全注意事项

1. **沙箱边界**：`/api/open` 只能打开沙箱允许目录内的文件（由后端 `path-sandbox.js` 控制），第三方前端无需额外做路径校验，但应在 UI 上明确告知用户打开的是服务器本地文件。

2. **可执行文件**：后端当前不限制文件扩展名。如果 Agent 生成了可执行文件（`.exe`、`.bat`、`.sh`），用户点击后会在服务器上执行。如需限制，可在 `src/gateway/routes/open.js` 中添加扩展名黑名单。

3. **并发防护**：建议前端添加防抖（如 2 秒内禁止重复点击），避免用户快速多次点击导致弹出多个窗口。

---

## 相关文件

| 文件 | 说明 |
|------|------|
| `src/gateway/routes/open.js` | 后端 `/api/open` 路由实现 |
| `src/tools/open.js` | `open` 工具，含沙箱校验逻辑 |
| `src/security/path-sandbox.js` | 沙箱路径校验 |
| `web/src/lib/markdown.js` | 前端 Markdown 渲染器（文件路径识别） |
| `web/src/components/MessageBubble.jsx` | 消息气泡组件（点击事件拦截） |
| `web/src/api/rest.js` | 前端 API 客户端 |
