# Tauri 桌面应用封装方案（方案 A）

> 目标：把现有 Web + Gateway 封装成单一桌面应用，替换当前 PowerShell 托盘 + VBScript 启动方案。
> 方案选型见对话记录；本文档为**方案 A（Tauri 壳 + Sidecar Gateway）**的正式设计与实施依据。

## 1. 方案概述

用 **Tauri** 做一个"带系统托盘 + 内嵌 WebView 的壳"，通过 **sidecar 守护现有 Gateway 进程**，WebView 直接加载 `http://127.0.0.1:214`。

```
Tauri App (Rust, ~5MB)
├─ 启动：spawn sidecar = node src/gateway/server.js（cwd = 项目根）
├─ 探测：轮询 http://127.0.0.1:214/api/health 直到就绪
├─ 就绪：WebView 加载 http://127.0.0.1:214  ← 前端、API 同源，零改动
├─ 系统托盘（Tauri tray API）替代 scripts/tray.ps1
├─ 开机自启（tauri-plugin-autostart）替代 start-tray.vbs
└─ 退出：杀掉 sidecar 子进程
```

**核心收益**：前端与 Gateway **零改动**即可获得单一桌面窗口、安装包、稳定托盘。这能成立，是因为当前设计正好踩在 Tauri 友好的形态上。

## 2. 现状有利条件

| 现状（已验证） | 对 Tauri 的意义 |
|---|---|
| Gateway 默认绑 `127.0.0.1:214`（`src/gateway/server.js:28-29`） | 本地回环，WebView 可直连，无外网暴露 |
| Gateway 同源 serve 前端：`express.static(web/dist)` + SPA fallback（`src/gateway/server.js:122-127`） | 前端与 API 同 origin，**无 CORS** |
| 前端 API 基址 `API_BASE = ""`，全相对路径 fetch `/api/...`（`web/src/api/rest.ts:1`） | WebView 加载 `http://127.0.0.1:214` 后，相对路径天然命中 Gateway，**前端无需改 URL** |
| 已有健康端点 `/api/health`（`src/gateway/routes/health.js` → `router.js:162` → `server.js:112`） | Tauri 启动探测有语义化 URL，返回 `{status:"ok"}` |
| 已有配置初始化 `/api/config/initialize`、`/api/config`（`web/src/stores/config-store.ts`） | 首次启动可在 UI 内配置 LLM key，不用手写 `.env` |
| 已有 `build:sea` 产出 `coqi-claw.exe` + 子命令分发 `web`（`scripts/build-sea.js`） | sidecar 现成的可执行入口（`coqi-claw.exe web`） |

## 3. 工程结构

```
desktop/
├── package.json              # devDep: @tauri-apps/cli，脚本 tauri
├── src-tauri/
│   ├── Cargo.toml            # tauri 2 依赖（init 生成后微调）
│   ├── build.rs
│   ├── tauri.conf.json       # window url 指向 127.0.0.1:214、security、图标
│   ├── icons/                # 复用 scripts/256.ico（或 init 默认）
│   └── src/main.rs           # sidecar spawn + 端口探测 + 托盘 + 退出清理
```

## 4. Rust 生命周期逻辑

> **实现注记（PoC 已落地）**：实际代码见 `desktop/src-tauri/src/lib.rs`。Tauri 2 的 `WebviewWindow` **没有运行时 `load_url`**（URL 在窗口创建时指定），故下方伪代码第 3 步实际改用：
> ```rust
> let url = url::Url::parse("http://127.0.0.1:214")?;
> tauri::WebviewWindowBuilder::new(app, "main", tauri::WebviewUrl::External(url))
>     .title("CoQiClaw").inner_size(1280.0, 800.0).build()?;
> ```
> 即「探测就绪后再创建窗口」，对应 `tauri.conf.json` 的 `windows` 改为不预声明（`[]`），避免窗口在 setup 之前按 devUrl 加载而 Gateway 未起导致失败页。

```rust
// 关键流程（伪代码，PoC 实现见 desktop/src-tauri/src/lib.rs）
fn main() {
    tauri::Builder::default()
        .setup(|app| {
            // 1. spawn node gateway（cwd = 项目根 = CARGO_MANIFEST_DIR/../..）
            let child = Command::new("node")
                .arg("src/gateway/server.js")
                .current_dir(project_root())
                .spawn()?;
            app.manage(GatewayChild(Mutex::new(Some(child))));

            // 2. 探测端口就绪（TCP connect，超时 30s）
            wait_for_port("127.0.0.1:214", Duration::from_secs(30))?;

            // 3. 加载并显示窗口（初始 visible:false）
            let win = app.get_webview_window("main").unwrap();
            win.load_url("http://127.0.0.1:214")?;
            win.show()?;
            Ok(())
        })
        .on_window_event(|window, event| {
            // 4. 窗口关闭 → 杀 sidecar
            if let tauri::WindowEvent::CloseRequested { .. } = event {
                if let Some(state) = window.try_state::<GatewayChild>() {
                    if let Some(mut c) = state.0.lock().unwrap().take() {
                        let _ = c.kill();
                    }
                }
            }
        })
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
```

要点：
- **初始 `visible: false`**：避免 Gateway 未就绪时 WebView 先显示"无法连接"。探测成功后再 `load_url` + `show`。
- **探测用 TCP 连通性**（`TcpStream::connect`）：Express 在 `listen` 前已注册全部路由，端口可连 ≈ 可服务；比纯 HTTP 探测少一个依赖。PoC 保留 `/api/health` 作为更严谨的可选项。
- **子进程归属**：child handle 存入 Tauri state（`Mutex<Option<Child>>`），窗口关闭/应用退出时取回并 `kill`，避免 node 进程残留。
- **子进程 stdout/stderr**：PoC 阶段 `inherit` 到终端便于排错；正式版改为收集到日志或静默。

## 5. tauri.conf.json 关键配置

```jsonc
{
  "productName": "CoQiClaw",
  "version": "2.0.1",
  "identifier": "com.coqiclaw.desktop",
  "build": {
    // 不让 Tauri 管前端 dev server——Gateway 已同源 serve 前端
    "frontendDist": "../../web/dist",   // 相对 src-tauri/，= 项目根 web/dist（打包占位）
    "devUrl": "http://127.0.0.1:214"
  },
  "app": {
    "windows": [{
      "title": "CoQiClaw",
      "url": "http://127.0.0.1:214",  // 加载外部 URL
      "visible": false,                 // 探测就绪后再 show
      "width": 1280, "height": 800,
      "resizable": true
    }],
    "security": {
      "csp": null                      // 加载远程同源页面，关闭 CSP 注入
    }
  },
  "bundle": {
    "active": true,
    "targets": ["msi", "nsis"],        // Windows 安装包
    "icon": ["icons/icon.ico"]
  }
}
```

## 6. Sidecar 的两种形态

| 形态 | 用途 | 说明 |
|---|---|---|
| **裸 node**（`node src/gateway/server.js`） | PoC | 最快验证链路；要求用户机器装 Node 22+。PoC 采用此形态 |
| **SEA exe**（`coqi-claw.exe web`） | 正式分发 | 免 Node 环境；但需走 Tauri `externalBinary`/sidecar 机制（二进制按平台后缀命名如 `coqi-claw-x86_64-pc-windows-msvc.exe`）。PoC 之后迁移 |

> PoC 先用裸 node 跑通"壳 + WebView 加载本地 Gateway"链路，再迁移到 SEA sidecar。

## 7. 关键技术点与风险

1. **⚠️ SEA 包当前不含前端**（最重要的现状缺口）
   `scripts/build-sea.js:119` 复制了 `skills/src/node_modules/config/plugins/...`，但**没有复制 `web/dist`**。SEA 包跑 `web` 模式时 Gateway 的静态 fallback（`server.js:123`）会 404 → 空白页。
   → 修法：`build-sea.js` 增加 `cpSync(web/dist, dist/web/dist)`，并在 `build:sea` 前置 `build:web`。Tauri 工程的 `beforeBuildCommand` 也可统一编排。

2. **WebView2 依赖**：Win11 自带，Win10 大多预装。Tauri 安装包可内嵌 WebView2 bootstrapper，首次自动安装。

3. **原生模块**：`better-sqlite3-multiple-ciphers`、`sharp`、`playwright` 均为 `.node` 原生二进制。SEA 包已通过拷贝完整 `node_modules` 闭包（`build-sea.js:143-186`）解决。当前仅 **Windows x64** 单目标，跨架构需额外处理。

4. **打包体积**：这套"Node 后端 + WebView 壳"架构的本质代价，预计 ~80–150MB（Tauri 壳 ~5MB + Node 运行时 ~50MB + node_modules 含 sharp/playwright）。仍远小于 Electron。若体积敏感，可裁 `playwright`（带浏览器二进制）。

5. **构建链复杂度**：引入 Rust 工具链 + Tauri CLI，CI 变长。团队需具备 Rust 基础维护能力（门槛高于现有 PS/JS）。

6. **配置与密钥**：SEA 包带 `.env.example`，真实运行需 `.env`。好在已有 `/api/config/initialize`，可在首次启动走 UI 配置，避免随包硬编码密钥。

## 8. 改动清单

| 项 | 工作量 | 范围 |
|---|---|---|
| 新建 `desktop/` Tauri 工程（Rust + 配置） | 中 | 2 个 Rust 文件 + `tauri.conf.json`；需 Rust 工具链 |
| sidecar 生命周期 + 端口探测 | 小 | ~80 行 Rust |
| 托盘 / 自启 | 小 | Tauri 插件，替代 254 行 `tray.ps1` |
| 修 `build-sea.js`：纳入 `web/dist` | 小 | 一行 `cpSync` + 前置 `build:web` |
| 前端、Gateway 代码 | **0** | 同源设计使其无需改动 |

## 9. PoC 范围与验收

**范围**：验证"壳 + sidecar + WebView 加载本地 Gateway"主链路通不通。

**验收标准**：
- [ ] `cd desktop && npx tauri dev` 启动后自动拉起 `node src/gateway/server.js`
- [ ] Tauri 窗口出现并加载 CoQiClaw Web UI（非空白/非"无法连接"）
- [ ] 聊天流（REST + WebSocket）正常
- [ ] `/api/config` 初始化流程可用
- [ ] 关闭窗口 → node 进程被 kill（任务管理器无残留 `node.exe`）
- [x] `cargo check` 通过（已验证：2.17s 增量编译通过，`tauri info` 环境健康）

**PoC 不含**：SEA sidecar 打包、安装包生成、开机自启、正式图标设计、CI。

## 10. 后续路线

- [x] **迁移到 SEA sidecar**（`coqi-claw.exe web`）+ `web/dist` 入包 —— ✅ 已完成（2026-07-25）：`build-sea.js` 纳入 `web/dist`，`tauri.conf.json` 加 `bundle.resources`，`lib.rs` 改 `spawn_gateway` spawn SEA exe；安装器免 Node 可分发（教程：`docs/desktop-tauri-build-guide.md`）
- [ ] 加系统托盘菜单（Open / Restart / Exit，对齐 `tray.ps1` 行为）
- [ ] 加 `tauri-plugin-autostart` 替代 `start-tray.vbs`
- [ ] 开箱即用 LLM 配置：Gateway 无 `.env` 也能启动 + UI 引导（避免首启探测超时）
- [ ] release 打包 + 安装包签名（当前验证用 `tauri build --debug`）
- [ ] CI：Windows 构建 pipeline
- [ ] 评估裁剪 `playwright` 以压缩体积
