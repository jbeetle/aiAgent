# 配置加载流程

本文档梳理 coqi-claw 从启动到运行时的完整配置加载流程，涵盖环境变量来源、优先级、缓存机制、以及 `.env.runtime` 覆盖层的工作原理。

## 1. 配置来源与优先级

从高到低：

| 优先级 | 来源 | 说明 | 持久化 |
|--------|------|------|--------|
| 1 | CLI `--set-KEY=VALUE` | 命令行覆盖（guarded 场景下安全键被忽略） | ❌ 仅运行时 |
| 2 | `.env.runtime` | Web UI 写入的覆盖层（guarded 场景下安全键被过滤） | ✅ 文件持久化 |
| 3 | `.env` | 主配置文件（guarded 场景下受 RSA 签名保护） | ✅ 文件持久化 |
| 4 | 场景预设 `SCENE_PRESETS` | `applyScenePreset()` 仅填充未定义的键 | ❌ 代码内置 |
| 5 | `config/env-config-schema.json` | JSON Schema 中的 `default` 字段 | ✅ 文件持久化 |

> **关键规则**：`.env.runtime` 使用 `dotenv.config({ override: true })` 加载，会覆盖 `.env` 中的同名变量。但在 guarded 场景（enterprise/financial）下，安全键（`SECURITY_KEYS` + `DB_ENCRYPTION_KEY` + `COQI_SCENE`）会被恢复为 `.env` 中的原始值，防止通过 `.env.runtime` 绕过签名保护。

## 2. 两个配置文件的角色

### `.env` — 主配置（不可变基准）

- 所有必需环境变量的唯一真实来源
- guarded 场景下受 RSA-SHA256 签名保护（`EnvGuard.verify()`）
- 支持加密值：`{base64密文}` 格式，启动时由 `decryptEnvConfig()` 解密
- 非 guarded 场景下，Web UI 的配置变更直接写入此文件

### `.env.runtime` — 运行时覆盖层

- 仅在文件存在时加载，不存在则跳过
- guarded 场景下，Web UI 的配置变更写入此文件（不污染受签名保护的 `.env`）
- 安全键在加载后被恢复为 `.env` 的原始值
- 重启后仍然生效（文件持久化），但设计意图是运行时覆盖

## 3. 启动时序详解

### 3.1 ESM import 阶段（BootstrapManager 之前）

Node.js ESM 的静态 `import` 在模块加载阶段执行。以下模块有**模块级副作用**，会在 `BootstrapManager.loadEnvironment()` 之前运行：

```
入口文件 (server.js / cli.js / tui/index.js)
  │
  ├─ import BootstrapManager ──────────────────────────────────────┐
  │   ├─ import logger.js                                         │
  │   │   └─ pino({ level: getLevel() })  ← 模块级，仅读 LOG_LEVEL │
  │   ├─ import config.js → config/index.js → config/env.js       │
  │   │   └─ dotenv.config({ path: '.env', override: true })       │
  │   │      ← 模块级副作用：.env 已加载到 process.env             │
  │   └─ import fast-json.js                                      │
  │       └─ ensureInitialized() → loadConfig()                    │
  │          ← 模块级副作用：loadConfig() 缓存被设置（.env 的值）   │
  │                                                                │
  └─ import SessionManager ── import DatabaseManager ── loadConfig │
                                                                    │
  此时 process.env 中只有 .env 的值，.env.runtime 尚未加载        ┘
```

**关键问题**：`fast-json.js` 等模块在 import 阶段调用了 `loadConfig()`，导致缓存了 `.env` 的值。`logger.js` 的 `getLevel()` 在 `configReady = false` 时仅读 `process.env.LOG_LEVEL`，不触发 `loadConfig()`（v2.0.2 修复）。

### 3.2 Phase 1: `loadEnvironment()` — 环境变量加载

```
loadEnvironment()
  │
  ├─ ① dotenv.config({ path: '.env', override: true })
  │     加载主配置文件到 process.env
  │
  ├─ ② parseCliArgs()
  │     解析 --scene, --set-KEY=VALUE, --env, --skip-env-guard
  │
  ├─ ③ 场景检测与签名验证
  │     ├─ isGuarded = (COQI_SCENE === 'enterprise' || 'financial')
  │     ├─ guarded: EnvGuard.verify() 验证 .env RSA 签名
  │     └─ guarded: 过滤 CLI 对安全键的覆盖
  │
  ├─ ④ applyScenePreset(scene, cliOverrides)
  │     仅设置 process.env 中尚未定义的键（不覆盖已有值）
  │
  ├─ ⑤ decryptEnvConfig()
  │     扫描 process.env 中的 {base64} 格式值，RSA-OAEP 解密替换
  │
  └─ ⑥ 加载 .env.runtime overlay
        ├─ 文件不存在则跳过
        ├─ guarded 模式:
        │   ├─ 保存安全键原始值
        │   ├─ dotenv.config({ path: '.env.runtime', override: true })
        │   └─ 恢复安全键原始值（防绕过签名保护）
        └─ 非 guarded 模式:
            └─ dotenv.config({ path: '.env.runtime', override: true })
```

### 3.3 Phase 2: `initializeSystem()` — 系统级初始化

```
initializeSystem()
  ├─ initWindowsEncoding()      — Windows UTF-8 编码设置
  ├─ ensureSandboxLayout()      — 创建 sandbox 目录结构
  └─ initializeTools()          — 注册内置工具 + 加载插件
```

此阶段不修改 `process.env`，不调用 `loadConfig()`。

### 3.4 Phase 3: `loadConfiguration()` — 配置对象构建

```
loadConfiguration()
  │
  ├─ clearConfigCache()          ← 清除 Phase 0 过早设置的缓存
  │   └─ cachedConfig = null
  │   └─ clearJsonDefaultsCache()
  │
  ├─ loadConfig()
  │   ├─ decryptEnvConfig()       — 再次扫描（确保 .env.runtime 中的加密值也被解密）
  │   ├─ 读取核心配置: LLM_PROVIDER, LLM_API_KEY, LLM_BASE_URL, LLM_MODEL
  │   ├─ 遍历 CONFIG_SCHEMA 读取其余配置项
  │   │   └─ 值来源: process.env[envName] > jsonDefaults[envName]
  │   ├─ 类型转换 (transform) + 校验 (validate)
  │   └─ 缓存到 cachedConfig
  │
  └─ markConfigReady()
      └─ 通知 logger.js 可以使用 loadConfig().logLevel
      └─ 更新 pino 日志级别
```

**为什么需要 `clearConfigCache()`**：`fast-json.js` 等模块在 ESM import 阶段调用了 `loadConfig()`，此时 `.env.runtime` 尚未加载，缓存的是 `.env` 的过期值。Phase 1 完成后 `.env.runtime` 已生效到 `process.env`，Phase 3 清除缓存后重新读取，即可获得正确的覆盖值。

### 3.5 Phase 4: `initializeAgent()` — LLM 客户端创建

```
initializeAgent()
  │
  ├─ SkillManager 加载技能
  ├─ new LLMClient({ config, label: 'primary' })      ← 使用 loadConfig() 的返回值
  ├─ loadMatcherConfig() → new LLMClient({ label: 'matcher' })
  │   └─ 读 MATCHER_LLM_* 环境变量，未配置则复用 primary config
  ├─ SkillSummarizer 生成技能摘要
  ├─ new Agent(skillManager, primaryClient, { matcherLLMClient, config })
  ├─ loadAuditConfig(primaryConfig) → new LLMClient({ label: 'audit' })
  │   └─ Fallback: AUDIT_LLM_* → MATCHER_LLM_* → primary config
  └─ loadBackgroundConfig() → new LLMClient({ label: 'background' })
      └─ 无 fallback，未配置则跳过
```

## 4. 各入口点的初始化顺序

### CLI (`src/cli.js`)

```
loadEnvironment() → initializeSystem() → loadConfiguration() → initializeAgent()
```

最简洁的流程，没有中间组件需要 `loadConfig()`。

### TUI (`src/tui/index.js`)

```
loadEnvironment() → initializeSystem() → loadConfiguration()
  → SessionManager.initialize() → showDisclaimer() → setupProfile()
  → initializeAgent({ sessionManager })
```

`loadConfiguration()` 在 `SessionManager.initialize()` 之前执行，确保 `SessionManager` 内部的 `loadConfig()` 调用获得正确的覆盖值。

### Web (`src/gateway/server.js`)

```
loadEnvironment() → initializeSystem() → loadConfiguration()
  → SessionManager.initialize()
  → initializeAgent({ sessionManager })
  → ConfigService 初始化
```

与 TUI 相同的顺序保证。

## 5. `loadConfig()` 缓存机制

```javascript
let cachedConfig = null;
let loading = false;

export function loadConfig() {
  if (cachedConfig || loading) return cachedConfig;
  loading = true;
  // ... 从 process.env 读取并构建 config ...
  return (cachedConfig = config);
}

export function clearConfigCache() {
  cachedConfig = null;
  loading = false;
  clearJsonDefaultsCache();
}
```

- **首次调用**：从 `process.env` 读取所有配置，构建 config 对象，缓存后返回
- **后续调用**：直接返回 `cachedConfig`（零开销）
- **清除缓存**：`clearConfigCache()` 将 `cachedConfig` 置为 null，下次调用重新构建

调用 `clearConfigCache()` 的场景：
1. `BootstrapManager.loadConfiguration()` — 清除过早缓存，确保 `.env.runtime` 生效
2. `ConfigService._persistAndHotReload()` — Web UI 保存配置后重新加载
3. `PATCH /api/config/reload` — 强制从磁盘重新加载
4. 测试代码

## 6. 模块级副作用清单

以下模块在 ESM import 阶段就会执行有副作用的代码：

| 模块 | 副作用 | 影响 | 缓解措施 |
|------|--------|------|----------|
| `src/utils/config/env.js` | `dotenv.config({ path: '.env', override: true })` | 将 `.env` 加载到 `process.env` | BootstrapManager 再次加载确保一致 |
| `src/utils/fast-json.js` | `ensureInitialized()` → `loadConfig()` | 缓存 `.env` 的过期配置值 | `loadConfiguration()` 中 `clearConfigCache()` |
| `src/utils/logger.js` | `pino({ level: getLevel() })` | 仅读 `process.env.LOG_LEVEL` | `configReady` 机制避免过早调用 `loadConfig()` |

## 7. LLM 配置的 Fallback 链

### 主模型（Primary）

```
LLM_PROVIDER, LLM_API_KEY, LLM_BASE_URL, LLM_MODEL
  ← 全部从 process.env 读取
  ← 可被 .env.runtime 覆盖
```

### Matcher（技能匹配）

```
MATCHER_LLM_PROVIDER / MATCHER_LLM_API_KEY / MATCHER_LLM_BASE_URL / MATCHER_LLM_MODEL
  ← 未配置则复用 primary config
  ← 独立参数: MATCHER_LLM_REQUEST_TIMEOUT (60s), MATCHER_LLM_TEMPERATURE (0.6) 等
```

### Audit（合规审计）

```
AUDIT_LLM_* → MATCHER_LLM_* → primary config
  ← 三级 fallback
  ← 独立参数: AUDIT_LLM_REQUEST_TIMEOUT (120s, 超时=阻断), AUDIT_LLM_TEMPERATURE (0)
```

### Background（后台画像提取）

```
BACKGROUND_LLM_*
  ← 无 fallback，未配置则跳过
  ← 独立参数: BACKGROUND_LLM_TEMPERATURE (0.1)
```

### Tool（技能脚本）

```
TOOL_LLM_API_KEY, TOOL_LLM_BASE_URL, TOOL_LLM_MODEL
  ← 独立配置，供 Python/JS 技能脚本调用
  ← 默认: 阿里云 DashScope + qwen3.5-35b-a3b
```

## 8. 运行时配置变更（Web UI）

```
前端 PATCH /api/config { changes: { LLM_ENABLE_THINKING: "false" } }
  │
  ├─ ConfigService.applyChanges()
  │   ├─ 校验: webEditable 策略 + guarded 安全键限制
  │   ├─ 类型转换: convertValue() (复用 CONFIG_SCHEMA.transform)
  │   ├─ 加密: schema.encrypted === true 时 RSA 公钥加密
  │   ├─ 更新: process.env[key] = value
  │   └─ 持久化: writeEnvChanges(targetFile)
  │       ├─ guarded → .env.runtime
  │       └─ 非 guarded → .env
  │
  └─ _persistAndHotReload()
      ├─ clearConfigCache()
      ├─ loadConfig() — 重新构建 config
      ├─ agent.setRuntimeConfig(newConfig) — 热更新非连接参数
      ├─ primaryClient.setRuntimeConfig(newConfig)
      │   ├─ 非连接参数: model, temperature, thinking 等 → 立即生效
      │   └─ 连接参数: baseURL, apiKey, provider → 标记 pendingRestart
      ├─ matcherClient.setRuntimeConfig(newConfig)
      └─ 尝试启动未初始化的模块
```

**需要重启的参数**（`restartRequired`）：
- 连接池: `LLM_HTTP_MAX_SOCKETS`, `LLM_KEEP_ALIVE_TIMEOUT`
- 凭证: `LLM_PROVIDER`, `LLM_BASE_URL`, `LLM_API_KEY`, `MATCHER_LLM_*`, `AUDIT_LLM_*`
- 启动期一次性: `COQI_SCENE`, `DB_ENCRYPTION_KEY`, `SANDBOX_PATHS`, `WEB_PORT`, 安全策略

## 9. 加密值处理

### 格式

```
{标准Base64密文}
```

示例: `LLM_API_KEY={eJw8TtGKG0cQ/JehL3nI/...}`

### 加密流程

```
明文 → RSA-OAEP 公钥加密 → Base64 编码 → 添加花括号 → 写入 .env / .env.runtime
```

- 公钥: `config/public-config.pem`
- 私钥: `src/utils/secure-key.js`（混淆存储，运行时还原）

### 解密流程

```
decryptEnvConfig() 扫描 process.env:
  ├─ 匹配 /^\{[A-Za-z0-9+/=]+\}$/
  ├─ 去花括号 → Base64 解码 → RSA-OAEP 私钥解密
  └─ process.env[key] = 明文
```

调用时机：
1. `BootstrapManager.loadEnvironment()` 第 ⑤ 步（`.env.runtime` 加载之前）
2. `loadConfig()` 函数体内（延迟解密，确保 `.env.runtime` 中的加密值也被处理）

## 10. 相关文件

| 文件 | 职责 |
|------|------|
| `src/bootstrap/manager.js` | 4 阶段初始化编排，`.env.runtime` 加载 |
| `src/bootstrap/scene-config.js` | 场景预设 + `applyScenePreset()` |
| `src/bootstrap/env-guard.js` | `.env` RSA 签名验证（guarded 场景） |
| `src/utils/config/env.js` | 模块级 `dotenv.config()` 副作用 |
| `src/utils/config/index.js` | `loadConfig()` / `clearConfigCache()` |
| `src/utils/config/schema.js` | `CONFIG_SCHEMA`（类型转换 + 校验） |
| `src/utils/config/json-defaults.js` | 从 `env-config-schema.json` 加载默认值 |
| `src/utils/config/llm-profiles.js` | Matcher/Audit/Background LLM 配置加载 |
| `src/utils/config/env-writer.js` | `.env` / `.env.runtime` 原子写入 |
| `src/utils/config-decrypt.js` | RSA-OAEP 加解密 |
| `src/utils/secure-key.js` | RSA 私钥（混淆存储） |
| `src/utils/logger.js` | `markConfigReady()` + `getLevel()` 延迟配置读取 |
| `src/services/config-service.js` | Web UI 配置变更编排 |
| `config/env-config-schema.json` | 默认值、分组、加密标记、说明 |
| `.env` | 主配置文件 |
| `.env.runtime` | 运行时覆盖层 |

## 11. 已知技术债

| 编号 | 问题 | 状态 | 优先级 |
|------|------|------|--------|
| T1 | `dotenv.config({ override: true })` 覆盖容器注入的环境变量，违背 12-Factor | 已知风险 | P3 |
| T2 | `fast-json.js` 模块级副作用调用 `loadConfig()` 导致过早缓存 | 已缓解（`clearConfigCache()`） | P2 |
| T3 | `.env.runtime` 中加密值（`{base64}`）不会被 `decryptEnvConfig()` 解密 | 设计限制 | P3 |

> T1 详见 `docs/config-tech-debt.md`。
