---
marp: true
size: 16:9
paginate: false
style: |
  section {
    background: white;
    color: #0a2540;
    font-family: "Segoe UI", "Noto Sans SC", system-ui, sans-serif;
    font-size: 11px;
    padding: 24px 48px 20px;
  }
  h1 { font-size: 28px; margin: 0 0 2px; font-weight: 800; letter-spacing: -0.02em; }
  h2 { font-size: 13px; color: #425466; font-weight: 500; margin: 0 0 10px; }
  h3 { font-size: 13px; color: #0a2540; margin: 0 0 1px; font-weight: 700; }
  p { margin: 0; line-height: 1.35; color: #425466; font-size: 10px; }
  table { font-size: 10px; border-collapse: collapse; width: 100%; }
  th { background: #f0f3f7; color: #8898aa; padding: 4px 8px; text-align: left; font-weight: 600; font-size: 9px; text-transform: uppercase; letter-spacing: 0.06em; }
  td { padding: 3px 8px; border-bottom: 1px solid #e0e4ea; font-size: 10px; color: #425466; line-height: 1.3; }
  td:first-child { font-weight: 600; color: #0a2540; }
  tr:last-child td { border-bottom: none; }
  .us { color: #0a2540; font-weight: 500; }
  .badge { display: inline-block; background: #0a2540; color: white; padding: 1px 5px; border-radius: 8px; font-size: 8px; font-weight: 600; margin-left: 3px; }
  .tagline { text-align: center; font-size: 14px; font-weight: 700; margin-top: 8px; border-top: 1.5px solid #1d4ed8; padding-top: 6px; }
  .tagline span { background: linear-gradient(135deg, #0a2540, #1d4ed8); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
  .card-box { display: flex; gap: 10px; margin-bottom: 8px; }
  .card-box > div { flex: 1; background: #f5f7fa; border-radius: 6px; padding: 9px 10px; }
  .cols { display: flex; gap: 10px; margin-bottom: 6px; }
  .cols > div { flex: 1; }
  .ci { color: #0e9f6e; font-weight: 700; }
  .caps-label { font-size: 9px; font-weight: 600; color: #8898aa; letter-spacing: .08em; text-transform: uppercase; margin-bottom: 3px; }
---

# CMBI e-Agent
## 你的每位员工，都有一个 AI 副驾驶 · 企业级 AI 智能助手平台

<div class="card-box">
<div>

### 👥 40+ 投行岗位 · 专属 AI 角色
从 IPO 保荐人到风控合规官，每个岗位都有匹配的 AI 人格与专业领域知识

</div>
<div>

### 🛡️ 5 层纵深防御 · 金融级安全
命令阻断 · 路径沙箱 · 网络策略 · DLP 脱敏 · 合规审计，全链路防护

</div>
<div>

### 🧩 Skills 扩展 · 经验资产化
部门工作流沉淀为可复用 Skills，加密签名形成企业专属知识库，经验不随人走

</div>
<div>

### 💻 3 端无缝覆盖 · 任意终端
命令行 · 桌面应用 · Web 端，同一账户无感切换

</div>
</div>

<div class="cols">
<div>

<div class="caps-label">已就绪的核心能力</div>

<span class="ci">✓</span> **自研 LLM 客户端** — 零第三方 SDK，数据不出环境
<span class="ci">✓</span> **合规审计体系** — 内幕交易 / AML / 跨境数据 · 前置审查
<span class="ci">✓</span> **技能加密签名** — RSA + AES-256-GCM，知识资产保护
<span class="ci">✓</span> **Skills 扩展机制** — 部门工作流 → 可复用技能包 → 企业知识库
<span class="ci">✓</span> **场景化部署** — 个人 / 企业 / 金融 · 一键切换安全等级
<span class="ci">✓</span> **多模型接入** — DeepSeek / OpenAI / 多种国产模型

</div>
<div>

<div class="caps-label">开源方案 vs CMBI e-Agent</div>

| 维度 | OpenClaw（个人助手） | CMBI e-Agent（我们） |
|------|---------------------|---------------------|
| 定位 | 个人效率工具 | <span class="us">企业生产力平台</span> <span class="badge">企业级</span> |
| 用户模型 | 单用户 · 无角色 | <span class="us">多用户 · 40+ 投行岗位角色</span> |
| 安全等级 | 社区级 | <span class="us">金融级 · 5 层纵深防御</span> <span class="badge">金融级</span> |
| 技能加载 | 明文 · 无签名 | <span class="us">RSA 签名 + AES 加密 · 未签名拒绝</span> |
| 合规能力 | 无 | <span class="us">前置 LLM 审查 · 审计日志只增不改</span> |
| 部署策略 | 固定配置 | <span class="us">4 场景一键切换</span> |
| LLM 客户端 | 依赖官方 SDK | <span class="us">全自研 · HTTP/2 · 数据不外泄</span> <span class="badge">自研</span> |
| 知识资产 | 无法沉淀 | <span class="us">Skills · 经验 → 资产 · 加密保护</span> <span class="badge">资产化</span> |

</div>
</div>

<div class="tagline">
别人做<span>个人工具</span>，我们做<span>企业能力平台</span>
</div>
