# coqi-claw Web 网关启动流程

> 本文档总结 `src/gateway/server.js` 的启动流程。
> 最后更新：2026-07-10

---

## 1. 总览

`src/gateway/server.js` 是 coqi-claw Web UI 的服务器入口，负责把核心 Agent 实例包装成 HTTP + WebSocket 服务。启动流程可分为 6 个阶段：

```text
main()
  │
  ├── 1. 核心组件初始化（BootstrapManager 4 阶段）
  │     ├── loadEnvironment()        # .env / CLI args / 场景检测
  │     ├── initializeSystem()       # 编码 / 沙箱 / 工具注册
  │     ├── SessionManager.initialize()  # 加密 SQLite 会话库
  │     ├── loadConfiguration()      # 配置校验
  │     └── initializeAgent()        # SkillManager + LLMClient + Agent
  │         └── 可选：挂载 SessionTitleGenerator（Matcher LLM）
  │
  ├── 2. 组装 Web 依赖对象
  │     agent / contextManager / sessionManager / auditReviewer
  │
  ├── 3. 构建 Express 应用
  │     ├── 安全响应头
  │     ├── /api 限流
  │     ├── CORS
  │     ├── API Key 认证
  │     ├── JSON Body Parser（1MB）
  │     ├── REST API 路由 /api/v1 + /api
  │     ├── /api 404 兜底
  │     ├── 静态文件 web/dist
  │     ├── SPA fallback
  │     └── 全局错误处理
  │
  ├── 4. 创建 HTTP + WebSocket Server
  │     ├── http.createServer(app)
  │     ├── new WebSocketServer({ server, maxPayload: 1MB })
  │     └── ConnectionManager 实例化
  │
  ├── 5. WebSocket 连接处理注册
  │     ├── 认证检查 validateWSAuth
  │     ├── 发送 connected 消息
  │     ├── message 事件分发（CHAT / CANCEL / PING）
  │     ├── close / error / pong 事件处理
  │
  ├── 6. 启动监听 + 关闭钩子
  │     ├── server.listen(PORT, HOST)
  │     ├── 控制台输出访问地址
  │     ├── server.on('error') 启动失败处理
  │     └── process.once(SIGINT/SIGTERM) 优雅关闭
  │
  └── 任一阶段异常 → 打印错误并 process.exit(1)
```

---

## 2. 阶段 1：核心组件初始化

这是与 TUI/CLI 共享的同一套 `BootstrapManager` 流水线：

| 步骤 | 调用 | 作用 |
|------|------|------|
| 加载环境 | `bootstrap.loadEnvironment()` | `.env`、CLI 参数、场景检测、`--set-KEY=VALUE` |
| 初始化系统 | `bootstrap.initializeSystem()` | Windows UTF-8、沙箱目录、工具注册 |
| 会话库 | `sessionManager.initialize()` | 加密 SQLite 数据库就绪 |
| 加载配置 | `bootstrap.loadConfiguration()` | 校验运行时配置 |
| 初始化 Agent | `bootstrap.initializeAgent({ sessionManager })` | SkillManager、主 LLMClient、MatcherClient、Agent |

随后可选为会话管理器挂载智能标题生成器：

```js
const matcherClient = bootstrap.getMatcherClient();
if (matcherClient) {
  sessionManager.setTitleGenerator(new SessionTitleGenerator(matcherClient));
}
```

---

## 3. 阶段 2：组装 Web 依赖

所有 HTTP/WebSocket 处理器共享同一个依赖对象：

```js
const chatDeps = { agent, contextManager, sessionManager, auditReviewer };
```

这保证了 REST 和 WebSocket 聊天请求使用同一套 Agent 和会话状态。

---

## 4. 阶段 3：Express 应用构建

中间件按以下顺序挂载，**顺序敏感**：

| 顺序 | 中间件/路由 | 说明 |
|------|------------|------|
| 1 | 安全响应头 | `X-Content-Type-Options`、`X-Frame-Options`、`Referrer-Policy` 等 |
| 2 | 速率限制 | `/api/*` 路径生效 |
| 3 | CORS | 在需要跨域的路由之前 |
| 4 | API Key 认证 | 在 body parser 前，避免未认证请求消耗解析资源 |
| 5 | Body Parser | `express.json({ limit: "1mb" })` |
| 6 | REST 路由 | `/api/v1` + `/api` 兼容 |
| 7 | API 404 兜底 | 防止前端把 SPA fallback 当正常响应 |
| 8 | 静态文件 | `web/dist`（SEA 兼容绝对路径） |
| 9 | SPA fallback | 所有非 API 路由返回 `index.html` |
| 10 | 全局错误处理 | 必须在最后 |

---

## 5. 阶段 4：HTTP + WebSocket Server

```js
const server = http.createServer(app);
const wss = new WebSocketServer({ server, maxPayload: 1024 * 1024 });
const connManager = new ConnectionManager();
```

WebSocket 与 HTTP 共享同一个 `server` 实例，因此只需要一个端口（默认 `3000`）。

---

## 6. 阶段 5：WebSocket 连接处理

每个 `connection` 事件：

1. **认证**：`validateWSAuth(req)`，失败则发送错误并 `ws.close(1008)`
2. **注册连接**：`connManager.add(ws)`
3. **发送 connected 确认**
4. **消息分发**：
   - `CHAT` → `handleChat(conn, payload, chatDeps)`
   - `CANCEL` → `handleCancel(conn)`
   - `PING` → `PONG`
5. **生命周期事件**：`close` / `error` / `pong` 都会刷新心跳并清理资源

---

## 7. 阶段 6：启动监听与优雅关闭

### 7.1 启动监听

```js
server.listen(PORT, HOST, () => {
  console.log(`coqi-claw Web UI running at http://${displayHost}:${PORT}`);
});
```

- `PORT` 默认 `3000`
- `HOST` 默认 `127.0.0.1`
- 监听 `0.0.0.0` 时会在控制台给出外部可访问警告

### 7.2 启动失败

```js
server.on("error", (err) => {
  logger.error("HTTP server 启动失败", { error: err.message });
  process.exit(1);
});
```

### 7.3 优雅关闭（SIGINT / SIGTERM）

```text
1. 设置 isShuttingDown 标志
2. connManager.closeAll() 关闭所有 WS
3. server.close() 最多等待 10 秒
4. bootstrap.shutdown()
5. sessionManager.close()
6. process.exit(0)
```

---

## 8. 错误处理

- 任何初始化阶段异常会进入 `main().catch(...)`，打印错误并 `process.exit(1)`
- 优雅关闭失败也会 `process.exit(1)`
- WebSocket 处理器内部错误会被捕获并返回 `ServerMessageType.ERROR`

---

## 9. 关键文件索引

| 文件 | 职责 |
|------|------|
| `src/gateway/server.js` | 网关入口，启动流程编排 |
| `src/bootstrap/manager.js` | BootstrapManager 4 阶段初始化 |
| `src/sessions/manager.js` | 会话持久化 |
| `src/sessions/context-manager.js` | 上下文管理 |
| `src/sessions/title-generator.js` | 会话标题生成 |
| `src/gateway/router.js` | REST API 路由 |
| `src/gateway/chat-handler.js` | WebSocket 聊天/取消处理 |
| `src/gateway/connection.js` | WebSocket 连接与心跳管理 |
| `src/gateway/protocol.js` | 客户端/服务端消息协议 |
| `src/gateway/middleware/api-auth.js` | API Key 认证 |
| `src/gateway/middleware/rate-limit.js` | 速率限制 |
| `src/gateway/middleware/cors.js` | 跨域处理 |
| `src/gateway/middleware/error-handler.js` | 全局错误处理 |
