# 场景化配置管理器设计方案

## 背景

coqi-claw 当前支持企业、金融企业、个人等多种发布场景，但配置系统完全扁平——所有场景共享同一套 `.env` 配置和安全策略。不同场景对安全的要求差异巨大：金融场景需要强制审计、严格网络白名单、技能签名验证；个人场景则需要宽松策略和可自由调整的 `.env`。

## 设计目标

1. **统一入口初始化**：消除 `cli.js` 和 `tui/index.js` 中高度重复的初始化代码
2. **场景化安全策略**：按场景预设不同的安全开关组合
3. **企业级 `.env` 保护**：企业/金融场景下 `.env` 全文 RSA 签名保护，篡改即退出
4. **防绕过设计**：Guarded 场景下场景值锁定，不接受命令行/环境变量覆盖

---

## 架构设计

### 新增模块

```
src/
  bootstrap/
    index.js          # 统一导出
    manager.js        # BootstrapManager 核心类
    scene-config.js   # 场景预设配置定义
    env-guard.js      # .env 完整性签名保护
    cli-args.js       # 命令行参数解析（--scene, --set-KEY 等）
```

### 职责划分

| 模块 | 职责 |
|------|------|
| `BootstrapManager` | 统一初始化流程、生命周期管理、资源释放 |
| `SceneConfig` | 定义各场景的预设安全策略、合并逻辑 |
| `EnvGuard` | 企业场景下 `.env` 的 RSA-SHA256 签名验证 |
| `CliArgs` | 解析 `--scene`、`--skip-env-guard`、`--set-KEY=VALUE` 等参数 |

---

## 场景定义

### 场景枚举

| 场景 | 标识 | 核心特征 |
|------|------|----------|
| 企业 | `enterprise` | 严格沙箱 + 强制审计 + Skill 签名 enforce + `.env` 签名保护 |
| 金融 | `financial` | 企业基础上更严格的网络白名单、每次对话免责声明、禁用 exec/http_request |
| 个人 | `personal` | 宽松沙箱、审计关闭、`.env` 可自由改动（**默认场景**） |
| 开发 | `dev` | 调试友好、安全策略宽松、Skill trust off |

### 场景预设安全策略

#### Enterprise（企业）

```javascript
SANDBOX_MODE: 'enforce'
EXEC_MODE: 'strict'
ENABLE_EXEC_ISOLATION: 'true'
NETWORK_MODE: 'blocklist'
DLP_REDACTION: 'true'
ENABLE_AUDIT: 'true'
SKILL_TRUST_MODE: 'enforce'
ENV_GUARD_ENABLED: 'true'
LOG_LEVEL: 'info'
DEBUG: 'false'
AI_DISCLAIMER_MODE: 'once'
DISABLED_TOOLS: ''
ARCHIVE_MAX_ENTRIES: '10000'
ARCHIVE_MAX_UNCOMPRESSED_SIZE: '524288000'
```

#### Financial（金融/投行）

```javascript
SANDBOX_MODE: 'enforce'
EXEC_MODE: 'strict'
ENABLE_EXEC_ISOLATION: 'true'
NETWORK_MODE: 'allowlist'          // 只允许白名单域名
ALLOWED_URLS: 'api.openai.com,api.anthropic.com,api.deepseek.com'
DLP_REDACTION: 'true'
ENABLE_AUDIT: 'true'
SKILL_TRUST_MODE: 'enforce'
ENV_GUARD_ENABLED: 'true'
LOG_LEVEL: 'warn'                  // 减少日志敏感信息泄露
DEBUG: 'false'
AI_DISCLAIMER_MODE: 'always'       // 每次对话都显示免责声明
DISABLED_TOOLS: 'exec,http_request' // 禁用高危工具
ARCHIVE_MAX_ENTRIES: '5000'
ARCHIVE_MAX_UNCOMPRESSED_SIZE: '104857600'  // 100MB
```

#### Personal（个人）

```javascript
SANDBOX_MODE: 'warn'
EXEC_MODE: 'lenient'
ENABLE_EXEC_ISOLATION: 'false'
NETWORK_MODE: 'blocklist'
DLP_REDACTION: 'false'
ENABLE_AUDIT: 'false'
SKILL_TRUST_MODE: 'warn'
ENV_GUARD_ENABLED: 'false'
LOG_LEVEL: 'info'
DEBUG: 'false'
AI_DISCLAIMER_MODE: 'off'
DISABLED_TOOLS: ''
ARCHIVE_MAX_ENTRIES: '10000'
ARCHIVE_MAX_UNCOMPRESSED_SIZE: '524288500'
```

#### Dev（开发）

```javascript
SANDBOX_MODE: 'warn'
EXEC_MODE: 'lenient'
ENABLE_EXEC_ISOLATION: 'false'
NETWORK_MODE: 'blocklist'
DLP_REDACTION: 'false'
ENABLE_AUDIT: 'false'
SKILL_TRUST_MODE: 'off'
ENV_GUARD_ENABLED: 'false'
LOG_LEVEL: 'debug'
DEBUG: 'true'
AI_DISCLAIMER_MODE: 'off'
DISABLED_TOOLS: ''
ARCHIVE_MAX_ENTRIES: '10000'
ARCHIVE_MAX_UNCOMPRESSED_SIZE: '524288500'
```

---

## BootstrapManager 生命周期

```javascript
const bootstrap = new BootstrapManager({ mode: 'cli' });  // or 'tui'

await bootstrap.loadEnvironment();      // 1. 加载 .env + 场景 + 签名验证 + 解密
await bootstrap.initializeSystem();     // 2. 编码 + 沙箱 + 工具
bootstrap.loadConfiguration();          // 3. 验证配置
await bootstrap.initializeAgent();      // 4. SkillManager + LLM + Agent + Audit

// 获取组件
const agent = bootstrap.getAgent();
const config = bootstrap.getConfig();
const auditReviewer = bootstrap.getAuditReviewer();

// 关闭
await bootstrap.shutdown();
```

### 阶段 1: loadEnvironment() — 环境加载

```
1. dotenv.config() 加载 .env
2. 解析命令行参数（--scene, --set-KEY=VALUE 等）
3. 判断 .env 中声明的场景
4. 如果是 Guarded 场景（enterprise/financial）：
   a. 强制验证 .env.sig 签名，失败直接退出
   b. 锁定场景值 = .env 中声明的值（忽略 --scene 覆盖）
   c. 禁止命令行覆盖安全策略相关的环境变量
5. 应用预设默认值（仅当对应 key 未设置时）
6. decryptEnvConfig() 解密加密配置值
```

### 阶段 2: initializeSystem() — 系统初始化

```
1. initWindowsEncoding()
2. ensureSandboxLayout()
3. initializeTools()
```

### 阶段 3: loadConfiguration() — 配置验证

```
loadConfig() — 验证必填项和 CONFIG_SCHEMA
```

### 阶段 4: initializeAgent() — Agent 初始化

```
1. new SkillManager() → loadAll()
2. new LLMClient({ label: 'primary' })
3. loadMatcherConfig() → 可选 matcher client
4. new Agent(skillManager, primaryClient, { matcherLLMClient, config })
5. 如果 ENABLE_AUDIT=true：
   a. loadAuditConfig() → audit LLM client
   b. new AuditReviewer()
```

---

## 防绕过设计（Guarded 场景）

### 核心原则

**Guarded 场景（enterprise/financial）下，`.env` 即真理。任何外部覆盖一律拒绝。**

### 锁定机制

```javascript
if (isGuarded) {
  // 1. 强制签名验证
  const result = this.envGuard.verify(this.options.envPath);
  if (!result.valid) {
    throw new ConfigError(`.env integrity check failed: ${result.reason}`);
  }

  // 2. 锁定场景：只能从已签名的 .env 读取
  this.state.scene = envScene;
  if (cliArgs.scene && cliArgs.scene !== envScene) {
    logger.warn(`--scene=${cliArgs.scene} ignored, using locked scene: ${envScene}`);
  }

  // 3. 禁止命令行覆盖安全策略
  const SECURITY_KEYS = [
    'SANDBOX_MODE', 'EXEC_MODE', 'ENABLE_EXEC_ISOLATION',
    'NETWORK_MODE', 'ALLOWED_URLS', 'DLP_REDACTION',
    'ENABLE_AUDIT', 'SKILL_TRUST_MODE', 'DISABLED_TOOLS',
    'LOG_LEVEL', 'AI_DISCLAIMER_MODE'
  ];
  for (const key of SECURITY_KEYS) {
    if (cliArgs.envOverrides[key] !== undefined) {
      logger.warn(`--set-${key} ignored in guarded mode`);
      delete cliArgs.envOverrides[key];
    }
  }
}
```

### 绕过方式与防御状态

| 攻击方式 | 防御状态 | 说明 |
|---------|---------|------|
| 修改 `.env` 中的 `COQI_SCENE` | ✅ 已阻止 | `.env.sig` 签名被破坏，启动直接退出 |
| 设置系统环境变量 `COQI_SCENE` | ✅ 已阻止 | `override: true` 强制用 `.env` 值覆盖 |
| 命令行 `--scene=personal` | ✅ 已阻止 | Guarded 场景下完全忽略 `--scene` |
| 命令行 `--set-ENABLE_AUDIT=false` | ✅ 已阻止 | Guarded 场景下安全策略不可覆盖 |
| 修改源码绕过 Guarded 检查 | ⚠️ 依赖交付形式 | SEA 交付下不可修改；源码交付需配合法律约束 |

---

## .env 签名保护机制

### 签名流程

```bash
# 管理员使用 RSA 私钥对 .env 签名
npm run sign-env

# 输出：.env.sig（Base64 编码的 RSA-SHA256 签名）
```

复用现有 RSA 密钥基础设施：
- **公钥**：`config/public-config.pem`
- **私钥**：`src/utils/secure-key.js`（XOR 混淆存储）
- **算法**：RSA-SHA256
- **签名文件**：`.env.sig`

### 验证流程

```javascript
const envGuard = new EnvGuard();
const result = envGuard.verify('.env');
// result.valid = true/false
// result.reason = 'signature-verified' 或具体失败原因
```

### 失败行为

Guarded 场景下签名验证失败：**直接抛出 `ConfigError`，入口 catch 后 `process.exit(1)`**。

```
╔══════════════════════════════════════════════════════╗
║  Configuration Error                                 ║
╚══════════════════════════════════════════════════════╝

.env integrity check failed: .env file has been tampered with (signature mismatch)
This is a guarded (financial) deployment. .env tampering is not allowed.
```

### 紧急绕过（不推荐）

```bash
# 仅用于紧急恢复，日志中会记录警告
npm start -- --skip-env-guard
```

---

## 金融企业场景发布流程

### 开发阶段

```bash
# 1. 配置 .env（COQI_SCENE=financial + 全部安全策略）

# 2. 对 .env 签名
npm run sign-env

# 3. 加密安全策略文件
node scripts/encrypt-policy.js

# 4. 对业务技能签名/加密
node scripts/skill-sign.js skills/compliance-check --key-id coqi-claw-internal --expire-days 365
node scripts/skill-encrypt.js skills/compliance-check --files "scripts/*,references/*"

# 5. 构建 SEA 单文件（确保 Guarded 检查不可绕过）
npm run build:sea
```

### 交付物

| 文件 | 说明 | 客户能否修改 |
|------|------|-------------|
| `coqi-claw.exe` | SEA 单文件可执行程序 | 否 |
| `.env` | 环境配置（已签名锁定） | **否** |
| `.env.sig` | RSA-SHA256 签名 | 否 |
| `config/skill-trust-policy.json.enc` | 加密后的技能信任策略 | 否 |
| `skills/` | 已签名/加密的技能包 | 否 |
| `config/public-*.pem` | 验证公钥 | 否 |

### 客户部署

```bash
# 启动方式
./coqi-claw.exe

# 启动时自动流程：
# 1. 加载 .env → 发现 COQI_SCENE=financial
# 2. 应用金融场景预设（严格沙箱、allowlist 网络、强制审计等）
# 3. 验证 .env.sig → 通过则继续，失败则退出
# 4. 初始化 Agent + AuditReviewer
# 5. 用户输入先经过合规审查
```

### 运维更新

**场景：API Key 过期需要更新**

```bash
# 客户向你提供新 Key
# 你在本地修改 .env，重新签名，交付新的 .env + .env.sig
sed -i 's/LLM_API_KEY=.*/LLM_API_KEY=sk-newkey/' .env
npm run sign-env
# 交付新的 .env + .env.sig 给客户替换
```

**没有私钥的客户无法自行签名 `.env`，因此无法绕过安全策略。**

---

## 关键设计决策

### 1. 为什么将 `dotenv.config()` 从 `config.js` 移到 `BootstrapManager`

原 `config.js` 在模块加载时立即执行 `dotenv.config()`，导致：
- 场景预设无法在 `.env` 加载前应用
- 企业场景的 `.env` 签名验证必须在 `dotenv` 填充 `process.env` 之前完成（否则恶意 `.env` 可能已被加载）

### 2. 为什么 Guarded 场景不接受命令行覆盖

命令行参数 `--scene=personal` 和 `--set-KEY=VALUE` 是真实的绕过途径。Guarded 场景下必须锁定：
- 场景值只能从已签名的 `.env` 读取
- 安全策略相关的环境变量不接受命令行覆盖

### 3. 为什么建议 SEA 交付金融场景

SEA（Single Executable Application）将 Node.js 运行时 + 源码打包为单个二进制文件：
- 客户无法修改 `manager.js` 绕过 Guarded 检查
- 客户无法查看源码中的混淆私钥
- 技术保护有效

源码交付时技术保护有限，需配合法律/合同约束。

### 4. 技能白名单的处理

本方案**不**在场景管理器中硬编码技能白名单。技能准入继续由 `config/skill-trust-policy.json` 控制。场景预设中的 `SKILL_TRUST_MODE` 控制策略生效级别：
- `enforce`：未签名/签名无效的技能直接拒绝加载
- `warn`：仅打印警告，仍允许加载
- `off`：完全跳过签名验证

如需按场景控制技能白名单，建议在 `skill-trust-policy.json` 中扩展 `scenes` 字段。

---

## 文件变更清单

### 新建文件

| 文件 | 说明 |
|------|------|
| `src/bootstrap/index.js` | 统一导出 |
| `src/bootstrap/manager.js` | BootstrapManager 核心 |
| `src/bootstrap/scene-config.js` | 场景预设定义 |
| `src/bootstrap/env-guard.js` | .env 签名验证 |
| `src/bootstrap/cli-args.js` | 命令行参数解析 |
| `scripts/sign-env.js` | .env 签名工具 |

### 修改文件

| 文件 | 修改内容 |
|------|----------|
| `src/utils/config.js` | 移除模块加载时的 `dotenv.config()`，改为由 BootstrapManager 控制 |
| `src/cli.js` | 使用 BootstrapManager 替代重复初始化逻辑 |
| `src/tui/index.js` | 使用 BootstrapManager 替代重复初始化逻辑 |
| `package.json` | 新增场景化启动脚本和 `sign-env` 脚本 |

---

## 风险与缓解

| 风险 | 影响 | 缓解 |
|------|------|------|
| `config.js` 移除 `dotenv.config()` 导致测试失效 | 中 | 所有入口已改为 BootstrapManager；测试需确保 dotenv 已加载 |
| `.env.sig` 缺失导致 Guarded 场景无法启动 | 高 | 错误信息明确提示 `Run: npm run sign-env` |
| 源码交付下客户修改源码绕过 | 高 | **建议 SEA 交付**；源码交付需配合法律约束 |
| 命令行参数与用户输入冲突 | 低 | cli-args.js 过滤所有 `--` 前缀参数作为配置参数 |
| SEA 打包后路径问题 | 中 | 使用 `getBaseDir()` 替代 `__dirname` |
