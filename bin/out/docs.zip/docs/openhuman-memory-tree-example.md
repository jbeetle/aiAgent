# OpenHuman 核心能力深度解析：记忆树 + 知识管理 + 多服务集成

> 基于 README + AGENTS.md 架构描述，结合 Cargo.toml 依赖验证的还原分析

---

## 一、核心架构全景

```
                      ┌─────────────────────────────┐
                      │      118+ 第三方服务           │
                      │  Gmail  GitHub  Slack  Jira   │
                      │  Drive  Notion  Stripe  ...   │
                      └──────────┬──────────────────┘
                                 │ OAuth (Composio)
                                 │ 每20分钟自动拉取
                                 ▼
┌────────────────────────────────────────────────────────────┐
│                    Auto-Fetch 引擎                          │
│  (src/openhuman/cron/ + src/openhuman/integrations/)       │
│                                                            │
│  cron 定时器 ──► 遍历活跃连接 ──► 拉取增量数据              │
│  每20分钟         Gmail/Drive/      新邮件/新文档/           │
│                  Slack/GitHub...    新消息/新PR...          │
└────────────────────────┬───────────────────────────────────┘
                         │ 原始数据 (HTML/JSON/文本)
                         ▼
┌────────────────────────────────────────────────────────────┐
│                    TokenJuice 压缩层                        │
│  (src/openhuman/tokenjuice/)                               │
│                                                            │
│  HTML → Markdown    URL 缩短    去重    摘要                │
│  CJK/Emoji 按 grapheme 完整保留，绝不丢弃                    │
│  成本降低最高 80%                                           │
└────────────────────────┬───────────────────────────────────┘
                         │ 规范化 Markdown 片段 (≤3k tokens)
                         ▼
┌────────────────────────────────────────────────────────────┐
│                    记忆树 (Memory Tree)                     │
│  (src/openhuman/memory/ + src/openhuman/tree_summarizer/)  │
│                                                            │
│  ┌──────────┐                                              │
│  │ 根摘要    │  "你是全栈开发者，主要用 Rust+React..."       │
│  │ (500词)  │                                              │
│  └────┬─────┘                                              │
│       │                                                    │
│  ┌────┴──────────────────────────┐                         │
│  │ 工作 (摘要)     │ 个人 (摘要)   │  层级化摘要树            │
│  │ "3个活跃PR..."  │ "下周三会议"  │                         │
│  └───┬─────────────┴───┬─────────┘                         │
│      │                 │                                    │
│  ┌───┴────┐      ┌────┴─────┐                              │
│  │Repo A  │      │ 家庭日历  │   叶子节点：                  │
│  │ 摘要   │      │  摘要    │   具体 Markdown 片段           │
│  └───┬────┘      └────┬─────┘                              │
│      │                │                                     │
│  ┌───┴────────┐  ┌───┴─────────┐                           │
│  │PR#42: fix  │  │周三 3pm     │   ≤3k token/片             │
│  │auth bug    │  │牙医预约     │                            │
│  └────────────┘  └─────────────┘                            │
│                                                             │
│  存储: SQLite (rusqlite)  + 评分排序 + 层级折叠              │
└────────────────────────┬───────────────────────────────────┘
                         │ 同步写入
                         ▼
┌────────────────────────────────────────────────────────────┐
│               Obsidian Wiki (本地文件系统)                   │
│  ~/openhuman/vault/                                        │
│  ├── work/                                                 │
│  │   ├── repo-a-pr-42.md                                   │
│  │   └── repo-b-issue-15.md                                │
│  ├── personal/                                             │
│  │   └── calendar-week-21.md                               │
│  └── emails/                                               │
│      └── 2026-05-28-inbox-summary.md                       │
│                                                            │
│  可在 Obsidian 中直接打开、浏览、编辑                         │
└────────────────────────────────────────────────────────────┘
```

---

## 二、完整示例：一天的工作流

### 场景设定

**用户**: 张伟，全栈开发者，使用以下服务：
- 公司邮箱 (Gmail)
- 代码托管 (GitHub)
- 项目管理 (Linear)
- 团队沟通 (Slack)
- 文档协作 (Notion)
- 个人日历 (Google Calendar)

### 早上 9:00 — 张伟打开 OpenHuman

OpenHuman 已经在过去 12 小时内通过 auto-fetch 自动拉取了所有服务的增量数据：

```
┌─────────────────────────────────────────────────────────┐
│               Auto-Fetch 拉取日志 (凌晨至今)               │
├─────────────────────────────────────────────────────────┤
│ 03:20  Gmail:       +3 新邮件 (2封来自Team Lead)         │
│ 03:40  GitHub:      +2 新PR评论 (repo-A PR#42)           │
│ 04:00  Linear:      +1 新任务指派 (LIN-287)              │
│ 04:20  Slack:       +15 新消息 (#general, #team-dev)     │
│ 04:40  Notion:      +1 更新文档 (API设计v3)              │
│ 05:00  Calendar:    +1 新事件 (下午3点 牙医预约)          │
│ 05:20  Gmail:       +1 新邮件 (HR 全员通知)              │
│ ...每20分钟循环...                                        │
└─────────────────────────────────────────────────────────┘
```

### TokenJuice 压缩效果

原始 Slack 消息示例：

```
原始 (380 tokens):
<div class="c-message_kit__gutter">
  <div class="c-message__sender">@刘经理</div>
  <div class="c-message__body">
    <span class="c-message__text">@张伟 PR#42 的 auth 模块需要加一个 
    rate limiting 中间件，用户反馈登录接口被暴力破解了。优先级 P0，
    今天下班前最好能上线。有问题随时找我。</span>
    <span class="c-message__timestamp">02:47 AM</span>
  </div>
</div>

压缩后 (45 tokens):
[Slack #team-dev] @刘经理 → @张伟: PR#42 auth 模块加 rate limiting 
中间件，P0，今天上线。有问题找我。(02:47)
```

**压缩比**: 380 → 45 tokens，节省 **88%**

### 记忆树构建

所有压缩后的片段被评分、分类、折叠成层级树：

```markdown
## 张伟的记忆树根摘要 (2026-05-28 09:00)
(由 tree_summarizer 每天自动生成)

### 工作 — 今日重点
- **P0: PR#42 auth rate limiting** — @刘经理指派，今天上线
- Linear LIN-287: 用户画像接口优化，本周完成
- Notion API设计v3 更新，需review新增的GraphQL端点

### 代码仓库动态
- repo-A: PR#42 有2条新评论，CI 通过，等待review
- repo-B: Issue#15 讨论技术选型 (Redis vs Valkey)

### 日历
- 🔴 15:00 牙医预约 (需提前出发)
- 🔵 10:00 每日站会

### 邮件摘要
- 2封来自 Team Lead (1封已自动标注为重要)
- 1封 HR 全员通知 (福利更新)

### 消息摘要
- Slack #team-dev: 3条@提及 (2条来自刘经理，1条来自李工)
```

### 张伟与 OpenHuman 的对话

```
张伟: "今天有什么重要的事？"

OpenHuman: 
  从你的记忆树中，今天有三件优先级最高的事：

  1. 🔴 P0任务 — PR#42 加 rate limiting 中间件
     刘经理凌晨2:47在Slack上说今天必须上线。
     GitHub上PR已经通过了CI，代码review完成。
     建议：确认测试覆盖 → merge → 部署到staging验证 → 上线

  2. 🟡 Linear LIN-287 — 用户画像接口优化
     本周内完成即可，不急。

  3. 🔵 下午3点有牙医预约
     需要2:30出发。我已经在你的日历上看到了。

  需要我帮你review PR#42的代码，或者准备部署脚本吗？
```

---

## 三、关键技术实现

### 3.1 Auto-Fetch 引擎

```rust
// 推断路径: src/openhuman/cron/schedule.rs

use cron::Schedule;
use chrono::{Utc, DateTime};
use std::str::FromStr;

pub struct AutoFetchScheduler {
    // 每20分钟执行一次
    schedule: Schedule,  // "0 */20 * * * *"
    active_connections: Vec<Connection>,
}

impl AutoFetchScheduler {
    pub async fn tick(&mut self) {
        for conn in &self.active_connections {
            let since = conn.last_fetch_time;
            
            // 根据连接类型调用对应provider
            let new_data = match conn.service_type {
                ServiceType::Gmail     => gmail::fetch_incremental(conn, since).await,
                ServiceType::GitHub    => github::fetch_notifications(conn, since).await,
                ServiceType::Slack     => slack::fetch_messages(conn, since).await,
                ServiceType::Linear    => linear::fetch_issues(conn, since).await,
                ServiceType::Notion    => notion::fetch_updated_pages(conn, since).await,
                ServiceType::Calendar  => calendar::fetch_events(conn, since).await,
                // ... 118+ 个 provider
            };
            
            // TokenJuice 压缩
            let compressed = tokenjuice::compress_raw_data(new_data);
            
            // 写入记忆树
            memory_tree::ingest(conn.user_id, compressed);
        }
    }
}
```

**Cargo.toml 证据**:
- `cron = "0.12"` — cron 定时器
- `chrono = "0.4"` — 时间管理
- `chrono-tz = "0.10"` — 时区处理
- `tokio = { features = ["full"] }` — 异步运行时

### 3.2 记忆树评分与折叠

```rust
// 推断路径: src/openhuman/memory/tree.rs

/// 记忆片段评分因子
struct MemoryScore {
    recency: f32,       // 越新越高
    relevance: f32,     // 与用户已知上下文的关联度
    importance: f32,    // 来源重要性 (直接@提及 > 群消息)
    actionability: f32, // 是否需要用户操作 (PR review > 公告)
}

fn score_chunk(chunk: &MemoryChunk, user_context: &UserContext) -> f32 {
    let mut score = 0.0;
    
    // 1. 时间衰减: 24小时内权重最高
    let hours_ago = (Utc::now() - chunk.created_at).num_hours() as f32;
    score += 10.0 * (-hours_ago / 24.0).exp();  // 指数衰减
    
    // 2. 直接@提及加权
    if chunk.contains_direct_mention(&user_context.username) {
        score += 5.0;
    }
    
    // 3. 是否有Deadline
    if let Some(deadline) = chunk.extract_deadline() {
        let urgency = 1.0 / (deadline - Utc::now()).num_hours() as f32;
        score += urgency * 3.0;
    }
    
    // 4. 来源权重
    score += match chunk.source {
        Source::DirectMessage => 4.0,
        Source::Mention      => 3.0,
        Source::AssignedTask => 5.0,  // Linear/Jira 指派
        Source::CalendarEvent=> 3.0,
        Source::EmailImportant=> 4.0,
        _                    => 1.0,
    };
    
    score
}

/// 层级折叠：将N个子节点压缩为父节点摘要
fn fold_children(children: &[MemoryNode], max_tokens: usize) -> String {
    if estimate_tokens(children) <= max_tokens {
        return format_children(children);
    }
    
    // 取 top-K 高分节点做详细展开，其余仅给一行摘要
    let mut sorted: Vec<_> = children.iter().collect();
    sorted.sort_by(|a, b| b.score.partial_cmp(&a.score).unwrap());
    
    let (top, rest) = sorted.split_at(5);
    let mut summary = String::new();
    for node in top {
        summary.push_str(&format!("- **{}**: {}\n", node.title, node.summary));
    }
    if !rest.is_empty() {
        summary.push_str(&format!("\n_...还有 {} 条低优先级内容_\n", rest.len()));
    }
    summary
}
```

**Cargo.toml 证据**:
- `rusqlite = "0.37"` — 记忆树存储
- `unicode-segmentation = "1"` — token 估算用 grapheme 计数

### 3.3 Obsidian Wiki 同步

```rust
// 推断路径: src/openhuman/memory/obsidian_sync.rs

use std::path::PathBuf;

pub struct ObsidianSyncer {
    vault_path: PathBuf,  // ~/openhuman/vault/
}

impl ObsidianSyncer {
    /// 将记忆树节点写入 Obsidian 兼容的 .md 文件
    pub fn sync_node(&self, node: &MemoryNode) {
        let relative_path = self.node_to_path(node);
        let full_path = self.vault_path.join(&relative_path);
        
        // 确保目录存在
        std::fs::create_dir_all(full_path.parent().unwrap());
        
        // 写入带 YAML frontmatter 的 Markdown 文件
        let content = format!(
            r#"---
source: {source}
created: {created}
score: {score}
tags: {tags}
---

# {title}

{body}

---
*自动生成于 {now} | 源: {source_url}*
"#,
            source = node.source,
            created = node.created_at,
            score = node.score,
            tags = node.tags.join(", "),
            title = node.title,
            body = node.body,
            now = chrono::Utc::now(),
            source_url = node.source_url,
        );
        
        std::fs::write(&full_path, content);
    }
    
    fn node_to_path(&self, node: &MemoryNode) -> PathBuf {
        // 按来源分类到不同文件夹
        let category = match node.source {
            Source::GitHub(_)   => "work/github",
            Source::Linear(_)   => "work/linear",
            Source::Slack(_)    => "work/slack",
            Source::Notion(_)   => "work/notion",
            Source::Gmail(_)    => "emails",
            Source::Calendar(_) => "personal/calendar",
            _                   => "other",
        };
        
        PathBuf::from(category)
            .join(sanitize_filename(&node.title))
            .with_extension("md")
    }
}
```

---

## 四、对比 coqi-claw：本质差异

| 维度 | OpenHuman | coqi-claw |
|------|-----------|----------|
| **核心哲学** | 被动感知 + 持续学习 | 主动执行 + 技能驱动 |
| **知识来源** | 118+服务自动拉取 (push) | 用户手动提供指令 (pull) |
| **记忆** | 持久化记忆树 + Obsidian | 无持久记忆 |
| **上下文构建** | 自动：auto-fetch→压缩→评分→折叠 | 手动：每次对话从零开始 |
| **压缩策略** | TokenJuice 全局中间件 | 无压缩层 |
| **知识可编辑** | ✅ Obsidian 直接编辑 .md | ❌ |
| **跨服务关联** | ✅ 记忆树自动关联 (Slack→PR→邮件) | ❌ |

### 用一句话概括差异

- **OpenHuman**: "我每天都看着你工作，记得你的一切"  
- **coqi-claw**: "你告诉我做什么，我用最好的技能帮你完成"

---

## 五、记忆树对 Agent 行为的实际影响

### 场景：用户问 "帮我处理今天的工作"

#### 没有记忆树的 Agent (如 coqi-claw)：

```
Agent: 请具体说明今天需要处理哪些工作。
用户: 我早上有好几封邮件，Slack上也有消息...
Agent: 我无法访问你的邮件和Slack。请粘贴相关内容。
用户: [手动粘贴10封邮件 + 15条Slack消息] ← 耗时且token昂贵
```

#### 有记忆树的 Agent (OpenHuman)：

```
Agent: 根据你的记忆树摘要，今天有以下工作：

  1. 🔴 P0 — PR#42 rate limiting (刘经理指派，今天上线)
     上次讨论: Slack 凌晨02:47
     PR状态: CI通过，等review
     建议: 我可以帮你review代码并准备部署

  2. 🟡 LIN-287 — 用户画像接口优化
     Linear描述: "优化GET /api/users/profile响应时间"
     截止: 本周五
     
  3. 📧 来自HR的福利更新通知
     内容摘要: 新增牙科保险，6月1日生效
     需要: 无需操作，仅供参考

  4. 📅 下午3点牙医，需要2:30出发

  要开始处理PR#42吗？我可以先帮你切换到这个分支。
```

**本质区别**：OpenHuman 在用户开口之前就已经准备好了上下文——因为 auto-fetch 每20分钟就拉取一次数据，记忆树在后台持续构建和更新。用户不需要"喂"上下文给 Agent，Agent 主动拥有上下文。
