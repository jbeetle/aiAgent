# Skill Trust Framework 实现计划

## Context

coqi-claw 定位为企业级 AI Agent，现有 skill 系统缺乏安全认证机制：
1. 用户可从网上下载 skill 放入 `skills/` 目录，Agent 会无条件加载使用
2. 业务部门开发的 skill（含业务逻辑脚本和提示词）可被轻易拷贝到其他 Agent 运行

需要引入两层保护：签名认证（解决需求1）+ 内容加密（解决需求2）。

## 设计决策

| 决策 | 选择 | 原因 |
|------|------|------|
| 未认证 skill 处理 | **严格拒绝**（enforce 模式） | 企业场景，网上下载的 skill 不应被加载 |
| 加密范围 | **scripts/ + references/ + SKILL.md body** | 业务逻辑和指令都需要保护 |
| 加密技术 | **AES-256-GCM + RSA-OAEP-SHA256 密钥封装** | 标准方案，AES-NI 硬件加速，性能无感 |
| Skill Key 策略 | **每次重新解封，不缓存** | 简单安全，RSA 解封开销 ~5ms 可忽略 |
| 隔离目录清理 | **exec 后立即删除 skill 子目录** | 避免解密后的明文长期暴露 |
| 自动清理 | **当前代码中不存在延迟清理** | 已确认，只有 `enforceSkillWorkDirLimit`（50个上限时删除最旧） |

## 新增文件

### 1. `src/security/skill-trust.js` — 信任锚点核心

**职责**：加载信任策略、验证 skill 签名、获取加密信息。

**关键函数**：
- `loadTrustPolicy(baseDir)` — 加载 `config/skill-trust-policy.json`，带文件修改时间缓存
- `verifySkillSignature(skillDir, policy)` — 验证 `.skill-trust` 文件中的签名，返回 `{ valid, reason, trustInfo }`
- `getSkillEncryptionInfo(skillDir)` — 读取 `.skill-trust` 中的加密元数据
- `computeKeyFingerprint(publicKeyPem)` — 计算公钥 SHA-256 指纹

**验证流程**：
1. 检查 `.skill-trust` 文件是否存在
2. 验证签名者 keyId 是否在可信列表中
3. 验证公钥指纹匹配
4. 验证时间戳（signedAt, expiresAt, maxAgeDays）
5. 验证 manifest 签名（RSA-SHA256）
6. 检查白名单（如有）

### 2. `src/security/skill-cipher.js` — 内容保护核心

**职责**：AES-256-GCM 加解密、Skill Key 的封装/解封。

**关键函数**：
- `getMasterKey()` — 从 `SKILL_MASTER_KEY` 环境变量（hex 格式）或 `secure-key.js` 私钥派生
- `unwrapSkillKey(encryptedKeyB64, keyWrap)` — RSA-OAEP-SHA256 解封 Skill Key
- `wrapSkillKey(skillKey, publicKeyPem)` — RSA-OAEP-SHA256 封装 Skill Key（发布工具用）
- `encryptContent(plaintext, key)` — AES-256-GCM 加密，返回 `nonce(12) + ciphertext + authTag(16)`
- `decryptContent(encryptedData, key)` — AES-256-GCM 解密，验证 auth tag
- `generateSkillKey()` — 生成随机 256-bit Skill Key

### 3. `config/skill-trust-policy.json` — 信任策略配置

```json
{
  "version": "1.0.0",
  "mode": "enforce",
  "signatures": {
    "trustedKeys": [
      {
        "id": "coqi-claw-internal",
        "name": "coqi-claw Internal Key",
        "publicKeyPath": "config/public.pem",
        "fingerprint": "sha256:..."
      }
    ],
    "requireTimestamp": true,
    "maxAgeDays": 365
  },
  "whitelist": {
    "enabled": false,
    "skills": []
  },
  "encryption": {
    "enabled": true,
    "masterKeyEnv": "SKILL_MASTER_KEY"
  }
}
```

### 4. `scripts/skill-sign.js` — Skill 签名 CLI 工具

**用法**：`node scripts/skill-sign.js <skill-dir> [--key-id <id>] [--expire-days <days>]`

**流程**：
1. 遍历 skill 目录所有文件，计算 SHA-256 hash 和 size，构建 manifest
2. 用 RSA 私钥签名 manifest（RSA-SHA256）
3. 计算公钥指纹
4. 生成 `.skill-trust` 文件（含签名、manifest、时间戳）

### 5. `scripts/skill-encrypt.js` — Skill 加密 CLI 工具

**用法**：`node scripts/skill-encrypt.js <skill-dir> [--files <patterns>]`

**流程**：
1. 加载公钥
2. 生成随机 256-bit Skill Key
3. 遍历匹配的文件，用 AES-256-GCM 加密，写入 `.enc` 文件
4. 用 RSA 公钥封装 Skill Key
5. 更新 `.skill-trust` 文件的 `encryption` 字段

## 修改文件

### 6. `src/skills/loader.js` — 集成签名验证

**改动点**：在 `loadSkills()` 中，每个 skill 目录加载前验证签名。

```javascript
const policy = loadTrustPolicy(getBaseDir());
// ... 在遍历 skill 目录时 ...
const trustResult = verifySkillSignature(skillDir, policy);
if (!trustResult.valid) {
    logger.error(`Skill "${entry.name}" trust verification failed: ${trustResult.reason}`);
    continue; // enforce 模式下拒绝加载
}
```

### 7. `src/skills/parser.js` — 支持加密内容解密

**改动点 1**：`parseSkillFile(filePath, options)` 增加 `options.encryptionInfo` 参数。
- 如果 `encryptionInfo.enabled` 且 frontmatter 标记 `encrypted: true`：
  - 解封 Skill Key
  - 提取 frontmatter 后的 base64 加密 body
  - AES-256-GCM 解密
  - 继续原有 YAML + Markdown 解析流程

**改动点 2**：新增 `readSkillFile(skillDir, relativePath, encryptionInfo)` 函数。
- 检查文件是否需要解密（`.enc` 后缀或在 `encryptedFiles` 清单中）
- 需要解密时：解封 Skill Key → 读取 `.enc` 文件 → AES-256-GCM 解密 → 返回 UTF-8 字符串
- 不需要解密时：直接 `fs.readFileSync`

**Windows 路径兼容性**：`encryptedFiles` 清单统一使用 `/` 分隔符，比较前将 `relativePath` 中的 `\` normalize 为 `/`：
```javascript
const normalizedPath = relativePath.replace(/\\/g, '/');
const isEncrypted = encryptionInfo.encryptedFiles?.includes(normalizedPath)
    || relativePath.endsWith('.enc');
```

供 `skill-view.js` 和 `exec.js` 调用。

**改动点 3**：`parseSkillFile` 确保向后兼容，新增 `options` 参数默认空对象：
```javascript
export function parseSkillFile(filePath, options = {}) {
    const { skillDir, encryptionInfo, trustVerified } = options;
    // ... 原有逻辑 ...
}
```

### 8. `src/tools/skill-view.js` — 透明解密

**改动点 1**：读取 SKILL.md 时传入加密信息。
```javascript
const encryptionInfo = loadEncryptionInfo(skillDir);
skill = parseSkillFile(skillFilePath, { encryptionInfo });
```

**改动点 2**：读取子文件时调用 `readSkillFile` 替代 `fs.readFileSync`。
```javascript
const content = readSkillFile(skillDir, subPath, encryptionInfo);
```

**改动点 3**：`discoverLinkedFiles` 过滤 `.enc` 后缀。
- 如果只有 `run.py.enc` 没有 `run.py`，显示 `scripts/run.py`

### 9. `src/tools/exec.js` — 隔离/非隔离模式均需解密 + 执行后清理

**关键变化**：当前代码中隔离条件已变为 `shouldIsolate = isSkillMode && ENABLE_EXEC_ISOLATION && sandboxMode === 'enforce'`。当 `SANDBOX_MODE=warn/off` 时，`shouldIsolate=false`，exec 直接在原始目录执行命令。加密 skill 在非隔离模式下也需要临时解密才能执行。

#### 9.1 隔离模式（`shouldIsolate === true`）

复制 skill 到隔离目录时自动解密（第 217-226 行）。

```javascript
// 替换 copyDirSync 为 copySkillDirWithDecryption
const encryptionInfo = loadEncryptionInfo(sourceSkillDir);
if (encryptionInfo?.enabled) {
    copySkillDirWithDecryption(sourceSkillDir, destSkillDir, encryptionInfo);
} else {
    copyDirSync(sourceSkillDir, destSkillDir);
}
```

`copySkillDirWithDecryption` 行为：
- 遍历目录，跳过 `.skill-trust` 文件
- 对加密文件（`.enc` 后缀或在清单中）：解封 Skill Key → AES 解密 → 去掉 `.enc` 后缀写入
- 对非加密文件：原样复制

执行后统一清理（使用 `try...finally` 确保任何路径都执行）：
```javascript
export async function execute(args) {
    // ... 参数解析 ...
    let workDir = null;
    let tempDecryptDir = null;

    try {
        // ... 创建目录、复制、执行命令 ...
        try {
            const { stdout, stderr } = await execAsync(...);
            // ... 处理结果、collectAndAttach ...
            return result;
        } catch (error) {
            // ... 处理错误 ...
            return result;
        }
    } finally {
        // 统一清理：任何路径都会执行
        if (workDir && effectiveSkillName) {
            const skillSubDir = path.join(workDir, 'skills', effectiveSkillName);
            if (fs.existsSync(skillSubDir)) {
                try { fs.rmSync(skillSubDir, { recursive: true, force: true }); } catch {}
            }
        }
        if (tempDecryptDir && fs.existsSync(tempDecryptDir)) {
            try { fs.rmSync(tempDecryptDir, { recursive: true, force: true }); } catch {}
        }
    }
}
```

#### 9.2 非隔离模式（`shouldIsolate === false` 但 `isSkillMode === true`）

当 skill 加密时，需要创建临时解密目录并修改 cwd，否则命令 `skills/xxx/scripts/run.py` 找不到文件（只有 `run.py.enc`）。

```javascript
let tempDecryptDir = null;

// 在非隔离模式下，如果 skill 加密，创建临时解密目录
if (!shouldIsolate && isSkillMode && effectiveSkillName) {
    const sourceSkillDir = path.join(getBaseDir(), 'skills', effectiveSkillName);
    const encryptionInfo = loadEncryptionInfo(sourceSkillDir);
    if (encryptionInfo?.enabled) {
        tempDecryptDir = path.join(sandboxTempDir, 'skills-temp',
            `skill-${effectiveSkillName}-${randomUUID().slice(0, 8)}`);
        fs.mkdirSync(tempDecryptDir, { recursive: true });
        const tempSkillDir = path.join(tempDecryptDir, 'skills', effectiveSkillName);
        copySkillDirWithDecryption(sourceSkillDir, tempSkillDir, encryptionInfo);
        resolvedCwd = tempDecryptDir; // 修改 cwd，使 skills/xxx/... 相对路径有效
    }
}
```

临时解密目录在 `finally` 块中统一清理（同上），确保超时/异常路径不遗漏。

**产出文件收集**：
- 隔离模式：`collectAndAttach(workDir, sandboxOutputDir, effectiveSkillName, beforeFiles, jsonResult)` — 扫描隔离目录新文件
- 非隔离模式：`collectOutputFiles(sandboxOutputDir, startTime)` — 扫描 output 目录按修改时间收集
- 两种模式产出收集均不受加密影响

## Skill 文件格式变化

加密后的 skill 目录结构：

```
skills/department-report/
├── SKILL.md              # frontmatter 明文，body 加密
├── .skill-trust          # 签名 + 加密元数据
├── scripts/
│   ├── generate.py.enc   # 加密脚本
│   └── utils.py.enc
├── references/
│   └── api.md.enc        # 加密参考文档
└── assets/
    └── template.pptx     # 非加密资源
```

## 向后兼容性

| 场景 | 行为 |
|------|------|
| 无 `config/skill-trust-policy.json` | 信任框架关闭，所有 skill 正常加载 |
| 有策略文件但 `mode: "off"` | 同上 |
| 策略 `mode: "warn"` | 未签名 skill 加载但报警告 |
| 策略 `mode: "enforce"` | 未签名 skill 拒绝加载 |
| Skill 无 `.skill-trust` | enforce 拒绝；warn 允许；off 允许 |
| Skill 有签名但无加密 | 只验证签名，内容不加密 |
| 加密 skill 但无 Master Key | 拒绝加载，报错提示配置 `SKILL_MASTER_KEY` |

## 环境变量

```bash
# Master Key（hex 格式，用于解封 Skill Key）
SKILL_MASTER_KEY=abcdef123456...

# 签名私钥路径（仅发布 skill 时使用）
SKILL_SIGNING_KEY_PATH=/path/to/private.pem
```

## 验证方案

### 1. 语法检查

```bash
node --check src/security/skill-trust.js
node --check src/security/skill-cipher.js
node --check src/skills/loader.js
node --check src/skills/parser.js
node --check src/tools/skill-view.js
node --check src/tools/exec.js
```

### 2. 单元测试

| 测试文件 | 覆盖场景 |
|---------|---------|
| `test/test-skill-trust.js` | 有效签名、无效签名、篡改 manifest、过期签名、未来签名、未知签名者、指纹不匹配、白名单 |
| `test/test-skill-cipher.js` | AES-GCM 加解密 roundtrip、RSA 封装/解封 roundtrip、错误 MasterKey、损坏的密文（auth tag 失败） |
| `test/test-skill-trust-loader.js` | 明文 skill + mode=off、明文 skill + mode=enforce（拒绝）、加密 skill + mode=enforce + 有效签名（加载）、加密 skill + 无 MasterKey（跳过） |

### 3. 集成测试

创建一个测试 skill，用 `skill-sign.js` 签名 + `skill-encrypt.js` 加密：

```bash
# 1. 创建测试 skill
mkdir -p skills/test-encrypted-skill/scripts
echo -e '---\nname: test-encrypted-skill\ndescription: Test encrypted skill\n---\n# Test\nRun scripts/hello.py' > skills/test-encrypted-skill/SKILL.md
echo 'print("hello")' > skills/test-encrypted-skill/scripts/hello.py

# 2. 签名
node scripts/skill-sign.js skills/test-encrypted-skill

# 3. 加密
node scripts/skill-encrypt.js skills/test-encrypted-skill --files "scripts/*"

# 4. 删除明文
rm skills/test-encrypted-skill/scripts/hello.py
```

验证清单：
- [ ] `npm start "使用 test-encrypted-skill"` — skill 正常匹配
- [ ] `skill_view({name:"test-encrypted-skill"})` — 返回明文 instructions
- [ ] `skill_view({name:"test-encrypted-skill", file_path:"scripts/hello.py"})` — 返回明文脚本内容
- [ ] `exec` 执行加密脚本成功 — 输出 "hello"
- [ ] 隔离目录中无残留明文 `scripts/hello.py`
- [ ] 未签名 skill 在 mode=enforce 下被拒绝加载

### 4. 并发测试

```bash
# 5 个并发请求同时执行同一加密 skill
# 验证：无文件冲突、无解密错误、各隔离目录独立清理
```
