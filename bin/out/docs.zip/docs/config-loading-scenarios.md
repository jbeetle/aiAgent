# 配置加载的两种场景：本地加载 vs Gateway 远程加载

> 本文总结 coqi-claw 环境变量配置的两种加载场景及其实现逻辑，反映 `b5e16ec`（enterprise web 模式 audit 延迟初始化修复）后的实现状态。
> 启动时序与缓存机制详见 [`config-loading-flow.md`](./config-loading-flow.md)，本文聚焦两种场景的对比与协同。

## 0. 本质区别

两种场景**方向相反**：

| | 本地加载 | Gateway 远程加载 |
|---|---------|------------------|
| 数据流向 | 磁盘 → `process.env`（**只读**） | 远程 → diff → 磁盘 + `process.env` 热更新（**读写**） |
| 触发 | 进程启动 | 运行时前端主动 `POST /api/config/remote` |
| 时机 | 冷启动一次性 | 随时增量 |

---

## 1. 场景一：本地加载

### 1.1 触发与入口

CLI / Chat / Web / Tray 四入口共享 `BootstrapManager` 四阶段流水线（`src/bootstrap/manager.js`）：

```
loadEnvironment() → initializeSystem() → loadConfiguration() → initializeAgent()
```

Web 入口 `src/gateway/server.js:33` 构造 `new BootstrapManager({ mode: "web" })`。

### 1.2 数据源与优先级（高 → 低）

| 优先级 | 来源 | 持久化 |
|--------|------|--------|
| 1 | CLI `--set-KEY=VALUE`（guarded 安全键被忽略） | ❌ 仅运行时 |
| 2 | `.env.runtime`（guarded 安全键被过滤恢复） | ✅ |
| 3 | `.env`（guarded 受 RSA 签名保护） | ✅ |
| 4 | 场景预设 `SCENE_PRESETS`（仅填充未定义键） | ❌ 代码内置 |
| 5 | `config/env-config-schema.json` 的 `default` | ✅ |

### 1.3 `loadEnvironment()` 六步（`manager.js:94-189`）

1. **① dotenv `.env`**（`override: true`）→ 加载主配置到 `process.env`
2. **② `parseCliArgs()`** → 解析 `--scene` / `--set-KEY=VALUE` / `--env` / `--skip-env-guard`
3. **③ 场景检测 + 签名验证** → guarded（enterprise/financial）锁定 `.env` 声明的场景、拒绝 `--scene` 覆盖、`EnvGuard.verify()` 验 RSA-SHA256 签名、过滤 CLI 对安全键的覆盖
4. **④ `applyScenePreset()`**（`scene-config.js:96`）→ 仅设置 `process.env` 中尚未定义的键
5. **⑤ `decryptEnvConfig()`** → 扫描 `{base64}` 格式值，RSA-OAEP 私钥解密替换为明文
6. **⑥ `.env.runtime` overlay**（`manager.js:153-181`）—— 两种加载分支：
   - **guarded**：保存安全键（`SECURITY_KEYS` ∪ `DB_ENCRYPTION_KEY` ∪ `COQI_SCENE`）原始值 → `dotenv override` → **恢复**安全键原始值（防绕过 `.env` 签名保护）
   - **非 guarded**：直接 `dotenv override`

### 1.4 `loadConfiguration()` Phase 3（`manager.js:207-216`）

```
clearConfigCache()          # 清除 ESM import 阶段过早设置的缓存
loadConfig({ allowPartial }) # 再次 decrypt + 读 schema + 类型转换 + 缓存
markConfigReady()           # 通知 logger 可用 loadConfig().logLevel
```

- Web 模式 `allowPartial = true`，允许主 LLM 配置缺失
- `primaryReady = isPrimaryConfigReady(config)`（`manager.js:48-49`）—— 要求 `provider && apiKey && baseURL && model` 四者齐全

### 1.5 安全模型

- **guarded**：`.env` RSA-SHA256 签名验证，失败抛 `ConfigError` 阻断启动；`.env.runtime` 安全键"保存→覆盖→恢复"过滤
- 信任边界 = 本机文件系统

### 1.6 加密处理

启动期 `decryptEnvConfig()` 把 `.env`/`.env.runtime` 里的 `{base64}` 密文解密成明文进 `process.env`（`manager.js:151`，`loadConfig` 内再次扫描确保 overlay 加密值也被处理）。

### 1.7 生效：冷启动

`initializeAgent()` 用 `loadConfig()` 返回的 config 对象 `new LLMClient({config})`（primary/matcher/audit/background），参数一次性固化进客户端实例。

### 1.8 web 等待模式（primary 缺失容忍）

`initializeAgent`（`manager.js:231-233`）：`!primaryReady && mode === 'web'` → 跳过 `_initializePrimary`/`_initializeMatcher`/`_createAgent`，直接 `_finalizeAgentInit(false)`，进入"等待远端推送"模式（`manager.js:316` 日志）。

> 这是 enterprise 远程推送部署的基础：本地 `.env` 不放明文 LLM 凭证，靠场景二远程推送补齐。

---

## 2. 场景二：Gateway 远程加载

### 2.1 触发与入口

```
POST /api/config/remote   body: { url?: string, token?: string }
```

路由 `src/gateway/routes/config.js:47-58` → `ConfigService.applyRemoteConfig(url, token)`（`src/services/config-service.js:338`）。

> 配套 `POST /api/config/schema`（`config.js:37-41`）只拉取纯 schema 元数据（不含 value），供前端渲染配置页。

### 2.2 SchemaProvider 远程管道（`src/utils/config/schema-provider.js`）

`fetchRemoteConfig(url, token)`（`:127-150`）一次性拿 `values` + `schema` + `version`：

```
_fetchAndNormalize → _fetchRaw → _doFetchRaw
  ├─ POST + A11n: Bearer ${token}，30s 超时
  ├─ 429 退避重试（max 3，读 Retry-After + jitter）
  ├─ 5xx → serverError；其余非 2xx → validation
  └─ 并发去重：按 (url, token) 复用进行中 Promise
_normalizeResponse
  ├─ wrapped: { data: { llmConfs: [{ enable, metaData }] } } → 取 enable===1 → JSON.parse(metaData)
  └─ 裸 schema（向后兼容）
_stripValues + _mergeSchemas → schema（剥离 value，合并本地 CONFIG_SCHEMA/json-defaults）
_flattenValues → values（保留明文 value）
_writeDiskCache（SHA256 自校验 + Windows EPERM 回退）+ _persistVersion（写 .env.runtime 的 CONFIG_REMOTE_SCHEMA_VERSION）
```

- `getSchema`（`:77-90`）取值场景**不做**版本比对、直接重写磁盘缓存（必须拿最新 value）
- `_fetchRemoteOrDefault`（`:162-208`）schema 场景：远程 `meta.version` 与磁盘缓存一致则复用 merge 结果

### 2.3 `applyRemoteConfig` diff 逻辑（`config-service.js:338-397`）

构建 `changes`，仅保留与本地不同的键：

| 远程值情况 | 处理 |
|-----------|------|
| `null`/`undefined`/`''` | 跳过 |
| 不在 schema 中 | `skipped: unknown key` |
| guarded + 安全键 | `skipped: security key blocked` |
| 加密字段 | `_decryptIfNeeded(本地密文)` 与远程明文对比，相同 `skipped: unchanged` |
| 普通字段 | `process.env[key] === remoteValue` 则 `skipped: unchanged` |
| 其余 | 进入 `changes` |

> 幂等：重复拉取相同配置不产生副作用、不无谓重写 `.env`。

### 2.4 复用 `applyChanges`（`config-service.js:132-219`）

`applyRemoteConfig` 把 diff 交给 `applyChanges(changes, {isGuarded})`，走标准校验/持久化链路：

- envHash 乐观并发：**remote 不传 envHash**（`config-service.js:390`），**不做**并发控制（以远程为准覆盖）
- `webEditable` 策略校验 + guarded 安全键拒绝
- `convertValue` 类型转换 + `validateWithSchema` 校验
- 加密字段：RSA 公钥（`config/public-config.pem`）**重新加密**后写入
- `process.env[key] = writeValue`
- 判断 `restartRequired` → `_pendingRestartKeys`

### 2.5 `_persistAndHotReload`（`config-service.js:225-305`）

```
writeEnvChanges(targetFile)
  ├─ guarded → .env.runtime
  └─ 非 guarded → .env
clearConfigCache() + loadConfig() → newConfig
agent.setRuntimeConfig(newConfig)              # 非连接参数立即生效
primaryClient/matcherClient.setRuntimeConfig    # 连接参数(baseURL/apiKey/provider/连接池) 标记 pendingRestart
contextManager.setRuntimeConfig
module-lifecycle.start(policy.moduleId)         # 启动未初始化模块（web 等待模式的关键热初始化入口）
LOG_LEVEL 热更新
```

### 2.6 安全模型

网关层三重防护：
1. **速率限制**（`middleware/rate-limit.js`）：默认 60 次/60s/客户端，按 `req.ip`
2. **API Key 鉴权**（`apiKeyAuth`，`server.js:91`）：配 `WEB_API_KEY` 时未认证请求在 body 解析前被拒
3. **guarded 安全键 `skipped`**（`config-service.js:360-363`）：远程下发也不落盘

远程传输机密性靠 HTTPS；`redactUrl()` 剥离日志中 URL 的 token/key/secret 参数。

### 2.7 加密处理

远程给明文 → diff 命中 → `applyChanges` 用公钥重新 RSA 加密 → 密文写回 `.env`/`.env.runtime`。**明文永不落盘**。

### 2.8 缓存

- `loadConfig` 的 `cachedConfig`：`_persistAndHotReload` 内 `clearConfigCache` → 重建
- SchemaProvider 磁盘缓存（`temp/schema-cache.json`）+ 并发去重（`_loadingPromises`）

---

## 3. 两种场景对比

| 维度 | 本地加载 | Gateway 远程加载 |
|------|---------|------------------|
| 触发 | 进程启动（四入口） | 运行时 `POST /api/config/remote` |
| 入口函数 | `BootstrapManager.loadEnvironment()` + `loadConfiguration()` | `ConfigService.applyRemoteConfig()` |
| 方向 | 磁盘 → `process.env`（只读） | 远程 → diff → 落盘 + 热更新（读写） |
| 范围 | 全量所有 env 键 | 增量，只应用变化的键 |
| 数据源 | 多源合并（.env + .env.runtime + CLI + 预设 + default） | 单一远程 HTTP 端点 |
| 加载机制 | `dotenv` + `decryptEnvConfig` | `fetch` POST + `A11n Bearer` + 归一化 |
| 认证 | 无（信任本地文件） | `A11n Bearer` + 网关 `WEB_API_KEY` |
| 加密 | 启动期**解密**密文→明文 | diff 后**重新加密**明文→密文落盘 |
| 落盘 | 不写盘（只读） | guarded→`.env.runtime` / 非 guarded→`.env` |
| 生效 | 冷启动 `new LLMClient` | `setRuntimeConfig` 热更新 |
| 缓存 | `loadConfig cachedConfig`（Phase 3 重建） | `clearConfigCache` 重建 + SchemaProvider 磁盘缓存 |
| 并发控制 | 无 | 不做 envHash 乐观并发（PATCH 才做） |
| 版本管理 | 无 | `meta.version` → `CONFIG_REMOTE_SCHEMA_VERSION` + 磁盘缓存版本比对 |
| 失败语义 | 签名失败→`ConfigError` 阻断启动 | `REMOTE_URL_MISSING`→422；429/5xx/网络→对应错误；推送不完整→env 已落盘但热更新跳过 |

### 关键差异

1. **安全模型**：本地靠签名+文件信任；远程靠网关鉴权+安全键跳过。远程**不做**签名验证——guarded 下安全键根本不落盘，无需也无法校验。
2. **范围**：本地全量灌入；远程增量 diff（加密字段先解密本地密文再与远程明文对比），幂等。
3. **加密流向相反**：本地解密出明文；远程重新加密回密文。
4. **生效路径**：本地冷启动固化；远程 `setRuntimeConfig` 热更新（非连接参数立即生效，连接参数 `pendingRestart`）。
5. **并发控制缺口**：`PATCH /api/config` 有 envHash 乐观并发；`POST /api/config/remote` 不传 envHash，远程推送并发写盘检测不到本地外部改动——有意为之（远程"推送同步"以远程为准，非"协作编辑"）。

---

## 4. 协同：web 等待模式 + 远程推送 + 热初始化

两种场景在 enterprise 远程推送部署中协同：

```
启动（本地加载，primary 缺失）
  └─ web 等待模式：跳过 primary/matcher/agent；audit 延迟（见 4.1）
       ↓ POST /api/config/remote（远程加载）
ConfigService.applyRemoteConfig → applyChanges → _persistAndHotReload
  └─ module-lifecycle.start('primary')（热初始化）
       ├─ 刷新 state.config = primaryConfig（修复 b5e16ec）
       ├─ _initializePrimary + _initializeMatcher + _createAgent + onClientsReady
       └─ 顺带 start('audit') + start('background')
```

### 4.1 各模块在 web 等待模式下的就绪差异

audit 之所以特殊：启动期被 `_finalizeAgentInit` **直接**调用（`manager.js:274`），**绕过** `module-lifecycle.start` 的 `requiredKeys` 前置校验，且 fallback 到 primary。三者叠加才崩。

| 模块 | 启动期 web 等待 | 热初始化 `start()` | fallback 到 primary 安全性 |
|------|----------------|---------------------|---------------------------|
| **audit** | `_finalizeAgentInit` 直接 `_initializeAudit(state.config)`；**修复后**加 `&& agentReady` 守卫跳过（`manager.js:273-280`） | 经 `start` 前置校验；`start('primary')` 顺带 `start('audit')` 用刷新后的完整 `state.config` | 修复前 fallback 到 partial 崩；修复后延迟至 primary 就绪 |
| **matcher** | 被 `manager.js:231-233` 跳过 | 经 `start` 前置校验（`module-lifecycle.js:92-96`），三键不全直接返回 misconfigured；三键全用独立配置 | `_initializeMatcher` fallback 只在 primary 已就绪场景触发（完整初始化 / `start('primary')`），fallback 到完整 config ✓ |
| **background** | `loadBackgroundConfig()` null → warn+skip（`manager.js:292-294`） | 经 `start` 前置校验；null → throw → 被 catch 返回 misconfigured | **无 primary fallback**（`loadBackgroundConfig` 不传 `primaryConfigFallback`），天然免疫 |

### 4.2 audit 未就绪期间的安全链

- web 等待模式（agent 未创建）：`chat-handler.js:24` 的 `!agent` 守卫先拦，chat 走不到 audit
- primary 热就绪后紧接 `start('audit')`（窗口极小）：万一有 chat，`performAuditReview(null)`（`chat-common.js:13-14`）直接放行不崩
- audit 就绪后恢复正常审查

### 4.3 完整初始化路径的 fail-fast 保留

`agentReady=true`（TUI/CLI/配置齐全的 Web）路径：audit 仍强制初始化、配置缺失仍 fail-fast（`test-bootstrap-manager.js` 验证）。enterprise 合规语义未削弱，仅把 audit 就绪时机从"启动期立即"改为"primary 就绪后紧跟"。

---

## 5. 相关文件索引

| 文件 | 职责 |
|------|------|
| `src/bootstrap/manager.js` | 四阶段初始化编排；`.env.runtime` 加载；`_finalizeAgentInit`（audit 守卫）；`isPrimaryConfigReady` |
| `src/bootstrap/scene-config.js` | `SCENE_PRESETS` + `applyScenePreset` + `isGuardedScene` |
| `src/bootstrap/env-guard.js` | `.env` RSA 签名验证（guarded） |
| `src/services/config-service.js` | `applyRemoteConfig`（diff）+ `applyChanges` + `_persistAndHotReload`（热更新） |
| `src/services/module-lifecycle.js` | `start/stop` 生命周期；`MODULE_DEFS`（requiredKeys + enableKey）；`start('primary')` 顺带启动 audit/background |
| `src/utils/config/schema-provider.js` | 远程 fetch + 归一化 + 磁盘缓存 + 版本管理 |
| `src/utils/config/llm-profiles.js` | `loadAuditConfig`/`loadMatcherConfig`/`loadBackgroundConfig` + fallback 链 + `getConfigSummary` |
| `src/utils/config/index.js` | `loadConfig` / `clearConfigCache` |
| `src/utils/config/env-writer.js` | `.env`/`.env.runtime` 原子写入 + envHash |
| `src/utils/config-decrypt.js` | RSA-OAEP 加解密 |
| `src/gateway/routes/config.js` | `POST /api/config/remote`、`/schema`、PATCH 等路由 |
| `src/gateway/server.js` | Web 入口 `mode: "web"`、`onClientsReady` 接线 |
| `src/gateway/middleware/rate-limit.js` | 60/60s 内存限流 |
| `src/gateway/chat-handler.js` + `chat-common.js` | `!agent` 守卫 + `performAuditReview(null)` 放行 |
| `config/env-config-schema.json` | 默认值、分组、加密标记 |
| `.env` / `.env.runtime` | 主配置 / 运行时覆盖层 |

> 详见 [`config-loading-flow.md`](./config-loading-flow.md)（启动时序 + 缓存机制）、[`scene-bootstrap-design.md`](./scene-bootstrap-design.md)（场景预设）、[`web-ui-dynamic-env-config-plan.md`](./web-ui-dynamic-env-config-plan.md)（Web 动态配置设计）。
