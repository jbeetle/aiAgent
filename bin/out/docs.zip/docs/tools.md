# src/tools/ 工具系统分析

## 整体架构

```
src/tools/
├── index.js              # 入口：注册、初始化、过滤、执行分发
├── plugin-loader.js      # 插件加载器（从 plugins/tools/ 动态加载）
├── exec-skill-helpers.js  # exec_skill 隔离/解密/产出收集辅助函数
│
├── 文件读写
│   ├── read.js           # 读取（文本/Excel/图片），入口 → read/{text,excel,image}.js
│   ├── write.js          # 写入（文本/Excel，支持设计系统样式）
│   └── edit-file/        # 精确文本替换（≥200行文件），含模糊匹配/冲突检测/diff
│       ├── index.js
│       ├── matcher.js    # Unicode规范化 + 三级降级模糊匹配
│       ├── conflict.js   # 唯一性 + 重叠检查
│       └── diff.js       # diff/patch 生成
│
├── 文件系统操作
│   ├── list.js           # 目录列表（Markdown/JSON格式，支持递归/过滤/gitignore）
│   ├── glob.js           # 文件模式匹配（ripgrep快速路径 + glob库fallback）
│   ├── search.js         # 文件内容搜索（ripgrep + Node.js双引擎）
│   ├── file-ops.js       # copy_path / move_path / delete_path（含关键路径保护）
│   └── archive/          # ZIP压缩/解压/列表（支持PowerShell加速路径）
│       ├── index.js
│       └── ps-zip.js
│
├── 命令执行
│   ├── exec.js           # 通用Shell命令（双层安全审计 + 工作目录隔离）
│   ├── exec-skill.js     # 技能脚本执行（隔离沙箱/加密解密/输出收集）
│   └── exec-common/      # 共享执行引擎
│       ├── index.js      # runCommand 编排器
│       ├── process.js    # 进程管理（execWithPid, killProcessTree）
│       ├── shell.js      # Shell检测 + cwd脱敏
│       └── formatter.js  # 输出格式化（成功/错误/截断）
│
├── 网络
│   ├── download.js       # HTTP/HTTPS文件下载（重定向跟踪/文件名智能检测/SSRF防护）
│   ├── web-fetch.js      # 网页内容抓取（cheerio解析/HTML→Markdown转换/噪音过滤）
│   └── http-request.js   # REST API请求（GET/POST/PUT/DELETE等全部方法）
│
├── 系统 & 杂项
│   ├── time.js           # 时间操作（now/format/add/diff/parse）
│   ├── clipboard.js      # 剪贴板读写
│   ├── system-info.js    # 系统信息（OS/内存/CPU/地理定位，敏感字段默认脱敏）
│   ├── open.js           # 用系统默认程序打开文件/URL/应用
│   └── skill-view.js     # 技能信息查看（解析SKILL.md frontmatter + 链接文件发现）
│
└── 高级
    ├── python-ptc/       # Python程序化工具调用（沙箱化Python代码执行+工具调用代理）
    │   ├── index.js      # 主入口：Python检测/安全扫描/子进程管理
    │   ├── helpers.js    # Python查找/临时目录管理等
    │   └── stub-generator.js  # Python stub生成
    └── read/             # 文件读取子系统
        ├── text.js       # 文本读取（多编码/分页/截断）
        ├── excel.js      # Excel读取（xlsx/xls → JSON/CSV/Markdown）
        └── image.js      # 图片读取（视觉模型分析）
```

## 一、核心注册机制 (`index.js`)

| 功能 | 说明 |
|------|------|
| **buildTool** | 统一包装：从模块提取 `description`、`parameters`、`execute` |
| **内置工具** | 21个内置工具一次性构建为 `tools` 对象 |
| **插件加载** | `initializeTools()` 异步加载 `plugins/tools/` 下插件，合并到 `tools` |
| **黑名单过滤** | `DISABLED_TOOLS` 环境变量过滤，支持逗号分隔，空值=全部启用 |
| **线程安全** | `initializeTools` 用 Promise 锁防止并发初始化 |

**初始化流程**：
1. `buildBuiltInTools()` 构建 21 个内置工具
2. `loadPlugins()` 扫描 `plugins/tools/` 目录加载 3 个插件工具
3. `DISABLED_TOOLS` 环境变量黑名单过滤
4. `initializing` Promise 防止并发初始化，`initialized` 标志防重复

## 二、21 个内置工具分类与能力矩阵

### 文件 I/O 组（6个）

| 工具 | 核心能力 | 关键限制/特性 |
|------|----------|---------------|
| **read** | 文本(多编码/分页)、Excel(xlsx/xls→JSON/CSV/Markdown)、图片(视觉模型分析) | 文本≤300KB，Excel≤10MB，图片走视觉模型 |
| **write** | 文本写入 + Excel生成（支持设计系统 `styled:true`），同文件写队列串行化 | 文本≤300KB，Excel数据≤50MB，自动建目录 |
| **edit_file** | 精确文本替换，≥200行文件，模糊匹配+冲突检测+diff审计，全部成功或全部回滚 | min old_text长度，禁止重叠编辑，基于原始基线匹配 |
| **copy_path** | 递归复制文件/目录 | 需沙箱校验，禁止同路径复制 |
| **move_path** | 移动/重命名（跨驱动器自动fallback到cp+rm） | 需沙箱校验，禁止同路径移动 |
| **delete_path** | 递归删除（保护 `src/`、`skills/`、`plugins/` 等关键路径 + 系统路径） | 关键路径硬阻断，受 `isDangerousPath()` 保护 |

### 文件系统导航组（3个）

| 工具 | 核心能力 | 性能优化 |
|------|----------|----------|
| **list** | 目录列表，Markdown标题分组（# Folders/# Files），递归+模式过滤+类型过滤 | gitignore自动过滤，符号链接循环检测，2000结果硬上限，深度12限制 |
| **glob** | 文件模式匹配，支持stats/排序(name/modified/size)/截断，gitignore过滤 | ripgrep `--files` 快速路径，glob库fallback，5000结果硬上限 |
| **search** | 文件内容搜索，支持上下文行/正则/大小写敏感/排序(path/line/name) | ripgrep快速引擎，Node.js fallback，2000结果硬上限 |

### 命令执行组（2个）

| 工具 | 安全级别 | 隔离机制 |
|------|----------|----------|
| **exec** | 通用上下文（严格）：拦截 `rm -rf /`、`sudo`、管道转shell等危险模式 | cwd沙箱校验，禁止执行skills路径脚本（会提示改用exec_skill） |
| **exec_skill** | 技能上下文（宽松）：允许技能脚本执行，专用审计规则 | 隔离工作目录 + `--output`参数重映射 + 产出文件自动收集 + 加密技能解密 + 工作目录数量限制(50) |

> **`exec_skill` 隔离模式完整流程**：
> 1. `temp/skills/skill-{name}-{uuid}/` → 复制技能文件 + 解密 `.enc` 文件（如有）
> 2. `--output`/`-o`/`--dest`/`--file` 重映射到 `output/`（沙箱内）
> 3. 执行后扫描新文件 → 移至 `output/skill-{name}/` 命名空间
> 4. 返回 `producedFiles` 数组，技能子目录延迟清理

### 网络组（3个）

| 工具 | 用途 | 安全措施 |
|------|------|----------|
| **download** | HTTP/HTTPS文件下载 | SSRF防护(私有IP+云元数据阻断) + Content-Disposition文件名提取 + 重定向跟踪(5次) + 下载路径限制为output/temp子目录 |
| **web_fetch** | 网页内容抓取→Markdown | cheerio HTML解析 + 噪音元素过滤(script/style/nav/ads等) + 智能正文区域检测(article/main) + SSRF防护 |
| **http_request** | REST API调用(GET/POST/PUT/DELETE/PATCH/HEAD/OPTIONS) | SSRF防护 + 动态User-Agent(根据Node.js版本映射Chrome) + JSON自动解析 |

### 系统/工具组（4个）

| 工具 | 功能 |
|------|------|
| **time** | now(当前时间)、format(格式化)、add(加减ms/s/m/h/d/w/M/y)、diff(差值)、parse(解析) |
| **clipboard** | read(读取系统剪贴板)、write(写入文本) |
| **system_info** | OS/内存/CPU + 地理定位(ip-api.com，5分钟缓存)，**敏感字段(用户名/homedir/IP)默认脱敏**，需`ENABLE_SENSITIVE_SYSTEM_INFO=true`开启 |
| **open** | 用系统默认程序打开文件/URL/应用(fire-and-forget)，智能区分URL/应用名/文件路径 |

### 技能系统组（1个）

| 工具 | 用途 |
|------|------|
| **skill_view** | 解析SKILL.md的YAML frontmatter + Markdown指令体 + 自动发现`scripts/`/`references/`/`assets/`链接文件。支持子文件读取(`file_path`参数)，路径穿越保护，加密技能文件处理 |

### 高级工具组（1个）

| 工具 | 用途 | 安全机制 |
|------|------|----------|
| **python_ptc** | 在沙箱中执行Python代码，Python通过JSON-RPC调用Agent工具 | Python路径自动检测 + 代码安全扫描(文件访问/网络/子进程模式检测) + 子进程超时/资源限制 + 工具调用计数上限 |

### 压缩工具组（1个）

| 工具 | 用途 | 安全机制 |
|------|------|----------|
| **archive** | ZIP压缩/解压/列表 | ZipSlip防护(路径逃逸检测) + ZipBomb防护(条目数/解压大小限制) + AdmZip主路径 + PowerShell备选路径 |

## 三、插件工具 (`plugins/tools/`)

| 插件 | 状态 | 说明 |
|------|------|------|
| **send-email** | 已部署 | SMTP邮件发送，支持SMTP_HOST/PORT/USER/PASS配置 |
| **calendar** | 已部署 | Outlook/ICS日历操作 |
| **chrome-automation** | 已部署 | Playwright浏览器自动化(基于Chrome CDP) |
| **pandoc** | 空目录 | 预留，未实现 |
| **ripgrep** | 静态二进制 | `rg.exe` (Windows)，被混合FS引擎使用，非独立工具 |

## 四、安全设计纵深防御

| 层级 | 机制 | 覆盖工具 |
|------|------|----------|
| **路径沙箱** | `validateWorkspacePath()` / `validatePath()` — 限制访问项目根+CWD+SANDBOX_PATHS | 所有文件操作工具 |
| **命令审计** | `auditExecCommand()` — 拦截危险模式，区分 general/skill 上下文 | exec, exec_skill |
| **网络策略** | `validateUrl()` — 阻断私有IP、云元数据端点，IPv4/IPv6双栈 | download, web_fetch, http_request |
| **关键路径保护** | `isDangerousPath()` — 禁止删除 src/skills/plugins/等目录 | delete_path |
| **下载路径限制** | `validateDownloadPath()` — 只能保存到 output/ 或 temp/ 子目录 | download |
| **敏感信息脱敏** | `redactSensitiveFields()` — 默认隐藏用户名/homedir/IP | system_info |
| **Python安全扫描** | `scanSandboxBypass()` — 检测文件访问/网络/子进程模式 | python_ptc |
| **Zip安全** | ZipSlip路径逃逸检测 + ZipBomb条目数/大小双重限制 | archive |

## 五、设计模式总结

### 1. 统一接口
所有工具遵循 `{ description (string), parameters (JSON Schema), execute (async function) }` 签名。

### 2. 统一错误分类
使用 `src/utils/errors.js` 的 `Errors.*` 抛出 `ToolError`：

| 类型 | 可重试 | 典型场景 |
|------|--------|----------|
| `not_found` | 否 | 文件/目录不存在 |
| `permission` | 否 | 权限不足(EACCES) |
| `timeout` | 是 | 操作超时 |
| `validation` | 否 | 参数无效 |
| `network` | 是 | 网络错误 |
| `cancelled` | 否 | 用户取消(AbortSignal) |
| `security` | 否 | 安全策略阻断 |
| `unknown` | 是 | 未分类错误 |

### 3. 统一输出格式
大部分工具支持 `outputFormat: "json"` (结构化/AI友好) 和 `"text"` (人类可读) 双格式，默认 `json`。

### 4. 子模块拆分
`read/`、`edit-file/`、`archive/`、`exec-common/`、`python-ptc/` 采用目录+index.js模式，职责清晰，对外暴露统一入口。

### 5. 插件体系
`plugin-loader.js` 支持从 `plugins/tools/` 动态加载，每个插件需：
- `package.json`（含 name + dependencies）
- 导出 `default` 函数或 `initTool` 命名导出
- `initTool(context)` 接收 `{ Errors, ErrorTypes, logger }` 基础设施
- 返回单个工具定义或 `{ tools: [...] }` 数组

### 6. 同文件写队列
`write` 工具使用 `withWriteQueue()` 对同一文件串行化并发写入，防止竞争条件。不同文件可并行。

### 7. 性能优化点
- **search/glob**：ripgrep 快速路径 + Node.js 降级
- **exec 截断**：大文本逐字符扫描避免 `split('\n')` 创建巨大数组
- **system-info**：IP 地理定位 5 分钟缓存
- **list**：gitignore 过滤器按需构建
- **archive**：PowerShell 加速路径（Windows Native API）
