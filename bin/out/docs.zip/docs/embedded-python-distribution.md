# 内嵌 Python 运行时与发布策略

> 版本：v1.0 | 2026-07-31 | 状态：已确认（部分已实现）
> 背景事件：2026-07-30 天气技能执行失败事故
> 适用范围：RatelAI 对外发布（金融企业客户，办公网不联互联网）

---

## 1. 背景与问题起源

2026-07-30，commit `658554f` 引入"嵌入式 Python 检测"后，原本 3-4 步即可完成的天气技能查询（`henry-city-weather`）连续失败 7 轮后跑偏。事故日志显示 agent 反复执行技能脚本失败 → 尝试 pip 安装无效 → 最终引用旧仓库路径触发沙箱安全违规。

本文档记录该事故的根因分析、由此沉淀的 pip/内嵌 Python 机制认知，以及在此基础上确认的对外发布策略。

---

## 2. 事故根因分析

### 2.1 完整因果链

| # | 环节 | 说明 |
|---|------|------|
| 1 | PATH 前置 | `BootstrapManager.initializeSystem()` 检测到 `plugins/python/python.exe` 后，将其与 `Scripts/` **前置（prepend）** 到 PATH |
| 2 | python 解析被劫持 | agent 派生的所有子进程中 `python` 解析到**内嵌 Python 3.14.6**（无 requests 等第三方包），而非系统 `C:\Python314\python.exe`（已装齐依赖）→ 技能脚本连续 `ModuleNotFoundError`（日志迭代 2-4） |
| 3 | pip 安装"假成功" | `plugins/python` 目录拷贝自旧仓库 `C:\workdir\git\CoQiClaw`，`Scripts/pip.exe` 启动器烧录的是**旧仓库绝对路径**，pip 实际检查/操作旧仓库环境，输出 "Requirement already satisfied"，本仓库内嵌 Python 依然缺包（迭代 5-6） |
| 4 | 致命跑偏 | pip 输出中的旧仓库路径被 LLM 获知，agent 尝试 `cd C:\workdir\git\CoQiClaw\...` 直接执行 → 路径在沙箱外，触发 fatal security error（迭代 7） |

### 2.2 设计缺陷定位

PATH 全局前置把"python_ptc 专用沙箱运行时"与"技能脚本的 python 解析"混为一谈。python_ptc 使用绝对路径 spawn 内嵌解释器，本就不依赖 PATH；被波及的恰恰是 exec_skill/exec。

### 2.3 同期修复（2026-07-30）

- `src/bootstrap/manager.js`：PATH **prepend 改为 append**（系统 Python 优先，内嵌运行时兜底）
- 重装内嵌 pip（`python.exe -m pip install --force-reinstall pip`），重建指向当前路径的启动器
- 删除 WindowsApps 的 python.exe/python3.exe 应用执行别名存根（静默失败隐患，exit 49 无输出）

---

## 3. pip / 内嵌 Python 机制关键认知

以下认知是后续所有方案讨论的基础，均已实测验证。

### 3.1 pip 的两个组成部分

| 组成 | 位置 | 可移植性 |
|------|------|---------|
| pip 包本体 | `Lib/site-packages/pip/`（纯 Python 库，全部安装逻辑） | **可移植**，目录整体拷贝可用 |
| pip 启动器 | `Scripts/pip.exe`（pip3.exe / pip3.x.exe，~108KB 同一二进制三份拷贝） | **不可移植**，二进制尾部烧录安装时刻的 python.exe 绝对路径（`#!C:\...\python.exe`）+ 入口引导脚本 |

- 任何带命令行入口的包安装时都会在 `Scripts/` 生成同款启动器（uvicorn.exe、pytest.exe 等），同样烧录绝对路径。
- **目录迁移后所有 `Scripts/*.exe` 启动器全部失效**；修复方式是重装对应包重新生成。
- 启动器路径烧死既是坑也是特性：多 Python 共存机器上，pip 命令精确对应安装它的解释器，不受 PATH 影响。

### 3.2 三条操作规则

1. **每个 Python 解释器有独立的 site-packages**，装进 A 的包 B 看不到（"pip 装了但 import 失败"的第一嫌疑）。
2. **永远优先 `python.exe -m pip`，不用裸 `pip`**。`-m` 让当前解释器运行自己的 pip 模块，装包方与使用方必然是同一个解释器，且绕开启动器路径问题。
3. **内嵌版（embeddable）定位是"随应用分发的最小运行时"**：出厂无 pip、无 ensurepip（`python -m venv` 不可靠）、带 `pythonXX._pth` 隔离文件（相对路径定位自身 site-packages，因此整个目录 xcopy 可移植）。

### 3.3 联网行为

| 操作 | 联网 |
|------|------|
| `python -m pip install <任何包>`（默认） | 需要（访问 PyPI） |
| `python -m ensurepip`（离线引导 pip） | 不需要，但**内嵌版无此模块**（已实测） |
| `python -m pip install --no-index --find-links=<whl目录> <包>` | 不需要（whl 摆渡方案） |
| `pip download <包> -d <目录>`（联网机器收包） | 需要；自动收齐依赖 whl |

---

## 4. 发布策略（已确认决策）

### 4.1 前提约束

- 客户为金融企业，**办公网不联互联网**；临时外网需申请审批
- 应用安装在**每用户目录**（`%LOCALAPPDATA%\<产品名>`）：用户可写、无 UAC、无 Program Files 权限问题
- 安装目录由客户自选（A/B 目录均可），一切路径必须运行时计算

### 4.2 核心策略：依赖在打包时烘焙，而非客户安装后执行

```
打包机（发布前）：plugins\python\python.exe -m pip install <全部技能依赖>
  → 包进入 Lib\site-packages\（相对路径，自包含）
  → 整个 plugins\python 目录打进安装包
客户：双击安装到任意目录 → 直接可用，零命令、零联网
```

- pip 只是**打包工具**，不是用户的安装工具；客户侧运行时不需要执行任何 pip 命令
- Python 自身定位（`._pth` 相对路径）与程序定位 Python（`getBaseDir()` 运行时拼绝对路径）均与安装目录无关
- 唯一带绝对路径的 `Scripts/*.exe` 启动器运行时本不被程序调用（由 4.4 修复兜底）

### 4.3 pip 随包保留

客户可能安装新技能，其脚本依赖出厂未装的包。典型流程：用户申请临时外网 → 获批 → 指挥 agent 装包。因此 **pip（~10MB）必须随包发布**，作为产品的运行时扩展能力。（"删 pip 省体积"仅适用于完全封闭产品，已被否决。）

### 4.4 运行时装包的两个坑与对策

**坑 1：客户机上 `Scripts/pip.exe` 必然失效**（烧录的是打包机路径）。
对策（均已实现，见 §5）：
- 首启时 `ensurePipLaunchers()` 检测烧录路径，不匹配则用随包 `plugins/python/wheels/pip-*.whl` **离线重建**启动器
- exec_skill 引导语规范 agent 用 `python -m pip install`（不依赖启动器）

**坑 2：安装目录权限**。因安装在 `%LOCALAPPDATA%`，用户可写，**此坑不存在**——运行时后装的包直接装进内嵌 Python 的 site-packages，无需 `--target`/`PYTHONPATH` 机制。

### 4.5 升级丢包策略（已拍板）

升级覆盖安装目录时 `plugins/python` 被整体替换，**用户后装的包丢失——接受此行为**，不做持久化机制；下次技能报 `ModuleNotFoundError` 时由 agent 自动重装自愈。

推论：装包路径正确性因此成为**生命线**（自愈是唯一补给线），§4.4 的两项对策为必选项。配套加速器（已实现）：工具结果检测到 `ModuleNotFoundError`/`Cannot find module` 时自动附装包 hint，agent 一轮即可自愈。

### 4.6 PATH 顺序

内嵌 Python 目录 **只 append 不 prepend**：系统 Python（含完整依赖）优先；客户机无系统 Python 时内嵌版兜底。python_ptc 用绝对路径 spawn，不受影响。

### 4.7 离线/内网配套

- 打包机本身离线时：联网机器 `pip download <包> -d wheels` → 摆渡 → `python -m pip install --no-index --find-links=wheels <包>`
- 安装包附 `plugins/python/wheels/`（至少含 pip 自身 whl），供首启修复与运维应急
- 客户若有内部 PyPI 镜像（Nexus/Artifactory/devpi），配置 `PIP_INDEX_URL` 环境变量，运行时装包可免临时外网申请（**待与客户运维确认**）

---

## 5. 已实现清单（2026-07-31）

| 文件 | 内容 |
|------|------|
| `src/bootstrap/python-launchers.js`（新增） | `ensurePipLaunchers()`：shebang 提取 → 路径比对 → 离线重建；失败仅告警不阻断启动 |
| `src/bootstrap/manager.js` | PATH append（事故修复）+ 接线 `ensurePipLaunchers()` |
| `scripts/download-runtime-wheels.js`（新增）+ `package.json` | `npm run prepare:wheels` 一键下载 pip wheel；已备好 `pip-26.2-py3-none-any.whl` |
| `src/tools/exec-skill.js` | 引导语：Python 用 `python -m pip install`（禁裸 pip/pip3）；Node 用 `npm install`（技能目录下） |
| `src/utils/shell-utils.js` | `buildDependencyHint()`：Python `ModuleNotFoundError`（含 dotenv→python-dotenv 等 8 个包名映射）+ Node `Cannot find module/package`（CJS/ESM，跳过相对路径与 `node:` 内置，处理 @scope） |
| `src/tools/exec-common/formatter.js` | 失败结果注入 `hint`（用未截断原始输出检测；exec 与 exec_skill 均受益） |
| `src/tools/exec-common/process.js` | **存量 bug 修复**：`execWithPid` 失败时挂载 stdout/stderr 到 error（Node exec 的 error 对象不携带输出——此前 agent 看不到任何失败命令的报错内容，是事故中 agent 盲试 6 轮的部分原因） |
| `scripts/collect-skill-python-deps.js`（新增） | 技能依赖聚合扫描器：requirements.txt 解析 + 全量 .py import 扫描（过滤标准库/本地模块/测试目录，import 名→pip 包名映射）。用法：`node scripts/collect-skill-python-deps.js <skills目录>` |

验证：dependencyHint 五种场景（Python 缺包/包名映射/Node CJS/Node ESM/相对路径不误报）全部正确；离线 whl 重建幂等成功；`test-exec-skill` 24/24、`test-exec-policy` 3/3 通过。

### 5.1 首次依赖烘焙执行记录（2026-07-31，源：`CoQiClaw/dist/skills`，34 个技能）

- 扫描结果：24 个技能有第三方依赖，12 个带 requirements.txt；import 扫描额外发现 requirements 未声明的依赖（pdf2image、pytesseract、reportlab），验证了双轨扫描的必要性
- 烘焙安装：23 个直接依赖 + 27 个传递依赖共 50 包，全部获得 cp314/win_amd64 wheel，**24/24 模块 import 验证通过**
- 已装清单：pandas、numpy、matplotlib、openpyxl、python-docx、python-pptx、pypdf、pymupdf、pdfplumber、pdf2image、pytesseract、Pillow、lxml、beautifulsoup4、reportlab、PyYAML、defusedxml、httpx、jieba、wordcloud、chardet、tqdm、pytest、python-dotenv
- 烘焙后体积：**315MB**（site-packages 287MB；大头 pandas 69M / pymupdf 53M / jieba 42M / numpy 55M / matplotlib 33M）；已清理 `__pycache__`（打包前需再清一次，import 测试会重新生成）

---

## 6. 发布流水线检查清单

- [ ] 汇总各技能依赖，打包前执行 `plugins\python\python.exe -m pip install -r <依赖清单>`
- [ ] 执行 `npm run prepare:wheels`（pip 版本变更时重跑）
- [ ] 打包前 smoke test：将 `plugins/python` 复制到临时目录，验证 `python.exe -c "import requests"` 等关键包可导入（模拟客户任意目录）
- [ ] 与客户运维确认内部 PyPI 镜像，必要时在产品环境变量中预置 `PIP_INDEX_URL`

---

## 7. 遗留事项与风险

| 项 | 说明 | 优先级 |
|----|------|--------|
| 内部 PyPI 镜像 | 未确认客户是否有；有则运行时装包体验质变 | 中 |
| 旧仓库残留 | `C:\workdir\git\CoQiClaw` 仍在磁盘且内嵌 Python 依赖齐全，曾诱发 LLM 引用旧路径；确认无用后建议移除（仅开发机问题） | 低 |
| skill-cipher 私钥异步加载竞态 | 启动后极短时间内执行加密技能可能误报 "no private key available"；真实启动流程不会触发 | 低 |
| test-exec-mode 1 例存量失败 | lenient 模式白名单语义分歧，与本次改动无关（已 stash 验证） | 低 |
| `SKILL_PYTHON_VENV` 与内嵌版 | 内嵌 Python 无 ensurepip，不要指望用它为技能自动建 venv；该机制依赖系统 Python | 备注 |
| 外部组件依赖（非 pip 可解决） | `pytesseract` 需客户机安装 **Tesseract OCR 引擎**（tesseract.exe）；`pdf2image` 传统路径需 **Poppler**（1.17+ 已随装 pypdfium2 可作后端，需按技能代码确认）。涉及技能：cmbi-invoice-scan-payment-list、cmbi-security-weekly-review、cmbi-document-qa、resume-analyzer。发布前需评估：随包附带 tesseract 便携版，或在技能文档声明前置要求 | **高** |
| 发行体积 | 烘焙后内嵌 Python 315MB。若需瘦身：可按发行 SKU 拆分技能集（excel 系才需 pandas/matplotlib/numpy ~160M；cmbi 系主要为 docx/pptx/pdf 类）；`jieba` 42M 仅 resume-analyzer 使用 | 中 |
