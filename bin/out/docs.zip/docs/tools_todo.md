# src/tools/ 代码审查报告

> 审查范围：`src/tools/` 目录全部工具模块 + `src/security/security.js`
> 审查日期：2026-04-25

---

## 一、安全问题（5项）

### 1. python -c 白名单放行任意代码执行
- **文件**：`src/security/security.js:125`
- **问题**：`isAllowedComplexCommand` 将 `python -c` 视为安全命令，但 `-c` 参数可执行任意 Python 代码（如 `python -c "import os; os.system('rm -rf /')"`），与直接 shell 执行等价。
- **建议**：从白名单中移除 `python -c`，或增加严格的参数校验（仅放行已知安全的内联表达式）。
- **严重级别**：高

### 2. exec.js resolveOutputParam 不支持带空格路径
- **文件**：`src/tools/exec.js:637-668`
- **问题**：`resolveOutputParam` 使用 `[^\s"']+` 匹配路径，无法识别带引号的空格路径，如 `--output "path with spaces/file.txt"`。
- **建议**：支持带双引号/单引号的路径参数解析，提取引号内的完整路径值。
- **严重级别**：中

### 3. exec.js 引号内转义字符处理不完整
- **文件**：`src/tools/exec.js:172-218`
- **问题**：`validateCommandPathArguments` 使用正则 `\"([^\"]*)\"` 提取引号内容，无法处理转义引号（如 `\"`）。对于 `python -c "print(\"C:\\\\path\")"` 会错误分割路径。
- **建议**：使用状态机逐字符解析，正确处理转义序列。
- **严重级别**：中

### 4. path-sandbox.js SANDBOX_MODE=off 日志级别过高
- **文件**：`src/security/path-sandbox.js:81-88`
- **问题**：`mode === 'off'` 时使用 `logger.error` 记录，但这是用户显式配置的行为，不应使用 error 级别，会污染错误日志。
- **建议**：降级为 `logger.warn` 或 `logger.info`。
- **严重级别**：低
- **状态**：✅ 已修复 — `logger.error` 改为 `logger.warn`

### 5. http-request / download 无响应大小限制
- **文件**：`src/tools/http-request.js`、`src/tools/download.js`
- **问题**：两个工具均未限制响应体大小，恶意服务端可能返回超大响应导致内存耗尽（OOM）或磁盘占满。
- **建议**：
  - `http_request`：添加 `maxResponseSize` 参数（默认如 5MB），超过时截断或报错。
  - `download`：添加 `maxDownloadSize` 参数（默认如 500MB），结合流式读取时实时监控大小。
- **严重级别**：中

---

## 二、功能缺陷（4项）

### 6. 跨驱动器文件移动失败（Windows）
- **文件**：`src/tools/exec.js:604`
- **问题**：`collectProducedFiles` 中使用 `fs.renameSync(filePath, destPath)`，Windows 上跨驱动器重命名会抛出 `EXDEV` 错误。
- **建议**：增加 copy + delete 的 fallback 逻辑：
  ```js
  try {
    fs.renameSync(filePath, destPath);
  } catch (err) {
    if (err.code === 'EXDEV') {
      fs.copyFileSync(filePath, destPath);
      fs.unlinkSync(filePath);
    } else {
      throw err;
    }
  }
  ```
- **严重级别**：高
- **状态**：✅ 已修复 — `EXDEV` 时自动 fallback 到 `copyFileSync + unlinkSync`

### 7. 下载重定向无次数限制
- **文件**：`src/tools/download.js:168-176`
- **问题**：`downloadFile` 递归处理 3xx 重定向，无重定向次数限制，可能因恶意重定向链导致栈溢出或无限循环。
- **建议**：增加 `maxRedirects` 参数（默认 10 次），达到上限时报错。
- **严重级别**：中

### 8. GBK 文件截断产生乱码
- **文件**：`src/tools/read.js:114-122`
- **问题**：文本截断逻辑 `buffer.toString('utf-8', 0, truncatePos)` 对 GBK 编码文件会产生乱码，因为 `buffer` 是原始 GBK 字节流。
- **建议**：GBK 编码时跳过字节级截断，改用解码后的字符串长度截断（如 `content.substring(0, maxChars)`）。
- **严重级别**：中
- **状态**：✅ 已修复 — 非 UTF-8 编码时改用 `content.substring(0, maxChars)` 截断

### 9. waitForNetworkIdle 事件监听竞态泄漏
- **文件**：`src/tools/chrome-cdp.js:1104-1113`
- **问题**：超时 resolve 时调用 `cleanup()`，但如果 Promise 在 `resolve` 后、`cleanup` 执行前被 reject，可能出现 `messageHandler` 未被移除的竞态条件。
- **建议**：将 `isResolved` 标记和 `cleanup()` 调用放在原子操作块中，确保 handler 一定被移除。
- **严重级别**：低

---

## 三、代码质量问题（5项）

### 10. chrome-cdp.js 文件过大，职责不单一
- **文件**：`src/tools/chrome-cdp.js`（2600+ 行）
- **问题**：单个文件包含 CDP 连接管理、页面导航、元素交互、内容提取、网络捕获、多标签页管理等全部功能，维护成本高。
- **建议**：按功能拆分为多个文件：
  - `chrome-cdp-connection.js` — WebSocket 连接池、CDPClient 类
  - `chrome-cdp-page.js` — 页面管理（list/new/navigate/close）
  - `chrome-cdp-interaction.js` — 元素交互（click/fill/wait）
  - `chrome-cdp-extract.js` — 内容提取（snapshot/table/list/text）
  - `chrome-cdp-network.js` — 网络相关（idle/captureResponses/block）
- **严重级别**：中（维护性）

### 11. exec.js 输出截断逻辑过于冗长
- **文件**：`src/tools/exec.js:293-416`
- **问题**：`truncateLines`、`truncateBySize`、`findValidUtf8Boundary`、`processOutput` 四个函数共 120+ 行，组合逻辑分散。
- **建议**：封装为统一的 `truncateOutput(stdout, stderr, options)` 策略函数，将行截断和大小截断内聚。
- **严重级别**：低

### 12. index.js 导出 mutable 全局对象
- **文件**：`src/tools/index.js:76-80`
- **问题**：`export let tools = buildBuiltInTools()` 允许任何模块直接修改 `tools` 对象，副作用难以追踪。
- **建议**：改为不可变导出 + 显式注册 API，如 `export function getTool(name)` 和 `export function registerTool(name, tool)`。
- **严重级别**：低

### 13. plugin-loader.js 使用同步 I/O
- **文件**：`src/tools/plugin-loader.js:21-22`
- **问题**：`async function loadPlugins()` 内部使用 `fs.readdirSync`。
- **建议**：改为 `fs.promises.readdir` 保持一致性（虽然实际影响极小）。
- **严重级别**：低

### 14. list.js 递归使用 fs.readdirSync
- **文件**：`src/tools/list.js:131-251`
- **问题**：`listDir` 递归函数使用同步 API，在大目录下会阻塞事件循环。
- **评估**：考虑到 `MAX_RESULTS = 2000` 和 `MAX_RECURSIVE_DEPTH = 12` 的限制，实际影响有限，可接受。如后续有性能需求，可改为异步递归。
- **严重级别**：低（暂不修复）

---

## 四、优化建议（3项）

### 15. exec.js shell 自动检测逻辑可简化
- **文件**：`src/tools/exec.js:781-801`
- **问题**：`isPowerShellCommand` 通过多个正则判断命令语法，维护成本高。
- **建议**：将 `shell` 参数的默认值改为动态推断，同时在返回结果中明确标注实际使用的 shell，便于 LLM 排查问题。

### 16. write.js 参数风格不统一
- **文件**：`src/tools/write.js`
- **问题**：`writeTextFile(path, content)` 与 `writeExcelFile(path, options)` 参数签名不一致。
- **建议**：统一为 `writeFile(path, { content, ...options })` 风格。
- **状态**：✅ 已修复 — `writeTextFile(filePath, { content })` 与 `writeExcelFile(filePath, options)` 风格统一

### 17. search.js ripgrep 降级逻辑缺少错误分类
- **文件**：`src/tools/search.js:102-111`
- **问题**：ripgrep 失败时直接抛错，不再尝试 Node.js fallback。未能区分"rg 未安装"（应降级）和"参数错误"（不应降级）两种情况。
- **建议**：根据错误类型判断是否降级，如 `error.code === 'ENOENT'` 时降级，其他情况直接报错。
- **状态**：✅ 已修复 — 区分 "Failed to spawn rg"（降级）与 rg 执行错误（直接抛错）

---

## 五、亮点

| 方面 | 评价 |
|------|------|
| exec.js 安全层 | 命令校验、路径参数沙箱检查、skill 模式隔离、UTF-8 安全截断，设计优秀 |
| chrome-cdp.js 多标签 | target session 缓存、竞态条件防护（pendingSessions dedup）、连接池复用 |
| 统一错误分类 | 所有工具均使用 `src/utils/errors.js`，错误类型一致、可追踪 |
| skill-view.js 路径防护 | `validateSubPath` 双重校验（skill 目录内 + 沙箱策略），严谨 |
| 输出截断 | 大文本性能优化（逐字符扫描代替 split）、UTF-8 多字节安全边界处理 |

---

## 优先级排序（建议修复顺序）

| 优先级 | 问题编号 | 说明 |
|--------|----------|------|
| P0 | 1 | 安全漏洞 |
| P1 | 5, 7 | 资源耗尽风险 + 功能缺陷 |
| P2 | 2, 3 | 边缘场景处理不完整 |
| P3 | 10 | 代码拆分（重构性质，影响面广） |
| P4 | 9, 11-15 | 低优先级优化和清理 |
| ✅ 已修复 | 4, 6, 8, 16, 17 | 日志级别 / 跨驱动器移动 / GBK截断 / 参数风格统一 / ripgrep 降级逻辑 |
