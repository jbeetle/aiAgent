# `src/core/` 代码审查报告

**审查日期**: 2026-05-22  
**审查人**: Claude (DeepSeek v4 Pro)  
**审查范围**: `src/core/` 目录下全部 8 个文件 + `llm/` 子包 6 个文件

---

## 目录结构

```
src/core/
├── agent.js              # 主编排器（技能匹配、上下文管理、委托执行）
├── agent-executor.js     # 执行循环（消息截断、并发工具调用、事件发射）
├── prompt-builder.js     # 系统提示构建（时间、环境、技能、工具、沙箱）
├── i18n.js               # 中英双语国际化（~280 行）
├── message-utils.js      # 消息格式化、过滤、大小估算、截断
├── llm.js                # LLM 子包入口（re-export）
└── llm/
    ├── client.js         # LLM HTTP 客户端（流式/非流式、thinking 配置、重试）
    ├── metrics.js        # Token 用量跟踪（环形缓冲区）
    ├── pricing.js        # 成本计算（策略模式）
    ├── res-helper.js     # 响应校验、thinking 标签清洗、JSON 提取
    └── summarize.js      # 上下文/对话摘要
```

---

## 整体架构评价

职责分离清晰：**Agent（编排） → AgentExecutor（执行循环） → LLMClient（HTTP 通信）**，三层递进。周边模块各司其职，没有循环依赖。

---

## 各模块详评

### 1. `agent.js` — 主编排器

**优点：**
- Agent 与 AgentExecutor 职责分离得当，编排逻辑清晰
- AbortController 所有权追踪机制（`ownsAbortController`），支持外部传入共享 controller 的正确生命周期管理
- 书挡策略（Bookending，第 189-213 行）：在 user message 尾部注入技能/工具匹配结果，利用 LLM 注意力 U 型曲线的尾部高峰强化执行遵循度
- 防御性检查贯穿全流程（null 检查、fallback prompt、try-catch 包裹摘要失败）

**问题：**
- `_summarizeAnswer` 以下划线前缀命名暗示私有，但同级的 `extractRecentContext`、`findRelevantSkillsOptimized` 无此前缀，命名约定不一致
- `findRelevantSkillsOptimized` 方法名带 "Optimized" 后缀，暗示曾有无优化版本，属于历史遗留命名

---

### 2. `agent-executor.js` — 执行循环

**优点：**
- EventEmitter 生命周期管理严谨：`destroy()` 正确处理 listener 清理和 AbortController 所有权判断（第 44-57 行）
- `checkAborted()` 使用 `isAgentAbort` 属性精确区分用户取消 vs 服务端取消，避免模糊的 `message.includes("cancelled")` 匹配
- 紧急截断策略精细（`emergencyTruncate`）：U 型保留（system + 首轮意图 + 最近轮次），当前轮过大时截断内容，历史过大时按轮次裁剪
- 增量大小估算：每 5 轮做一次完整 `calculateMessagesSize`，其余轮次用 `estimateMessageSize` 增量更新，避免频繁 JSON 序列化
- 并发工具调用 via `p-limit`，支持 `toolConcurrency` 配置
- 对 ToolError 保留原始 metadata（含 `fatal`/`reason`），不被 `getErrorInfo` 重包装丢失

**问题：**

1. **流式中断后 `streamHandle.result` 可能长时间悬挂**（第 296-298 行）
   ```javascript
   if (streamHandle) {
       streamHandle.result.catch(() => {});
   }
   ```
   当 `isDestroyed` 在流式消费中被触发（第 157-158 行 `break` 退出 for-await）时，`await streamHandle.result`（第 161 行）需等待底层 stream 自然结束或 abort 触发才能 resolve。如果 abort 信号未正确传递到 HTTP 层，这里会长时间悬挂。建议在 destroy 时主动终止底层 stream。

---

### 3. `prompt-builder.js` — 系统提示构建

**优点：**
- 各模块清晰组合（时间、环境、工具、沙箱、指令、技能、建议）
- 沙箱模式正确处理 `off`（不显示沙箱约束）、`warn`/`enforce`（显示目录约定，措辞不同）
- 时区偏移计算准确（`Intl.DateTimeFormat` + `getTimezoneOffset`）
- 技能列表输出 `skill_view({ name: "..." })` 调用格式，强化 LLM 使用专用工具而非 `read`

**问题：**
- `buildSandboxSection` 只有 `enforce` 和 `warn` 共用同一段逻辑（第 15-18 行仅区分 `off`），两者的 isStrict 差异仅影响措辞，设计合理无实际缺陷
- 工具建议显示为纯名称列表，无任何参数提示，对 LLM 选择工具的引导较弱

---

### 4. `llm/client.js` — LLM HTTP 客户端

**优点：**
- 流式/非流式双路径统一入口
- Thinking 配置通过 `buildThinkingConfig` 按提供商自动注入
- 内容安全检测覆盖多提供商（OpenAI `content_filter`、Azure `content_policy_violation`、DeepSeek `Content Exists Risk`）
- tool_call ID 缺失时生成 UUID fallback（第 329-337 行、第 457-466 行），避免多 tool_call 时 ID 碰撞
- 流式 tool_calls 按 index 合并 delta，支持增量拼接
- Usage 自动记录到 metrics

**问题：**

1. **`stream_options: { include_usage: true }` 兼容性风险**（第 187 行）
   这是 OpenAI 特有的参数，部分国产兼容提供商可能不认识此字段并报错。建议对已知不支持的提供商做条件判断。

2. **无效的 Promise catch 包装**（第 388-389 行）
   ```javascript
   result: resultPromise.catch((error) => {
       throw error;  // 原样重新抛出，等价于直接返回 resultPromise
   }),
   ```
   此 `.catch()` 没有做任何转换，是无效操作。

3. **`_rawChat` 方法名以下划线开头**，但被 `summarize.js` 外部调用（第 92 行 `client._rawChat`），说明这实际上是公共 API，命名有误导性。

---

### 5. `message-utils.js` — 消息格式化

**优点：**
- 乱码检测（`isGarbledText`）+ DLP 脱敏（`redactSecrets`）在工具结果进入 LLM 上下文前执行，安全分层到位
- 内容过滤器系统可扩展（`CONTENT_FILTERS.addPattern`）
- `estimateMessageSize` 避免每次都做完整 JSON 序列化，性能优化合理
- `truncateSingleMessage` 截断后附带末尾预览，帮助 LLM 理解截断内容

**问题：**

1. **与 `res-helper.js` 重复过滤 thinking 标签**
   `CONTENT_FILTERS.patterns`（第 22-28 行）的正则 `<thinking>`/`<think>` 与 `res-helper.js:58-95` 的 `sanitizeThinkingTags` 功能重叠。两处定位不同（通用内容过滤层 vs LLM 响应清洗层），但正则定义重复，未来修改需同步两处。

---

### 6. `i18n.js` — 国际化

**优点：**
- 完整的键值对设计，英文自动 fallback
- `getLocale()` 正确处理 `zh_CN.UTF-8` 等环境变量格式
- 覆盖全面（系统提示、匹配器提示、摘要提示、环境信息、免责声明）

**问题：**
- 内联翻译体量 ~280 行，中英双语时可控；若扩展到 3+ 语言建议拆分为 `locales/zh.js`、`locales/en.js`
- 部分中文翻译很长（如 `instructionSkillExec`），在 system prompt 中占用较多 token

---

### 7. `llm/metrics.js` — Token 跟踪

**优点：**
- 环形缓冲区设计正确（第 31-49 行），满 50 条后按 `_ringHead` 循环覆盖
- 支持 `costKnown` 字段区分价格未知/已知状态，报告输出时显示 `N/A`

**问题：**
- 环形缓冲区首次满时的逻辑（`_ringSize >= MAX_CALL_HISTORY`）正确但缺少注释说明，后续维护者可能疑惑
- `getUsageReport` 硬编码货币符号 `$`（第 58 行），非美元场景下不准确

---

### 8. `llm/pricing.js` — 成本计算

**优点：**
- 策略模式设计（`createDefaultPricingStrategy` / `createMockPricingStrategy`），可注入自定义定价
- 默认策略返回 `null`（成本未知），零额外开销
- 模型匹配使用 substring 包含关系，自动适配版本后缀（如 `qwen3-235b-a22b-instruct-2507` 匹配 `qwen3-235b`）

**问题：**

1. **价格表硬编码**（第 24-43 行）
   价格数据内联在代码中，会随时间过时。建议改为从 JSON 配置文件加载或由环境变量注入。

2. **模型匹配依赖 Object.keys 顺序**（第 58-60 行）
   ```javascript
   const modelKey = Object.keys(providerTable).find(k =>
       model.toLowerCase().includes(k.toLowerCase())
   );
   ```
   依赖 JavaScript 对象键的插入顺序，如果 `gpt-4o` 在 `gpt-4o-mini` 之后定义，`"gpt-4o-mini"` 会错误匹配到 `"gpt-4o"`。建议按 key 长度降序排列进行匹配。

---

### 9. `llm/res-helper.js` — 响应处理

**优点：**
- `validateResponse` 逐层校验 response 结构，报错信息含类型和截断的 JSON 原文
- `stripJsonPreamble` 的 `looksLikeJsonStart` 使用括号平衡检查而非简单正则，避免将自然语言中的 `{` 误判为 JSON 起始
- `sanitizeThinkingTags` 分两阶段（闭合标签 + 未闭合标签），覆盖截断输出场景
- `buildThinkingConfig` 覆盖 6 种提供商的不同 thinking 注入格式

**问题：**
- `sanitizeThinkingTags` 与 `message-utils.js` 的 `CONTENT_FILTERS` 重复（见上文 #5）
- 未闭合标签的检测使用两次正则（先 match 再 replace），可合并为一次

---

### 10. `llm/summarize.js` — 摘要

**优点：**
- `truncateAtSentence` 在标点边界截断，避免断句不完整（且只在截断点 >60% maxLength 时才保留标点，防止短摘要）
- `formatConversationRounds` 按配额比例分配 Q/A 截断长度
- `summarizeConversation` 输入预算 = 输出长度 × 6，压缩比合理
- 同时设置 `max_tokens` 和 `max_completion_tokens`，兼容旧模型和 OpenAI o1/o3/o4+

**问题：**

1. **`formatConversationRounds` 硬编码中文标签**（第 47-49 行）
   ```javascript
   return `[${i + 1}] 用户：${q}\n    助手：${a}`;
   ```
   英文环境下输出的摘要中包含中文 "用户"/"助手" 标签不协调，未使用 i18n。

---

## 问题汇总

| # | 文件 | 严重度 | 问题描述 |
|---|------|--------|----------|
| 1 | `pricing.js:24-43` | 中 | 价格表硬编码，随时间过时 |
| 2 | `client.js:187` | 中 | `stream_options.include_usage` 非所有提供商支持 |
| 3 | `summarize.js:47-50` | 低 | `formatConversationRounds` 硬编码中文标签，未 i18n |
| 4 | `message-utils.js:22-28` / `res-helper.js:5-12` | 低 | thinking 标签正则定义重复 |
| 5 | `client.js:388-389` | 低 | 无效的 `.catch()` 包装 |
| 6 | `agent-executor.js:157-158` | 低 | 流式中断后 result promise 可能悬挂 |
| 7 | `i18n.js` | 低 | 内联翻译不利于扩展到 3+ 语言 |

---

## 总结

整体代码质量高，架构清晰，错误处理和边界条件考虑充分。Agent → AgentExecutor → LLMClient 三层递进职责分明，紧急截断、并发控制、生命周期管理等关键路径设计精心。7 个发现的问题中无安全漏洞或逻辑错误，1 个中等问题（价格硬编码）和 1 个兼容性风险（`stream_options`）建议优先处理。
