# Chrome 工具上下文溢出根因分析与改进计划

## 背景

Agent 使用 Chrome 浏览器工具进行网上检索时，LLM 上下文频繁溢出，导致任务中断或进入错误循环。本计划基于对 `src/tools/chrome-*.js`、`src/core/agent-executor.js`、`src/core/message-utils.js` 的代码审查，识别根因并提出改进方案。

## 已完成的修复

### ✅ 修复 1：evaluateScript 变量隔离（运行时错误）

**问题**：`Runtime.evaluate` 在页面全局作用域执行脚本，`const`/`let` 声明会持久化，导致后续调用抛出 `Identifier 'x' has already been declared`。

**修复**（`chrome-cdp.js`）：
- 添加 `wrapEvaluateScript()` 函数，根据脚本内容选择两种隔离策略：
  - **含 `return` 或 `await` 的脚本** → 包装为 `async IIFE`，支持显式 `return` 和 `await`
  - **其他脚本** → `eval()` 嵌套在 IIFE 中，每个 `eval()` 调用获得独立的词法环境，既隔离变量又保留脚本完成值（completion value）
- 错误行号调整：对 async IIFE 包装器的行偏移进行修正，使报错位置指向用户原始脚本

**测试**：`test/test-chrome-cdp.js` 新增测试用例 `[9b]` 和 `[9c]`

### ✅ 修复 2：evaluateScript 智能截断 + 4 个 chrome 工具紧凑 JSON

**问题**：`evaluateScript` 返回值无大小限制；4 个 chrome 工具 wrapper 使用 `JSON.stringify(result, null, 2)` 浪费 25-30% token。

**修复**：
- `chrome-cdp.js:evaluateScript`：添加 `maxLength` 参数（默认 10000），按内容类型智能截断：
  - HTML 源码 → 去标签转纯文本
  - JS/CSS 代码 → 丢弃，仅返回类型和长度提示
  - JSON 数据 → 结构化截断（缩短数组保留结构）
  - 纯文本 → 直接截断
- `chrome-nav.js` / `chrome-interact.js` / `chrome-extract.js` / `chrome-env.js`：`JSON.stringify(..., null, 2)` → `JSON.stringify(...)`

### ✅ 修复 3：clickElement 稳定性增强

**问题**：动态页面在 snapshot 和 click 之间重渲染，导致选择器失效。

**修复**：
- 点击前执行 `scrollIntoView({behavior: 'instant', block: 'center'})`
- 点击失败后等待 500ms 重试一次
- 改进错误提示，引导使用 snapshot 重新获取选择器

### ✅ 修复 4：Skill 文档更新

**修复**：`skills/henry-chrome-automation/SKILL.md` 及参数参考文档：
- 新增 `get_text` action，纯阅读场景优先使用（token 占用约为 snapshot 的 1/5 ~ 1/10）
- 修正 frontmatter、章节编号、timeout 默认值、返回值字段

---

## 根因分析（原始记录）

### 根因 1：evaluateScript 完全无大小限制（最关键）

`chrome-cdp.js:1126-1172` 的 `evaluateScript` 函数返回 `result.result?.value` 时**没有任何大小检查**。
- 一个 `document.body.innerText` 在大型页面上可返回 100KB+
- 一个 `JSON.stringify(largeArray)` 可返回数 MB
- 这是唯一一个没有浏览器端或 Node 端截断的 Chrome 工具
- **Impact**：单条消息即可突破 `MAX_SINGLE_MESSAGE_SIZE`（20000 字符）

### 根因 2：工具结果使用 pretty-print JSON，浪费 25-30% token

`message-utils.js:94` 的 `formatToolResultForLLM` 使用 `JSON.stringify(result, null, 2)`。
- 4 个 chrome 工具 wrapper（`chrome-nav.js:103`、`chrome-interact.js:82`、`chrome-extract.js:109`、`chrome-env.js:225`）也都用 `JSON.stringify(..., null, 2)`
- 一个 50 元素的 snapshot：紧凑 JSON ~18KB，pretty-print ~25KB
- 每个工具调用都多浪费数千 token，多次调用后累积显著
- **Impact**：每次 chrome 工具调用多消耗 25-30% 的上下文空间

### 根因 3：紧急截断策略错误——丢了用户意图，保留了已消费数据

`agent-executor.js:257-337` 的 `emergencyTruncate`：
- 保留当前轮次所有消息（包括已完成的工具结果）
- 保留 system 消息 + 第一轮 user 消息（用户意图）
- **删除中间轮次的对话历史**
- 问题是：被删除的中间轮次可能包含**用户的重要指令或澄清**，而被保留的当前轮次中的 tool results 是 Agent **已经使用过**的数据（如早期的 snapshot）
- **Impact**：Agent 失去了"为什么在做这件事"的上下文，但保留了"某页面上有什么按钮"的过时信息

### 根因 4：缺乏工具结果生命周期管理

Agent 的典型工作流：
```
navigate → snapshot → click → snapshot → fill → evaluate → extract_table
```
每次操作的结果都被永久保留在消息历史中。即使 Agent 已经完成了交互，早期的 snapshot 数据仍然占据上下文。没有机制可以：
- 标记某条 tool result 为"已消费"
- 在后续轮次中将其压缩或移除
- **Impact**：6-10 轮 chrome 操作后，历史消息中堆积了 5-10 条大型 JSON 数据

### 根因 5：snapshot 的 DOM 全量评估开销

`chrome-cdp.js:627-894` 的 `getSnapshot`：
- 先 walk 整个 DOM（包括 iframe）
- 对每个 actionable 元素调用 `getBoundingClientRect()`、`querySelectorAll()`、`closest()`
- 构建完整的 `elements` 数组后才排序截断
- 虽然结果大小受控（200 元素上限），但浏览器端执行开销大
- **Impact**：不是直接导致上下文溢出，但增加了单轮执行时间，间接导致 Agent 需要更多轮次

### 根因 6：MAX_MESSAGES_SIZE 可能过紧

`src/utils/config.js` 中 `MAX_MESSAGES_SIZE` 默认 300000 字节，但 `.env` 中可能设为 80000。
- 80000 字节 ≈ 中文 25000 字 ≈ 英文 40000 词
- 一条 snapshot 结果（25KB pretty-print JSON）+ 一条 extract_table（15KB）+ 一条 evaluate（无限制）= 轻松突破
- **Impact**：配置层面限制了可用上下文，使问题更早触发

## 改进方案（已实施 / 已决策）

| 状态 | 方案 | 说明 |
|------|------|------|
| 已实施 | A：evaluateScript 智能截断 | 添加 `maxLength` 参数（默认 10000），按内容类型智能处理 |
| 已实施 | B：chrome 工具紧凑 JSON | 4 个 chrome 工具 wrapper 移除 pretty-print |
| 不实施 | `message-utils.js` 移除 pretty-print | 用户确认**只改 chrome 工具**，避免影响其他工具理解 |
| 不实施 | `agent-executor.js` emergencyTruncate 优化 | 用户确认保持现有设计，不动 ContextManager / emergencyTruncate |
| 已实施 | D：Skill 强化 get_text 优先 | 更新 SKILL.md 和参数参考文档 |
| 建议 | E：调整 MAX_MESSAGES_SIZE | 配置建议，如需调整在 `.env` 中修改 |

### 详细实施记录

#### 方案 A：evaluateScript 大小限制 + 变量隔离
- `chrome-cdp.js`：`evaluateScript` 添加 `maxLength` 参数，添加 `guardEvaluateResult` / `guardStringResult` / `smartTruncateObject` 等辅助函数
- `chrome-cdp.js`：新增 `wrapEvaluateScript` 函数，用 IIFE + eval 隔离变量声明，修复 `const`/`let` 重声明错误
- `chrome-nav.js`：`evaluate` action 参数添加 `max_result_length`

#### 方案 B：紧凑 JSON
- `chrome-nav.js:103`、`chrome-interact.js:82`、`chrome-extract.js:109`、`chrome-env.js:225`
- 全部改为 `JSON.stringify(result)`

#### 方案 D：Skill 文档
- `SKILL.md`：frontmatter 修正、章节编号修正、timeout 默认值修正
- 新增 `get_text` action 说明，强调纯阅读场景使用 `get_text`
- `references/parameter-reference.md`：同步更新参数表

---

## 验证方法

1. **evaluateScript 截断测试**：
   ```bash
   node -e "import('./src/tools/chrome-cdp.js').then(c => c.evaluateScript(9222, 'Array(1000).fill("x".repeat(100)).join(" ")', true, 500).then(r => console.log(r.truncated, r.originalLength)))"
   ```

2. **evaluateScript 重声明隔离测试**：
   ```bash
   node test/test-chrome-cdp.js
   # 检查 [9b] 和 [9c] 是否通过
   ```

3. **JSON 紧凑化效果对比**：
   手动比较同一条 snapshot 结果在 pretty-print 和 compact 模式下的字符数差异

## 修改文件清单（实际）

| 优先级 | 文件 | 改动内容 |
|--------|------|---------|
| P0 | `src/tools/chrome-cdp.js` | evaluateScript 添加 maxLength、智能截断、IIFE 变量隔离 |
| P0 | `src/tools/chrome-nav.js` | 添加 `max_result_length` 参数；紧凑 JSON |
| P1 | `src/tools/chrome-interact.js` | 紧凑 JSON |
| P1 | `src/tools/chrome-extract.js` | 紧凑 JSON |
| P1 | `src/tools/chrome-env.js` | 紧凑 JSON |
| P1 | `src/tools/chrome-cdp.js` | clickElement 添加 scrollIntoView + 重试 |
| P2 | `skills/henry-chrome-automation/SKILL.md` | 强化 get_text 优先策略，修正文档错误 |
| P2 | `skills/henry-chrome-automation/references/parameter-reference.md` | 同步参数表 |
| — | `test/test-chrome-cdp.js` | 新增重声明隔离和 async evaluate 测试用例 |
| — | `doc/chrome-todo.md` | 本计划文档 |

## 回滚策略

所有改动均为保守改进：
- A：新参数有默认值，不传则行为不变；IIFE 包装对用户透明
- B：单行改动，可一键回滚
- D：文档改动，不影响代码
