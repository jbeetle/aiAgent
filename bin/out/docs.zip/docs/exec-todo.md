# exec.js Skill 处理机制 Review

## 整体流程（Skill 模式）

```
exec({ command, context?, skill_name? })
  │
  ├─ 1. 模式检测 ──────────────────────────────────────┐
  │   • context='skill' → 直接进入 skill 模式           │
  │   • context='general' + 命令路径含 skills/x/scripts/ │
  │     → 自动推断为 skill 模式                          │
  │   • 注意：显式传 context='skill' 会跳过自动检测       │
  │                                                     │
  ├─ 2. 安全校验 ──────────────────────────────────────┤
  │   • validateCommand() — skill 模式下校验规则放宽     │
  │   • validateCommandPathArguments() — 防止越界路径注入 │
  │                                                     │
  ├─ 3. 输出参数重映射 ────────────────────────────────┤  ← ⚠️ 问题点
  │   • resolveOutputParam() 在 cwd 变更前执行           │
  │   • path.resolve() 使用 Agent 进程 cwd，非 workDir    │
  │                                                     │
  ├─ 4. 工作目录隔离 ──────────────────────────────────┤
  │   • ENABLE_EXEC_ISOLATION=true 时：                  │
  │     - 创建 temp/skills/skill-{name}-{uuid8}/        │
  │     - 复制整个 skill 目录到隔离区                     │
  │     - cwd 锁定到隔离目录                             │
  │     - 执行前文件快照(beforeFiles)                     │
  │   • ENABLE_EXEC_ISOLATION=false 时：全部跳过          │
  │                                                     │
  ├─ 5. 命令执行 ──────────────────────────────────────┤
  │                                                     │
  ├─ 6. 产物归集 ──────────────────────────────────────┤
  │   • 重试扫描(3次×500ms) 检测新增文件                  │
  │   • 移动到 output/skill-{name}/ 命名空间              │
  │   • 附加 producedFiles 到 JSON 结果                  │
  │                                                     │
  └─ 7. 延迟清理 ──────────────────────────────────────┤
      • 60s 后 rm -rf 整个 workDir                       │
```

---

## 发现的问题

### 1. 输出参数重映射与 cwd 时序不一致（中等严重度）✅ 已修复

`exec.js:157` — `resolveOutputParam()` 在 `resolvedCwd` 被修改为 workDir **之前**调用。这意味着 `path.resolve(paramPath)` 基于 Agent 进程的 cwd 解析相对路径，但命令实际在 workDir 中运行。

```javascript
// exec.js:155-158 — 此时 resolvedCwd 仍是 Agent 的 cwd
if (isSkillMode) {
    resolvedCommand = resolveOutputParam(command, sandboxOutputDir);
}
// ... 几十行后
// exec.js:199 — cwd 才被改为 workDir
resolvedCwd = workDir;
```

**实际影响**：大多数情况下无害（沙箱内路径保持不变，沙箱外路径重映射为绝对路径），但存在一个逻辑漏洞——如果 Agent cwd 和 workDir 处于不同的沙箱根目录下，同一个相对路径 `--output report.pdf` 在两个 cwd 下可能一个在沙箱内、另一个在沙箱外，导致重映射决策不一致。

### 2. 产物归集忽略被重映射的输出文件（低严重度）✅ 已修复

`exec.js:238` — 重映射目标从固定的 `sandboxOutputDir` 改为 `workDir || sandboxOutputDir`。有隔离时重映射到 workDir 内，产物被 `collectProducedFiles` 自然归集到 `output/skill-{name}/`。

`exec-skill.js:88-137` — `collectProducedFiles()` 只扫描 `workDir` 内的新增文件。但如果 `resolveOutputParam()` 将输出重映射到 `sandboxOutputDir/`（workDir 外部），该文件不会被归集到 `producedFiles`。

LLM 需要自行从（被重映射后的）命令字符串推断输出位置。如果 LLM 没有注意到重映射，可能找不到输出文件。

### 3. `context='skill'` 但缺少 `skill_name` 时静默降级（低严重度）✅ 已修复

`exec.js:131-141`:

```javascript
let effectiveContext = context;
let effectiveSkillName = skillName;
if (context !== 'skill') {
    // auto-detection logic...
}
```

当 LLM 显式传 `context: "skill"` 但忘记传 `skill_name` 时：
- 自动检测被跳过（`context !== 'skill'` 为 false）
- `effectiveSkillName` 保持 `undefined`
- workDir 命名为 `skill-{uuid}`（无名称）
- **不会复制 skill 文件**到隔离目录
- **不会归集产物**
- cwd 仍被锁定到空的 workDir → 脚本很可能因为找不到文件而失败

只有通过命令路径正则自动检测时才会自动补全 `skillName`。

### 4. 自动检测正则无法覆盖 `cd` 模式（低严重度）✅ 已修复

`exec.js:135-143` — 新增 Pattern 2：`cd skills/{name}` + 命令中存在 `scripts/` 时自动推断为 skill 模式。

`exec.js:135` 的正则是:

```javascript
/skills[\/\\]([\w-]+)[\/\\]scripts[\/\\]/i
```

这要求 `skills/{name}/scripts/` 作为连续字符串出现在命令中。但如果 LLM 使用分步命令：

```bash
cd skills/my-tool && python scripts/run.py
```

`skills/my-tool` 与 `scripts/run.py` 被 `&& python ` 分隔，正则无法匹配，不会自动进入 skill 模式。

### 5. `ENABLE_EXEC_ISOLATION=false` 时 Skill 模式退化为空壳（设计需注意）

当 `ENABLE_EXEC_ISOLATION=false`：
- 工作目录隔离：**跳过**
- Skill 文件复制：**跳过**
- 文件快照/归集/清理：**全部跳过**
- 唯一保留的 skill 特性：`resolveOutputParam()` + relaxed `validateCommand()`

这意味着关闭隔离后，skill 脚本直接在 Agent cwd 运行，产物散落各处，没有归集。这是有意为之的"逃生舱"，但关闭隔离会导致 skill 执行与普通 exec 几乎没有区别。

### 6. ~~清理定时器无守护——产物可能消失~~ ✅ 已修复（删除定时器）

`exec-skill.js:180` — 原 60 秒延迟清理已删除。定时器过度设计：`enforceSkillWorkDirLimit`（50 上限 + mtime 排序）+ `cleanupStaleSkillWorkDirs`（启动时 24h 清理）已经足够。重型 skill（5-6 分钟）不再有产物被抢先删除的风险。

---

## 好的设计

| 设计点 | 说明 |
|--------|------|
| **文件复制策略** | 将整个 skill 目录复制到隔离区，保持 `skills/{name}/` 结构，相对路径引用可用 |
| **重试扫描** | 3 次 × 500ms 延迟扫描新增文件，容忍异步写入 |
| **跨驱动器 fallback** | `EXDEV` 错误时自动降级为 copy+delete |
| **工作目录数量限制** | 超过 50 个时清理最旧的，防止磁盘耗尽 |
| **超时也能归集** | `catch` 块中也调用 `collectAndAttach()`，超时/失败前的部分产物不会丢失 |
| **命名空间隔离** | 产物归集到 `output/skill-{name}/`，不同 skill 的输出不冲突 |

---

## 建议改进

1. **`resolveOutputParam` 应延迟到 cwd 变更后执行**，或在函数内部接受 cwd 参数来正确解析相对路径。

2. **显式 `context='skill'` 时，若 `skill_name` 缺失应校验报错**，而非静默降级：

```javascript
if (context === 'skill' && !skillName) {
    throw Errors.validation('skill_name', 
        'skill_name is required when context="skill"');
}
```

3. ~~清理定时器可考虑延长到 3-5 分钟~~ ✅ 已修复（定时器已删除，依赖启动清理 + 数量上限）

4. 自动检测正则可以考虑增强，支持路径中夹杂空格/引号的情况。
