# Hermes `code_execution_tool.py` vs coqi-claw `exec.js` 对比分析

## 一、核心定位差异

| 维度 | Hermes `execute_code` | coqi-claw `exec` |
|------|----------------------|------------------|
| **执行范式** | **代码优先** — LLM 写 Python 脚本，脚本内调用工具 | **命令优先** — 直接执行 shell 命令 |
| **设计目标** | 把多步工具链压缩成**单次推理**，中间结果不出现在上下文 | 单步命令执行，工具结果直接返回 |
| **复杂度** | 1400 行，两层 RPC（UDS + File-based） | 380 行，单层 exec |
| **平台** | POSIX only（不支持 Windows） | 全平台（含 PowerShell 自动检测） |

## 二、关键架构对比

### 2.1 执行模型

**Hermes — 内嵌工具代理模式**
```
LLM 写 script.py
    -> 子进程运行 script.py
        -> script.py import hermes_tools (自动生成的 stub)
            -> stub 通过 UDS/File RPC 调回父进程
                -> 父进程调用真实工具
                    -> 结果经 RPC 返回给脚本
                        -> 脚本处理/聚合后 print()
                            -> stdout 返回给 LLM
```

核心洞察：**中间工具结果（web_search、read_file 等）永远不会进入 LLM 上下文**，只有最终聚合后的 stdout 出现。这解决了长工具链的上下文膨胀问题。

**CoQi — 传统 Shell 代理模式**
```
LLM 调用 exec({ command: "..." })
    -> 直接 spawn shell 子进程
        -> stdout/stderr 截断后返回
            -> 结果进入 LLM 上下文
```

无内嵌工具调用能力。如果需要"搜索->读取->处理"的链式操作，必须每步一个工具调用，由 LLM 在上下文中拼接。

### 2.2 工具调用机制

| | Hermes | CoQi |
|--|--------|------|
| 内嵌工具 | **有** — 7 种受限工具通过 `hermes_tools.py` 暴露 | **无** — exec 只能执行系统命令 |
| 工具白名单 | 运行时与 `SANDBOX_ALLOWED_TOOLS` 取交集 | 命令黑名单（`rm -rf` 等） |
| 调用次数限制 | `max_tool_calls=50`（脚本内隐式） | 无次数限制 |
| 嵌套深度 | 脚本内无限嵌套（通过 RPC） | 单层（exec 不再 spawn 子 agent） |

### 2.3 安全模型

**Hermes — 环境隔离（偏向 CIA 保密性）**

```python
# 白名单前缀 + 黑名单子串双重过滤
_SAFE_ENV_PREFIXES = ("PATH", "HOME", "USER", ...)     # 允许
_SECRET_SUBSTRINGS = ("KEY", "TOKEN", "SECRET", ...)   # 阻断
child_env = {k: v for k, v in os.environ.items()
             if safe_prefix(k) and not secret_name(k)}
# 还额外移除 HERMES_TIMEZONE
```

- **HOME 隔离**：`HOME = {HERMES_HOME}/home/`（配置隔离）
- **stdin 切断**：`stdin=subprocess.DEVNULL`（防交互式攻击）
- **stdout 脱敏**：`redact_sensitive_text`（防磁盘秘密泄露到上下文）
- **无网络直连**：脚本内 `import requests` 受限？-> 未明确限制，但通过工具白名单间接控制

**CoQi — 命令+路径双重验证（偏向权限控制）**

```javascript
// 第一层：命令语义校验
validateCommand(command, shell, { context: effectiveContext, skillName });

// 第二层：参数路径校验（命令参数中的路径不得越界）
validateCommandPathArguments(command);

// 第三层：cwd 沙箱
validatePath(resolvedCwd);

// Skill 模式附加：--output 参数自动改写到 sandbox/output/
resolveOutputParam(command, sandboxOutputDir);
```

| 安全维度 | Hermes | CoQi |
|---------|--------|------|
| 命令过滤 | 不直接过滤命令（脚本内可写 `os.system("rm -rf /")`） | **显式黑名单**：`rm -rf /`、`sudo`、`mkfs`、pipe-to-shell 等 |
| 路径隔离 | HOME 重定向 + PYTHONPATH 注入 | **cwd 锁定**（skill 模式） + **参数路径白名单** |
| 环境泄漏 | 环境变量 scrub + secrets 脱敏 | `PYTHONIOENCODING=utf-8` 注入，无 secrets 脱敏 |
| 网络控制 | 无直接网络策略（依赖工具白名单间接） | `network-policy.js` 阻止私有 IP/云元数据 |

### 2.4 输出处理

| | Hermes | CoQi |
|--|--------|------|
| 截断策略 | **head+tail**（40%/60%），保证最终 `print()` 可见 | 按行截断（默认 500 行） + 按字节截断（默认 100KB） |
| 编码处理 | `utf-8` errors=`replace` | 乱码检测 `isGarbledText()` + 编码警告 |
| ANSI 剥离 | `strip_ansi` | **无**（未处理 ANSI） |
| secrets 脱敏 | `redact_sensitive_text` | **无** |
| stderr | 独立收集，10KB 硬限，错误时拼入输出 | 结构化分离（JSON 模式），默认 100KB 限 |

Hermes 的 head+tail 设计有明确目的：**保证最终 print 语句的输出不被截断丢失**。CoQi 的按行截断更直观，但如果关键信息在中间段落会丢失。

### 2.5 终止策略

```python
# Hermes — 优雅降级
os.killpg(os.getpgid(proc.pid), signal.SIGTERM)  # 先尝试优雅终止
proc.wait(timeout=5)                              # 等 5s
os.killpg(os.getpgid(proc.pid), signal.SIGKILL)   # 再强制终止
```

```javascript
// CoQi — 直接终止
const KILL_SIGNAL = process.platform === 'win32' ? 'SIGKILL' : 'SIGTERM';
execAsync(resolvedCommand, { killSignal: KILL_SIGNAL });
```

Hermes 区分 `SIGTERM`/`SIGKILL` 的优雅降级更适合长时间运行的数据分析脚本；CoQi 直接 `SIGKILL` 对 Windows 兼容性更好（Win 无 SIGTERM 概念）。

### 2.6 执行模式 / 环境感知

| | Hermes | CoQi |
|--|--------|------|
| 模式 | `strict`（隔离 tmpdir） / `project`（session CWD + venv） | `general`（无隔离） / `skill`（隔离 + 文件归集） |
| Python 解释器 | 自动检测 `VIRTUAL_ENV`/`CONDA_PREFIX` -> 优先使用项目 Python | 无（直接执行命令，不感知解释器） |
| CWD 解析 | `TERMINAL_CWD` 环境变量 -> `os.getcwd()` -> fallback | `process.cwd()` / Skill 模式自动切到隔离目录 |

Hermes 的 project/strict 模式是为了**让 `import pandas` 等依赖可用**，这是一个重要设计——AI agent 经常需要 Python 数据分析能力。CoQi 的 skill 模式则纯粹是为了**文件隔离和产出归集**。

## 三、Hermes 的先进设计（CoQi 可借鉴）

### 3.1 PTC（Programmatic Tool Calling）模式

这是 Hermes 的核心创新：让 LLM 用 Python 脚本作为"胶水"把多个工具调用串联起来。

**为什么这很重要？**
- 10 步工具链 -> LLM 需要 10 次推理 + 10 轮上下文往返
- PTC -> 1 次推理 + 1 次上下文往返，中间工具结果不进入上下文

**代价**：代码生成风险（LLM 写的脚本可能有 bug）、调试困难（黑盒脚本内失败）。

### 3.2 环境变量 Secret 过滤

```python
_SECRET_SUBSTRINGS = ("KEY", "TOKEN", "SECRET", "PASSWORD", ...)
child_env = {k: v for k, v in os.environ.items() if not secret_name(k)}
```

这是**防御性深度设计**：即使脚本尝试 `print(os.environ["OPENAI_API_KEY"])`，也因为 env scrubbing 拿不到值。CoQi 目前没有这层过滤——如果子进程 shell 里能读到父进程的 API key，这是一个真实风险。

### 3.3 Secrets 脱敏 + ANSI 剥离

```python
stdout_text = strip_ansi(stdout_text)
stdout_text = redact_sensitive_text(stdout_text)
```

防止脚本读取 `~/.hermes/.env` 后把 secrets 泄露到 LLM 上下文。CoQi 没有这层保护。

### 3.4 Head+Tail 截断策略

```python
_STDOUT_HEAD_BYTES = int(MAX_STDOUT_BYTES * 0.4)   # 20KB
_STDOUT_TAIL_BYTES = MAX_STDOUT_BYTES - _STDOUT_HEAD_BYTES  # 30KB
```

保证脚本最后的 `print(result)` 始终可见——这对 AI 脚本特别重要，因为关键输出通常在脚本末尾。

## 四、CoQi 的先进设计（Hermes 可借鉴）

### 4.1 命令安全校验

Hermes 的脚本内可以写 `os.system("rm -rf /")`，系统不会阻止（只通过 env scrubbing 间接限制）。CoQi 的 `validateCommand` 明确拦截危险命令，这是**更积极的防御**。

### 4.2 参数路径校验

```javascript
validateCommandPathArguments(command);
```

扫描命令字符串中的路径参数，防止通过 `exec({ command: "cat /etc/passwd" })` 绕过文件沙箱。Hermes 的脚本内 `read_file("/etc/passwd")` 受工具权限限制，但 `os.system("cat /etc/passwd")` 不受限制。

### 4.3 Shell 自动检测

```javascript
if (!shell && process.platform === 'win32') {
    if (isPowerShellCommand(resolvedCommand)) {
        shellOption = 'pwsh.exe';
        detectedShell = 'pwsh';
    }
}
```

自动识别 `Get-Content`、`Remove-Item` 等 PowerShell 命令并切换解释器，这是 Windows 开发体验的重要优化。Hermes 不支持 Windows。

### 4.4 编码/乱码检测

```javascript
if (isGarbledText(processedStdout)) {
    jsonResult.encodingWarning = 'Output may contain garbled text...';
}
```

Windows 命令行 GBK->UTF-8 乱码是真实痛点，CoQi 提供了诊断提示。

### 4.5 超时不抛错

```javascript
if (error.killed) {
    return JSON.stringify({
        success: false, status: 'timeout',
        stdout: partialStdout, hint: 'Command timed out...'
    });
}
```

超时返回部分输出 + hint，让 LLM 做部分判断。Hermes 也做同样的事（return timeout status），但 CoQi 的 `partialStdout.slice(0, 1000)` 更紧凑。

### 4.6 Skill 模式文件归集

```javascript
await collectAndAttach(workDir, sandboxOutputDir, effectiveSkillName, beforeFiles, jsonResult);
```

自动发现脚本产出的新文件并搬到 `output/` 目录，解决了"脚本写了文件但 LLM 不知道在哪"的问题。

## 五、架构取舍总结

| 设计决策 | Hermes 选择 | CoQi 选择 | 优劣 |
|---------|-------------|-----------|------|
| **核心抽象** | Python 脚本作为"微 agent" | Shell 命令作为原子操作 | Hermes 更适合多步链式任务；CoQi 更简单可靠 |
| **上下文控制** | 工具结果不出上下文（RPC 代理） | 工具结果直接入上下文 | Hermes 节省 token，但增加调试难度 |
| **安全哲学** | 环境隔离 + 事后脱敏（信任脚本但 scrub 环境） | 事前阻断 + 路径白名单（不信任命令本身） | Hermes 更开放但依赖深度防御；CoQi 更严格但限制了灵活性 |
| **平台覆盖** | POSIX only | 全平台 | CoQi 明显胜出 |
| **依赖感知** | 自动检测 venv/conda | 无 | Hermes 更适合数据科学场景 |

## 六、对 coqi-claw 的改进建议

如果要在 CoQi 中引入 Hermes 的 PTC 模式，可以考虑：

1. **新增 `execute_code` 工具**（不替换现有 `exec`），专门用于"多步 Python 脚本 + 内嵌工具调用"场景
2. **环境变量 Secret 过滤**：在 `exec` 的 child env 中增加白名单过滤，防止 API key 泄露
3. **Head+Tail 截断**：对 skill 模式下的 stdout 采用 40%/60% 策略，保证最终输出可见
4. **ANSI 剥离**：在 `processOutput` 后增加 `stripAnsi` 步骤，防止终端格式污染 LLM 上下文
5. **Secrets 脱敏**：在返回 LLM 前扫描 stdout/stderr 中是否包含 `LLM_API_KEY` 等环境变量值
