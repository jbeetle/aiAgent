# 用户交互模式优化

## 背景

用户倾向于一次性输入几百字的重任务描述，Agent 收到后按部就班执行所有步骤，中间没有用户介入点。导致结果可能跑偏、用户不满意、浪费 token。

目标：引导用户通过**逐步问答**与 Agent 协作完成任务，而非一次性丢出完整需求。

---

## 已实施方案：输入长度硬拦截

### 环境变量

| 变量 | 默认值 | 说明 |
|------|--------|------|
| `INPUT_ENFORCE_LIMIT` | `1500` | 输入字符数上限，超过此值在入口处直接拒绝，不进入 Agent 执行 |

设置方式（`.env` 文件）：

```env
# 输入长度硬限制（字符数），超过后直接拦截
INPUT_ENFORCE_LIMIT=1500
```

### 拦截入口

| 端 | 文件 | 函数 | 拦截行为 |
|------|------|------|----------|
| TUI | `src/tui/processor.js` | `processInput()` | 打印友好提示 → 返回 `{ type: 'blocked' }` |
| Web WebSocket | `src/gateway/chat-handler.js` | `handleChat()` | 发送 `ERROR` 消息 → `return` |
| Web 协议层 | `src/gateway/protocol.js` | `validateClientMessage()` | WebSocket 消息校验阶段返回 `valid: false` |

### 拦截位置说明

所有拦截均在以下操作**之前**生效：
- `sm.addMessage()` — 不在 DB 中残留无效消息
- `ContextManager.buildContext()` — 不浪费上下文构建开销
- `Agent.runWithHistory()` — 不进入 Agent 执行循环
- `connection.isProcessing = true`（WebSocket）— 不污染连接状态

### 用户提示内容

TUI、WebSocket 两端使用统一文案：

> ⚠️ 输入过长（X 字符），上限 1500 字符。请分步描述需求后再试。

---

## 备选方案：系统提示词注入（未实施，待评估）

在系统提示的 `workModeGlobal` 全局约束中追加一条"分步协作"规则，让 Agent 自身学会分步处理复杂任务。

### 优点
- 更优雅，非强制拦截
- 让 Agent 主动与用户交互

### 缺点
- 增加系统提示 token 消耗
- 当前 Agent 已经简单高效，加约束可能影响执行效率
- LLM 不一定会严格遵守

### 后续决策点
如果仅靠硬拦截不够，可在 `src/core/i18n.js` 的 `workModeGlobal` 中追加以下内容（中英文各一行），作为软性补充：

```
"协作方式：\n" +
"  - **分步协作**：一次性提出多步骤需求时，先确认核心目标，拆解为多个阶段，每完成一阶段后向用户汇报结果并确认方向"
```
