# Skill 签名接入规范（Java 后台）

## 1. 概述

本规范定义 Java 后台如何对 skill 目录进行数字签名，生成 `.skill-trust` 文件。我方将提供签名私钥，后台只需按本规范实现签名逻辑即可。验证工作由双方通过测试共同保证。

---

## 2. 密钥信息

我方将提供以下文件：

| 文件 | 用途 | 说明 |
|------|------|------|
| `skill-private.pem` | 签名 | RSA-4096 私钥，PKCS#8 PEM 格式 |
| `public-skill.pem` | 指纹计算 | RSA-4096 公钥，SPKI PEM 格式 |

**签名算法：** `RSA-SHA256`（Java 中为 `SHA256withRSA`，PKCS#1 v1.5 填充）

**Key ID：** `coqi-claw-internal`

---

## 3. 私钥保管要求

- 禁止将私钥硬编码在源码中
- 禁止将私钥提交到版本控制系统
- 建议存储在 KMS、HSM、Vault 或受限文件系统中
- 签名接口需鉴权，并记录审计日志
- 如怀疑私钥泄露，须立即通知我方更换密钥

---

## 4. 签名流程

```
接收 skill 目录
    ↓
计算 manifest（见第 5 节）
    ↓
将 manifest 序列化为 compact JSON
    ↓
使用 RSA-SHA256 私钥签名
    ↓
生成 .skill-trust 文件（见第 6 节）
```

---

## 5. Manifest 计算规范

Manifest 是签名的输入，必须严格按以下规则生成。

### 5.1 目录遍历

1. 递归遍历 skill 目录下所有文件和子目录
2. **跳过** `.skill-trust` 文件
3. 在每个目录内，按**不区分大小写**的字母顺序排序
4. 排序后，**先处理目录，再处理文件**

> 注意：不是全局排序，而是逐层排序、目录优先。

### 5.2 文件条目

每个文件生成一个对象：

| 字段 | 类型 | 说明 |
|------|------|------|
| `path` | string | 相对 skill 目录的路径，分隔符统一为 `/` |
| `hash` | string | 文件内容的 SHA-256，小写 hex |
| `size` | number | 文件字节长度 |

### 5.3 示例

```json
{
  "files": [
    {"path": "SKILL.md", "hash": "a1b2c3...", "size": 1234},
    {"path": "scripts/main.py", "hash": "d4e5f6...", "size": 5678}
  ]
}
```

---

## 6. `.skill-trust` 文件格式

最终写入 skill 目录根目录，内容如下：

```json
{
  "version": "1.0.0",
  "signature": {
    "keyId": "coqi-claw-internal",
    "value": "<base64 签名值>",
    "signedAt": "2026-06-18T12:00:00.000Z",
    "expiresAt": "2027-06-18T12:00:00.000Z",
    "algorithm": "RSA-SHA256"
  },
  "manifest": {
    "files": [...]
  },
  "fingerprint": "sha256:<public-skill.pem 的 SHA-256 hex>"
}
```

### 字段说明

| 字段 | 说明 |
|------|------|
| `version` | 固定 `"1.0.0"` |
| `signature.keyId` | `"coqi-claw-internal"` |
| `signature.value` | Base64 编码的 RSA-SHA256 签名 |
| `signature.signedAt` | 签名时间，ISO 8601 UTC 格式 |
| `signature.expiresAt` | 过期时间，默认当前时间 + 365 天 |
| `signature.algorithm` | 固定 `"RSA-SHA256"` |
| `manifest` | 按第 5 节计算出的 manifest |
| `fingerprint` | `sha256:` + `public-skill.pem` 全文 SHA-256 |

---

## 7. 签名输入的 JSON 规范

签名前，将 manifest 对象序列化为 JSON 字符串，要求：

- UTF-8 编码
- 无缩进、无换行（compact JSON）
- 字段顺序固定：`files` → 每个对象的 `path` → `hash` → `size`
- 数组顺序与第 5 节遍历顺序一致

---

## 8. Java 参考代码

```java
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.*;
import java.util.stream.Collectors;

public class SkillSigner {

    @JsonPropertyOrder({"path", "hash", "size"})
    public static class ManifestFile {
        public String path;
        public String hash;
        public long size;
    }

    public static class Manifest {
        public List<ManifestFile> files = new ArrayList<>();
    }

    public static class SignatureBlock {
        public String keyId = "coqi-claw-internal";
        public String value;
        public String signedAt;
        public String expiresAt;
        public String algorithm = "RSA-SHA256";
    }

    public static class TrustData {
        public String version = "1.0.0";
        public SignatureBlock signature = new SignatureBlock();
        public Manifest manifest = new Manifest();
        public String fingerprint;
    }

    public static Manifest computeManifest(Path skillDir) throws Exception {
        Manifest manifest = new Manifest();
        walk(skillDir, "", manifest);
        return manifest;
    }

    private static void walk(Path dir, String prefix, Manifest manifest) throws Exception {
        List<Path> entries;
        try (var stream = Files.list(dir)) {
            entries = stream
                .sorted((a, b) -> {
                    String na = a.getFileName().toString().toLowerCase();
                    String nb = b.getFileName().toString().toLowerCase();
                    return na.compareTo(nb);
                })
                .collect(Collectors.toList());
        }

        for (Path entry : entries) {
            String name = entry.getFileName().toString();
            String relativePath = prefix.isEmpty() ? name : prefix + "/" + name;

            if (Files.isDirectory(entry)) {
                walk(entry, relativePath, manifest);
            } else if (Files.isRegularFile(entry)) {
                if (".skill-trust".equals(name)) continue;
                byte[] content = Files.readAllBytes(entry);
                ManifestFile mf = new ManifestFile();
                mf.path = relativePath.replace("\\", "/");
                mf.hash = sha256Hex(content);
                mf.size = content.length;
                manifest.files.add(mf);
            }
        }
    }

    private static String sha256Hex(byte[] data) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        return bytesToHex(digest.digest(data));
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    public static PrivateKey loadPrivateKey(String pemPath) throws Exception {
        String pem = Files.readString(Paths.get(pemPath), StandardCharsets.UTF_8);
        String base64 = pem
            .replace("-----BEGIN PRIVATE KEY-----", "")
            .replace("-----END PRIVATE KEY-----", "")
            .replaceAll("\\s", "");
        byte[] encoded = Base64.getDecoder().decode(base64);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        return keyFactory.generatePrivate(new PKCS8EncodedKeySpec(encoded));
    }

    public static String signManifest(Manifest manifest, PrivateKey privateKey) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        String manifestJson = mapper.writeValueAsString(manifest);
        Signature signer = Signature.getInstance("SHA256withRSA");
        signer.initSign(privateKey);
        signer.update(manifestJson.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(signer.sign());
    }

    public static String computeFingerprint(String publicKeyPath) throws Exception {
        byte[] pubKeyBytes = Files.readAllBytes(Paths.get(publicKeyPath));
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        return "sha256:" + bytesToHex(digest.digest(pubKeyBytes));
    }

    public static String generateTrustFile(Path skillDir, PrivateKey privateKey,
                                           int expireDays) throws Exception {
        Manifest manifest = computeManifest(skillDir);
        String signatureValue = signManifest(manifest, privateKey);
        String fingerprint = computeFingerprint("config/public-skill.pem");

        String signedAt = java.time.Instant.now().toString();
        String expiresAt = java.time.Instant.now()
            .plusSeconds(expireDays * 24L * 60L * 60L)
            .toString();

        TrustData trust = new TrustData();
        trust.signature.value = signatureValue;
        trust.signature.signedAt = signedAt;
        trust.signature.expiresAt = expiresAt;
        trust.manifest = manifest;
        trust.fingerprint = fingerprint;

        ObjectMapper mapper = new ObjectMapper();
        return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(trust);
    }
}
```

### Maven 依赖

```xml
<dependency>
    <groupId>com.fasterxml.jackson.core</groupId>
    <artifactId>jackson-databind</artifactId>
    <version>2.15.0</version>
</dependency>
```

---

## 9. 联调验证

双方按以下方式验证：

1. 后台使用本规范生成 `.skill-trust`
2. 我方使用 Agent 加载并验证该 skill
3. 如验证失败，双方对比 manifest JSON 字符串和签名算法参数，定位差异

---

## 10. 注意事项

1. **签名算法必须是 `SHA256withRSA`**，不能使用 PSS 填充
2. **manifest JSON 必须 compact 且无字段顺序差异**
3. **路径分隔符必须统一为 `/`**
4. **文件遍历必须逐层排序、目录优先**，不能全局排序
5. 签名时以磁盘上实际文件内容为准
