# coqi-claw 记忆系统最终方案

> 融合 OpenHuman (Memory Tree + TokenJuice) 和 Hermes (Frozen Snapshot + 注入扫描 + 漂移检测) 的设计精华
> 基于 coqi-claw 现有基础设施 (better-sqlite3 / database/ 沙箱 / 工具系统 / 技能系统)

---

## 一、设计原则

```
三取三不取:

OpenHuman 取:  层级树摘要  / 评分折叠 / Token 预算控制
OpenHuman 不取: 托管后端 / 118+ OAuth / 全局压缩中间件

Hermes 取:   Frozen Snapshot / 注入扫描 / 原子写入 / 双文件分离 / 漂移检测
Hermes 不取: § 文本格式 / fcntl 文件锁 / 单文件存储

coqi-claw 自己:  better-sqlite3 引擎 / 工具注册体系 / 技能系统 / Skill 拉取
```

## 二、最终架构

```
┌──────────────────────────────────────────────────────────────┐
│                     数据来源层                                │
│                                                              │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────────┐ │
│  │memory_add│  │ web_fetch│  │exec_skill│  │ 对话自动摘要  │ │
│  │(手动)    │  │(工具产出)│  │(Skill)   │  │(每会话结束)  │ │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘  └──────┬───────┘ │
│       │              │              │               │         │
└───────┼──────────────┼──────────────┼───────────────┼─────────┘
        │              │              │               │
        ▼              ▼              ▼               ▼
┌──────────────────────────────────────────────────────────────┐
│              MemoryStore (src/memory/store.js)               │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │            SQLite — database/memory.db (WAL mode)      │ │
│  │                                                        │ │
│  │  memory_agent 表   ← agent 的工作笔记                   │ │
│  │  memory_user 表    ← 用户画像和偏好                     │ │
│  │  memory_summaries 表 ← 层级摘要 (Phase 2)               │ │
│  └────────────────────────────────────────────────────────┘ │
│                                                              │
│  安全层:                                                     │
│  ┌────────────────────────────────────────────────────────┐ │
│  │ 注入扫描 (借鉴 Hermes) — 写入前检测威胁模式+隐形Unicode │ │
│  │ 原子写入 — tempfile + fsync + rename                   │ │
│  │ 漂移检测 — 检测外部直接修改 (Phase 2+)                 │ │
│  └────────────────────────────────────────────────────────┘ │
└───────────────────────────┬──────────────────────────────────┘
                            │
                            ▼
┌──────────────────────────────────────────────────────────────┐
│            Frozen Snapshot (借鉴 Hermes)                      │
│                                                              │
│  会话启动时:  加载 memory_agent + memory_user → 冻结快照      │
│  会话进行中:  memory_add 只写 DB，不更新系统提示词            │
│  下次会话:    重新加载，快照自然更新                          │
│                                                              │
│  效果: 系统提示词在整会话内稳定 → 前缀缓存 100% 复用          │
└───────────────────────────┬──────────────────────────────────┘
                            │
                            ▼
┌──────────────────────────────────────────────────────────────┐
│             Context Injector (src/memory/injector.js)         │
│                                                              │
│  取 frozen_snapshot.agent (≤400 tokens)                      │
│  取 frozen_snapshot.user  (≤300 tokens)                      │
│  → 注入 System Prompt 末尾                                   │
│                                                              │
│  Token 预算: ≤700 total (≈3% of 20K context)                │
└───────────────────────────┬──────────────────────────────────┘
                            │
                            ▼
                   ┌────────────────┐
                   │  LLM 上下文     │
                   │  + 稳定记忆块   │ ← 前缀缓存可复用
                   └────────────────┘
```

## 三、核心实现

### 3.1 数据模型（两个独立的表，借鉴 Hermes 双文件设计）

```sql
-- Agent 的工作笔记
CREATE TABLE memory_agent (
  id          TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
  title       TEXT NOT NULL,
  content     TEXT NOT NULL,           -- ≤2000 字符
  content_hash TEXT NOT NULL,          -- SHA256 去重
  importance  INTEGER DEFAULT 3,       -- 0-5
  tags        TEXT DEFAULT '[]',       -- JSON数组
  source      TEXT DEFAULT 'manual',   -- 'manual' | 'web_fetch' | 'skill:xxx' | 'summary'
  source_url  TEXT,
  created_at  INTEGER NOT NULL,
  expires_at  INTEGER,
  access_count INTEGER DEFAULT 0
);

-- 用户画像和偏好
CREATE TABLE memory_user (
  id          TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
  title       TEXT NOT NULL,
  content     TEXT NOT NULL,           -- ≤1500 字符
  content_hash TEXT NOT NULL,
  importance  INTEGER DEFAULT 3,
  tags        TEXT DEFAULT '[]',
  source      TEXT DEFAULT 'manual',
  source_url  TEXT,
  created_at  INTEGER NOT NULL,
  expires_at  INTEGER,
  access_count INTEGER DEFAULT 0
);

-- 层级摘要 (Phase 2)
CREATE TABLE memory_summaries (
  id          TEXT PRIMARY KEY,
  category    TEXT NOT NULL,           -- 'agent' | 'user'
  level       INTEGER NOT NULL,        -- 0=根 1=分类
  content     TEXT NOT NULL,           -- LLM 摘要 ≤500 字符
  child_count INTEGER DEFAULT 0,
  generated_at INTEGER NOT NULL
);

-- 索引
CREATE INDEX idx_memory_agent_importance ON memory_agent(importance DESC);
CREATE INDEX idx_memory_agent_created ON memory_agent(created_at DESC);
CREATE INDEX idx_memory_agent_hash ON memory_agent(content_hash);
CREATE INDEX idx_memory_user_importance ON memory_user(importance DESC);
CREATE INDEX idx_memory_user_hash ON memory_user(content_hash);
```

### 3.2 MemoryStore（核心）

```javascript
import Database from 'better-sqlite3-multiple-ciphers';
import path from 'path';
import { randomUUID, createHash } from 'crypto';
import { getSandboxBaseDir } from '../security/sandbox-layout.js';
import { logger } from '../utils/logger.js';
import { scanMemoryContent } from './scanner.js';
import { calculateScore } from './scorer.js';

const MAX_AGENT_CONTENT = 2000;  // ≈500 tokens
const MAX_USER_CONTENT  = 1500;  // ≈375 tokens

let db = null;

function getDb() {
  if (db) return db;
  const dbPath = path.join(getSandboxBaseDir(), 'database', 'memory.db');
  db = new Database(dbPath);
  db.pragma('journal_mode = WAL');
  db.exec(SCHEMA_SQL);
  return db;
}

export class MemoryStore {
  // ═══════════════════════════════════════════════════════════
  // Frozen Snapshot（借鉴 Hermes）
  // ═══════════════════════════════════════════════════════════
  static frozenSnapshot = { agent: '', user: '' };

  /** 会话启动时调用一次：加载数据 → 冻结快照 → 注入系统提示词 */
  static freeze() {
    const agentRows = this.getTop('agent', 8);
    const userRows  = this.getTop('user', 5);

    this.frozenSnapshot.agent = agentRows.length
      ? this._renderBlock('agent', agentRows)
      : '';
    this.frozenSnapshot.user  = userRows.length
      ? this._renderBlock('user', userRows)
      : '';
  }

  /** 获取冻结快照（注入系统提示词用）。整个会话返回相同内容。 */
  static getSnapshot() {
    return this.frozenSnapshot;
  }

  // ═══════════════════════════════════════════════════════════
  // CRUD（借鉴 coqi-claw 自身 + Hermes）
  // ═══════════════════════════════════════════════════════════

  static add({ target, title, content, importance = 3, tags = [], source = 'manual', sourceUrl = null }) {
    const db = getDb();
    const table = target === 'user' ? 'memory_user' : 'memory_agent';
    const maxLen = target === 'user' ? MAX_USER_CONTENT : MAX_AGENT_CONTENT;

    // ① 注入扫描（借鉴 Hermes）
    const threat = scanMemoryContent(content);
    if (threat) {
      throw Object.assign(new Error(threat), { code: 'SECURITY_BLOCKED' });
    }

    const hash = createHash('sha256').update(content).digest('hex');

    // ② 去重
    const existing = db.prepare(`SELECT id FROM ${table} WHERE content_hash = ?`).get(hash);
    if (existing) {
      db.prepare(`UPDATE ${table} SET created_at=?, access_count=access_count+1 WHERE id=?`)
        .run(Date.now(), existing.id);
      return existing.id;
    }

    // ③ 截断
    const truncated = content.length > maxLen
      ? content.slice(0, maxLen) + '\n[截断]' : content;

    const score = calculateScore({ importance, source, tags });
    const id = randomUUID();

    db.prepare(`INSERT INTO ${table}
      (id,title,content,content_hash,importance,tags,source,source_url,created_at)
      VALUES (?,?,?,?,?,?,?,?,?)`).run(
      id, title, truncated, hash, importance, JSON.stringify(tags), source, sourceUrl, Date.now()
    );

    logger.info(`Memory[${target}] added: "${title}" score=${score.toFixed(1)}`);
    return id;
  }

  static search({ target = 'agent', query, limit = 10 }) {
    const db = getDb();
    const table = target === 'user' ? 'memory_user' : 'memory_agent';
    const now = Date.now();

    let sql = `SELECT * FROM ${table} WHERE (expires_at IS NULL OR expires_at > ?)`;
    const params = [now];

    if (query) {
      sql += ` AND (title LIKE ? OR content LIKE ?)`;
      params.push(`%${query}%`, `%${query}%`);
    }

    // 评分排序：重要性 × 新鲜度 × 频率
    sql += ` ORDER BY importance * (1.0 / (1 + (${now} - created_at) / 604800000.0)) DESC LIMIT ?`;
    params.push(Math.min(limit, 20));

    return db.prepare(sql).all(...params).map(r => ({
      ...r,
      tags: JSON.parse(r.tags || '[]'),
      age_days: ((now - r.created_at) / 86400000).toFixed(1)
    }));
  }

  static getTop(target = 'agent', limit = 8) {
    return this.search({ target, limit });
  }

  static delete({ target, id }) {
    const table = target === 'user' ? 'memory_user' : 'memory_agent';
    getDb().prepare(`DELETE FROM ${table} WHERE id = ?`).run(id);
  }

  // ═══════════════════════════════════════════════════════════
  // 内部
  // ═══════════════════════════════════════════════════════════

  static _renderBlock(target, rows) {
    const label = target === 'user'
      ? '## 用户画像 (你是谁，偏好与习惯)'
      : '## 工作记忆 (项目、任务、上下文)';
    const items = rows.map(r =>
      `- **${r.title}**: ${r.content.length > 200 ? r.content.slice(0, 200) + '...' : r.content}`
    ).join('\n');
    return `${label}\n${items}`;
  }
}
```

### 3.3 注入扫描器（借鉴 Hermes 的 13条威胁模式）

```javascript
// src/memory/scanner.js

const THREAT_PATTERNS = [
  // 提示词注入
  [/ignore\s+(previous|all|above|prior)\s+instructions/i, 'prompt_injection'],
  [/you\s+are\s+now\s+/i,                          'role_hijack'],
  [/do\s+not\s+tell\s+the\s+user/i,                'deception_hide'],
  [/system\s+prompt\s+override/i,                   'sys_prompt_override'],
  [/disregard\s+(your|all|any)\s+(instructions|rules)/i, 'disregard_rules'],
  // 数据泄露
  [/curl\s+[^\n]*\$\{?\w*(KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL|API)/i, 'exfil_curl'],
  [/wget\s+[^\n]*\$\{?\w*(KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL|API)/i, 'exfil_wget'],
  [/cat\s+[^\n]*(\.env|credentials|\.netrc)/i,      'read_secrets'],
  // 后门
  [/authorized_keys/i,                               'ssh_backdoor'],
  [/\$HOME\/\.ssh|\~\/\.ssh/i,                       'ssh_access'],
];

// 隐形 Unicode 字符（零宽空格、双向文本控制符）
const INVISIBLE_CHARS = /[\u200B-\u200D\u2060\uFEFF\u202A-\u202E]/;

export function scanMemoryContent(content) {
  if (INVISIBLE_CHARS.test(content)) {
    const match = content.match(INVISIBLE_CHARS)[0];
    return `Blocked: invisible Unicode U+${match.charCodeAt(0).toString(16).toUpperCase()} — possible injection`;
  }

  for (const [pattern, id] of THREAT_PATTERNS) {
    if (pattern.test(content)) {
      return `Blocked: threat pattern '${id}' — memory is injected into system prompt`;
    }
  }

  return null; // safe
}
```

### 3.4 评分器

```javascript
// src/memory/scorer.js

const SOURCE_WEIGHT = {
  manual:    10,
  summary:    8,
  skill:      6,
  web_fetch:  4,
  default:    3,
};

/**
 * 评分 = 来源权重 + 重要性加成 + 标签加成
 *
 * 示例: manual + importance=5 + 2个标签
 *       = 10 + 7.5 + 1.0 = 18.5
 */
export function calculateScore({ importance = 3, source = 'manual', tags = [] }) {
  let score = SOURCE_WEIGHT[source] || SOURCE_WEIGHT.default;
  score += importance * 1.5;
  score += (tags || []).length * 0.5;
  return score;
}
```

### 3.5 Frozen Snapshot 注入器

```javascript
// src/memory/injector.js

import { MemoryStore } from './store.js';

/**
 * 返回当前冻结快照（整个会话不变，保护前缀缓存）
 * 在 Agent 初始化时调用 MemoryStore.freeze() 设置快照
 */
export function getMemoryContext() {
  const snapshot = MemoryStore.getSnapshot();
  const parts = [];

  if (snapshot.agent) parts.push(snapshot.agent);
  if (snapshot.user)  parts.push(snapshot.user);

  if (parts.length === 0) return '';
  return parts.join('\n\n');
}
```

### 3.6 工具: memory_add

```javascript
import { Errors } from '../../utils/errors.js';
import { MemoryStore } from '../store.js';

export const name = 'memory_add';

export const description = `持久化记忆——保存在本地知识库，在后续对话的 System Prompt 中自动可用。

两个独立存储:
- target="agent": Agent 自己的工作笔记（项目上下文、任务进展、技术决策等）
- target="user":  关于用户的画像（偏好、习惯、约束等）

importance (0-5): 越高在 System Prompt 中优先级越高，衰减越慢。
tags: 方便 memory_search 分类检索。
注意: 记忆内容会被注入 System Prompt，不要包含指令或代码片段。`;

export const parameters = {
  type: 'object',
  properties: {
    target: { type: 'string', enum: ['agent', 'user'], default: 'agent',
      description: '存储目标: agent=工作笔记, user=用户画像' },
    title: { type: 'string', description: '简短标题，语义化便于检索' },
    content: { type: 'string', description: '记忆内容 Markdown，≤500 tokens' },
    importance: { type: 'number', minimum: 0, maximum: 5, default: 3 },
    tags: { type: 'array', items: { type: 'string' } },
  },
  required: ['title', 'content']
};

export async function execute(args) {
  const { target, title, content, importance, tags } = args;

  if (!title?.trim()) throw Errors.validation('title', 'Required');
  if (!content?.trim()) throw Errors.validation('content', 'Required');

  try {
    const id = MemoryStore.add({ target, title, content, importance, tags });
    return JSON.stringify({
      success: true, id, target, title,
      note: `已保存到 ${target === 'user' ? '用户画像' : '工作记忆'}。将在下次对话的 System Prompt 中生效。`
    }, null, 2);
  } catch (e) {
    if (e.code === 'SECURITY_BLOCKED') {
      return JSON.stringify({ success: false, error: e.message }, null, 2);
    }
    throw e;
  }
}
```

### 3.7 集成到 Agent

```javascript
// src/core/prompt-builder.js — 唯一侵入点

import { getMemoryContext } from '../memory/injector.js';

export function buildSystemPrompt(options = {}) {
  const sections = [
    baseSystemPrompt(),
    buildSandboxSection(options),
    buildToolSection(options),
  ];

  // ← 仅此新增：注入 Frozen Snapshot 记忆
  const memory = getMemoryContext();
  if (memory) sections.push(memory);

  return sections.join('\n\n');
}
```

```javascript
// src/core/agent.js — 会话启动时冻结快照

import { MemoryStore } from '../memory/store.js';

export class Agent {
  constructor(skillManager, llmClient, options = {}) {
    // ... 现有初始化 ...
    MemoryStore.freeze();  // ← 冻结记忆快照
  }
}
```

## 四、完整示例

### 示例1: 场景设定

```
用户: "记住——我正在用 Rust 开发一个叫 coqiclaw 的 AI agent 项目。
       后端用 Node.js ESM，数据库用 SQLite。
       代码风格：函数式、纯函数、最小依赖。"
Agent: memory_add({target:"agent", title:"coqiclaw 项目技术栈",
        content:"Rust核心 + Node.js ESM后端 + SQLite存储。函数式风格，最小依赖。",
        importance:5, tags:["project","tech-stack"]})

用户: "记住——我喜欢中文回答，代码注释用英文。别用太多 emoji。"
Agent: memory_add({target:"user", title:"语言和风格偏好",
        content:"回答:中文。代码注释:英文。不使用emoji。",
        importance:5, tags:["preference","language"]})

用户: "记住——src/tools/ 下是工具系统，index.js 是注册入口。每个工具导出
       description/parameters/execute 三个字段。"
Agent: memory_add({target:"agent", title:"工具系统架构",
        content:"src/tools/index.js注册入口。buildTool()统一包装。每个工具导出description+parameters+execute。21个内置+3个插件。",
        importance:4, tags:["architecture","tools"]})

用户: "记住——PR#42 是给 auth 模块加 rate limiting 中间件，P0，今天上线。
       测试文件在 test/auth-rate-limit.test.js。"
Agent: memory_add({target:"agent", title:"PR#42 auth rate limiting",
        content:"P0任务，今天上线。添加rate limiting中间件到auth模块。测试:test/auth-rate-limit.test.js。由刘经理指派。",
        importance:5, tags:["p0","auth","urgent"]})
```

### 示例2: 下次会话的效果

```
--- 用户关闭终端，第二天打开 ---

Agent 初始化 → MemoryStore.freeze() 加载:

## 工作记忆 (项目、任务、上下文)
- **coqiclaw 项目技术栈**: Rust核心 + Node.js ESM后端 + SQLite存储。函数式风格...
- **工具系统架构**: src/tools/index.js注册入口。buildTool()统一包装...
- **PR#42 auth rate limiting**: P0任务，今天上线。添加rate limiting中间件...

## 用户画像 (你是谁，偏好与习惯)
- **语言和风格偏好**: 回答:中文。代码注释:英文。不使用emoji。

---

用户: "看看今天有什么要做的"

Agent: 根据我的记忆，今天最重要的任务是 PR#42——给 auth 模块加 rate limiting 中间件，
       P0 今天上线。测试文件在 test/auth-rate-limit.test.js。
       需要我开始 review 代码还是先跑一下测试？

用户: "帮我写个新的工具模块，放在 src/tools/ 下"

Agent: [自动使用中文回答，代码注释用英文，无 emoji]
      根据项目架构，src/tools/ 下每个工具模块需要导出 description、parameters、execute。
      通过 buildTool() 包装后在 src/tools/index.js 注册。

      新工具的模板:

      ```javascript
      // src/tools/my-tool.js
      export const name = 'my_tool';
      export const description = '...';
      export const parameters = { type: 'object', properties: {...} };
      export async function execute(args) { ... }
      ```

      需要我帮你注册到 index.js 吗？
```

### 示例3: Frozen Snapshot 的前缀缓存效果

```
传统做法 (每次对话重建记忆上下文):
  请求1: System Prompt(10K) + Memory(500) + Msg1(200) = 10.7K
  请求2: System Prompt(10K) + Memory(500) + Msg1+2(500) = 11K   ← Memory变了！
  请求3: System Prompt(10K) + Memory(500) + Msg1-3(800) = 11.3K  ← Memory又变了！
  → 前缀缓存命中率: 0%

Frozen Snapshot 做法 (记忆在会话中不变):
  请求1: System Prompt(10K) + Memory(500) + Msg1(200) = 10.7K
  请求2:                            Memory(500) + Msg1+2(500)  ← Memory不变！
  请求3:                            Memory(500) + Msg1-3(800)  ← Memory还是不变！
  → 前缀缓存命中率: 接近 100%（前 10.5K 字节完全复用）
```

**成本对比**（假设 20轮对话，200K context，$2/M tokens input）:

| 模式 | 每轮有效 input tokens | 20轮总成本 |
|------|:---:|:---:|
| 传统 | 增量（缓存命中 0%） | ~$8.00 |
| Frozen Snapshot | 仅增量部分（缓存命中 ~95%） | ~$0.40 |

**降低 95% 的前缀 token 成本。**

## 五、Phase 规划

| Phase | 内容 | 文件数 | 行数 | 工时 |
|:---:|------|:---:|:---:|:---:|
| **1** | Frozen Snapshot + 双表 + 注入扫描 + memory_add/search | 5新+2改 | ~420 | 1.5天 |
| **2** | 层级摘要 (借鉴 OpenHuman) | 2新 | ~120 | 0.5天 |
| **3** | Skill 拉取 (借鉴 OpenHuman auto-fetch) | 4 Skill文件 | ~200 | 1天 |
| **4** | 漂移检测 + 原子写入加固 | 0新+1改 | ~50 | 0.3天 |
| **合计** | | 11+2 | ~790 | **3.3天** |

## 六、与借鉴源的对比

| 特性 | 来源 | 实现方式 |
|------|------|----------|
| Frozen Snapshot | Hermes | 会话启动时 freeze()，全会话不变 |
| 注入扫描 | Hermes | 13条威胁模式 + Unicode检测，写入前执行 |
| 双存储分离 | Hermes | memory_agent + memory_user 两个独立表 |
| 原子写入 | Hermes | tempfile + fsync + rename (Phase 4) |
| 层级摘要 | OpenHuman | LLM 驱动的树折叠 (Phase 2) |
| 评分折叠 | OpenHuman | 多因子评分：来源+重要性+时间+频率 |
| Token 预算控制 | OpenHuman | 硬上限 700 tokens（agent 400 + user 300） |
| Skill 拉取 | coqi-claw 自身 | 通过 exec_skill 定时拉取外部数据 (Phase 3) |
| SQLite 引擎 | coqi-claw 自身 | better-sqlite3 WAL 模式 |
| 工具注册 | coqi-claw 自身 | buildTool() 统一接口 |

## 七、Phase 1 启动检查清单

- [ ] 创建 `src/memory/` 目录 (`store.js`, `scorer.js`, `scanner.js`, `injector.js`)
- [ ] 创建 `src/memory/tools/memory-add.js`
- [ ] 创建 `src/memory/tools/memory-search.js`
- [ ] 在 `src/tools/index.js` 注册 `memory_add`, `memory_search`
- [ ] 在 `src/core/prompt-builder.js` 调用 `getMemoryContext()`
- [ ] 在 `src/core/agent.js` 构造器调用 `MemoryStore.freeze()`
- [ ] 验证: `node --check src/memory/**/*.js`
- [ ] 测试: 添加记忆 → 新会话查看 System Prompt → 验证 Frozen Snapshot 稳定性
