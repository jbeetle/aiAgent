# Skill Summarizer 实现方案（修订版）

## 一、问题

当 `skills/` 目录下安装大量 skill 时，LLM Matcher 的系统提示词会随 skill 数量线性膨胀。
当前每个 skill 的 `description` 直接嵌入 prompt，如 `pdf-summary` 的描述长达 1000+ 字符。

```
50 个 skill × 平均 400 字 = 20,000 字  ← 不可接受
```

**目标**：把 skill 描述压缩为一句话摘要（≤100 字），使 prompt 大小与 skill 数量解耦。

---

## 二、设计原则

1. **不修改 SKILL.md 规范**：不新增 `matcherDescription` 等字段，保证对网上第三方 skill 的兼容性。
2. **启动时完成加载**：摘要生成放在 `BootstrapManager.initializeAgent()` 阶段，避免用户第一次匹配时等待。
3. **进度可感知**：通过日志打印 `[1/N] skill-name`，让用户知道系统在加载数据。
4. **失败可降级**：LLM 不可用时回退到截断 description，不影响系统启动。
5. **缓存复用**：description 未变时不再调用 LLM。

---

## 三、涉及文件

| 文件 | 变更类型 | 说明 |
|------|---------|------|
| `src/skills/skill-summarizer.js` | **新增** | 摘要生成器类 |
| `src/bootstrap/manager.js` | 修改 | 在 `initializeAgent()` 中创建 matcherClient 后调用 summarizer |
| `src/skills/llm-matcher.js` | 修改 | `buildSystemPrompt()` 优先使用 `matchSummary` |
| `src/core/i18n.js` | 修改 | 新增 summarizer 系统提示词的中英文翻译 |
| `.gitignore` | 修改 | 忽略自动生成的 `skills/.match-summaries.json` |
| `skills/.match-summaries.json` | **新增**（自动生成） | 摘要缓存文件 |

---

## 四、新文件：`src/skills/skill-summarizer.js`

```javascript
import { join } from "path";
import { existsSync, readFileSync, writeFileSync } from "fs";
import { createHash } from "crypto";
import pLimit from "p-limit";
import { logger } from "../utils/logger.js";
import { getLocale, t } from "../core/i18n.js";

const CONCURRENCY = 3;
const MAX_SUMMARY_LENGTH = 100;
const FALLBACK_LENGTH = 150;
const SUMMARY_TIMEOUT = 15000;

export class SkillSummarizer {
  /**
   * @param {LLMClient} llmClient - 用于生成摘要的 LLM 客户端（使用 matcherClient）
   * @param {string} skillsDir - skills/ 目录路径
   */
  constructor(llmClient, skillsDir) {
    this.client = llmClient;
    this.cacheFile = join(skillsDir, ".match-summaries.json");
    this.cache = this._loadCache();
  }

  /** 加载缓存 */
  _loadCache() {
    try {
      if (existsSync(this.cacheFile)) {
        return JSON.parse(readFileSync(this.cacheFile, "utf-8"));
      }
    } catch (error) {
      logger.warn("Failed to load match-summaries cache, rebuilding", error.message);
    }
    return {};
  }

  /** 保存缓存 */
  _saveCache() {
    try {
      writeFileSync(this.cacheFile, JSON.stringify(this.cache, null, 2), "utf-8");
    } catch (error) {
      logger.warn("Failed to save match-summaries cache", error.message);
    }
  }

  /** 计算 description 的 hash（变更检测） */
  _hash(str) {
    return createHash("md5").update(str || "").digest("hex").substring(0, 8);
  }

  /** 按词边界截断，避免在触发词中间截断 */
  _trimAtBoundary(text, maxLen) {
    if (!text || text.length <= maxLen) return text;
    const cut = text.substring(0, maxLen);
    const lastBoundary = Math.max(
      cut.lastIndexOf(" "),
      cut.lastIndexOf("/"),
      cut.lastIndexOf("，"),
      cut.lastIndexOf("。"),
      cut.lastIndexOf(","),
      cut.lastIndexOf("."),
    );
    if (lastBoundary > maxLen * 0.7) {
      return cut.substring(0, lastBoundary) + "...";
    }
    return cut + "...";
  }

  /**
   * 批量生成摘要
   * @param {Array} skills - 已加载的 skill 数组（会被原地添加 matchSummary）
   * @param {Object} [options={}] - 选项
   * @param {Function} [options.onProgress] - 进度回调 (current, total, skillName) => void
   */
  async summarizeAll(skills, options = {}) {
    const { onProgress } = options;
    const limit = pLimit(CONCURRENCY);
    const toGenerate = [];

    // 清理已不存在的 skill 的缓存条目
    const validNames = new Set(skills.map((s) => s.name));
    let cleaned = false;
    for (const key of Object.keys(this.cache)) {
      if (!validNames.has(key)) {
        delete this.cache[key];
        cleaned = true;
      }
    }

    for (const s of skills) {
      if (!s.name) continue;
      const hash = this._hash(s.description);
      const cached = this.cache[s.name];
      if (cached && cached.hash === hash && cached.summary) {
        s.matchSummary = cached.summary;
      } else {
        toGenerate.push(s);
      }
    }

    if (toGenerate.length === 0) {
      if (cleaned) this._saveCache();
      logger.info("All skill summaries cached");
      return;
    }

    logger.info(`Generating summaries for ${toGenerate.length} skill(s)`);
    const total = toGenerate.length;
    let completed = 0;

    await Promise.all(
      toGenerate.map((s) =>
        limit(async () => {
          await this._generate(s);
          completed++;
          if (onProgress) onProgress(completed, total, s.name);
        }),
      ),
    );

    this._saveCache();
    logger.info(`Generated ${completed}/${total} skill summaries`);
  }

  /** 单个 skill 摘要生成 */
  async _generate(skill) {
    try {
      const summary = await this._callLLM(skill);
      const trimmed = this._trimAtBoundary(summary.trim(), MAX_SUMMARY_LENGTH);
      skill.matchSummary = trimmed;
      this.cache[skill.name] = {
        hash: this._hash(skill.description),
        summary: trimmed,
      };
    } catch (error) {
      logger.warn(`Failed to generate summary for "${skill.name}", using fallback`, error.message);
      // fallback 不写入缓存，下次启动会重试
      skill.matchSummary = this._trimAtBoundary(skill.description || "", FALLBACK_LENGTH);
    }
  }

  /** LLM 调用 */
  async _callLLM(skill) {
    const locale = getLocale();
    const systemPrompt = t("skillSummarizerSystemPrompt", locale);
    const userPrompt = t("skillSummarizerUserPrompt", locale)
      .replace("{name}", skill.name)
      .replace("{description}", skill.description || "");

    const response = await this.client.chat(
      [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
      null,
      this.client.maxRetries ?? 2,
      null,
      SUMMARY_TIMEOUT,
    );
    return response.content || "";
  }
}
```

---

## 五、`src/bootstrap/manager.js` 改动

在 `initializeAgent()` 中，**创建 matcherClient 之后、创建 Agent 之前**插入摘要生成阶段：

```javascript
async initializeAgent(agentOptions = {}) {
  const { config } = this.state;
  const skillsDir = getSkillsDir();

  const skillManager = new SkillManager(skillsDir);
  await skillManager.loadAll();
  this.state.skillManager = skillManager;

  const primaryClient = new LLMClient({
    config,
    label: "primary",
    enableThinking: config.llmEnableThinking,
    reasoningEffort: config.llmReasoningEffort,
  });
  this.state.primaryClient = primaryClient;

  const matcherConfig = loadMatcherConfig();
  let matcherClient;
  if (matcherConfig) {
    matcherClient = new LLMClient({
      config: matcherConfig,
      label: "matcher",
      enableThinking: matcherConfig.llmEnableThinking,
      reasoningEffort: matcherConfig.llmReasoningEffort,
    });
  } else {
    matcherClient = new LLMClient({
      config,
      label: "matcher",
      enableThinking: false,
      reasoningEffort: null,
    });
  }
  this.state.matcherClient = matcherClient;

  // 为所有 skill 生成匹配摘要
  const skills = skillManager.getAllSkills();
  if (skills.length > 0) {
    const { SkillSummarizer } = await import("../skills/skill-summarizer.js");
    const summarizer = new SkillSummarizer(matcherClient, skillsDir);
    await summarizer.summarizeAll(skills, {
      onProgress: (current, total, name) => {
        logger.info(`正在加载技能数据... [${current}/${total}] ${name}`);
      },
    });
  }

  const agent = new Agent(skillManager, primaryClient, {
    matcherLLMClient: matcherClient,
    config,
    ...agentOptions,
  });
  this.state.agent = agent;

  if (process.env.ENABLE_AUDIT === "true") {
    await this._initializeAudit(config);
  }

  this.state.initialized = true;
  return this;
}
```

> 说明：使用 `await import("../skills/skill-summarizer.js")` 是为了避免 `BootstrapManager` 在不需要时加载 summarizer 的依赖。

---

## 六、`src/skills/llm-matcher.js` 改动

```diff
  const skillList = skills.map((s, i) => {
-   return `${i + 1}. ${s.name}: ${s.description}`;
+   return `${i + 1}. ${s.name}: ${s.matchSummary || s.description}`;
  });
```

---

## 七、`src/core/i18n.js` 新增 key

中文：

```javascript
skillSummarizerSystemPrompt:
  "你是一个技能总结助手。将长描述压缩为短摘要，用于技能语义匹配。\n\n" +
  "格式要求：\n" +
  "- 一句话概括，100字以内\n" +
  "- 结构：[核心功能] + [关键特性] + [触发词]\n" +
  "- 触发词必须从描述中提取，用 / 分隔\n" +
  "- 只返回摘要文本\n\n" +
  "错误示例：\n" +
  "  处理天气信息和相关数据，提供良好的用户体验\n\n" +
  "正确示例：\n" +
  "  查询全球城市天气、预报和空气质量，提供出行建议。触发：天气/温度/降雨/紫外线/穿衣\n" +
  "  总结PDF文档：短摘要/要点/分段/结构化输出。支持大文件分块和CJK。触发：总结/提炼/摘要/概要 PDF",
skillSummarizerUserPrompt: "技能名: {name}\n描述: {description}",
```

英文：

```javascript
skillSummarizerSystemPrompt:
  "You are a skill summarization assistant. Compress long descriptions into short summaries for skill semantic matching.\n\n" +
  "Format requirements:\n" +
  "- One sentence, within 100 characters\n" +
  "- Structure: [core function] + [key features] + [trigger words]\n" +
  "- Trigger words must be extracted from the description, separated by /\n" +
  "- Return only the summary text\n\n" +
  "Bad example:\n" +
  "  Processes weather information and related data, providing a good user experience\n\n" +
  "Good example:\n" +
  "  Query global city weather, forecast and air quality, provide travel advice. Triggers: weather/temperature/rain/UV/dressing\n" +
  "  Summarize PDF documents: short/bullet/section/structured. Supports chunked extraction and CJK. Triggers: summarize/extract/abstract/summary PDF",
skillSummarizerUserPrompt: "Skill name: {name}\nDescription: {description}",
```

---

## 八、`.gitignore` 改动

新增一行：

```gitignore
skills/.match-summaries.json
```

说明：缓存文件是环境生成的产物，不同模型、不同用户可能生成不同结果，不建议纳入版本控制。

---

## 九、摘要 prompt 设计说明

### 为什么用「触发词」格式

```
自然语言: "这个技能可以查询天气，提供预报和空气质量信息"
          → Matcher 难以对齐"空气质量"这个词

触发词格式: "触发：天气/温度/降雨/紫外线/空气质量"
           → 每个词都是明确匹配信号
```

### 为什么 100 字

```
60 字:  pdf-summary 的"多风格/大文件分块/CJK"塞不下
100 字: 足够容纳 1 个功能 + 2~3 个特性 + 5~8 个触发词
1024 字(原文): 太长，达不到压缩目的
```

---

## 十、调用次数分析

| 场景 | LLM 调用 |
|------|---------|
| 首次启动（7 个 skill 无缓存） | 7 次并发（上限 3 个并行）→ 约 3 批 |
| 第二次启动 | 0 次（全部命中缓存） |
| 新增 1 个 skill | 1 次 |
| 修改 skill description | 1 次（hash 失效） |
| 删除 skill | 0 次，下次启动清理缓存条目 |
| LLM 摘要服务不可用 | 0 次 → 降级为截断 |

---

## 十一、效果预估

| | 改前 | 改后 |
|---|---|---|
| 6 个 skill prompt 大小 | ~2,500 字 | ~400 字 |
| 50 个 skill prompt 大小 | ~20,000 字 | ~3,000 字 |
| 100 个 skill prompt 大小 | ~40,000 字 | ~6,000 字 |
| 首次启动额外耗时 | 0 | ~3-5 秒（并发 3） |
| 后续启动耗时 | 0 | ~10 毫秒（读缓存） |

---

## 十二、降级策略

```
优先级 1: 缓存命中且 description 未变 → 使用缓存 matchSummary
优先级 2: 缓存未命中 → LLM 生成 → 写入缓存
优先级 3: LLM 调用失败 → 截断 description（不写入缓存，下次重试）
优先级 4: description 为空 → 仅显示 skill.name
```

---

## 十三、风险与注意事项

1. **缓存文件写入失败**：skills 目录只读时无法写入缓存。此时仍可使用 fallback 截断运行，但会失去缓存加速。可考虑未来迁移到 `getDataDir()`。
2. **LLM 输出不稳定**：同一段 description 可能每次生成略有不同摘要。这通常不影响匹配，但会导致缓存频繁失效。可通过固定 temperature=0 缓解。
3. **超长触发词列表**：若 skill 触发词很多，100 字可能不够。可以让 LLM 优先保留高频/核心触发词。
4. **进度日志在 TUI 模式**：当前通过 `logger.info` 输出，TUI 的 spinner 可能覆盖。未来可接入 TUI 的进度条组件。

---

## 十四、验证步骤

1. 语法检查：`node --check src/skills/skill-summarizer.js`、`node --check src/bootstrap/manager.js`
2. 删除缓存 `skills/.match-summaries.json`，启动应用，观察日志输出 `[1/N] skill-name`
3. 第二次启动，观察日志输出 `All skill summaries cached`
4. 运行 `npm test` 或 `node test/test-integration-matching.js`，确认匹配行为正常
5. 渲染 matcher 系统提示词，确认 skill 描述已被压缩到 ≤100 字
