# Chrome 工具优化清单

> 基于对 `src/tools/chrome-*.js` 的 code review，总结当前阻碍 Agent 高效准确工作的关键问题。

---

## ✅ 已修复

### 1. `block_requests` 的 `*` 通配 Bug

**修复时间**：2026-04-21

**改动**：`chrome-cdp.js:1923-1971`

将原来所有资源类型都用 `*` 通配符拦截的方式，改为按**文件扩展名精确匹配**：
- 图片：`*.jpg`, `*.jpeg`, `*.png`, `*.gif`, `*.svg`, `*.webp`, `*.ico`, `*.bmp`, `*.avif`
- CSS：`*.css`
- 字体：`*.woff`, `*.woff2`, `*.ttf`, `*.otf`, `*.eot`
- 媒体：`*.mp4`, `*.webm`, `*.ogv`, `*.mp3`, `*.wav`, `*.ogg`, `*.m4a`, `*.aac`, `*.flac`

**根因**：`Network.setBlockedURLs` 只接受 URL pattern 字符串数组，不支持 `resourceType`。原来传 `urls: ['*', '*', '*', '*']` 实际上等同于 `['*']`，会拦截包括 HTML、JS、XHR 在内的所有网络请求，导致页面白屏。

---

### 2. `snapshot` 文字内容获取增强

**修复时间**：2026-04-21

**改动**：`chrome-cdp.js:572-626`

| 优化点 | 修改前 | 修改后 |
|--------|--------|--------|
| text 截断 | `substring(0, 100)` | `substring(0, 500)` |
| a 标签 href | 无 | 新增 `href` 字段 |
| iframe 遍历 | 只遍历 `document.body` | 递归遍历同域 iframe，跨域自动跳过 |

---

### 3. `snapshot` 选择器唯一化

**修复时间**：2026-04-21

**改动**：`chrome-cdp.js:578-596`

选择器生成逻辑从：
```javascript
const selector = id ? '#' + id : (cls ? '.' + cls.split(' ')[0] : tag);
```

改为 `getUniqueSelector()`：
- 有 `id` 的元素 → `#id`（最简短且唯一）
- 无 `id` 的元素 → `body > div:nth-child(2) > button:nth-child(3)`（完整路径，每个元素唯一）

---

### 4. 多 tab active target 跟踪

**修复时间**：2026-04-21

**改动**：`chrome-cdp.js` 全局 30+ 处

**问题**：`getCDPClient` 只连接第一次获取到的 page 的 WebSocket，不跟踪当前激活的 tab。Agent `new_page` 打开新页面后，`snapshot`/`click` 仍操作在旧页面上。

**修复内容**：
1. `CDPClient.send` 支持 `sessionId` 参数，通过同一 WebSocket 路由到不同 target
2. `TargetSessionClient` 保存并使用 `sessionId`，attach 后命令发往正确 target
3. `createTargetSession` 正确获取 `attachToTarget` 返回的 `sessionId`
4. `newPage` 创建新 tab 后自动设为 `activeTargetId` 并创建 target session
5. `navigate`/`closePage` 使用 `getActiveTarget()` 获取正确的 target ID
6. 所有操作函数（click、fill、snapshot、evaluate 等 20+ 个）统一通过 `getClientForTarget()` 获取 client，自动路由到 active target

---

### 5. `snapshot` 补充 `name` 属性

**修复时间**：2026-04-21

**改动**：`chrome-cdp.js:638-640`

对 `input`/`textarea`/`select` 标签增加 `name` 字段，Agent 可利用该属性定位表单字段。

---

### 6. 暴露 `wait_for_text` 给 Agent

**修复时间**：2026-04-21

**改动**：`chrome-interact.js`

- description 增加 `wait_for_text` 说明
- action enum 增加 `wait_for_text`
- parameters 增加 `texts` 数组参数
- execute 中调用底层 `cdp.waitForText()`

Agent 现在可直接使用 `wait_for_text` 等待页面文本出现，无需写 `evaluate` 轮询。

---

### 7. `screenshot` 保存路径改为可访问目录

**修复时间**：2026-04-21

**改动**：`chrome-nav.js:1-4, 74`

截图保存路径从 `os.tmpdir()`（系统临时目录，Agent 无法访问）改为 `getBaseDir()/output/screenshots/`（项目 output 目录，Agent 可通过 `read` 工具读取）。

---

### 8. snapshot 元素上限提升

**修复时间**：2026-04-21

**改动**：`chrome-cdp.js:670-677`

- 元素上限从 200 提升到 500
- 返回结果新增 `totalElements` 和 `truncated` 字段，Agent 可感知是否有信息被截断

---

### 9. click 事件完善

**修复时间**：2026-04-21

**改动**：`chrome-cdp.js:503-517`

将原来仅触发 `el.click()` 的方式，改为完整的鼠标事件序列：
```javascript
const opts = { bubbles: true, cancelable: true, clientX: x, clientY: y };
el.dispatchEvent(new MouseEvent('mousedown', opts));
el.dispatchEvent(new MouseEvent('mouseup', opts));
el.dispatchEvent(new MouseEvent('click', opts));
```

事件包含元素中心坐标（`clientX`/`clientY`），`bubbles: true` 确保事件冒泡，SPA 框架（React/Vue/Angular）可正确捕获。

---

### 10. `evaluate` 去掉 async IIFE 包装

**修复时间**：2026-04-21

**改动**：`chrome-cdp.js:743-748` 与 `chrome-nav.js:40-42`

- 去掉 `(async function() { ${script} })()` 包装，直接传递 `expression: script`
- 保留 `awaitPromise: true`，Agent 仍可使用 `await`
- 更新工具描述：告诉 Agent "Write an expression (not a function), the result is returned automatically"

Agent 现在可以像 Chrome 控制台一样直接写表达式：`document.title`、`document.querySelector('h1').innerText`、`await fetch('/api').then(r => r.json())`，无需写 `return`。

---

## 🟢 细节优化建议（未修复）

| 问题 | 位置 | 说明 |
|------|------|------|
| fill 缺少 focus | `chrome-cdp.js:537-548` | 未触发 `focus`/`blur`，某些表单验证失效 |
| 连接断开无感知 | `chrome-cdp.js:270-286` | WebSocket 断开后没有重连，Agent 后续操作全部失败 |

---

### 11. Skill 文档同步更新

**修复时间**：2026-04-21

**改动**：`skills/henry-chrome-automation/SKILL.md` + `references/*.md`

同步工具层优化到 skill 文档，确保 Agent 按照最新行为操作：

| 变更项 | 说明 |
|--------|------|
| 工具分工 | `chrome_interact` 增加 `wait_for_text` action |
| 新增 WF3 | "等待页面文本出现"工作流，展示 `wait_for_text` 用法 |
| 选择器说明 | 更新为 snapshot 返回的唯一路径选择器格式，告知 Agent 直接复制使用 |
| 返回值 | snapshot 增加 `totalElements`、`truncated`、`href`、`name` 字段说明；screenshot 路径说明更新 |
| evaluate 描述 | 更新为"直接写表达式"，所有示例修正为有效表达式形式 |
| click 恢复 | "操作无效"恢复步骤简化（click 现在触发完整事件序列） |
| 参数参考 | `chrome_interact` enum 增加 `wait_for_text`，新增 `texts` 参数 |

---

### 12. fill 事件完善

**修复时间**：2026-04-21

**改动**：`chrome-cdp.js:563-569`

在设置 `value` 前后分别触发 `focus()` 和 `blur()`，并保留原有的 `input` 和 `change` 事件：
```javascript
el.focus();
el.value = value;
el.dispatchEvent(new Event('input', { bubbles: true }));
el.dispatchEvent(new Event('change', { bubbles: true }));
el.blur();
```

某些表单验证框架（如 React Final Form、VeeValidate）依赖 `blur` 事件触发校验，此修复确保表单验证正常工作。

---

### 13. WebSocket 断连自动重连

**修复时间**：2026-04-21

**改动**：`chrome-cdp.js:271-291` 与 `chrome-cdp.js:336-351`

- `ws.on('close')` 处理器：连接断开时拒绝所有 pending 请求，清理队列，避免请求卡死
- `ws.on('error')` 处理器：记录警告但不阻断（连接后错误不再抛异常）
- `send()` 方法：发送前检测 `ws.readyState`，如非 `OPEN` 则自动调用 `connect()` 重连

Agent 在长时间会话中即使 Chrome 页面刷新或网络波动导致连接断开，后续操作也会自动重连并继续执行。

---

## 🟡 后续修复

### 14. 修复 snapshot 数据量过大导致消息截断

**修复时间**：2026-04-21

**改动**：`chrome-cdp.js:635,693` 与 `skills/henry-chrome-automation/SKILL.md:31-52`

**问题**：
- MAX_ELEMENTS 设为 5000、text 截断 500 字符后，单次 snapshot 返回 100KB+ 数据
- `MAX_SINGLE_MESSAGE_SIZE` = 20000 字符，`MAX_MESSAGES_SIZE` = 80000 字节
- 第 6 轮迭代触发 emergency truncation，历史消息被截断，Agent 丢失页面结构
- 截断后 `click #search-button` 失败，任务进入错误循环

**v1 修复（2026-04-21）**：
- `text` 截断：500 → **200** 字符
- `MAX_ELEMENTS`：5000 → **200**
- skill 增加"避免重复 snapshot"原则
- skill 增加"Snapshot 数据限制"说明

**v2 优化（2026-04-21）——从源头减少数据量**：

| 优化项 | 修改前 | 修改后 | 效果 |
|--------|--------|--------|------|
| 纳入范围 | a/button/input/textarea/select/h1-h6/label/img + hasId + hasBtnClass + onclick | **a/button/input/textarea/select** + onclick | 去掉标题/标签/图片和宽松的 id/class 规则，大幅减少无关元素 |
| 子元素去重 | 父元素纳入后子元素仍重复遍历 | 增加 `parentIncluded` 标志，已纳入元素的**子树整体跳过** | 避免 button 里的 span、icon 被作为独立元素重复返回 |
| text 截断 | 200 字符 | **100 字符** | 单个元素更小 |

**预期效果**：单条 snapshot 从 30-50KB 降到 **5-10KB**，历史消息可支撑 8-15 轮不触发截断。

---

### 15. Skill 文档 press_key 归属明确化

**修复时间**：2026-04-21

**改动**：`skills/henry-chrome-automation/SKILL.md:24`

确认 `press_key` 已在 `chrome_nav` 工具分工表中正确列出。Agent 误将 `press_key` 发到 `chrome_interact` 的原因是技能匹配或上下文混乱，文档本身已正确。通过减少 snapshot 频率降低上下文混乱概率。

---

### 16. 选择器策略改进（nth-child → class + nth-of-type）

**修复时间**：2026-04-21

**改动**：`chrome-cdp.js:614-659`

**问题**：`nth-child` 完整路径选择器（如 `body > div:nth-child(2) > div:nth-child(3) > a:nth-child(1)`）在页面动态更新时极易失效——前面插入新元素后索引全部偏移。

**修复**：新策略分层递进：
1. 有 id → `#id`
2. 无 id → `tag.class1.class2:nth-of-type(N)`（class + nth-of-type）
3. 不唯一 → `parentTag.parentClass > tag.class1.class2:nth-of-type(N)`（只加一层父元素）

**优势**：
- `nth-of-type` 只统计同标签名兄弟，不受其他类型元素插入影响
- class 选择器比纯 nth-child 更语义化
- 选择器长度从 `body > div:nth-child(2) > div:nth-child(3) > a:nth-child(1)` 缩短到 `.note-item:nth-of-type(1) a`

---

### 17. 增强 Chrome 反检测与限速策略

**修复时间**：2026-04-21

**改动**：`chrome-cdp.js:154-172`、`chrome-cdp.js:471-486` 与 `skills/henry-chrome-automation/SKILL.md:56-89`

**问题**：
- 每次启动 Chrome 使用全新临时 user-data-dir，无 cookies/session，网站一眼识别为新用户
- `navigator.webdriver` 未隐藏，缺少插件/语言指纹
- Agent 操作间隔过短，触发反爬 rate limit

**修复**：

| 层面 | 改动 | 效果 |
|------|------|------|
| Chrome 启动参数 | user-data-dir 改为按 port 持久化 (`temp/chrome-profile-{port}`) | 保留 cookies、localStorage、session，建立正常用户画像 |
| Chrome 启动参数 | 新增 `window-size=1920,1080`、`start-maximized`、`disable-features=IsolateOrigins,site-per-process` | 模拟真实显示器，减少站点隔离带来的指纹差异 |
| JS 注入 | `Page.addScriptToEvaluateOnNewDocument` 注入 stealth 脚本：隐藏 `navigator.webdriver`、模拟 `chrome.runtime`、伪造 `navigator.plugins` 和 `navigator.languages` | 绕过最常见的自动化检测脚本 |
| Skill 限速 | 新增"限速与反爬"章节，明确操作间隔：navigate 后 2-3s、click/fill 之间 1s、翻页 5-10s | 降低被识别为机器人的概率 |

---

## ✅ 全部修复完成

所有 Chrome 工具优化点已全部修复（共 17 项）。当前无未修复问题。
