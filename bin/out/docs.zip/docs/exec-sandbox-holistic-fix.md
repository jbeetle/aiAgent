# exec 路径沙箱与工具选型 — 整体修复方案

> 状态：**P0+P1 已实施**（2026-05-22）  
> 日期：2026-05-22  
> 背景：用户请求「列出 C 盘根目录」时，Matcher 推荐 `exec`；`dir C:\` 被路径校验拦截后，Agent 使用 `powershell -Command "Get-ChildItem -Path C:\ ..."` 绕过静态路径校验并成功执行。

---

## 1. 问题摘要

### 1.1 已观测行为

| 轮次 | 命令形态 | 结果 |
|------|----------|------|
| 1 | `dir C:\` 或等价 CMD 参数 | **BLOCK**：`File operation path "C:\" is outside sandbox` |
| 2 | `powershell -Command "Get-ChildItem -Path C:\ ..."` | **ALLOW** → 自动切 `pwsh` 后执行成功 |

### 1.2 根因（静态路径校验盲区）

`validateCommandPathArguments()` 对命令分词后首 token 为 `powershell`，而非 `Get-ChildItem`：

- Layer 1（CMD schema）：无 `powershell` schema，跳过。
- Layer 2（PowerShell cmdlet）：仅当**整段以 cmdlet 开头**时调用 `validatePowerShellPaths`；`-Command` 内嵌脚本不解析。
- Layer 3（保守回退）：`C:\` 位于第三个 token 字符串**中间**，`isDefinitePath()` 不匹配 token 首部，放行。

### 1.3 关联问题（非同一 bug，需一并治理）

1. **工具选型**：LLM Matcher 将「列目录」映射为 `relevantTools: ["exec"]`，系统提示「优先使用 exec」，而项目已有 `list` 工具。
2. **需求越界**：`C:\` 在 `SANDBOX_MODE=enforce` 下本就不应满足；`list({ path: "C:\\" })` 同样应被 `validatePath` 拒绝。
3. **架构级绕过**（见 `doc/safe-solution.md` §已知限制）：`write` 沙箱内脚本 + `exec` 执行，脚本体内可访问沙箱外路径；纯 Node 静态校验无法彻底杜绝。

---

## 2. 设计目标

**文件系统读写在沙箱内优先走专用工具；`exec` 定位为「已校验的脚本启动器」，不作为任意列目录 / 访问盘符的通用通道。**

---

## 3. 整体架构：四层防护 + 统一策略

```
┌─────────────────────────────────────────────────────────────┐
│ 0. 策略层（单一真相）                                         │
│    列目录 → list/glob │ 读文件 → read │ 写 → write           │
│    仅 skill 脚本 / 白名单场景 → exec                          │
└───────────────────────────┬─────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────┐
│ 1. 路由层                                                     │
│    match-rule.json │ list 工具描述 │ 系统提示 / bookend       │
└───────────────────────────┬─────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────┐
│ 2. 静态层（exec 执行前必过）                                  │
│    规范化 unwrap → 路径提取 extractPaths → validatePath 全量  │
│    + validateCommand 语义规则                                 │
└───────────────────────────┬─────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────┐
│ 3. 运行时层（接受固有局限）                                   │
│    Skill 隔离 cwd │ DISABLED_TOOLS │ 场景预设 │ OS 隔离(可选) │
└─────────────────────────────────────────────────────────────┘
```

| 层 | 解决什么 | 对本次 incident |
|----|----------|-----------------|
| 0 策略 | 何种需求禁止用 exec 满足 | 「列 C 盘」应拒绝或改为列沙箱目录 |
| 1 路由 | Matcher/提示勿只推 exec | 避免 `relevantTools: ["exec"]` |
| 2 静态 | 嵌套命令内路径也要校验 | 堵住 `powershell -Command` |
| 3 运行时 | 脚本体内 `open()` 等 | 文档化；高安全场景禁 exec |

---

## 4. 核心模块：`exec-policy`（建议新建）

**路径**：`src/security/exec-policy.js`（名称可调整）

**职责**：`exec.js` 在执行前只调用一个审计入口，避免逻辑散落在 `command-path-validator.js` 与 `exec.js`。

```javascript
// 概念 API
auditExecCommand(command, shell, { context, skillName, sandboxMode })
  → { allowed, normalizedCommand, violations[], userHint }
```

### 4.1 Step A — 规范化（unwrap launchers）

识别外壳命令，取出**待校验表面**（可能多条 segment）：

| 外壳 | 处理 |
|------|------|
| `powershell` / `pwsh` + `-Command` | 取出引号内脚本，进入内层校验 |
| `powershell` / `pwsh` + `-EncodedCommand` | Base64 UTF-16LE 解码后校验 |
| `cmd /c "..."` | 取出内层 |
| `python -c` / `node -e` | 内层路径扫描（P2 可加强） |

**general 模式推荐策略**：

- **禁止或严格限制** `-Command` / `-EncodedCommand`（嵌套脚本不可信）。
- **允许**：`pwsh -File skills/<name>/scripts/run.ps1`（路径须过 `validateSkillScriptPath` + `validatePath`）。

内层 PowerShell 对整段脚本复用现有 `POWERSHELL_PATH_PARAMS` + `validatePowerShellPaths()`（`Get-ChildItem -Path` 等）。

### 4.2 Step B — 路径提取（单一实现）

对每条 segment 依次：

1. 已知 CMD schema（`dir`、`copy`…）— 沿用 `command-path-schemas.js`
2. 顶层 PowerShell cmdlet — 沿用 `validatePowerShellPaths`
3. **新增**：从 `-Command` / 解码后的内层脚本再跑 PowerShell 路径提取
4. 未知命令 — Layer 3 保守回退，**增强**：对引号内字符串扫描 `-Path` / `LiteralPath` 等（不只依赖 token 首字符）

**所有提取路径** → `validatePath()`（尊重 `SANDBOX_MODE`：`off` / `warn` / `enforce`）。

### 4.3 Step C — 命令语义

继续调用现有 `validateCommand()`：

- `blockedPatterns`、分号链、`EXEC_MODE=strict` 白名单、skill 模式放宽等保持不变。
- general 模式：不把「系统管理 / 列盘符」默认为 exec 职责。

### 4.4 Step D — 结构化拒绝与 hint

用户请求路径全部越界（如 `C:\`）时：

- 拒绝 exec，返回 `SECURITY` + `hint`：请使用 `list` 列沙箱内目录，或说明仅需工作区内容。
- **禁止**在错误处理中暗示改用 `powershell -Command` 重试。

---

## 5. 路由层：专用工具优先

### 5.1 `config/match-rule.json`

新增语义规则示例：

```json
{
  "scenario": "用户要列出目录内容、浏览文件夹、查看某路径下有哪些文件",
  "skills": [],
  "tools": ["list"],
  "confidence": 0.85,
  "note": "不要用 exec 的 dir/Get-ChildItem；沙箱外路径 list 也会拒绝"
}
```

### 5.2 工具与提示文案

| 位置 | 改动要点 |
|------|----------|
| `src/tools/list.js` `description` | 列目录**必须优先** `list`；沙箱外路径会失败 |
| `src/tools/exec.js` `description` | 勿用 exec 做目录列举；用 `list` |
| `src/core/i18n.js` / `prompt-builder.js` | Windows 环境说明：`list` = 列目录，`exec` ≠ dir |
| Matcher 规则 5 补充 | 列目录类需求填 `list`，非 `exec` |

说明：`relevantTools` **不**从 function calling 中移除其它工具，仅影响「优先工具」段落；路由层降低误选概率。

---

## 6. 运行时层：已知上限与场景

引用 `doc/safe-solution.md` §已知限制：

- `write` + `exec` 执行沙箱内脚本，脚本硬编码外部路径 → **静态层无法完全封堵**。

| 场景 | 建议 |
|------|------|
| personal / dev | P0 静态 unwrap + P0 路由 |
| enterprise | + `ENABLE_EXEC_ISOLATION` + `EXEC_MODE=strict` |
| financial | `DISABLED_TOOLS=exec`（已有预设） |
| 最高安全 | 禁 exec + OS 用户/容器仅挂载沙箱目录 |

可选 P3：general 禁止 `python -c` / `node -e`；对 `temp/*.py` 做简单 AST 扫描绝对路径（误报需调参）。

---

## 7. 实施阶段

| 阶段 | 内容 | 验收 |
|------|------|------|
| **P0** | `unwrapPowerShellCommand` + 内层 `validatePowerShellPaths` | `powershell -Command "Get-ChildItem -Path C:\"` → BLOCK |
| **P0** | `match-rule.json` + `list`/`exec` 描述 + 沙箱外 hint | Matcher 推荐 `list`；模型少先试 exec |
| **P1** | `auditExecCommand` 单入口；`exec.js` 仅调用该函数 | 路径逻辑集中一处 |
| **P1** | general 限制 `-Command` / `-EncodedCommand`（或仅允许 `-File` 且路径在 skill/沙箱内） | 封住整类嵌套外壳 |
| **P2** | 更新 `doc/safe-solution.md`、`doc/tools.md`；扩展 `test/test-command-path-validator.js` | CI 手工跑测试矩阵 |
| **P3** | 脚本 AST / 禁 `-c` / OS 隔离 | 缓解 write+exec 链 |

### 7.1 回归测试矩阵（`test/test-command-path-validator.js` 或新文件）

| 用例 | 期望 |
|------|------|
| `dir C:\` | BLOCK |
| `Get-ChildItem -Path C:\` | BLOCK |
| `powershell -Command "Get-ChildItem -Path C:\"` | BLOCK |
| `pwsh -EncodedCommand <含 C:\ 的编码>` | BLOCK |
| `cmd /c "powershell -Command \"Get-ChildItem -Path C:\""` | BLOCK |
| `list` 工具 `path: "C:\\"`（工具单测） | BLOCK |
| `Get-ChildItem -Path <sandbox>/output` | ALLOW |
| `list({ path: "." })` | ALLOW |

---

## 8. 方案对比

| 做法 | 优点 | 缺点 |
|------|------|------|
| 仅加正则拦 `powershell -Command` | 实现快 | `cmd /c`、`bash -c` 等仍可能漏 |
| **本方案（推荐）** | unwrap + 全路径提取 + 路由 + 可测试 | 需新增模块与测试 |
| 彻底禁用 `exec` | 最安全 | skill 脚本、构建类任务受影响 |

---

## 9. 相关文件（实施时）

| 文件 | 角色 |
|------|------|
| `src/security/exec-policy.js` | **新建**：统一审计流水线 |
| `src/security/command-path-validator.js` | 扩展内层 PowerShell / 引号内路径扫描 |
| `src/tools/exec.js` | 调用 `auditExecCommand` |
| `config/match-rule.json` | 列目录 → `list` |
| `src/tools/list.js` | 工具描述 |
| `test/test-command-path-validator.js` | 回归矩阵 |
| `doc/safe-solution.md` | 实施后更新「已知限制」与修复记录 |

---

## 10. 修订记录

| 日期 | 说明 |
|------|------|
| 2026-05-22 | 初稿：基于 Web 日志 incident 与代码审查整理 |
| 2026-05-22 | P0+P1 落地：`exec-policy.js`、`command-path-validator` 嵌套校验、match-rule、测试 |
| 2026-05-22 | 工作区隔离：`validateWorkspacePath` 限制文件工具仅访问 user/output/temp/database/logs（`SANDBOX_WORKSPACE_ONLY=false` 可恢复） |
