# coqi-claw 用户画像机制设计审查 — 已确认决策记录

> 针对 `docs/user-profile-design.md` 的 review 结论，所有问题已讨论完毕并确认决策。
>
> 审查日期：2026/06/24–25

## 已确认决策汇总

| 编号 | 问题 | 决策 |
|------|------|------|
| D-1 | `UNIQUE(user_id, category, content)` 唯一键 | 取消，去重由应用层/LLM 处理 |
| D-2 | 缺少 TTL / 置信度 / 过期机制 | Phase 1 不做，画像条目永久保留 |
| D-3 | 写入语义一致性（先删后插 vs 只提取新偏好） | 方案 A：修改 Prompt，LLM 每次返回该会话"全部仍然有效的偏好" |
| D-4 | 统一使用 `Errors` / `ErrorTypes` | 同意，后台线程 LLM 调用失败统一包装 |
| D-5 | 提取 Prompt 增加 Few-shot 示例 | 同意，增加 3 个中文示例 |
| D-6 | 仅取 user 消息会丢失纠正信号 | 只取 `role='user'` 消息，不附带 assistant 上下文 |
| D-7 | `MAX_USER_CHARS = 3000` 太保守 | 改为 30000 |
| D-8 | `RESCAN_RATIO = 0.5` 偏高 | 改为 0.3 |
| D-9 | `SCAN_INTERVAL` 2 小时太保守 | 改为 30 分钟 |
| D-10 | Phase 3 全量兜底扫描 | 取消，30 分钟扫描频率 + Agent 启动即开始，不会积累未扫老会话 |
| D-11 | `profile_set` 立即生效 vs Frozen Snapshot | 方案 A：`profile_set` 调用后触发 `invalidateSystemPrompt()`，当前会话立即生效 |
| D-12 | cleanup 中 `process.exit(0)` | 去掉，只停止扫描线程，让 Node.js 自然退出 |
| D-13 | 用户消息外发至 LLM 需要开关 | 增加 `ENABLE_PROFILE_EXTRACTION` 开关 + `BACKGROUND_LLM_*` 独立配置，无 Fallback 链 |

## 各决策详细说明

### D-1. 取消唯一键

- **决策**：删除 `UNIQUE(user_id, category, content)` 约束
- **理由**：画像条目数量级预计 <100，数据库唯一键收益小，且限制后续 LLM 语义去重灵活性
- **影响**：`buildProfileBlock()` 和写入逻辑需在应用层负责去重

### D-2. 不做过期机制

- **决策**：Phase 1 不增加 `expires_at` 字段，画像条目永久保留
- **理由**：偏好本质是长期/永久的；LLM 提取 Prompt 已限定只提取稳定偏好；数量级可控；偏好变化时通过重扫或 `profile_set` 覆盖

### D-3. 方案 A：全量重提取

- **决策**：修改 Prompt 语义，LLM 每次返回该会话"当前仍然有效的全部偏好"
- **理由**：与先删后插完全匹配，实现最简单；每次重扫自然修正过时偏好；重扫频率低（30 分钟），token 成本可控
- **影响**：Prompt 已更新，先删后插逻辑不变

### D-4. 统一错误处理

- **决策**：后台线程 LLM 调用失败使用项目统一的 `Errors` / `ErrorTypes`
- **理由**：符合 `.claude/rules/coding-rules.md` 要求

### D-5. Few-shot 示例

- **决策**：提取 Prompt 增加 3 个中文示例
- **理由**：稳定 LLM 输出格式，减少 `constraints` 写成字符串而非数组等问题

### D-6. 只取 user 消息

- **决策**：只取 `role='user'` 消息，不附带 assistant 上下文
- **理由**：简单直接，token 消耗低；用户纠正信号通过 user 消息本身已能体现

### D-7. MAX_USER_CHARS 调整

- **决策**：从 3000 改为 30000
- **理由**：现代 LLM 支持长上下文，3000 太保守，绝大多数会话用户消息可完整传入

### D-8. RESCAN_RATIO 调整

- **决策**：从 0.5 改为 0.3
- **理由**：50% 增量阈值偏高，30% 更合理，能更及时捕获新偏好

### D-9. SCAN_INTERVAL 调整

- **决策**：从 2 小时改为 30 分钟
- **理由**：2 小时太保守，30 分钟更及时，且不会显著增加 LLM 调用成本

### D-10. 取消全量兜底扫描

- **决策**：取消 Phase 3 全量兜底扫描方案
- **理由**：30 分钟扫描频率 + Agent 启动即开始扫描，不会积累未扫过的老会话

### D-11. profile_set 立即生效

- **决策**：`profile_set` 调用后触发 `invalidateSystemPrompt()`，当前会话后续轮次立即使用新画像
- **理由**：与工具描述"立即生效"一致，用户说"记住xxx"后能立即看到效果；复用已有 `invalidateSystemPrompt()` 机制

### D-12. cleanup 去掉 process.exit(0)

- **决策**：SIGINT/SIGTERM 处理中只停止扫描线程，不调用 `process.exit(0)`
- **理由**：`process.exit(0)` 会打断其他异步清理（日志、WebSocket、审计落盘）

### D-13. 后台任务 LLM 独立配置

- **决策**：增加 `ENABLE_PROFILE_EXTRACTION` 开关（默认 false）+ `BACKGROUND_LLM_*` 独立配置
- **理由**：
  - 金融/企业场景下用户消息外发至 LLM 需要可控
  - 后台任务 LLM 命名为 `BACKGROUND_LLM_*`，不限于画像提取，未来其他后台分析场景复用
  - 无 Fallback 链，调用失败记录日志，下次扫描周期重试
- **配置项**：
  ```bash
  ENABLE_PROFILE_EXTRACTION=true
  BACKGROUND_LLM_API_KEY=xxx
  BACKGROUND_LLM_BASE_URL=xxx
  BACKGROUND_LLM_MODEL=xxx
  BACKGROUND_LLM_REQUEST_TIMEOUT=60000
  BACKGROUND_LLM_MAX_RETRIES=3
  BACKGROUND_LLM_TEMPERATURE=0.1
  BACKGROUND_LLM_HTTP_MAX_SOCKETS=10
  BACKGROUND_LLM_KEEP_ALIVE_TIMEOUT=300000
  ```

## 已确认的技术事实

- `sessions` 表已有 `status` 字段（枚举：`'active'` / `'archived'`），设计文档中 `WHERE s.status = 'active'` 正确
- `sessions` 表已有 `message_count` 和 `updated_at` 字段，与设计文档一致
- `src/sessions/` 使用 better-sqlite3，需确认 WAL 模式是否已启用（影响后台线程并发写入）
