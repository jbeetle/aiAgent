# coqi-claw 项目分析与总结

## 项目定位

**coqi-claw** 是一个基于技能的 AI 智能体/个人助手框架，使用 LLM API（DeepSeek、OpenAI 及兼容提供商）通过工具执行任务。ESM 项目，要求 Node.js >= 22.0.0，当前版本 1.0.6。

## 核心架构

```
用户输入
  → BootstrapManager（场景检测→环境校验→配置加载→组件初始化）
  → Agent（技能语义匹配→个性化系统提示构建）
  → AgentExecutor（主循环：abort检查→消息大小→LLM调用→工具过滤→并发执行(≤5)→结果推入）
  → LLMClient（undici HTTP/2→重试→校验→thinking清洗→用量记录）
  → Security层（命令验证→路径沙箱→网络策略→DLP→审计）
```

## 双模式入口

- **单轮** (`src/cli.js`): 无状态一次性任务
- **多轮** (`src/chat.js` → `src/tui/`): SQLite 持久化 REPL，支持会话管理

## 关键子系统

| 子系统 | 核心文件 | 职责 |
|--------|---------|------|
| **技能系统** | `src/skills/` | YAML frontmatter 解析 + LLM 语义匹配 + 5 分钟缓存 |
| **工具系统** | `src/tools/` (21 内置) + `plugins/tools/` (3 插件) | 文件操作、网络、exec、压缩、Python PTC 等 |
| **安全层** | `src/security/` (13 模块) | 命令验证、路径沙箱、网络策略、DLP、审计、技能信任 |
| **LLM 客户端** | `src/core/llm/` | 自建 undici HTTP/2 客户端，零 SDK 依赖 |
| **会话管理** | `src/sessions/` | 加密 SQLite 存储、U 型上下文截断、LLM 摘要 |
| **Web 服务** | `src/gateway/` | Express v5 + WebSocket，带认证/限流/CORS |

## 安全深度防御（5 层）

场景化策略矩阵（personal/enterprise/financial/dev），金融场景最严格：沙箱 enforce、执行 strict、网络 allowlist、DLP 开启、禁用 exec/http 工具。

## 代码规模

- `src/` ~100+ JS 文件，约 15000-25000 行核心代码
- `test/` 45 个测试文件
- `skills/` 17 个技能
- 总项目自写代码约 30000-40000 行

## 设计亮点

1. **零 SDK 依赖**：自建 OpenAI 兼容客户端（undici HTTP/2 + 连接池）
2. **渐进式技能披露**：元数据(启动)→指令(激活)→资源(按需)，降低 token 消耗
3. **独立 Matcher LLM**：轻量模型做技能匹配，降低成本
4. **加密 SQLite**：`better-sqlite3-multiple-ciphers` 多算法加密会话
5. **Bookending**：用户消息末尾追加匹配信号强化工具选择
6. **混合搜索引擎**：ripgrep 快速路径 + Node.js 回退
