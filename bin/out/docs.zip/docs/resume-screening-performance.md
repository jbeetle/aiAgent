# 简历智能筛选 Skill — 性能优化方案

## 当前性能概况

处理 N 份简历的端到端流程与耗时分析：

```
Step 1: 确认 JD + 简历列表          ~5s
Step 2: 预处理 (串行×N)             ~3-12s × N
Step 3: LLM 结构化提取 (串行×N)     ~3-10s × N   ← 最大瓶颈
Step 4: LLM 评分 (串行×N)           ~3-10s × N   ← 最大瓶颈
Step 5: postprocess (含 LLM 风险检测) ~3-10s × N + ~5s
Step 6: 展示结果                     ~2s
```

以 10 份简历为例：**总耗时约 3-10 分钟**，其中 LLM API 调用占 ~75%。

---

## 瓶颈 1：Step 3 + Step 4 逐份串行 LLM 调用

### 现状

`SKILL.md` 要求 Agent 对每份简历依次执行提取和评分：

```
Step 3: for each resume → LLM 提取 → write temp/extraction_{name}.json
Step 4: for each resume → LLM 评分  → write temp/scoring_{name}.json
```

N 份简历 = 2N 次串行 LLM 请求。每次请求的 system prompt（九大铁律 + 提取/评分数指令）完全相同，但被重复发送了 N 次。

### 根因

SKILL.md 的流程设计是"逐份处理"，没有批量模式。references/extraction.md 和 references/scoring.md 的 prompt 也是按单份简历设计。

### 优化方案

将 Step 3 和 Step 4 合并为一次批量 LLM 调用：

**Step 3+4 合并（批量提取 + 评分）**：

```
输入: JD + [简历1文本, 简历2文本, ..., 简历N文本]
输出: [{候选人1 提取+评分}, {候选人2 提取+评分}, ...]
```

- 一次 API 请求包含所有简历，共享 system prompt
- prompt 总 token 数相近（N 份简历文本 = N 次单独调用文本之和）
- 但省去了 N-1 次网络往返 + N-1 次 prompt 重复传输
- **预期收益：从 2N 次 API 调用降为 1 次，节省 50-60% 总时长**

注意事项：
- 单次请求 token 上限需控制，N 较大时（>15 份）分 2-3 批
- 需修改 references/extraction.md 和 references/scoring.md，增加批量输出格式定义
- 九大铁律"上下文隔离"约束可通过 prompt 指令保证（每份简历独立评估，不交叉比较）

---

## 瓶颈 2：postprocess.py 每候选人串行 LLM 风险检测

### 现状

`postprocess.py:274` `_detect_risks_by_llm()` 对每个候选人单独调 LLM：

```python
# postprocess.py:540-545
for candidate in candidates:
    new_risks = risk_detector.detect_all(candidate, jd_data)
    # ↑ 内部调用 _detect_risks_by_llm → call_llm()
```

N 个候选人 = N 次额外串行 LLM 调用。每次请求 payload 很小（单份简历摘要 + 合规关键词），但网络往返开销固定（~2-5s/次）。

### 优化方案

改为批量调用：一次 LLM 请求检测所有候选人。

```python
def _detect_risks_by_llm_batch(self, candidates: list, jd_requirements: list) -> dict:
    """批量检测所有候选人的合规风险与牌照缺失"""
    # 构建候选人摘要列表
    candidates_summary = [
        {"candidate_id": c.get("candidate_id", ""), "name": c.get("name", ""), ...}
        for c in candidates
    ]
    
    system_prompt = (
        "你是一位资深金融合规审查专家..."
        "对以下所有候选人逐一检测，返回以 candidate_id 为 key 的 JSON 对象：\n"
        '{"candidate_id_1": [...risks...], "candidate_id_2": [...risks...]}'
    )
    
    response = call_llm(messages, temperature=0.1, max_tokens=4000)
    all_risks = json.loads(response)
    
    for candidate in candidates:
        cid = candidate.get("candidate_id", "")
        candidate["_llm_risks"] = all_risks.get(cid, [])
```

**预期收益：N 次 → 1 次 LLM 调用，节省 ~15% 总时长**

---

## 瓶颈 3：preprocess.py 串行文件处理

### 现状

`preprocess.py:1033` `preprocess_directory()` 逐个文件串行处理：

```python
for fp in all_files:
    result = preprocess_file(str(fp))  # 串行，阻塞 I/O + CPU
```

### 优化方案

使用 `concurrent.futures.ProcessPoolExecutor` 并行处理：

```python
from concurrent.futures import ProcessPoolExecutor, as_completed

def preprocess_directory(dir_path: str, max_workers: int = None) -> List[PreprocessResult]:
    dir_p = Path(dir_path)
    if not dir_p.is_dir():
        return []

    all_files = [
        str(f) for f in dir_p.rglob("*")
        if f.is_file() and f.suffix.lower() in SUPPORTED_EXTENSIONS
    ]

    if max_workers is None:
        max_workers = min(os.cpu_count() or 4, len(all_files))

    results = []
    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        future_to_file = {executor.submit(preprocess_file, fp): fp for fp in all_files}
        for future in as_completed(future_to_file):
            results.append(future.result())

    return results
```

**注意**：Windows 上 `ProcessPoolExecutor` 需要 `if __name__ == "__main__"` 保护。同时 `preprocess_file` 中 win32com (Word COM) 在多进程下可能不稳定，建议对 .doc 文件回退到串行。

**预期收益：预处理阶段 2-4x 加速（取决于 CPU 核数和 I/O 带宽）**

---

## 瓶颈 4：Agent 层 execute 工具调用开销

### 现状

SKILL.md 引导 Agent 对每份简历单独调用 `execute`：

```
execute: python "scripts/preprocess.py" "简历A.docx"
execute: python "scripts/preprocess.py" "简历B.pdf"
execute: python "scripts/preprocess.py" "简历C.doc"
```

每次 `execute` = Python 进程冷启动 + import 依赖 + 文件 I/O。

### 优化方案

SKILL.md Step 2 强制使用 `--batch` 模式：

```
execute: python "scripts/preprocess.py" --batch "{简历目录}" --output-dir "temp"
```

一次 Python 进程启动处理所有文件。SKILL.md 中已经有 `--batch` 方式的文档（方式 D），但未被标记为推荐方式。

**预期收益：省去 (N-1) 次 Python 冷启动，约 1-2s/份**

---

## 瓶颈 5：PDF 扫描件无效 fallback 浪费时间

### 现状

`preprocess.py:390` 对图片型 PDF 依次尝试 4 种方法：

```python
methods = [
    ("pdfplumber", ...),  # 图片 PDF 必然失败 → 耗时但无产出
    ("PyPDF2",     ...),  # 同上
    ("pdfminer",   ...),  # 同上
    ("OCR",        ...),  # 唯一有效的方法
]
```

pdfplumber 打开图片型 PDF 不会立即报错，而是返回空文本后才触发 fallback，每个方法浪费 1-3 秒。

### 优化方案

在 PDF 提取前快速检测是否为扫描件：

```python
def _is_scanned_pdf(file_path: str) -> bool:
    """通过采样前 3 页快速判断是否为扫描件"""
    pdfplumber = _import_pdfplumber()
    if pdfplumber is None:
        return True  # 无法判断，走 OCR
    with pdfplumber.open(file_path) as pdf:
        sample_pages = pdf.pages[:3]
        total_chars = sum(len(page.extract_text() or "") for page in sample_pages)
        # 前 3 页总字符数 < 50 → 极可能是扫描件
        return total_chars < 50
```

如果是扫描件，直接跳到 OCR，跳过 PyPDF2 和 pdfminer。

**预期收益：每个扫描件 PDF 节省 3-8s**

---

## 瓶颈 6：_detect_risks_by_llm 无谓调用

### 现状

即使候选人简历中无任何风险相关关键词，`_detect_risks_by_llm` 仍然调用 LLM。

### 优化方案

增加前置快速判断，在无风险迹象时跳过 LLM 调用：

```python
def _should_skip_llm_risk_check(self, candidate_data: dict, jd_requirements: list) -> bool:
    """快速判断是否需要 LLM 风险检测"""
    # 无牌照要求且候选人无异常关键词 → 跳过
    has_license_req = any(r.get("category") == "license" for r in jd_requirements)
    
    extraction = candidate_data.get("extraction_data", {})
    all_text = json.dumps(extraction, ensure_ascii=False).lower()
    
    red_flags = self.rules.get("compliance_rules", {}).get("red_flag_keywords", {})
    zh_keywords = [k.lower() for k in red_flags.get("zh", [])]
    en_keywords = [k.lower() for k in red_flags.get("en", [])]
    
    has_flag = any(kw in all_text for kw in zh_keywords + en_keywords)
    
    return not has_license_req and not has_flag
```

**预期收益：无风险候选人省去 LLM 调用，约 3-5s/人**

---

## 优化优先级排序

| 优先级 | 措施 | 改动文件 | 预期收益 | 风险 |
|--------|------|---------|---------|------|
| **P0** | Step 3+4 批量 LLM 调用 | SKILL.md, references/extraction.md, references/scoring.md | **-50% 总时长** | 需重新设计 prompt 输出格式 |
| **P0** | 风险检测批量 LLM 调用 | postprocess.py:274-371 | **-15% 总时长** | 低 |
| **P1** | Step 2 强制使用 --batch | SKILL.md Step 2 流程描述 | **-1-2s × N** | 无 |
| **P1** | preprocess 并行处理 | preprocess.py:1033-1053 | **2-4x 预处理** | Windows 多进程兼容性 |
| **P2** | 扫描件 PDF 快速检测 | preprocess.py:390-413 | **-3-8s/扫描件** | 低 |
| **P2** | 跳过无谓 LLM 风险检测 | postprocess.py:274 | **-3-5s/安全候选人** | 可能漏检 |

---

## 优化后预期

以 10 份简历为例（假设 2 份为扫描件 PDF）：

| 阶段 | 优化前 | 优化后 |
|------|--------|--------|
| Step 2 预处理 | 30-120s | 8-30s (并行 + batch) |
| Step 3+4 LLM | 60-200s | 10-30s (单次批量调用) |
| Step 5 后处理 | 30-100s | 5-15s (批量风险检测) |
| **总计** | **120-420s (2-7 分钟)** | **25-80s (0.5-1.5 分钟)** |

**预期总体提速：4-5 倍**
