# LLM 模块架构优化 TODO

## 来源

基于 `src/core/llm/` + `src/utils/openai/` 全模块代码审查（client.js / retry.js / summarize.js / res-helper.js / metrics.js / pricing.js / api-errors.js / index.js / openai-compatible.js）。

---

## ✅ 已完成

### P0 — 统一重试层（2026-04-21, commit 4f536f9）

| 层级 | 实现位置 | 基础延迟 | Retry-After 解析 | 信号清理 |
|------|---------|---------|-----------------|----------|
| HTTP 底层 | `utils/openai/retry.js` | 200ms | ✅ 支持 | ✅ 完整 |
| ~~LLM 主循环~~ | ~~`core/llm/client.js`~~ | ~~1000ms~~ | ~~❌~~ | ~~❌~~ |
| ~~摘要循环~~ | ~~`core/llm/summarize.js`~~ | ~~1000ms~~ | ~~❌~~ | ~~❌~~ |

**改动：**
- 删除 `core/llm/retry.js` 中的 `sleep` / `BASE_RETRY_DELAY` / `RATE_LIMIT_DELAY` / `computeRetryDelay` / `classifyError`
- `client.js` `chat()` 改用 `utils/openai/retry.js` 的 `withRetry`
- `summarize.js` `summarize()` / `summarizeConversation()` 改用 `withRetry`
- 修复 `summarize.js` signal 传参位置错误（`create(opts, {signal})` → `create({...opts, signal})`）
- `LLMClient.sanitizeThinkingTags` 改为 `static` 方法

---

## 🔴 P0 — 剩余关键问题

### 1. `summarize.js` 封装泄漏（Facade 模式失效）

`summarize()` 和 `summarizeConversation()` 仍直接访问 `client.client.chat.completions.create()`（`summarize.js:111/183`），而不是走 `LLMClient.chat()`。这意味着：

- 绕过了 `LLMClient` 的所有统一处理：thinking 配置、usage 记录
- 手动重复了 `validateResponse()`、`sanitizeThinkingTags()`、`buildThinkingConfig()`、`_recordUsage()`
- 直接调用伪私有方法 `client._recordUsage()`

**建议**：在 `LLMClient` 中暴露一个低层级方法（如 `_rawChat(messages, options)`）统一处理请求组装、thinking 注入、响应清洗、usage 记录；`summarize()` 和 `chat()` 都基于它构建。

---

## 🟡 P1 — 设计缺陷

### 2. `validateResponse()` 抛出的原生 `Error` 在 `withRetry` 中默认被视为可重试

`validateResponse()` 抛出原生 `Error`（`retry.js:8-23`），没有 `.type` 属性。`withRetry` 通过 `wrapRequestError()` 包装后，落入 `APIError(ErrorTypes.UNKNOWN)`，而 `ErrorTypes.UNKNOWN` 在 `RetryableErrors` 中 → **默认可重试**。

结构验证失败（如 `choices` 为空、响应不是对象）通常是服务端返回畸形数据，重试可能有一定意义，但分类语义不够精确。如果希望不可重试，需要抛出自定义错误。

**建议**：结构验证失败抛 `ToolError(ErrorTypes.VALIDATION, ...)`，使 `isRetryable()` 返回 `false`。

### 3. `pricing.js` 是空壳，但 `metrics.js` 为此承担了复杂状态

`calculateCost()` 永远返回 `null`，`PRICING` 为空对象。`metrics.js` 用 `costKnown` 布尔值来掩盖这一事实。

**建议**：如果暂时没有定价需求，移除成本相关代码；否则提供可注入的定价策略接口。

### 4. `res-helper.js` 的 JSON 前导文本剥离过于激进

```javascript
// res-helper.js:86-89
const match = cleaned.search(JSON_START_REGEX);
if (match > 0 && looksLikeJsonStart(cleaned, match)) {
  cleaned = cleaned.substring(match);
}
```

这会在任何包含 `{` 或 `[` 的响应前截断所有文本。虽然 `looksLikeJsonStart()` 做了括号平衡校验，但 256 字符的前缀扫描仍然是启发式的。

**建议**：将此逻辑与 thinking tag 清洗分离，或增加更严格的上下文判断（如仅在 `tool_calls` 场景启用）。

---

## 🟢 设计亮点（保持）

1. **HTTP 客户端实现扎实**：`utils/openai/client.js` 的 undici 连接池、HTTP/2 协商、流式处理、资源清理、`_headers` 不可枚举属性设计都很专业。
2. **错误体系分层良好**：`APIError` 继承 `ToolError`，保持了与项目错误分类（`isRetryable()`）的一致性。
3. **指标环形缓冲区**：`metrics.js` 的 50 条调用历史环形容量控制得当，避免无界增长。
4. **Thinking 标签清洗覆盖全面**：`res-helper.js` 处理了闭合标签、未闭合标签（截断输出）、三种标签名，考虑很周全。

---

## 执行优先级总览

| 优先级 | 事项 | 状态 | 影响文件 |
|--------|------|------|---------|
| **P0** | 统一重试层：删除 `core/llm/retry.js` 的独立重试 | ✅ 已完成 | `client.js`, `retry.js`, `summarize.js` |
| **P0** | 修复 `summarize.js` 封装泄漏 | ✅ 已完成 (2026-04-21, commit ed54e81) | `summarize.js`, `client.js` |
| **P1** | `validateResponse()` 使用结构化错误 | ✅ 已完成 (2026-04-21, commit c40c335) | `retry.js`, `api-errors.js` |
| **P2** | 清理 `pricing.js` 空壳或实现接口化 | ✅ 已完成 (2026-04-21, commit 8324936) | `pricing.js`, `client.js` |
| **P2** | `res-helper.js` JSON 前导文本剥离上下文化 | ✅ 已完成 (2026-04-21, commit a249d4d) | `res-helper.js`, `llm-matcher.js` |
