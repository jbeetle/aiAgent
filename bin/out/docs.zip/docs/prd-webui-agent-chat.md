# coqi-claw WebUI — Agent 聊天产品需求文档（PRD）

> 版本：1.1（整合审查修订）
> 日期：2026-06-24

---

## 1. 概述

### 1.1 背景

coqi-claw 当前提供两套交互界面：

- **TUI**（`src/tui/`）：终端 REPL 多轮聊天，功能完整但受限于终端环境
- **Web 后端**（`src/gateway/`）：Express v5 + WebSocket 服务，协议层已就绪
- **Web 前端**（`web/`）：React 19 + Vite 6，基础聊天框架已有雏形

本需求文档的目标是：**对齐 TUI 全部交互功能，补齐 Web 前端缺失能力，交付一个生产可用的 Web 交互式 Agent 聊天工具**。

### 1.2 目标用户

- 企业/金融机构员工（`enterprise`/`financial` 场景）
- 个人用户（`personal` 场景）
- 开发/运维人员（`dev` 场景）

### 1.3 设计原则

| 原则 | 说明 |
|------|------|
| **功能对等** | WebUI 须覆盖 TUI 全部交互功能，不降级 |
| **渐进增强** | Web 环境允许的增强体验（富文本、文件拖拽、主题切换）应充分利用 |
| **场景适配** | 安全策略（沙箱/审计/网络/DLP）由后端场景配置决定，前端仅展示结果 |
| **实时优先** | 流式输出、工具调用进度、合规审查结果均通过 WebSocket 实时推送 |

---

## 2. 功能需求

### 2.1 启动与认证

#### FR-2.1.1 用户认证

当 `WEB_API_KEY` 环境变量已配置时，启用认证；未配置时跳过（开发/个人场景）。

认证流程：

1. 首次访问显示登录弹窗（`LoginModal`），输入用户名 + 密码
2. 调用 `POST /api/auth/login` 验证，成功后返回 API Key
3. API Key 存入 `localStorage`，后续 REST 请求通过 `X-API-Key` 请求头携带，WebSocket 通过 `api_key` 查询参数携带
4. 设置面板（`SettingsPanel`）中可手动查看/修改/清除 API Key
5. 服务端预配置 API Key 时（`window.__API_KEY__`），设置面板显示"已由服务端配置，无需手动设置"

> **与 TUI 的差异**：TUI 无认证机制，Web 通过 API Key 实现多用户隔离。

#### FR-2.1.2 AI 免责声明

对齐 TUI `disclaimer.js`，根据 `AI_DISCLAIMER_MODE` 配置：

| 模式 | 行为 |
|------|------|
| `once` | 首次登录显示，用户确认后记住（存入后端用户偏好 `aiDisclaimerAccepted`），后续不再弹出 |
| `always` | 每次会话开始前显示 |
| `off` | 不显示 |

交互规格：

- 声明内容从后端 API 动态获取（`GET /api/disclaimer`），Markdown 渲染展示
- 用户确认调用 `POST /api/disclaimer/accept`，后端更新用户偏好
- 用户拒绝确认则无法进入聊天界面，关闭弹窗等同于拒绝
- `/api/disclaimer` 和 `/api/disclaimer/accept` 为公开路径，不需要认证（否则未认证用户无法查看）

> **后端需新增**：`/api/disclaimer` + `/api/disclaimer/accept` 两个端点。

#### FR-2.1.3 首次配置引导

对齐 TUI `config.js`，首次使用时引导用户完成初始配置：

1. 输入姓名
2. 输入职业/角色（可选）
3. 选择内置助手（从 `/api/assistants` 加载，展示名称/性格/专长）

交互规格：

- 判断条件：`GET /api/user` 返回的 `name` 为空时触发引导
- 配置保存调用 `PATCH /api/user`，后续访问自动恢复
- 支持在设置面板中重新修改
- 取消引导时使用默认配置（姓名"用户"，默认助手）

> **前端需新增**：`OnboardingWizard` 组件。后端 API 已就绪（`/api/user` GET/PATCH + `/api/assistants` GET）。

---

### 2.2 会话管理

#### FR-2.2.1 会话列表

- 左侧边栏展示活跃会话列表，每项显示：
  - 会话标题（未命名时显示"未命名会话"）
  - 消息条数
  - 最后更新时间（相对时间 + 绝对时间 tooltip）
  - 当前活动会话高亮标记
- 支持分页加载（滚动到底部加载更多）
- 数据来源：`GET /api/sessions?status=active&limit=50&offset=N`
- 对齐 TUI `/list` 命令

#### FR-2.2.2 创建会话

- 点击"新建会话"按钮或快捷键 `Ctrl+N` 创建新会话
- 支持选择助手（默认使用当前助手）
- 调用 `POST /api/sessions`
- 对齐 TUI `/new` 命令

#### FR-2.2.3 切换会话

- 点击侧边栏会话项切换
- 切换时加载该会话消息历史（`GET /api/sessions/:id/messages`）
- 切换时自动保存旧会话输入草稿、加载新会话草稿
- 对齐 TUI `/switch` 命令

#### FR-2.2.4 重命名会话

- 双击会话标题进入编辑态，或右键菜单"重命名"
- 编辑完成后调用 `PATCH /api/sessions/:id` 更新标题
- 对齐 TUI `/rename` 命令

#### FR-2.2.5 删除会话

- 会话项右侧删除按钮，或右键菜单"删除"
- 弹出确认对话框（`ConfirmDialog`）
- 软删除（状态改为 `archived`），删除后自动切到新会话
- 调用 `DELETE /api/sessions/:id`
- 对齐 TUI `/delete` 命令

#### FR-2.2.6 清空会话

- 右键菜单"清空消息"，弹出确认对话框
- 仅清空消息，保留会话
- 调用 `DELETE /api/sessions/:id/messages`
- 对齐 TUI `/clear` 命令

#### FR-2.2.7 会话搜索

- 侧边栏顶部搜索框，按标题或会话 ID 模糊搜索
- 调用 `GET /api/sessions?search=xxx`
- TUI 无此功能，属于 Web 增强体验

#### FR-2.2.8 归档会话恢复

侧边栏底部"已归档"折叠区域：

```
  ▸ 已归档 (3)

点击展开：
  ▾ 已归档 (3)
    归档会话1  [恢复]
    归档会话2  [恢复]
    归档会话3  [恢复]
```

- 数据来源：`GET /api/sessions?status=archived`
- 点击"恢复"调用 `PATCH /api/sessions/:id` 将 `status` 改为 `active`
- 恢复后会话移入活跃列表
- 对齐 TUI `switchSession` 中的 `archived` 分支

> **前端需新增**：侧边栏归档折叠区域组件。

#### FR-2.2.9 自动标题生成

- 首次交互后（消息数 ≥ 2），后端自动为会话生成智能标题
- 标题生成后通过 `session_updated` WebSocket 事件推送到前端
- 前端收到事件后更新侧边栏中对应会话的标题
- 对齐 TUI `processor.js` 中的 `autoGenerateTitle` 逻辑

---

### 2.3 消息输入与发送

#### FR-2.3.1 文本输入

- 底部输入区域，支持多行文本框
  - `Enter` 发送消息
  - `Shift+Enter` 换行（对齐 TUI `\` 续行功能）
- 输入内容最大 1MB（后端协议限制）
- **草稿自动保存**：输入内容 300ms 防抖保存到 `localStorage`，切换会话时自动保存旧会话草稿、加载新会话草稿，页面关闭（`beforeunload`）时 flush 草稿
- **输入历史导航**：`↑`/`↓` 键浏览当前会话的输入历史（仅内存，不跨会话持久化）

#### FR-2.3.2 文件附件

支持拖拽或点击上传文件附件：

- **上传**：拖拽/点击 → `POST /api/upload`（multipart/form-data，字段名 `file`）→ 上传成功后消息前缀添加 `[上传文件: filename]`
- **下载**：工具产出文件 → `producedFiles` 数组 → 生成 `/api/files/download?path=xxx` 下载链接
- **文件类型白名单**（与后端 `upload.js` 对齐）：
  - 文档：`.pdf .docx .doc .xlsx .xls .pptx .ppt .txt .md .csv .tsv`
  - 数据：`.json .xml .yaml .yml`
  - 图片：`.jpg .jpeg .png .gif .webp .svg .bmp`
  - 压缩：`.zip .tar .gz .rar .7z`
  - 代码：`.py .js .ts .css .sql .sh`
- **文件名清理**：后端自动 sanitize 特殊字符，限制 255 字符
- TUI 无此功能，属于 Web 增强体验

#### FR-2.3.3 消息重试

- 用户消息旁提供"重试"按钮，重新发送最后一条用户消息
- 重试时清空上一轮工具调用记录和流式内容
- 对齐 TUI 中取消后重新输入的场景

---

### 2.4 消息展示

#### FR-2.4.1 用户消息

- 右侧气泡，显示用户名 + 消息内容 + 时间戳
- 对齐 TUI `printUserMessage`（黄色标签 + 边框）

#### FR-2.4.2 助手消息

左侧气泡，Markdown 渲染，支持：

- 标题（H1-H6，分级着色）
- 粗体/斜体/删除线
- 代码块（`highlight.js` 语法高亮）与行内代码
- 有序/无序列表
- 表格（分层着色）
- 引用
- 链接（可点击跳转）
- 图片（内嵌展示）
- Mermaid 图表渲染（Web 增强体验，TUI 仅提示"请在浏览器查看"）

**代码块交互**：
- 右上角"复制"按钮，点击后反馈"已复制"
- 语法高亮由 `highlight.js` 驱动

**用量统计**：
- 当后端 `SHOW_USAGE=true` 时，助手消息底部展示 token 用量、成本、耗时
- 数据来源：`complete` 事件中的 `usage` 字段

**消息底部**：
- 显示响应耗时（`durationMs` 转换为秒）

对齐 TUI `printAssistantMessage` + `markdown.js` 渲染能力。

#### FR-2.4.3 推理过程展示

- 助手消息内可折叠的"思考过程"区域（`ReasoningPanel`）
- 流式输出时实时渲染推理 token
- 推理进行中显示 `⏳` 指示器
- 推理结束后可折叠/展开，默认展开
- 最大高度 200px，超出滚动
- 对齐 TUI `stream-display.js` 的 `reasoningActive` 逻辑

#### FR-2.4.4 消息历史加载

- 切换会话时加载最近 N 条消息（`GET /api/sessions/:id/messages?limit=50`）
- 向上滚动到顶部时加载更早的消息（分页，虚拟滚动 + `loadMore` 入口）
- 新消息到达时自动滚动到底部
- 用户主动向上滚动时暂停自动滚动，滚回底部后恢复
- 虚拟滚动（`@tanstack/react-virtual`）确保大量消息下的渲染性能

#### FR-2.4.5 错误与系统消息

| 角色 | 样式 | 场景 |
|------|------|------|
| `error` | 红色居中气泡 | Agent 执行失败、WebSocket 错误 |
| `system` | 灰色居中气泡 | 连接状态变化、系统提示 |
| `audit_block` | 品红边框居中气泡 | 合规审查阻止（见 FR-2.7.1） |
| `audit_warning` | 黄色边框居中气泡 | 合规审查警告（见 FR-2.7.2） |

---

### 2.5 流式输出与进度

#### FR-2.5.1 流式内容输出

- LLM 响应通过 WebSocket 实时推送到前端，逐 token 渲染
- 支持内容流（`type: "content"`）和推理流（`type: "reasoning"`）两种类型
- 流式输出期间显示闪烁光标
- **rAF 合并策略**：同一 `requestAnimationFrame` 帧内的多个 token chunk 合并为一次 state update，避免频繁渲染导致卡顿
- **双渲染器策略**：streaming 阶段使用轻量级 Markdown 渲染器（`renderStreamingMarkdown`），请求完成后切换为完整渲染器（`marked` + `DOMPurify` + `highlight.js`），避免流式阶段 O(n²) 开销
- 对齐 TUI `stream-display.js` 的流式渲染能力

#### FR-2.5.2 执行进度展示

顶部或消息内显示当前 Agent 执行阶段（`ProgressBar` 组件）：

| 阶段 | 显示文字 | 对齐 TUI |
|------|----------|----------|
| `thinking` | 思考中 [1/10] | Spinner "思考中" |
| `truncating` | 压缩上下文 | Spinner "压缩上下文" |
| `tool_executing` | 执行工具 · read, exec | Spinner "执行: read, exec" |
| `tool_completed` | 工具完成 | Spinner "工具完成" |

- 旋转指示器 + 阶段标签 + 取消按钮
- 对齐 TUI Spinner 进度信息

#### FR-2.5.3 友好等待提示

- 长时间等待时（> 20s）随机展示友好提示语
- 前端维护 20 条提示语副本（与 TUI `src/tui/constants.js` 内容同步），20s 定时器本地轮换
- 请求完成/取消时清除定时器
- 对齐 TUI `FRIENDLY_MESSAGES` 常量

#### FR-2.5.4 请求取消

- 输入区域显示"停止生成"按钮（替代发送按钮）
- 点击后发送 `cancel` WebSocket 消息，后端 abort 当前请求
- 取消后回滚用户消息，显示"操作已取消"
- 对齐 TUI Ctrl+C 取消逻辑

---

### 2.6 工具调用展示

#### FR-2.6.1 工具调用实时展示

Agent 执行工具时，在助手消息内展示工具调用卡片（`ToolCallList` 组件）：

| 状态 | 显示 | 图标 |
|------|------|------|
| 运行中 | `⏳ 工具名(参数摘要)` | 沙漏 + 左侧蓝色边框 |
| 成功 | `✓ 工具名 结果摘要 (耗时)` | 绿色 ✓ + 左侧绿色边框 |
| 失败 | `✗ 工具名 (耗时)` | 红色 ✗ + 左侧红色边框 |

每个工具有对应的语义图标（如 `read` → 📄、`exec` → ⚡、`web_fetch` → 🌐）。

对齐 TUI `stream-display.js` 的 `onToolCall`/`onToolResult`。

#### FR-2.6.2 工具调用详情展开

默认折叠，点击展开详情：

```
默认（折叠）：
┌──────────────────────────────────┐
│ ⚙ read  (1.2KB, 30行)  ✓ 0.3s  │
└──────────────────────────────────┘

展开后：
┌──────────────────────────────────┐
│ ⚙ read  (1.2KB, 30行)  ✓ 0.3s  │
├──────────────────────────────────┤
│  输入参数                        │
│  { "filePath": "/path/to/file" } │
│  ─────────────────────────────── │
│  执行结果                        │
│  file content here...            │
│  ─────────────────────────────── │
│  产出文件: output.csv  [下载]    │
└──────────────────────────────────┘
```

- 产出文件通过 `/api/files/download?path=xxx` 生成下载链接
- TUI 受终端限制仅展示摘要，Web 提供完整详情

#### FR-2.6.3 参数摘要提取

后端按工具类型提取最具辨识度的参数（如 `read` → 文件路径、`exec` → 命令、`web_search` → 查询词），前端也做结构化摘要渲染（如 `exec` → `exitCode=0 · stdout preview`）。

对齐 TUI `getToolArgSummary` 逻辑 + 前端 `buildSummary` 增强。

---

### 2.7 合规审查

#### FR-2.7.1 审查阻止

当 `ENABLE_AUDIT=true` 且审查结果为 `violation` 时：

- 显示合规检查员消息（`audit_block` 角色，品红边框居中气泡）
- 展示违规类别 + 原因
- 消息不发送给 Agent
- 对齐 TUI `printAuditorBlock`

#### FR-2.7.2 审查警告

审查结果为 `warning` 时：

- 显示黄色警告提示（`audit_warning` 角色，黄色边框居中气泡）
- 消息照常发送，用户可见警告但可继续
- 对齐 TUI `printAuditorWarning`

#### FR-2.7.3 审查通过

- 静默放行，前端不显示任何提示
- 对齐 TUI 审查通过的静默行为

---

### 2.8 身份与配置

#### FR-2.8.1 当前身份展示

- 顶部栏或侧边栏显示当前用户名 + 助手名
- 对齐 TUI `/whoami` 命令

#### FR-2.8.2 设置面板

侧边栏底部设置入口，可修改：

- API Key（手动输入/显示/清除，服务端预配置时只读提示）
- 用户姓名/角色（调用 `PATCH /api/user`）
- 当前助手（从列表选择，调用 `PATCH /api/user` 更新 `preferences.assistantId`）

保存后立即生效。

对齐 TUI 首次配置 + `/whoami` 信息。

---

### 2.9 快捷键

| 快捷键 | 功能 | TUI 对应 |
|--------|------|----------|
| `Enter` | 发送消息 | — |
| `Shift+Enter` | 换行 | `\` 续行 |
| `Ctrl/Cmd+N` | 新建会话 | `/new` |
| `Escape` | 取消当前请求 | `Ctrl+C` |
| `↑`/`↓`（输入框内） | 浏览输入历史 | 上下键翻阅历史 |
| `Ctrl+Shift+S` | 切换侧边栏 | — |

> 可通过 `Ctrl+/` 显示快捷键帮助面板（对齐 TUI `/help`）。

---

### 2.10 主题与外观

#### FR-2.10.1 明暗主题

- 支持亮色/暗色主题切换，默认跟随系统
- 用户偏好存入 `localStorage`
- 基于 Tailwind CSS v4 的 CSS 变量主题系统

#### FR-2.10.2 响应式布局

- 桌面端（≥768px）：左侧边栏 + 右侧聊天区
- 移动端（<768px）：侧边栏收起为抽屉，全屏聊天区，汉堡菜单切换

---

### 2.11 连接状态

#### FR-2.11.1 WebSocket 连接状态

- 顶部指示器显示连接状态：已连接（绿）/ 重连中（黄）/ 断开（红）
- 断连时自动重连（指数退避 1s → 2s → 4s → ... → 30s 上限）
- 断连期间消息缓存到队列（上限 20 条），重连后带节流发送（50ms 间隔）
- 重连期间禁用消息发送
- 重连成功后自动恢复当前会话上下文

#### FR-2.11.2 请求防并发

- 同一 WebSocket 连接同时只处理一个 Agent 请求
- 请求处理中时输入区域显示"停止生成"按钮替代发送按钮
- 对齐 TUI 的单请求串行处理逻辑

#### FR-2.11.3 心跳机制

- 客户端每 30s 发送 `ping` 消息
- 后端每 30s 检查连接活性，60s 内未收到 `pong` 则断开
- 对齐后端 `connection.js` 的心跳配置

---

### 2.12 通知

#### FR-2.12.1 Toast 通知

全局 Toast 通知系统，用于非阻塞式反馈：

| 类型 | 样式 | 持续时间 | 场景 |
|------|------|----------|------|
| `success` | 绿色 | 2.5s | 会话创建成功、配置保存成功 |
| `error` | 红色 | 4s | 请求失败、上传失败 |
| `warning` | 黄色 | 5s | 合规警告、连接不稳定 |

- 支持手动关闭
- 多条通知堆叠展示

---

## 3. 非功能需求

### 3.1 性能

| 指标 | 要求 | 实现手段 |
|------|------|----------|
| 流式首 token 延迟 | ≤ 200ms（本地网络） | WebSocket + 30ms flush |
| 消息列表渲染 | 1000 条消息内滚动帧率 ≥ 30fps | `@tanstack/react-virtual` 虚拟滚动 |
| 流式渲染流畅度 | 无可见卡顿 | rAF chunk 合并 + 双渲染器（streaming/完整） |
| 会话切换 | ≤ 500ms 完成加载 | 分页加载 + 草稿缓存 |
| WebSocket 重连 | 断连后 ≤ 5s 首次重连 | 指数退避 1s 起步 |
| 流式内存控制 | 长响应（>10k token）不 OOM | streaming 阶段轻量渲染器，完成后切换 |

### 3.2 安全

| 项目 | 说明 |
|------|------|
| 传输安全 | 生产环境必须 HTTPS + WSS |
| 认证 | API Key（`X-API-Key` 请求头 / `api_key` 查询参数） |
| XSS 防护 | Markdown 渲染必须通过 DOMPurify sanitize，禁止执行 `<script>` |
| DLP | 前端展示内容已由后端 `redactSecrets` 脱敏 |
| CORS | 由后端 `WEB_CORS_ORIGINS` 配置控制 |
| 文件上传 | 后端校验文件扩展名白名单 + sanitize 文件名 + 沙箱隔离 |
| 文件下载 | 路径校验 + 沙箱边界检查（`validatePath`），防止目录遍历 |
| 安全响应头 | `X-Content-Type-Options: nosniff`、`X-Frame-Options: DENY`、`Referrer-Policy: strict-origin-when-cross-origin` |
| WebSocket 载荷 | 上限 1MB（服务端 `maxPayload` 配置） |

### 3.3 兼容性

- 浏览器：Chrome 90+、Firefox 90+、Safari 15+、Edge 90+
- 移动端：iOS Safari 15+、Android Chrome 90+
- 屏幕尺寸：320px ~ 2560px 宽度自适应

### 3.4 国际化

- 支持中文（`zh`）和英文（`en`）两种语言
- 语言由后端 `LANG` 环境变量决定，前端从 API 获取
- 对齐 TUI `i18n.js` 的 locale 机制

### 3.5 多标签页行为

- 同一用户在多个浏览器标签页打开时，各标签页拥有独立的 WebSocket 连接
- 同一会话的消息可能交叉写入（当前不设会话级锁）
- 前端通过 `session_updated` WebSocket 事件实时同步标题变更
- 未来可考虑增加会话级锁（当前不实现）

### 3.6 错误响应规范

所有 REST API 错误响应统一格式：

```json
{
  "success": false,
  "error": {
    "code": "ValidationError",
    "message": "人类可读的错误描述"
  }
}
```

HTTP 状态码映射：

| 状态码 | 含义 | 场景 |
|--------|------|------|
| 400 | 参数错误 | 缺少必填字段、格式无效 |
| 401 | 未认证 | 缺少或无效 API Key |
| 403 | 权限/合规拦截 | 沙箱越界、合规审查阻止、安全违规 |
| 404 | 不存在 | 会话/文件/助手不存在 |
| 409 | 并发冲突 | 同一会话已有请求在处理 |
| 500 | 服务端错误 | 内部异常 |
| 502 | 网关错误 | 上游服务不可用 |
| 504 | 超时 | 请求超时 |

---

## 4. 数据模型

### 4.1 WebSocket 协议

**Client → Server**：

| 类型 | Payload | 说明 |
|------|---------|------|
| `chat` | `{ sessionId, content }` | 发送消息 |
| `cancel` | `{ requestId }` | 取消当前请求（`requestId` 为 `"current"` 或具体 ID） |
| `ping` | `{}` | 心跳 |

**Server → Client**：

| 类型 | Payload | 说明 | TUI 对应 |
|------|---------|------|----------|
| `connected` | `{ connectionId }` | 连接建立 | 启动初始化 |
| `progress` | `{ phase, current, total, tools, toolCount, size, requestId }` | 执行进度 | Spinner 更新 |
| `tool_call` | `{ sessionId, id, name, arguments }` | 工具调用开始 | `⚙ 工具名` |
| `tool_result` | `{ sessionId, toolCallId, name, success, content, producedFiles }` | 工具执行结果 | `✓/✗ 工具名` |
| `assistant_message` | `{ sessionId, content, type, iteration }` | 流式 token（`type` 为 `content` 或 `reasoning`） | 流式渲染 |
| `complete` | `{ sessionId, result, durationMs }` | Agent 完成 | Spinner succeed |
| `error` | `{ message, sessionId, durationMs }` | 错误 | printError |
| `aborted` | `{ sessionId, reason, durationMs }` | 请求被取消 | "操作已取消" |
| `audit_block` | `{ category, categoryName, reason, confidence, sessionId }` | 合规阻止 | `🚫` 审查阻止 |
| `audit_warning` | `{ category, categoryName, warningMessage, sessionId }` | 合规警告 | `⚠️` 审查警告 |
| `session_updated` | `{ sessionId, title }` | 会话信息更新 | 标题生成回调 |
| `pong` | `{}` | 心跳响应 | — |

### 4.2 REST API

| 路径 | 方法 | 说明 | 认证 |
|------|------|------|------|
| `/api/auth/login` | POST | 用户名密码登录，返回 API Key | 公开 |
| `/api/disclaimer` | GET | 获取免责声明内容 + 模式 | 公开 |
| `/api/disclaimer/accept` | POST | 确认免责声明 | 公开 |
| `/api/sessions` | GET | 列出会话（分页/搜索/状态过滤） | 需要 |
| `/api/sessions` | POST | 创建会话 | 需要 |
| `/api/sessions/:id` | GET | 获取会话详情 | 需要 |
| `/api/sessions/:id` | PATCH | 更新会话（重命名/恢复归档等） | 需要 |
| `/api/sessions/:id` | DELETE | 删除会话（软删除，状态→archived） | 需要 |
| `/api/sessions/:id/messages` | GET | 获取消息历史（分页） | 需要 |
| `/api/sessions/:id/messages` | DELETE | 清空会话消息 | 需要 |
| `/api/assistants` | GET | 列出可用助手 | 需要 |
| `/api/user` | GET | 获取当前用户信息 | 需要 |
| `/api/user` | PATCH | 更新用户配置（姓名/角色/助手偏好） | 需要 |
| `/api/upload` | POST | 上传文件（multipart/form-data） | 需要 |
| `/api/files/download` | GET | 下载沙箱文件（`?path=xxx`） | 需要 |
| `/api/open` | POST | 用系统默认程序打开文件或 URL | 需要 |
| `/api/health` | GET | 健康检查 | 公开 |

---

## 5. 页面结构

```
┌─────────────────────────────────────────────────┐
│  顶部栏：应用名 │ 当前助手 │ 连接状态 │ 设置 │ │
├──────────┬──────────────────────────────────────┤
│          │                                      │
│  侧边栏   │  聊天区域                              │
│          │                                      │
│  [搜索]   │  ┌──────────────────────────────┐    │
│          │  │ 合规检查员 🚫 阻止消息          │    │
│  会话1 ●  │  └──────────────────────────────┘    │
│  会话2    │  ┌──────────────────────────────┐    │
│  会话3    │  │ USER: 用户消息                │    │
│  ...     │  └──────────────────────────────┘    │
│          │  ┌──────────────────────────────┐    │
│          │  │ AI: 助手消息                  │    │
│          │  │  ▼ 思考过程（可折叠）          │    │
│          │  │    reasoning content...       │    │
│          │  │  ──                           │    │
│          │  │  正文内容（Markdown 渲染）      │    │
│          │  │  ⚙ read  (1.2KB)  ✓ 0.3s     │    │
│          │  │  ⏱ 5.2s                       │    │
│          │  └──────────────────────────────┘    │
│          │                                      │
│  ─────── │  ┌──────────────────────────────┐    │
│  ▸ 已归档  │  │ [📎] 输入消息...    [发送/停止] │    │
│  ─────── │  └──────────────────────────────┘    │
│  [新建]   │                                      │
│  [设置]   │                                      │
└──────────┴──────────────────────────────────────┘
```

---

## 6. 前端技术栈

| 依赖 | 版本 | 用途 |
|------|------|------|
| React | 19 | UI 框架 |
| Vite | 6 | 构建工具 + HMR |
| Tailwind CSS | v4 | 样式系统（CSS 变量主题） |
| Zustand | 最新 | 状态管理（`chat-store`/`session-store`/`ui-store`/`auth-store`） |
| `@tanstack/react-virtual` | 最新 | 消息列表虚拟滚动 |
| `marked` | 最新 | Markdown 解析 |
| `highlight.js` | 最新 | 代码语法高亮 |
| `dompurify` | 最新 | XSS 防护（sanitize HTML） |
| `mermaid` | 最新 | Mermaid 图表渲染 |

---

## 7. TUI → WebUI 功能映射表

| TUI 功能 | TUI 实现 | WebUI 对应 | 增强点 |
|----------|----------|------------|--------|
| REPL 输入 | `repl-loop.js` + `ReplInput` | 多行文本框 + Enter/Shift+Enter | 拖拽附件、草稿自动保存 |
| `\` 续行 | `repl-loop.js` 多行收集 | `Shift+Enter` 换行 | 更直觉的交互方式 |
| `/new` | 斜杠命令 | 侧边栏"新建"按钮 + `Ctrl+N` | — |
| `/list` | 斜杠命令 | 侧边栏会话列表（常驻可见） | 实时可见，无需命令 |
| `/switch` | `SessionLoader` 交互菜单 | 点击侧边栏会话项 | 更快切换 |
| `/rename` | `p.text()` 输入 | 双击标题编辑 / 右键菜单 | — |
| `/clear` | `p.confirm()` 确认 | 右键菜单 + 确认弹窗 | — |
| `/delete` | `p.confirm()` 确认 | 删除按钮 + 确认弹窗 | — |
| `/whoami` | `console.log` 输出 | 顶部栏常驻 + 设置面板 | 始终可见 |
| `/help` | `console.log` 输出 | `Ctrl+/` 快捷键面板 | — |
| `/exit` | 进程退出 | 关闭浏览器标签 | — |
| Spinner 动画 | braille 帧 + `setInterval` | 进度条 + 阶段文字 + 取消按钮 | 可视化进度条 + 可交互 |
| 友好等待提示 | 20 条随机提示语 | 同样逻辑，前端定时器本地轮换 | — |
| 流式输出 | `stream-display.js` | WebSocket `assistant_message` + rAF 合并 | 更流畅的渲染 |
| 推理展示 | 💭 + 斜体淡色 | `ReasoningPanel` 可折叠思考区域 | 可交互折叠 |
| 工具调用 | `⚙`/`✓`/`✗` 单行 | `ToolCallList` 工具卡片 + 可展开详情 | 完整参数/结果/文件下载 |
| 合规阻止 | `🚫` + 品红边框 | `audit_block` 角色居中气泡 | — |
| 合规警告 | `⚠️` + 黄色边框 | `audit_warning` 角色居中气泡 | — |
| 免责声明 | 外置 MD 文件 + 确认 | 全屏模态框 + Markdown 渲染 | — |
| 首次配置 | `@clack/prompts` 交互 | `OnboardingWizard` 步骤引导 | — |
| 中断/取消 | `Ctrl+C` + `AbortController` | "停止生成"按钮 + `cancel` WS 消息 | — |
| 消息边框 | 左侧 `│` 竖线 | 气泡卡片样式 | 更丰富的视觉层次 |
| Markdown 渲染 | `marked` + `marked-terminal` | `marked` + `highlight.js` + DOMPurify | 语法高亮更丰富 + XSS 安全 |
| Mermaid 渲染 | 文本提示"请在浏览器查看" | 内嵌 Mermaid 渲染 + 源码切换 + PNG 下载 | Web 独有增强 |
| 会话上下文预览 | 最近 6 条消息摘要 | 切换会话时加载完整历史 | 更完整的信息 |
| 自动标题 | `autoGenerateTitle` | `session_updated` 事件推送 + 侧边栏更新 | 实时更新 |
| 输入历史 | `input_history.json` 持久化 | `↑`/`↓` 键浏览（仅内存） | 不跨会话持久化 |
| — | 无 | 文件上传/下载 | Web 独有增强 |
| — | 无 | 会话搜索 | Web 独有增强 |
| — | 无 | 明暗主题切换 | Web 独有增强 |
| — | 无 | 归档会话恢复 | TUI 有实现但非命令入口 |

---

## 8. 开放问题（已决议）

| # | 问题 | 决策 | 影响 |
|---|------|------|------|
| 1 | 免责声明 API | **新增 `/api/disclaimer` + `/api/disclaimer/accept`** | 后端需新增 2 个公开路由端点 |
| 2 | 友好等待提示驱动方式 | **前端定时器本地轮换** | 前端维护 20 条提示语副本，无需后端推送 |
| 3 | 工具调用详情默认状态 | **默认折叠，点击展开** | 前端工具卡片默认收起，减少视觉噪音 |
| 4 | 归档会话管理位置 | **侧边栏内折叠区域** | 侧边栏底部"已归档"折叠入口 |
| 5 | 移动端语音输入 | **不支持** | 首期不做，降低复杂度 |

---

## 9. 前端需新增/改造的组件清单

| 组件 | 状态 | 动作 | 说明 |
|------|------|------|------|
| `OnboardingWizard` | 不存在 | **新增** | 首次配置引导（姓名/角色/选择助手） |
| `DisclaimerModal` | 不存在 | **新增** | AI 免责声明弹窗 |
| 侧边栏归档区域 | 不存在 | **新增** | 已归档会话折叠列表 + 恢复按钮 |
| 会话右键菜单 | 不存在 | **新增** | 重命名/清空/删除操作入口 |
| 会话双击编辑 | 不存在 | **新增** | 双击标题进入编辑态 |
| 快捷键帮助面板 | 不存在 | **新增** | `Ctrl+/` 触发的快捷键参考 |
| 用量统计展示 | 不存在 | **新增** | 消息底部 token/成本/耗时 |
| 友好等待提示 | 不存在 | **新增** | 进度区 20s 轮换提示语 |
| `SettingsPanel` | 已存在 | **改造** | 增加用户姓名/角色/助手选择 |
| `Sidebar` | 已存在 | **改造** | 增加归档区域 |
| `SessionItem` | 已存在 | **改造** | 增加双击编辑、右键菜单 |

---

## 10. 后端需新增的 API 端点

| 路径 | 方法 | 说明 | 认证 |
|------|------|------|------|
| `/api/disclaimer` | GET | 返回当前语言的免责声明 Markdown 内容 + `mode`（once/always/off） | 公开 |
| `/api/disclaimer/accept` | POST | 记录用户已同意，更新用户偏好 `aiDisclaimerAccepted: true` + 时间戳 | 公开 |

> 其余 API 端点均已实现，无需后端改动。
