# Gateway 配置 API 技术债 — `/validate` 全局 `process.env` 污染

> 状态：已知风险，暂不处理 | 优先级：P1 | 记录日期：2026-07-15

## 背景

`src/gateway/routes/config.js` 的 `POST /api/config/validate` 端点用于临时测试新的 LLM 配置连通性。当前实现会先把请求体中的 `values` 直接写入全局 `process.env`，再创建 `LLMClient` 调用一次最小请求，最后在 `finally` 中恢复原始值。

## 风险

### 1. 绕过配置策略校验
`applyChanges` 中的校验链路（类型转换、`validateWithSchema`、加密字段 RSA 加密、guarded 场景安全键保护）全部被绕过。调用方可以通过 `/validate` 临时把任意值（包括 `SANDBOX_MODE`、`EXEC_MODE` 等安全键）注入运行时。

### 2. 并发竞态
Node.js 事件循环在 `await testClient.chat(...)` 期间会处理其他请求，这些请求可能读到临时的 `LLM_API_KEY`、`DB_ENCRYPTION_KEY` 等敏感值。

### 3. 恢复不完整
`savedEnv` 只记录 `values` 中显式传入的键。如果 `loadConfig()` 或 `LLMClient` 初始化期间改写了其他 `process.env` 键，无法还原。

## 影响范围

- 仅影响 Web/Gateway 模式下的配置验证接口。
- 需要配合有效的 `WEB_API_KEY` 或会话认证才能调用。
- 在 enterprise/financial guarded 场景下，该接口仍可通过认证后调用，风险更高。

## 建议方案

### 方案 A：重构 `LLMClient` 支持显式配置（推荐）

让 `LLMClient` 的构造函数接受一个可选的 `runtimeEnv` 或 `overrideEnv` 对象，验证时直接传入 `values`，不修改全局 `process.env`。

```js
const testClient = new LLMClient({
  config,
  label: 'test-validate',
  enableThinking: false,
  envOverrides: values, // 仅本次实例生效
});
```

优点：
- 零全局状态副作用
- 天然支持并发安全
- 不改写任何持久化文件

缺点：
- 需要修改 `src/core/llm/client.js` 的配置读取路径

### 方案 B：将验证逻辑下沉到 `ConfigService`

在 `src/services/config-service.js` 中新增 `validateConnectivity(values)` 方法，内部使用一次性子进程或独立 `LLMClient` 实例完成验证，避免在 HTTP 请求上下文中修改全局 env。

优点：
- 路由层保持简洁
- 可复用现有的配置加载逻辑

缺点：
- 仍需解决 `LLMClient` 对 `process.env` 的依赖

### 方案 C：限制 `/validate` 可接受的键白名单

在路由层只允许传入非敏感的 LLM 连接参数（如 `LLM_PROVIDER`、`LLM_BASE_URL`、`LLM_API_KEY`、`LLM_MODEL`），拒绝安全键和未知键。

优点：
- 改动最小

缺点：
- 不能解决并发竞态和恢复不完整问题
- 白名单维护成本高

## 决策

暂不处理。当前场景下该接口主要供已认证的管理员在 Web UI 中使用，且问题 1/3/4/5/6/7/8/9/10 已修复，剩余风险可控。未来若开放给非管理员或增加并发调用量，应优先实施方案 A。

## 相关文件

- `src/gateway/routes/config.js`
- `src/core/llm/client.js`
- `src/services/config-service.js`
- `src/utils/config.js`
