# 统一沙箱安全设计 v2：Agent 提示词 + exec 工作目录隔离

> **状态：已落地生产** — 2026-04-19 完成实现并部署。
> 涉及文件：`src/tools/exec.js`、`src/tools/read.js`、`src/security/security.js`、`src/security/path-sandbox.js`、`src/security/sandbox-layout.js`

## 背景与问题

coqi-claw 的 skill 是插件式设计，可动态添加，Agent 通过内置 `read` 和 `exec` 工具读取技能描述并调用脚本。但当前沙箱存在以下问题：

1. **路径校验误判**：Agent 读 `skills/xxx/SKILL.md` 时，因 `cwd` 变化或路径格式问题被 `validatePath` 误杀
2. **命令校验过严**：`security.js` 对 skill 脚本执行采用通用命令策略，参数中的 `&&`、`/` 等被误伤
3. **产出文件散落**：skill 脚本是黑盒，内部 `open('report.pdf', 'w')` 不受 `path-sandbox.js` 管控，文件可能落到任意位置

核心约束：**skill 可能是第三方开发，无法强制要求其按内部规范开发**（如输出契约、环境变量读取等）。

---

## 设计原则

1. **脚本内部不可控，执行环境可控**：不改造 skill，只增强 exec 工具的执行环境
2. **两层隔离**：Agent 行为用提示词约束（已存在），脚本执行用工作目录隔离兜底
3. **恶意行为前置拦截**：硬编码外部绝对路径的脚本走 skill 市场审核，不依赖运行时沙箱

---

## 三层方案架构

```
+-------------------------------------------------------------+
| Layer 1: Agent 提示词层（约束 Agent 行为）                   |
| -- 系统提示中规定工作目录规范                                |
| -- Agent 调用工具时的路径选择受此约束                        |
+-------------------------------------------------------------+
| Layer 2: exec 工作目录隔离（约束脚本执行环境）               |
| -- 锁定 cwd 到沙箱 temp/skills/ 下的隔离目录                 |
| -- 参数路径自动补全到沙箱 output/                            |
| -- 执行后扫描并归集产出文件                                  |
+-------------------------------------------------------------+
| Layer 3: Skill 市场审核（前置拦截恶意 skill）                |
| -- 审核脚本是否硬编码外部绝对路径                            |
| -- 运行时沙箱不为此类恶意行为兜底                            |
+-------------------------------------------------------------+
```

---

## Layer 1: Agent 提示词（已存在）

系统提示中已包含工作目录规范：

```
文件操作须在以下目录内进行：
- C:/clawSandbox/user/：存放用户上传的原始数据
- C:/clawSandbox/output/：存放 Agent 生成的结果文件（报告、图表等）
- C:/clawSandbox/temp/：存放工作过程中的临时文件和缓存
- C:/clawSandbox/database/：存放知识库、公共参考数据
- C:/clawSandbox/logs/：存放运行日志
```

该提示词约束 Agent 调用 `read`/`write`/`exec` 时的路径选择，覆盖 Agent 可控部分。

**局限**：提示词只能约束 Agent，无法约束 skill 脚本内部的文件操作。例如第三方脚本可能直接写 `open('C:/Users/Admin/Desktop/result.pdf', 'wb')`。

---

## Layer 2: exec 工作目录隔离（核心改动）

### 功能开关

```bash
# .env
ENABLE_EXEC_ISOLATION=true   # 默认 true，设为 false 回退到旧行为
```

### 2.1 锁定 cwd

执行 skill 相关命令时，强制将工作目录设为沙箱 `temp/skills/` 下的隔离目录：

```javascript
const workDirName = `skill-${name}-${randomUUID().slice(0, 8)}`;
const workDir = path.join(sandboxTempDir, 'skills', workDirName);
fs.mkdirSync(workDir, { recursive: true });

const result = await execImpl(command, {
  cwd: workDir,        // 锁定工作目录
  env: { ...process.env, ... }
});
```

**效果**：脚本写相对路径（如 `open('report.pdf', 'w')`）时，文件自然落在隔离目录内。命令执行完成后，exec 工具扫描该目录并归集产出。

### 2.2 参数路径自动补全

执行前扫描命令行中的输出参数，若路径不在沙箱内，自动重映射：

| 参数模式 | 示例 | 处理逻辑 |
|----------|------|---------|
| `--output <path>` | `--output report.pdf` | 补全为 `--output C:\clawSandbox\output\report.pdf` |
| `-o <path>` | `-o result.json` | 同上 |
| `--dest <path>` | `--dest ./out/` | 同上 |
| `--file <path>` | `--file data.csv` | 同上 |

**防逃逸校验**：补全前调用 `validatePath(resolved)`，确认路径在沙箱内。如果不在沙箱内，重映射到 `output/`；如果重映射后的路径仍越界，拒绝执行。

### 2.3 执行后文件归集

命令执行完成后，自动执行以下步骤：

1. 扫描 `workDir`（隔离工作目录）内新创建的文件（**重试机制**：3 次扫描，间隔 500ms，应对异步写文件）
2. 将发现的产出文件统一搬运到 `output/skill-{name}/` 命名空间（防止不同 skill 产出覆盖）
3. **大文件保护**：超过 500MB 的文件不搬运，直接返回原路径
4. **搬运失败降级**：搬运失败时不阻断返回，保留原路径并记录日志
5. 在返回结果中附加 `producedFiles: [...]` 字段，Agent 直接知晓有哪些产出

```javascript
// 伪代码
const beforeFiles = new Set(scanDirectory(workDir));
// ... execute command ...
const afterFiles = scanDirectory(workDir);
const newFiles = afterFiles.filter(f => !beforeFiles.has(f));

for (const file of newFiles) {
  if (file.size > MAX_AUTO_MOVE_SIZE) {
    producedFiles.push(file.path); // 大文件不搬运
    continue;
  }
  const dest = path.join(outputDir, `skill-${name}`, path.basename(file));
  try {
    fs.renameSync(file, dest);
    producedFiles.push(dest);
  } catch {
    producedFiles.push(file); // 搬运失败，保留原路径
  }
}

return { ...result, producedFiles };
```

### 2.4 临时目录清理

```javascript
// 延迟 1 分钟后自动清理
setTimeout(() => {
  fs.rmSync(workDir, { recursive: true, force: true });
}, 60 * 1000);
```

> **注意**：启动时清理超过 24 小时的残留目录尚未实现，建议作为运维脚本定期执行。

### 2.5 Skill 模式自动检测

`exec` 工具无需 Agent 显式传递 `context: 'skill'`，自动从命令中检测：

```javascript
const skillMatch = command.match(/skills[\/\\]([\w-]+)[\/\\]scripts[\/\\]/i);
if (skillMatch) {
  effectiveContext = 'skill';
  effectiveSkillName = skillMatch[1];
}
```

**工具参数**：

```javascript
context: {
  type: 'string',
  enum: ['general', 'skill'],
  default: 'general'
},
skill_name: {
  type: 'string',
  description: 'Skill name (used when context="skill")'
}
```

---

## Layer 2.5: 命令参数路径校验（exec.js 层面）

除了 `security.js` 的字符串级校验，`exec.js` 额外做了两层路径校验：

### 文件操作命令路径校验

对 `copy`/`move`/`mv`/`cp`/`del`/`rm`/`mkdir` 等命令，提取路径参数并调用 `validatePath()`：

```javascript
// Windows: move "C:/outside/file.txt" "C:/sandbox/file.txt"
// 如果源或目标路径越界，直接拒绝执行
```

### PowerShell cmdlet 路径校验

对 `Remove-Item`/`Move-Item`/`Copy-Item`/`New-Item`/`Set-Content`/`Clear-Content`，提取 `-Path`/`-Destination`/`-Value` 参数并校验：

```javascript
// Remove-Item -Path "C:/outside/file.txt" -Force
// 路径越界 → 拒绝执行
```

### 通用参数路径校验

扫描命令行中所有引号包裹的字符串和未引号的路径 token，识别出路径特征（含路径分隔符、Windows 盘符、以 `~` 开头）后调用 `validatePath()` 校验。

---

## Layer 2.6: security.js 命令校验增强

### Skill 模式校验策略

| 校验项 | 通用命令 | Skill 命令 |
|--------|---------|-----------|
| `&& \|\| ;` 链式操作 | 严格阻断 | 允许（脚本参数中常见） |
| `rm -rf /` 等危险模式 | 阻断 | 阻断 |
| 路径中的 `..` | 阻断 | 允许（脚本内部可能用到） |
| 脚本路径合法性 | 不检查 | **强制检查脚本文件必须在 `skills/{name}/` 下** |
| 引号内 `$(cmd)` | 放行（作为参数值） | 放行 |
| 纯文件操作链（move/copy 等） | 放行 | 放行 |

### 关键安全机制

1. **`isCdToScriptRunner()`**：放行 `cd <path> && python/node <script>` 模式，但验证 cd 目标路径在沙箱内、脚本路径在 cd 目标目录内
2. **`areAllChainSegmentsSafe()`**：当命令链的所有段都是纯文件操作命令（`move`/`copy`/`mkdir`/`echo`/`cd` 等，不含 `python`/`node`/`bash`）时放行
3. **`validateSkillScriptPath()`**：skill 模式下，脚本路径必须真实存在于 `skills/{skillName}/` 目录下
4. **`isIndexInQuotes()`**：命令替换 `$()` 和 `` ` `` 仅在引号外出现时阻断，引号内作为参数值放行

---

## Layer 3: Skill 市场审核

对于硬编码外部绝对路径的脚本，运行时沙箱**无法拦截**（脚本内部行为不受控制）。此类问题应在 skill 市场审核阶段解决：

### 审核检查项

1. **路径扫描**：检查脚本源码中是否存在硬编码的外部绝对路径（如 `C:\`、`/home/`、`/tmp/` 等）
2. **输出路径约定**：检查脚本是否支持通过参数指定输出路径（`--output`、`-o` 等）
3. **环境变量读取**：检查脚本是否读取 `COQI_CWD` 或 `COQI_SANDBOX_OUTPUT`（加分项，非强制）

### 审核结果分级

| 等级 | 标准 | 处理 |
|------|------|------|
| 通过 | 支持参数指定输出路径，无硬编码外部路径 | 上架 |
| 警告 | 有硬编码外部路径，但仅在特定条件下触发 | 上架+风险提示 |
| 拒绝 | 强制写死外部路径（如 `C:/Users/*/Desktop/`） | 拒绝上架 |

---

## 配套改动：read 路径锚定

修改 `src/tools/read.js`，对 `skills/` 路径走**项目根锚定解析**：

```javascript
// execute() 中
if (filePath && typeof filePath === 'string') {
  const trimmed = filePath.trim();
  if (trimmed.startsWith('skills/') || trimmed.startsWith('skills\\')) {
    filePath = path.join(getBaseDir(), trimmed);
  } else {
    const resolved = path.resolve(filePath);
    const skillsDir = path.join(getBaseDir(), 'skills');
    if (resolved.startsWith(skillsDir + path.sep)) {
      filePath = resolved;
    }
  }
}
```

**效果**：skill 描述文件读取不再依赖 `cwd`，始终以项目根为锚点，杜绝误判。

---

## 配套改动：沙箱路径缓存优化

### path-sandbox.js

- `getSandboxRoots()` 增加缓存（`cachedRoots` + `cachedEnvPaths`），避免每次调用都重新解析环境变量
- 错误信息包含允许的根目录列表和 `SANDBOX_PATHS` 配置指引

### sandbox-layout.js

- `getSandboxBaseDir()` 增加缓存（`cachedBaseDir` + `cachedEnvPaths`）
- 提供 `clearSandboxBaseDirCache()` 供测试使用

---

## 覆盖能力矩阵

| 场景 | 提示词 | + exec 隔离 | 市场审核 |
|------|--------|------------|---------|
| Agent 传了 `--output output/xxx` | 有效 | 有效，且自动补全绝对路径 | - |
| 脚本接收 `--output` 并遵守 | - | 有效 | - |
| 脚本忽略 `--output`，写相对路径 | - | **有效**（被 cwd 隔离在 temp，执行后归集到 output/skill-{name}/） | - |
| 脚本硬编码外部绝对路径 | - | **无效** | **前置拦截** |
| 两个 skill 同时产生 `report.pdf` | - | **有效**（命名空间隔离，不覆盖） | - |

---

## 涉及文件

| 文件 | 改动内容 |
|------|---------|
| `src/tools/exec.js` | 工作目录隔离、参数路径补全（含防逃逸校验）、执行后文件扫描归集、返回 `producedFiles`、自动 skill 模式检测、文件操作/PowerShell 路径校验、特性开关 `ENABLE_EXEC_ISOLATION` |
| `src/tools/read.js` | skill 路径项目根锚定解析 |
| `src/security/security.js` | `validateCommand()` 区分 general/skill 策略、脚本路径验证、`isCdToScriptRunner()` 安全链、`areAllChainSegmentsSafe()` 文件操作链、引号内命令替换放行、skill 模式放宽 `&&\|\|;` |
| `src/security/path-sandbox.js` | `getSandboxRoots()` 缓存优化、错误信息包含允许根目录列表 |
| `src/security/sandbox-layout.js` | `getSandboxBaseDir()` 缓存优化 |
| `test/test-exec-skill.js` | 22 个测试用例覆盖 skill 模式、文件操作链、命令替换等 |

---

## 验证步骤

1. 配置 `.env`：`SANDBOX_PATHS=C:\clawSandbox`
2. 启动 Agent，调用一个写相对路径的 skill 脚本
3. 验证：
   - 脚本执行成功，不被命令安全层误伤
   - 产出文件出现在 `C:\clawSandbox\output\skill-{name}\`
   - Agent 通过返回的 `producedFiles` 字段直接获取产出路径
   - `read("skills/xxx/SKILL.md")` 不受 `cwd` 影响
4. 测试硬编码外部路径的 skill 脚本（模拟恶意场景），确认市场审核机制能拦截

---

## 隔离机制设计缺陷（2026-04-26 Review 发现）

### 问题描述

Layer 2 的 exec 工作目录隔离存在**设计层面的断裂**：隔离目录是空的，原始 skill 脚本从未被复制进去。

**执行流程的矛盾**：

```
Agent 生成: cd skills/henry-city-weather && python scripts/weather.py ...
                ↓
exec.js 创建隔离目录: C:\clawSandbox\temp\skills\skill-henry-city-weather-{uuid}\
                ↓
设置 cwd = 隔离目录（空目录，无脚本文件）
                ↓
执行原始命令（未被改写）
                ↓
cd skills/henry-city-weather → 进入隔离目录下的 skills/henry-city-weather/（不存在！）
```

### 三个子系统各自为政

| 子系统 | 知道的目录 | 不知道的目录 |
|-------|----------|------------|
| exec.js 隔离机制 | `temp/skills/skill-{uuid}/` | 原始 skills/ 下的脚本文件 |
| security.js 路径校验 | 原始 `skills/{skillName}/` | 隔离目录中的脚本 |
| Agent（LLM） | 原始 `skills/xxx/scripts/` | 隔离目录的存在 |

### 引发的恶性循环

1. **第一次执行**：相对路径命令在隔离目录下找不到脚本，执行失败
2. **Agent 后续迭代**：Agent 从返回结果中得知隔离目录路径，改用绝对路径引用
3. **安全校验阻断**：`validateSkillScriptPath` 只认原始 `skills/{skillName}/`，隔离目录路径触发 Security FATAL

### 修复方案（已确认实施）

**方案 A：创建隔离目录后将原始 skill 内容复制到隔离目录**

```javascript
// exec.js: 创建 workDir 后
const sourceSkillDir = path.join(getBaseDir(), 'skills', effectiveSkillName);
if (fs.existsSync(sourceSkillDir)) {
    copyDirSync(sourceSkillDir, workDir);
}
```

**收益**：
- 脚本和依赖文件都在隔离目录中，相对路径命令正常工作
- Agent 使用绝对路径引用隔离目录也正常
- 安全校验可简化为：只要脚本在沙箱内就放行
- 产出文件收集机制继续工作

**涉及文件**：`src/tools/exec.js`、`src/tools/exec-skill.js`、`src/security/security.js`

---

## 已知限制与后续工作

| 项 | 状态 | 说明 |
|----|------|------|
| 启动时清理残留 temp 目录 | 未实现 | 建议运维脚本定期清理 `temp/skills/` 下超过 24 小时的目录 |
| 安全事件统一日志格式 | 未实现 | 仍使用原有 `logger.error/warn` 格式，未统一为结构化安全事件 |
| OS 级隔离 | 长期建议 | 应用层隔离无法防御符号链接绕过、子进程 spawn 等，建议评估 Docker/Windows Sandbox |
| Skill 市场审核流程 | 长期建议 | 需要审核脚本自动扫描源码中的硬编码绝对路径 |
| 磁盘配额监控 | 长期建议 | 建议监控 `output/` 和 `temp/` 磁盘使用 |
