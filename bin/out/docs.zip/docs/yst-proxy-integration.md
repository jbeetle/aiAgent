# 一事通 OA 代理网关适配总结

> 将 `web/vite.config.ts` 中的一事通（招商银行内部 SSO）代理能力迁移到 `src/gateway/`，
> 使网关可脱离 vite 独立发布，支撑第三方 Web 客户端集成 agent runtime。
>
> 日期：2026-08-06（2026-08-07 更新联调记录）｜ 涉及版本：coqi-claw 2.0.1

---

## 1. 背景与目标

第三方 Web 客户端（一事通扫码登录 + 聊天）需要访问 agent runtime。原方案依赖
`web/vite.config.ts` 的 dev server 代理，**无法在生产环境脱离 vite 发布**。目标：

1. 网关（`src/gateway/`）完整承接 vite 的四条代理能力，行为逐条对齐
2. 一事通扫码登录与用户名密码登录**同时并存**
3. 一事通登录链路的新增 API **公开放行**（不需要 `X-API-Key` 验证）
4. 前端与网关统一打包发布，完全脱离 vite

## 2. 需求与约束（来自领导/第三方沟通）

| 约束 | 影响 |
|------|------|
| 前端与网关统一打包发布，纯 Web HTML 应用（同 web-bak 形态），**无 Electron** | 同源部署：网关 serve 静态 + 代理 + API 一体化；iframe 与页面同源，cookie 全链路可管理 |
| 网关只绑定 `127.0.0.1:214` | `WEB_HOST`/`WEB_PORT` 环境变量配置；威胁面限本机 |
| 一事通页面 URL、页面内接口路径、资源（图片/CSS/JS）路径**均不可修改** | 代理规则必须完整覆盖上游路径形态，网关侧适配，不能要求一事通改动 |
| 一事通扫码登录与用户名密码登录同时支持 | 双 Tab 共存；密码登录走现有 `X-API-Key` 流程 |
| 一事通访问网关**新增 API 一律放行**，不需要验证 | 登录链路接口（`/api/v1/yst/token`）加入认证白名单；业务 API 保护不变（方案 A） |

## 3. 第 1 步：现状盘点

### 网关已有能力（复用，零开发）

| 能力 | 位置 | 说明 |
|------|------|------|
| `/api/remote-login` 透传 | `routes/remote-login.js` | 转发到 `REMOTE_LOGIN_URL`（默认 `http://tmogw-dev.cmbi.online/eagent/edge/login`），已公开放行 |
| `/api/auth/login` 密码登录 | `routes/auth.js` | `WEB_LOGIN_USERNAME/PASSWORD` 换取 apiKey |
| `X-API-Key` 认证 | `middleware/api-auth.js` | 全局挂载，静态资源/公开路径跳过 |
| CORS / 限流 / WS 认证 | `middleware/cors.js` 等 | `WEB_CORS_ORIGINS`、`WEB_RATE_LIMIT` |
| 静态托管 + SPA fallback | `server.js` | `express.static(web/dist)` |

### 网关缺失能力（本次开发）

1. OA 认证域反向代理（`/yst-proxy`、`/zh-login`、`/auth-server` 三条路径 + CSP 剥离 + HttpOnly 处理）
2. 一事通 code→token 接口（`/api/v1/yst/token`）

## 4. 第 2 步：方案设计

### 4.1 认证矩阵

| 路径 | 凭证要求 | 说明 |
|------|----------|------|
| `/api/auth/login`、`/api/remote-login` | 公开（已有） | 登录链路 |
| `/api/v1/yst/token`（新增） | **公开放行** | 登录链路，加入 `PUBLIC_PATHS` |
| `/yst-proxy`、`/zh-login`、`/auth-server`（新增代理） | 公开 | 不在 `/api` 前缀下，天然跳过认证；iframe 静态资源必须公开 |
| 业务 API（sessions/chat/files/…） | `X-API-Key`（不变） | 双登录最终收敛到同一 apiKey 体系（方案 A） |

### 4.2 一事通登录链路（方案 A）

```
扫码 → 三方页回调 yhtLogin(code, type)
  → POST /api/v1/yst/token（网关 → 管理端 YST_TOKEN_URL）→ { remoteToken, username }
  → POST /api/v1/auth/login（配置的管理账号）→ apiKey
  → 后续请求 X-API-Key（+ Bearer remoteToken）
```

### 4.3 代理路径规则（以 vite 为蓝本；`/zh-login` 经联调修正为整链路保留前缀，见第 11 节）

| 网关路径 | 上游映射 | 规则 |
|----------|----------|------|
| `/yst-proxy/*` | `{OA_BASE}/*` | 去前缀 |
| `/zh-login`、`/zh-login/`、`/zh-login/*` | `{OA_BASE}/zh-login/...` | **整链路保留前缀**（联调实测修正：页面与子资源均部署在 `/zh-login/` 下，去前缀上游 404） |
| `/auth-server/*` | `{OA_BASE}/auth-server/*` | **保留前缀**（与 vite 一致，无 rewrite；OA 域自己的网关会剥离该前缀） |

## 5. 第 3 步：实施

### 5.1 新增 `src/gateway/middleware/oa-proxy.js`

OA 认证域反向代理中间件，核心设计：

- **路径规则表** `PROXY_RULES`：三条前缀 + 各自的 map 函数（`/zh-login`、`/auth-server` 保留前缀，`/yst-proxy` 去前缀）
- **请求头白名单** `FORWARD_REQUEST_HEADERS`：透传 content-type/accept/cookie/origin/referer 等；
  `host`/`content-length`/hop-by-hop 由 undici fetch 自动处理（等效 vite `changeOrigin: true`）
- **强制 `accept-encoding: identity`**：避免 undici 自动解压后透传头与 body 不一致
- **响应头过滤** `SKIP_RESPONSE_HEADERS`：删除 content-encoding/content-length/hop-by-hop/CSP；
  Set-Cookie 多值单独处理（`getSetCookie()`）
- **重定向** `redirect: 'manual'`：3xx 原样透传给浏览器（与 http-proxy 一致），不跟随——避免 fetch 绕过代理直连 OA 域
- **流式管道** `Readable.toWeb(req)` / `Readable.fromWeb(upstream.body).pipe(res)`：请求体与响应体零缓冲透传
- **超时与错误**：30s 超时（可配）→ 504；网络错误 → 502
- **防 SSRF**：上游目标固定 `YST_PROXY_OA_BASE` 白名单，不接受请求指定目标
- **配置缓存**：以 env 快照为缓存键，env 变化自动重新解析（测试可动态切换场景）
- **客户端中断处理**：`res.on('close')` 时取消上游读取，防连接悬挂

### 5.2 新增 `src/gateway/routes/yst.js`

`POST /api/v1/yst/token`：code→token 透传（对齐 `remote-login.js` 模式）：

- 延迟读取 `YST_TOKEN_URL`；未配置 → 501 `NotConfigured`
- 参数校验：`{ code, type }` 必填 → 400
- 30s 超时 → 504；网络错误 → 502；响应（JSON/文本）原样透传

### 5.3 接线 `src/gateway/server.js`

```js
// 一事通 OA 扫码页代理（默认开启，YST_PROXY_ENABLED=false 关闭）
app.use(oaProxyMiddleware);   // 必须在通用安全头（X-Frame-Options: DENY）之前！
```

关键：代理必须挂载在通用安全头中间件**之前**——否则 `X-Frame-Options: DENY`
会污染代理响应，扫码页无法在 iframe 中渲染；同时需在 body parser 之前以透传原始请求体。

### 5.4 认证放行 `src/gateway/middleware/api-auth.js`

`PUBLIC_PATHS` 新增 `/api/yst/token`、`/api/v1/yst/token`。

### 5.5 路由注册 `src/gateway/router.js`

```js
router.use("/yst", createYstRoutes());   // /api/v1/yst/token + 兼容 /api/yst/token
```

### 5.6 配置（已加入 `.env.example`）

```env
# OA 扫码页代理（iframe 沙箱），默认开启；设为 false 关闭
YST_PROXY_ENABLED=true
YST_PROXY_OA_BASE=https://oa-auth.paas.cmbchina.com
YST_PROXY_STRIP_HTTPONLY=true                    # 默认开启（与 vite 一致）；false 保留 HttpOnly
YST_PROXY_TIMEOUT_MS=30000                       # 代理超时（毫秒）

# 一事通 code→token（管理端）
YST_TOKEN_URL=
```

## 6. 第 4 步：与 vite.config.ts 逐条对齐 review

对比后发现 4 处不一致，全部修复：

| # | 差异 | 影响 | 修复 |
|---|------|------|------|
| 1 | `/auth-server`：vite **无 rewrite（保留前缀）**，初版网关**去前缀** | OA 域认证接口 404 | `map: (p) => p` 保留前缀 |
| 2 | 重定向策略：vite 透传 3xx，网关 fetch 默认 `follow` | 跟随重定向会**绕过代理直连 OA 域**（跨域/防火墙不通） | `redirect: 'manual'` 原样透传 |
| 3 | `YST_PROXY_STRIP_HTTPONLY`：vite **无条件去 HttpOnly**，初版默认 `false` | 一事通清理逻辑（`clearYstCookies`/登录失败重置 iframe）依赖 JS 可管理 cookie，默认关则退化 | 默认改为开启 |
| 4 | `/api/remote-login`：vite 支持**所有方法** + **响应头透传**（含 Set-Cookie），网关仅 POST + 仅 body | GET 等请求 404、Set-Cookie 丢失 | `router.all` + 响应头透传（过滤 hop-by-hop/长度/编码，Set-Cookie 多值处理） |

已一致无需改动的项：`/yst-proxy`、`/zh-login` 路径规则逐字符一致；CSP 剥离；
changeOrigin（undici 自动使用目标 URL host）；默认代理目标一致；静态托管替代 vite dev server。

**顺带修复**：`remote-login.js` 的 `logger.error` 参数顺序与项目 logger API（message 在前）不符，
导致错误日志输出 `[object Object]`——5 处调用全部修正。

**联调追加修正（2026-08-06）**：与真实上游联调发现 vite 规则本身的假设已不成立——
子资源实际同样部署在 `/zh-login/` 下（`/zh-login/umi.*.js` → 200，`/umi.*.js` → 404），
"子资源去前缀"会导致全部 JS/CSS chunk 404、扫码页空白。网关与 `web/vite.config.ts`
已同步改为 `/zh-login` 整链路保留前缀，`test/test-oa-proxy.js` 同步更新（16 用例通过），
并对真实上游验证页面 + 子资源全链路 200。

## 7. 第 5 步：静态资源穿透 review

| 环节 | 状态 |
|------|------|
| GET/HEAD、二进制流式透传、content-type | ✅ |
| 缓存头（cache-control/etag/last-modified/expires/vary） | ✅ |
| 4xx/5xx/304 状态透传 | ✅ |
| Cookie、query 参数 | ✅ |
| **条件请求头 `if-none-match`/`if-modified-since`、`range`** | ❌ 初版缺失 → **已补**（缓存协商失效、断点续传失效） |
| 编码路径（中文/空格文件名） | ✅ req.path 基于 parseurl 未解码，拼接安全 |

修复：`FORWARD_REQUEST_HEADERS` 补充 `if-none-match`、`if-modified-since`、`range`。

有意的取舍：请求强制 `accept-encoding: identity`（未压缩传输）——规避 undici
自动解压与透传头不一致的风险，内网场景带宽可接受。

## 8. 第 6 步：测试验证

### 8.1 单元测试

| 文件 | 用例数 | 覆盖 |
|------|--------|------|
| `test/test-oa-proxy.js` | 16 | 开关关闭放行、三条路径 rewrite 规则、query 保留、POST body 透传、CSP 剥离、HttpOnly 开关、if-none-match/range 透传、302 透传不跟随、未匹配放行、502/504 |
| `test/test-remote-login.js` | 6 | POST body/路径透传、JSON 透传、Set-Cookie 透传、GET 方法支持、上游 500 透传、502 |

### 8.2 端到端实测（`npm run web` 真实启动，enterprise 场景）

| 验证项 | 结果 |
|--------|------|
| 网关启动（127.0.0.1:214，.env 签名校验通过） | ✅ |
| `/api/health` | ✅ 200 |
| `/api/v1/yst/token` | ✅ 501（YST_TOKEN_URL 未配置，路由注册 + 公开放行） |
| `/api/v1/auth/login` | ✅ 401（认证正常） |
| `/yst-proxy/api/ping` | ✅ 去前缀转发（上游收到 `/api/ping`） |
| `/zh-login/` | ✅ 返回 OA 域真实扫码页 HTML，CSP 已剥离，Set-Cookie 无 HttpOnly |
| `/auth-server/ping` | ✅ 保留前缀转发（OA 域自己剥离前缀，上游收到 `/auth-server/ping`） |
| WebSocket 握手 | ✅ 101 |
| 静态根 `/` | ❌ 500 ENOENT（`web/dist` 前端产物缺失，发布前需构建） |

## 9. 第 7 步：最终能力清单

| 能力 | 位置 | 状态 |
|------|------|------|
| OA 反向代理（3 路径 + CSP/HttpOnly + 超时 + SSRF 防护） | `middleware/oa-proxy.js` | ✅ 默认开启 |
| 一事通 code→token | `routes/yst.js` | ✅ 公开放行 |
| remote-login 全方法 + 响应头透传 | `routes/remote-login.js` | ✅ 修复增强 |
| 网关接线（挂载顺序：安全头之前） | `server.js` | ✅ |
| 认证放行 | `api-auth.js` | ✅ |
| 路由注册（双前缀） | `router.js` | ✅ |
| 第三方集成文档 | `docs/api-guide.md`「一事通扫码登录」章节 | ✅ |

## 10. 遗留事项

1. **前端产物缺失**：`web/dist/` 不存在，页面访问 500（API/代理不受影响）。发布前需将第三方
   Web 前端构建产物放入 `web/dist/`（复用现有 `express.static` + SPA fallback）。
2. **`YST_TOKEN_URL` 待确认**：一事通管理端 code→token 接口地址与可用性（源码注释曾有 TODO）。
   未配置时扫码登录返回 501。
3. ~~**`.env.example` 补充**~~（已完成）：`YST_PROXY_*` 与 `YST_TOKEN_URL` 配置项已加入 `.env.example`。
4. **`WEB_HOST` 现状**：`.env` 中为 `0.0.0.0`（外部可访问）。如仅本机使用，
   建议改为 `WEB_HOST=127.0.0.1`（与"只绑定本地"预期一致）。
5. **生产出站放行**：网关 → `oa-auth.paas.cmbchina.com` 与 SSO 网关的网络连通性。
6. **扫码 URL 联调**：一事通实际扫码 URL 形态是否全部落在三条代理路径下。
7. **旧打包产物不含 OA 代理**：`dist/`、`target/release/coqi-backend/` 中的产物早于本次适配，
   无 `oa-proxy` 中间件。用于联调/发布前需重新构建（`npm run build:sea` / `build:obf`），
   否则 `/zh-login/` 会落入 SPA fallback 返回 SPA 外壳并被浏览器缓存（同源缓存投毒：
   曾占用同一端口的其他服务也会造成同样问题）。若已发生，硬刷新（Ctrl+F5）即可经本网关
   自愈——上游对不匹配的 ETag 会返回 200 新内容覆盖缓存。

---

## 11. 联调记录与排查总结（2026-08-06）

### 11.1 症状

三方页面 iframe 加载 `http://localhost:214/zh-login/` 持续 304 Not Modified，扫码页出不来。

### 11.2 结论 A：同源缓存投毒（表象）

- 浏览器缓存条目的 ETag 为 `W/"1dd-19fd6630260"`——Express 风格弱 ETag
  （0x1dd = 477 字节 + 文件 mtime 十六进制），而真实上游返回 nginx 风格强 ETag
  `"6a4774e8-62b"` 且 `cache-control: no-store`。缓存内容根本不是 OA 页面。
- 取证：网关日志无该请求记录；当时 214 端口被三方前端自己的静态服务器占用，
  `/zh-login/` 落入其 SPA fallback，返回 477 字节的 index.html 并被浏览器缓存。
- 自愈性：该缓存条目每次必须重验证（max-age=0），经本网关重验证时上游对不匹配的
  ETag 返回 200 覆盖缓存（已实测）。硬刷新（Ctrl+F5）即可恢复。
- 教训：**同一端口不可混跑其他服务或旧打包**（旧 dist 产物无 oa-proxy，同样投毒）。

### 11.3 结论 B：`/zh-login` 子资源去前缀规则错误（主因）

- vite 配置假设"子资源去前缀（上游部署在域名根路径）"，与真实上游现状不符：
  - `GET /zh-login/umi.3ad06b68.js`（保留前缀）→ **200**
  - `GET /umi.3ad06b68.js`（去前缀）→ **404**
- 后果：即使页面 HTML 加载成功，全部 JS/CSS chunk 404，扫码页必然空白。
- 修复：网关 `oa-proxy.js` 与 `web/vite.config.ts` 同步改为 `/zh-login` 整链路保留
  前缀；`test/test-oa-proxy.js` 同步更新。
- 验证：单元测试 16 + 6 全部通过；对真实上游经代理验证页面 + 子资源
  （umi.js / vendors.js / umi.css / favicon.ico）全链路 200。
- 提交：`d8fc341`（feat: 网关承接一事通 OA 扫码登录代理，18 文件）。
- 经验：**vite 规则是蓝本不是 ground truth**；平移后必须逐条对真实上游验证，
  并补齐 fetch 与 http-proxy 的语义差异（3xx 透传、强制 identity 编码、Set-Cookie
  多值、请求头白名单、挂载顺序在安全头之前等，见第 6、7 节）。

### 11.4 YST_TOKEN_URL 数据流澄清

- 扫码成功后，一事通通过页面回调 `yhtLogin(code, type)` 把 **code** 交给三方前端
  （JS 层面回调，并非 HTTP 推送到 YST_TOKEN_URL）。
- 兑换链路：前端 POST `{code, type}` → `VITE_YST_TOKEN_URL`（前端构建变量，应指向
  网关 `/api/v1/yst/token`）→ 网关透传 → `YST_TOKEN_URL`（网关 env，管理端真实接口）
  → 管理端用 code 向一事通服务端换身份，返回 `{ token, username }` 原样透传回前端。
- 两个同名变量都需配置；网关侧未配置时 `/api/v1/yst/token` 返回 501 NotConfigured。
- 观察点：`routes/yst.js` 回写统一用 `res.json()`，若管理端返回纯文本会被 JSON
  序列化加引号（返回 JSON 时无影响）。

### 11.5 当前遗留阻塞项

1. `YST_TOKEN_URL` 待管理端确认并配置（否则 code 换 token 501）。
2. 三方前端构建产物待放入 `web/dist/`（否则主页面 `/` 404）。
3. 联调前确认 214 端口只运行本网关；旧打包需重新构建后再使用。
