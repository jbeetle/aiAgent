# 系统提示设计与 Provider 端 KV Cache 优化

> 创建日期：2025-07-18
> 状态：设计阶段

## 一、背景

### 1.1 Provider 端 KV Cache 机制

LLM 处理 token 时，每个 token 在 Transformer 每一层都需要计算 **Key-Value 矩阵**（注意力机制核心）。该计算复杂度为 O(n²)，是推理过程中最昂贵的部分。

**Prefix KV Cache**：如果新请求的**前缀**与之前某个请求的 token 序列完全一致，Provider 侧直接复用已计算好的 KV 矩阵，跳过这部分计算。

### 1.2 各主流 Provider 实现差异

| Provider | 触发方式 | 最小可缓存长度 | Cache TTL | 粒度 |
|---------|---------|-------------|-----------|------|
| DeepSeek | 自动，无需配置 | 64 tokens | 数小时 | 64 token 块 |
| OpenAI | 自动（>1024 tokens）| 1024 tokens | 5~10 分钟 | 128 token 块 |
| Anthropic | 显式 `cache_control` 标记 | 1024 tokens | 5 分钟 / 1 小时 | 整块内容 |
| Qwen/DashScope | 自动 | 64 tokens | 数小时 | 64 token 块 |

### 1.3 命中收益

- **TTFT（首 token 延迟）**：降低 60-80%
- **Input token 费用**：DeepSeek 缓存命中 token 价格为正常价格的 10%

### 1.4 缓存失效条件

**缓存只作用于前缀**，前缀必须字节级完全一致。任何前缀内容变化都会导致该位置及之后所有 token 的缓存失效。

**示例**：

```
请求 1 system：当前时间：2025-07-18 周五 14:32  ← 全量缓存
请求 2 system：当前时间：2025-07-18 周五 14:34  ← 完全 miss，全部重算
```

---

## 二、coqi-claw 当前问题

### 2.1 时间字段阻断缓存

当前 `buildTimeSection()` 精确到分钟，内嵌在 system prompt 中：

```
system prompt 结构（当前）：
┌─────────────┐
│ 角色定义     │
│ 当前时间 ⏰  │  ← 每分钟变化，导致后面全部失效
│ 执行环境     │
│ 技能列表 🔀  │
│ 工具列表     │
│ Sandbox 规范 │
│ L0→L4 指令  │
└─────────────┘
```

**影响**：同一会话内连续对话，system prompt 每分钟必然 miss 一次。技能、工具、指令一字未变，但仍需全量重算。

### 2.2 技能列表动态排序

技能按"相关度排序"注入 system prompt。即使同一会话内技能集合未变，排序波动也会导致该位置之后所有 token 的缓存失效。

---

## 三、优化设计：梯度稳定化

### 3.1 核心原则

**越稳定的内容放越靠前，越动态的内容放越靠后（或移出 system）。**

```
┌─────────────────────────────────────────────────────────────┐
│ ████████████████████████████████████████████████████████████ │ ← 永久缓存命中区
│ STATIC — 完全不变，跨用户、跨会话一致                       │
│                                                             │
│   - 角色定义（assistantRole）                                │
│   - 执行环境信息（OS、Shell、Python/Node 版本、字体、沙箱）  │
│   - 全量工具名列表                                           │
│   - Sandbox 目录规范                                         │
│   - L0→L4 分层指令                                           │
│                                                             │
│ 占比：system prompt 的 70-80%                                │
├─────────────────────────────────────────────────────────────┤
│ ██████████████████████████████████░░░░░░░░░░░░░░░░░░░░░░░░░ │ ← 可能命中区
│ SEMI-STATIC — 按会话 / 用户意图变化                          │
│                                                             │
│   - 匹配到的技能列表（按 name 字母序排列，稳定输出）         │
│   - 工具建议                                                 │
│                                                             │
│ 占比：system prompt 的 20-30%                                │
├─────────────────────────────────────────────────────────────┤
│ ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░ │ ← 移出 system
│ DYNAMIC — 每轮都变，移入 user message                        │
│                                                             │
│   - 当前时间 → user message 尾部                             │
│   - 用户身份信息 → 已在 user message 中                      │
└─────────────────────────────────────────────────────────────┘
```

### 3.2 为什么技能不能全部移出 system

技能匹配结果放在 system prompt 里有一个不可替代的作用：**权威信号**。

LLM 训练数据中，`system` message 是权威指令源，`user` message 是可协商的请求。如果把 `你必须使用 skill 脚本，禁止自行编写替代代码` 放在 user message 里，LLM 会认为"这是用户在建议我用某工具"，而不是"系统要求我必须用某工具"——执行遵循度会明显下降。

**当前 Bookending 设计**正是意识到了这一点：同一信息在 system（首部信号）和 user 末尾（尾部信号）**同时出现**，利用 U 型注意力曲线两端的高峰来强化执行遵循度。这是比纯缓存更重要的正确性保障，不应牺牲。

### 3.3 System Prompt 重组方案

**改后结构**：

```
system prompt（按此顺序构建）：
┌──────────────────────┐
│ 1. 角色定义           │  ← STATIC
│ 2. 执行环境信息       │  ← STATIC
│ 3. 全量工具名列表     │  ← STATIC
│ 4. Sandbox 目录规范   │  ← STATIC
│ 5. L0→L4 分层指令     │  ← STATIC
│ 6. 技能列表（字母序） │  ← SEMI-STATIC
│ 7. 工具建议           │  ← SEMI-STATIC
└──────────────────────┘

user message 尾部注入：
┌──────────────────────┐
│ [当前时间：...]       │  ← DYNAMIC
│ [系统匹配：...]       │  ← Bookending
└──────────────────────┘
```

### 3.4 技能列表稳定化

技能按 `name` 字母序排列后注入 system prompt，相关度信息通过 Bookending 在 user message 中传递（Bookending 本来就在 user message 里，不影响 system 稳定性）。

---

## 四、缓存命中率预期

| 场景 | 改前 | 改后 |
|------|------|------|
| 同一会话连续对话 | 每分钟 miss | 几乎 100% hit |
| 不同会话，同类任务（同技能） | 每次都 miss | system 静态部分 hit（70-80% token 复用） |
| 不同会话，不同任务 | 每次都 miss | 静态前缀（工具/指令部分）hit |

对于高频使用场景（多用户、长会话），Provider 侧费用可降低 30-50%，首 token 延迟显著改善。

---

## 五、实施优先级

### Phase 1：最小改动，立即收益

**时间信息从 system 移到 user message 尾部**。

改动范围：`src/core/prompt-builder.js`（移除 `buildTimeSection` 调用）+ `src/core/agent.js`（在 `runWithHistory` 中向 user message 尾部追加时间标签）。

收益：同一会话内 system prompt 完全稳定，从"每分钟 miss"变成"首次 miss，后续全部 hit"。

### Phase 2：System Prompt 结构重组

按 3.3 节方案重排 system prompt 构建顺序，静态内容前置，动态内容后置。

改动范围：`src/core/prompt-builder.js`（`buildSystemPrompt` 中组装顺序调整）。

收益：跨会话的静态前缀也可命中。

### Phase 3：技能列表稳定化

技能按 name 字母序排列后再注入 system prompt。

改动范围：`src/core/prompt-builder.js`（`buildSkillsSection`）+ `src/core/agent.js`（确认排序逻辑）。

收益：同一技能集在不同会话中命中率提升。

---

## 六、不影响的设计

以下设计保持不变，不因缓存优化而修改：

- **Bookending**：继续在 user message 末尾注入技能/工具标记，保持执行遵循度
- **技能匹配洞察（matchInsight）**：继续注入 system prompt（Instructions 之前），字数极小，不影响缓存
- **工具定义的 function calling 传输**：与 system prompt 是独立通道，不受影响
- **assistantIdentity**：若配置了 assistant 个性化，保持在 system prompt 首位（静态内容）
