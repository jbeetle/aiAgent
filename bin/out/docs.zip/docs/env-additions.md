# ===== Web Search (plugin: plugins/tools/web-search/) =====

# 秘塔搜索 Metaso（推荐首位，国内中文搜索，质量最高）
# 申请: https://metaso.cn
#METASO_API_KEY=

# 博查 AI Search（备选，国内中文搜索）
# 申请: https://open.bocha.cn 选择「AI 搜索」产品
# 免费额度: 1000次/月
#BOCHA_API_KEY=

# Tavily Search（英文技术文档搜索）
# 申请: https://tavily.com/
# 免费额度: 1000次/月
#TAVILY_API_KEY=

# Brave Search（英文通用搜索）
# 申请: https://brave.com/search/api/
# 免费额度: 2000次/月
#BRAVE_SEARCH_API_KEY=

# SearXNG 自建实例（无限制）
#SEARXNG_URL=

# 后端自动选择优先级: metaso > bocha > tavily > brave > searxng
# 强制指定后端: WEB_SEARCH_BACKEND=metaso

# ===== Vision Model (read 图片分析) =====
# 视觉模型 ID，配置后 read 工具可分析图片内容
# 不配置则仅返回图片元数据（格式、尺寸等）
#VISION_LLM_MODEL=
# 视觉模型 API（回退到 LLM_API_KEY / LLM_BASE_URL）
#VISION_LLM_API_KEY=
#VISION_LLM_BASE_URL=
# 视觉 API 超时(ms)，默认 60000
#VISION_LLM_TIMEOUT=60000

"""
NOTE: Append this to your .env file. 
The existing .env.example is protected and cannot be modified directly.
Please add these sections manually.
"""
