# .env 配置项 RSA 加密使用说明

## 概述

`.env` 中的敏感配置项（如 `DB_ENCRYPTION_KEY`、`LLM_API_KEY`、`SMTP_PASS`）支持 RSA-2048 非对称加密存储。公钥加密 → `{密文}` 贴入 `.env` → 启动时私钥自动解密。

## 工作原理

```
┌─ 发布者操作（一次性）────────────────────────────────────┐
│  gen-keys.js → config/public.pem (加密用，不发布)           │
│              → src/utils/secure-key.js (私钥混淆嵌入，发布)  │
│                                                           │
│  encrypt-config.js + public.pem → {密文} → 手动贴入 .env    │
└──────────────────────────────────────────────────────────┘

┌─ 运行时（自动，无感知）───────────────────────────────────┐
│  dotenv 加载 .env → 扫描 {base64} 值 → 私钥解密 → 明文使用  │
└──────────────────────────────────────────────────────────┘
```

## Step 1：生成密钥对

```bash
node scripts/gen-keys.js
```

输出：
- `config/public.pem` — 公钥，用于加密，**不提交到 git，不发布**
- `src/utils/secure-key.js` — 私钥混淆嵌入，**随代码发布**

## Step 2：加密敏感配置值

```bash
node scripts/encrypt-config.js "要加密的明文值"
```

示例：
```bash
# 加密数据库密钥
node scripts/encrypt-config.js "my-super-secret-db-key-12345"
# 输出: {eJw8TtGKG0cQ/JehL3nI/AbCd...}

# 加密 LLM API Key
node scripts/encrypt-config.js "sk-abc123def456..."
# 输出: {fK3mR7xP2qN9wL5oP8sT...}
```

限制：RSA-2048 最多加密 **190 字节**（约 190 个英文字符），超长值会被拒绝。

## Step 3：将密文填入 .env

```bash
# 密文用花括号包裹
DB_ENCRYPTION_KEY={eJw8TtGKG0cQ/JehL3nI/AbCd...}
LLM_API_KEY={fK3mR7xP2qN9wL5oP8sT...}
SMTP_PASS={aB4dE8fG1hJ3kM6nP0qR...}

# 不需要加密的值保持明文即可
LLM_MODEL=gpt-4
LANG=zh
```

支持写法：
- `KEY={xxx}` — 标准
- `KEY="{xxx}"` — 带引号（兼容不同 dotenv 版本）

## Step 4：启动

```bash
npm start
```

启动时自动解密，无需额外操作。如果 `.env.example` 中的 `{使用 scripts/encrypt-config.js 加密后填入}` 是说明文字（含中文，非 Base64 字符），不会被误解析。

## 加密值格式规范

- 以 `{` 开头、`}` 结尾
- 中间为 RSA-OAEP-SHA256 加密后的标准 Base64 字符串（仅含 `A-Za-z0-9+/=`）
- 不符合此格式的值原样保留，不参与解密

## 密钥轮换

1. 备份当前 `src/utils/secure-key.js`
2. 重新生成密钥对：`node scripts/gen-keys.js`
3. 用新公钥重新加密所有敏感值：`node scripts/encrypt-config.js "新值"`
4. 更新 `.env` 中所有 `{xxx}` 值
5. 测试启动

## 安全边界

| 场景 | 效果 |
|------|------|
| `.env` 文件单独泄露 | 无法解密（需要私钥），密文不可用 |
| `.env` + `secure-key.js` 同时泄露 | 可被解密，但私钥已混淆非明文 |
| 源码反编译 + 调试 | 可提取私钥，纯软件方案无法完全防御 |
| 发布后攻击者拿到 exe | 私钥在 SEA blob 中，需反编译才能提取 |

**本质**：防止 `.env` 单文件泄露导致密钥暴露，属于"防君子不防小人"级别的保护。

## 文件 git 管理

| 文件 | 是否提交 |
|------|:--:|
| `config/public.pem` | 不提交 |
| `src/utils/secure-key.js` | 提交（发布需要） |
| `.env` (含密文) | 不提交 |
| `.env.example` (说明模板) | 提交 |
