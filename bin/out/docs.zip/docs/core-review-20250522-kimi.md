# src/core/ 代码审查报告

**审查日期**: 2026-05-22
**审查范围**: `src/core/` 全部文件（含 `src/core/llm/` 子目录）
**语法检查**: 全部通过 (`node --check`)

---

## 审查文件清单

| 文件 | 说明 |
|------|------|
| `src/core/agent.js` | Agent 主编排类 |
| `src/core/agent-executor.js` | 执行循环与工具并行执行 |
| `src/core/message-utils.js` | 消息格式化与内容过滤 |
| `src/core/prompt-builder.js` | 系统提示构建 |
| `src/core/i18n.js` | 国际化翻译 |
| `src/core/llm.js` | LLM 子模块入口（re-export） |
| `src/core/llm/client.js` | LLMClient（含流式接口） |
| `src/core/llm/res-helper.js` | 响应校验与 thinking tag 清洗 |
| `src/core/llm/metrics.js` | Token 用量与成本统计 |
| `src/core/llm/pricing.js` | 定价策略 |
| `src/core/llm/summarize.js` | 上下文摘要 |

---

## 高优先级问题

### 1. agent-executor.js: 安全/错误消息硬编码中文，破坏英文模式

**位置**: `src/core/agent-executor.js:267-277`, `:585-586`, `:589`

**问题**: 以下三处错误提示直接硬编码中文，当 `LANG=en` 时用户仍收到中文：

- Fatal security 终止消息：
  ```javascript
  return `[Security Error] ${errorMsg}\n\n此操作触犯安全策略被阻断...`;
  ```
- `buildToolResponse` 中的安全策略提示：
  ```javascript
  content += "\n(安全策略限制，请尝试其他方式达成目标)";
  ```
- `buildToolResponse` 中的可重试提示：
  ```javascript
  content += "\n(此错误可重试)";
  ```

**修复建议**: 在 `src/core/i18n.js` 中新增对应翻译键（如 `errorSecurityFatal`、`errorSecurityBlocked`、`errorRetryable`），使用 `t()` 根据当前 locale 输出。

---

### 2. agent.js: `extractRecentContext` 遗漏纯 tool_calls 的 assistant 消息

**位置**: `src/core/agent.js:324-325`

**问题**: 提取最近上下文时，判断 assistant 消息有效性的条件为：

```javascript
messageHistory[j].role === "assistant" &&
messageHistory[j].content
```

当 assistant 仅发起 `tool_calls` 而无文本 `content` 时（非常常见），该轮对话被完全跳过。多轮工具密集型会话的上下文会断裂，影响指代消解和意图延续。

**修复建议**: 条件应允许 `tool_calls` 存在时也算作有效回复：

```javascript
messageHistory[j].role === "assistant" &&
(
  messageHistory[j].content ||
  messageHistory[j].tool_calls
)
```

---

### 3. agent-executor.js: 流式中断不取消底层 HTTP 请求

**位置**: `src/core/agent-executor.js:157-160`

**问题**: 当 executor 被 destroy 时，流式循环仅 `break`：

```javascript
for await (const event of streamHandle.stream) {
  if (this.isDestroyed) break;
}
```

生成器终止，但底层 HTTP 流仍在后台继续消费至结束，浪费带宽和 token。

**修复建议**: 在 `break` 前通过 `abortController` 触发取消信号，或至少让 `streamHandle.result` 以取消原因 settle。

---

## 中优先级问题

### 4. agent.js: `_summarizeAnswer` 与 `formatPair` 截断逻辑冗余

**位置**: `src/core/agent.js:275-292`, `:351-360`

**问题**: `_summarizeAnswer` 内部 catch 已返回 `smartTruncate` 结果，不会抛出。但 `formatPair` 在调用 `_summarizeAnswer` 时又包了一层 try-catch，失败后再做一次 `smartTruncate`。内层 catch 永不抛出，外层 catch 是死代码。

**修复建议**: 移除 `formatPair` 中对 `_summarizeAnswer` 的冗余 try-catch，直接赋值：

```javascript
answer = await this._summarizeAnswer(qa.user, answer);
```

---

### 5. llm/client.js: `chatStream` result promise 无意义包装

**位置**: `src/core/llm/client.js:386-390`

**问题**:

```javascript
result: resultPromise.catch((error) => {
  throw error;
}),
```

`.catch(...throw)` 是 no-op，仅增加一个微任务，无实际作用。

**修复建议**: 直接返回 `result: resultPromise`。

---

### 6. message-utils.js 与 res-helper.js 的 thinking tag 过滤重复

**位置**: `src/core/message-utils.js:26-27` 和 `src/core/llm/res-helper.js:58-95`

**问题**: `CONTENT_FILTERS` 和 `sanitizeThinkingTags` 都过滤 `<think>` / `<thinking>`。AgentExecutor 先用 `filterLLMContent` 过滤一次存入消息历史，LLMClient 的 `_rawChat` 再过滤一次返回内容。虽无害，但双重过滤增加维护负担，且两处 pattern 列表可能漂移。

**修复建议**: 保留 `res-helper.js`（更完整，含未闭合标签处理），`message-utils.js` 的 `CONTENT_FILTERS` 可移除 thinking 相关 pattern，仅保留项目特定的其他过滤规则。

---

## 低优先级 / 代码整洁

### 7. prompt-builder.js: `buildSandboxSection` 有未使用的参数

**位置**: `src/core/prompt-builder.js:12`

JSDoc 声明 `@param {Date} date`，但函数体未使用该参数。应移除参数或更新 JSDoc。

---

### 8. llm/metrics.js: `getUsageReport` 有未使用的参数

**位置**: `src/core/llm/metrics.js:53`

函数签名接受 `provider`，但函数体内未引用。可移除该参数以简化接口。

---

## 值得肯定的实现

| 位置 | 说明 |
|------|------|
| `agent-executor.js:33, 51-52` | `ownsAbortController` 模式正确处理外部传入的 AbortController，避免 chat.js 多轮复用时被误 abort |
| `agent-executor.js:296-298` | 流式中断时 `streamHandle.result.catch(() => {})` 防止 unhandled rejection |
| `agent-executor.js:76-80` | `checkAborted` 使用 `error.isAgentAbort = true` 做精确判别，替代脆弱的消息字符串匹配 |
| `res-helper.js:71-92` | 对截断输出中残留的开标签做安全清理，且用 `before !== cleaned` 防御空内容误删 |
| `agent-executor.js:552` | `Promise.allSettled` + `p-limit` 保证并发控制下任何单个工具失败不影响其他工具执行 |
| `llm/client.js:331-337, 456-465` | tool_call ID 缺失时生成 fallback UUID，避免多 tool_call 时 ID 碰撞导致对话错配 |
| `llm/summarize.js:99-100` | 同时发送 `max_tokens` 和 `max_completion_tokens`，兼容旧模型及 OpenAI o1/o3/o4+ |
