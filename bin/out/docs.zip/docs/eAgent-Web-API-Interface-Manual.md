# cospark-Runtime Gateway Web API 接口说明书

**版本**：v2.0.1  
**服务入口**：`http://<HOST>:<PORT>`（默认 `127.0.0.1:214`）  
**REST 基础路径**：`/api/v1`（同时保留 `/api` 兼容路径）  
**内部 OpenAPI 规范**：`docs/openapi.json`

---

## 1. 通用约定

### 1.1 认证方式

系统通过环境变量 `WEB_API_KEY` 控制认证开关：

- **未设置 `WEB_API_KEY`**：不启用认证（本地开发场景）。
- **已设置 `WEB_API_KEY`**：除公开接口外，所有 REST 与 WebSocket 请求都必须携带密钥。

支持以下两种方式传递：

| 位置 | 名称 | 示例 |
|------|------|------|
| Header | `X-API-Key` | `X-API-Key: your-api-key` |
| Query | `api_key` | `?api_key=your-api-key` |

公开接口（无需认证）：

- `POST /api/v1/auth/login`
- `GET /api/v1/files/download`
- `GET /api/v1/files/{id}/{filename}`

> 注意：`/api/v1/health` 在 `WEB_API_KEY` 启用后需要认证。

### 1.2 通用响应结构

**成功示例**（多数接口）：

```json
{
  "success": true,
  "data": { ... }
}
```

**成功示例**（列表类接口）：

```json
{
  "sessions": [ ... ],
  "total": 42
}
```

**错误示例**（`sendError` 生成）：

```json
{
  "success": false,
  "error": {
    "code": "NotFound",
    "message": "会话不存在"
  }
}
```

> 注意：`/api/v1/health` 等特殊接口直接返回 `{ status, timestamp }`，没有 `success` 包装。全局错误处理中间件产生的 5xx 错误格式为 `{ error, message }`。

### 1.3 通用 HTTP 状态码

| 状态码 | 含义 |
|--------|------|
| 200 | 成功 |
| 201 | 创建成功 |
| 204 | 成功且无返回体 |
| 400 | 请求参数无效 |
| 401 | 认证失败 |
| 403 | 权限/安全拒绝 |
| 404 | 资源不存在 |
| 429 | 请求过于频繁 |
| 500 | 服务器内部错误 |
| 502/504 | 网络/超时错误（`/open` 等工具代理场景） |

---

## 2. REST API 接口

### 2.1 Auth（认证）

#### POST `/api/v1/auth/login`

验证用户名密码并返回 `apiKey`。

**请求体**：

```json
{
  "username": "admin",
  "password": "coqi@2026"
}
```

> 默认用户名/密码可通过 `WEB_LOGIN_USERNAME` / `WEB_LOGIN_PASSWORD` 覆盖。

**响应 200**：

```json
{
  "success": true,
  "data": {
    "apiKey": "your-api-key"
  }
}
```

**响应 400**：

```json
{
  "success": false,
  "error": { "code": "ValidationError", "message": "用户名和密码必填" }
}
```

**响应 401**：用户名或密码错误。  
**响应 429**：同一 IP 登录过于频繁（每 60 秒最多 5 次）。

---

### 2.2 System（系统）

#### GET `/api/v1/health`

健康检查。

**响应 200**：

```json
{
  "status": "ok",
  "timestamp": 1751280000000
}
```

---

#### GET `/api/v1/version`

获取系统版本号，数据来自 `package.json`。

**响应 200**：

```json
{
  "version": "2.0.1"
}
```

---

#### GET `/api/v1/system-info`

获取当前服务器的系统信息（OS、内存、CPU、地理位置等）。

实现复用 `src/tools/system-info.js`，身份/网络字段默认脱敏；开启完整输出需设置环境变量 `ENABLE_SENSITIVE_SYSTEM_INFO=true`。

**查询参数**：

| 参数 | 类型 | 说明 |
|------|------|------|
| `include` | string | 可选，逗号分隔。支持：`hostname`、`user`、`os`、`network`、`location`、`all`。默认 `all` |

**响应 200**：

```json
{
  "os": {
    "platform": "win32",
    "type": "Windows_NT",
    "release": "10.0.22621",
    "arch": "x64",
    "uptime": "12 hours",
    "totalMemory": "32 GB",
    "freeMemory": "16 GB",
    "cpuCount": 16
  },
  "location": {
    "country": "China",
    "city": "Beijing",
    "timezone": "Asia/Shanghai"
  },
  "timestamp": "2026-06-30T12:00:00.000Z"
}
```

> 若 `ENABLE_SENSITIVE_SYSTEM_INFO=true`，响应还会包含 `hostname`、`user`、`network.localIPs`、`network.publicIP` 等字段。

**响应 400**：`include` 包含无效值。

---

#### POST `/api/v1/upload`

上传单个文件到沙箱 `user/upload/` 目录。

**请求头**：

```
Content-Type: multipart/form-data
```

**表单字段**：

| 字段 | 类型 | 说明 |
|------|------|------|
| `file` | File | 要上传的文件，仅支持 1 个 |

**限制**：

- 单文件最大 **10 MB**
- 单次请求总大小最大 **30 MB**
- 仅允许白名单扩展名（文档、数据、图片、压缩包、代码等）

**响应 200**：

```json
{
  "success": true,
  "data": {
    "name": "example.pdf",
    "serverPath": "user/upload/example.pdf",
    "size": 102400
  }
}
```

**响应 400**：未提供文件、类型不支持、文件头与扩展名不匹配、路径不合法。

---

#### GET `/api/v1/files/download`

下载沙箱内的文件（兼容旧版 query 参数）。

**查询参数**：

| 参数 | 类型 | 说明 |
|------|------|------|
| `path` | string | 相对路径，例如 `output/skill-xxx/report.xlsx` |

**限制**：

- 必须是相对路径，禁止绝对路径
- 必须位于沙箱允许目录内（`output/`、`user/`、`database/` 等）

**响应 200**：文件流，`Content-Disposition: attachment`。  
**响应 400**：`path` 缺失或无效。  
**响应 403**：路径越界。  
**响应 404**：文件不存在。

---

#### GET `/api/v1/files/{id}/{filename}`

RESTful 风格下载沙箱内的文件。

**路径参数**：

| 参数 | 类型 | 说明 |
|------|------|------|
| `id` | string | 文件所在相对目录，URL 编码。例如 `output%2Fskill-xxx` 或 `user%2Fupload` |
| `filename` | string | 文件名，URL 编码 |

**示例**：

```
GET /api/v1/files/output%2Fskill-xxx/biz-trip-flowchart-v2.png
```

**限制**：

- 禁止路径遍历（`..`）和绝对路径
- 必须位于沙箱允许目录内

**响应 200**：文件流，`Content-Disposition: attachment`。  
**响应 400**：路径参数无效。  
**响应 403**：路径越界。  
**响应 404**：文件不存在。

---

#### POST `/api/v1/open`

使用系统默认程序打开沙箱文件或外部 URL。

**请求体**：

```json
{
  "path": "output/report.xlsx"
}
```

**响应 200**：

```json
{
  "success": true,
  "message": "已打开"
}
```

**错误映射**：

| 工具错误类型 | HTTP 状态码 |
|--------------|-------------|
| `validation` | 400 |
| `not_found` | 404 |
| `permission` / `security` | 403 |
| `network` | 502 |
| `timeout` | 504 |
| 其他 | 500 |

---

### 2.3 Sessions（会话）

#### GET `/api/v1/sessions`

获取会话列表。

**查询参数**：

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `limit` | integer | 50 | 最大 100 |
| `offset` | integer | 0 | 分页偏移 |
| `status` | string | `active` | 状态过滤 |
| `search` | string | - | 按标题或 ID 搜索，最多 100 字符 |
| `assistantId` | string | - | 按助手 ID 过滤会话；与 `search` 可组合使用 |

**响应 200**：

```json
{
  "sessions": [ { ...Session... } ],
  "total": 42
}
```

---

#### POST `/api/v1/sessions`

创建新会话。

**请求体**（可选）：

```json
{
  "title": "未命名会话",
  "assistantId": "ib-banker",
  "status": "active",
  "metadata": { "source": "web" }
}
```

> 仅允许字段：`title`、`assistantId`、`status`、`metadata`。
> 传入 `assistantId` 时，服务端会校验该助手是否存在；不存在则返回 `400 ValidationError`。

**响应 201**：返回创建的 `Session` 对象。

**响应 400**：请求体含非法字段，或指定的 `assistantId` 不存在。

---

#### GET `/api/v1/sessions/{id}`

获取会话详情。

**响应 200**：`Session` 对象。  
**响应 404**：会话不存在。

---

#### PATCH `/api/v1/sessions/{id}`

更新会话（重命名、修改状态、更换助手等）。

**请求体**：

```json
{
  "title": "新标题",
  "status": "archived",
  "assistantId": "ib-banker"
}
```

> 允许字段：`title`、`status`、`assistantId`、`metadata`。
> 传入 `assistantId` 时，服务端会校验该助手是否存在；不存在则返回 `400 ValidationError`。

**响应 200**：更新后的 `Session` 对象。  
**响应 400**：请求体含非法字段，或指定的 `assistantId` 不存在。  
**响应 404**：会话不存在或无需更新。

---

#### DELETE `/api/v1/sessions/{id}`

删除会话（软删除）。

**响应 204**：无返回体。  
**响应 404**：会话不存在。

---

#### GET `/api/v1/sessions/{id}/messages`

获取会话消息列表。

**查询参数**：

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `limit` | integer | 50 | 最大 100 |
| `offset` | integer | 0 | 分页偏移 |

**响应 200**：

```json
{
  "messages": [ { ...Message... } ]
}
```

> 消息按 `created_at ASC` 排序。

---

#### DELETE `/api/v1/sessions/{id}/messages`

清空会话消息。

**响应 204**：无返回体。  
**响应 404**：会话不存在。

---

### 2.4 Assistants（助手）

#### GET `/api/v1/assistants`

获取所有可用助手配置。

**响应 200**：

```json
{
  "assistants": [ { ...Assistant... } ]
}
```

---

### 2.5 User（用户）

#### GET `/api/v1/user`

获取当前默认用户信息。

**响应 200**：`User` 对象；若不存在则返回：

```json
{
  "id": "default",
  "name": null,
  "role": null,
  "preferences": null
}
```

---

#### PATCH `/api/v1/user`

更新用户信息。

**请求体**：

```json
{
  "name": "张三",
  "role": "分析师",
  "preferences": {
    "assistantId": "ib-banker"
  }
}
```

**响应 200**：更新后的 `User` 对象。

---

### 2.6 Config（运行时配置）

运行时配置管理接口，操作对象来自 `config/env-config-schema.json` 定义的环境变量集合。在企业/金融等 Guarded 场景下，安全相关字段的修改会被限制。

---

#### GET `/api/v1/config`

获取当前运行时配置。

**响应 200**：

```json
{
  "LLM_PROVIDER": "custom",
  "LLM_MODEL": "your-model-id",
  "LLM_BASE_URL": "https://api.xxx.com/v1",
  "COQI_SCENE": "personal",
  "LOG_LEVEL": "info",
  "...": "..."
}
```

> 具体字段取决于当前 `.env` 与场景预设的合并结果。

---

#### POST `/api/v1/config/schema`

获取环境变量 schema（支持从远程 URL 拉取）。

**请求体**：

```json
{
  "url": "https://example.com/env-config-schema.json",
  "token": "optional-access-token"
}
```

> `url` 与 `token` 均为可选；不传则使用内置 schema。

**响应 200**：

```json
{
  "schema": {
    "properties": { ... },
    "required": [ ... ]
  }
}
```

---

#### PATCH `/api/v1/config`

应用配置变更。

**请求头**：

| 名称 | 说明 |
|------|------|
| `If-Match` | 可选，上一次获取配置时的 `envHash`，用于并发冲突检测 |

**请求体**：

```json
{
  "changes": {
    "LLM_MODEL": "new-model-id",
    "LOG_LEVEL": "debug"
  }
}
```

**响应 200**：

```json
{
  "success": true,
  "changes": {
    "LLM_MODEL": "new-model-id",
    "LOG_LEVEL": "debug"
  },
  "envHash": "sha256-hash"
}
```

**响应 400**：`changes` 不是对象。  
**响应 409**：`If-Match` 与服务端当前 `envHash` 不一致（并发冲突）。  
**响应 500**：应用失败。

> Guarded 场景下，安全相关键（如 `SANDBOX_MODE`、`EXEC_MODE`、`DISABLED_TOOLS` 等）不允许通过此接口修改。

---

#### POST `/api/v1/config/remote`

从远程 URL 拉取配置并应用到运行时。

**请求体**：

```json
{
  "url": "https://example.com/config.json",
  "token": "optional-access-token"
}
```

**响应 200**：

```json
{
  "success": true,
  "changes": { ... }
}
```

**响应 400**：未提供远程 URL。  
**响应 500**：拉取或应用失败。

---

#### POST `/api/v1/config/initialize`

初始化指定模块。

**请求体**：

```json
{
  "moduleId": "llm"
}
```

**响应 200**：

```json
{
  "success": true,
  "moduleId": "llm",
  "state": "running"
}
```

**响应 400**：`moduleId` 缺失。  
**响应 500**：模块初始化失败。

---

#### POST `/api/v1/config/validate`

验证指定模块的连通性。当前主要用于验证 LLM 配置是否可用：临时注入请求中的环境变量，创建 `LLMClient` 并发送最小请求。

**请求体**：

```json
{
  "moduleId": "llm",
  "values": {
    "LLM_MODEL": "test-model",
    "LLM_API_KEY": "test-key",
    "LLM_BASE_URL": "https://api.xxx.com/v1"
  }
}
```

**响应 200**：

```json
{
  "success": true,
  "moduleId": "llm"
}
```

**响应 400**：`moduleId` 或 `values` 参数无效。  
**响应 502/504**：网络错误/超时。  
**响应 500**：其他内部错误。

---

#### POST `/api/v1/config/reset`

将指定配置项恢复为默认值。

**请求体**：

```json
{
  "keys": ["LLM_MODEL", "LOG_LEVEL"]
}
```

**响应 200**：

```json
{
  "success": true,
  "reset": ["LLM_MODEL", "LOG_LEVEL"]
}
```

**响应 400**：`keys` 不是数组。  
**响应 500**：重置失败。

> Guarded 场景下，安全相关键不允许重置。

---

#### POST `/api/v1/config/reload`

清除所有配置缓存，从磁盘重新加载 schema 和配置。

**响应 200**：

```json
{
  "success": true,
  "config": { ... }
}
```

**响应 502**：刷新 schema 失败。  
**响应 500**：其他内部错误。

---

## 3. 数据模型

### Session

| 字段 | 类型 | 说明 |
|------|------|------|
| `id` | string | 会话唯一 ID，例如 `sess_xxx` |
| `title` | string \| null | 会话标题 |
| `status` | string | 状态，如 `active`、`archived` |
| `model` | string \| null | 当前使用的 LLM 模型 |
| `userId` | string | 用户 ID，默认 `default` |
| `assistantId` | string | 绑定的助手 ID |
| `createdAt` | integer | 创建时间戳（毫秒） |
| `updatedAt` | integer | 最后更新时间戳（毫秒） |
| `messageCount` | integer | 消息数量 |
| `metadata` | object \| null | 自定义元数据 |
| `deletedAt` | integer \| null | 删除时间戳（软删除） |

### Message

| 字段 | 类型 | 说明 |
|------|------|------|
| `id` | integer | 消息自增 ID |
| `sessionId` | string | 所属会话 ID |
| `role` | string | `user` / `assistant` / `system` / `tool` |
| `content` | string | 消息内容 |
| `toolCalls` | object \| null | 工具调用结构 |
| `toolCallId` | string \| null | 关联的工具调用 ID |
| `createdAt` | integer | 创建时间戳（毫秒） |

### Assistant

| 字段 | 类型 | 说明 |
|------|------|------|
| `id` | string | 助手 ID |
| `name` | string | 助手名称 |
| `personality` | string \| null | 性格描述 |
| `expertise` | string \| null | 专业领域 |
| `systemPromptTemplate` | string \| null | 系统提示模板 |
| `isDefault` | boolean | 是否为默认助手 |
| `createdAt` | integer | 创建时间戳 |

### User

| 字段 | 类型 | 说明 |
|------|------|------|
| `id` | string | 用户 ID |
| `name` | string \| null | 用户名 |
| `role` | string \| null | 角色 |
| `preferences` | object \| null | 偏好设置，可包含 `assistantId` |
| `createdAt` | integer | 创建时间戳 |
| `updatedAt` | integer | 更新时间戳 |

---

## 4. WebSocket 聊天协议

WebSocket 与 HTTP 服务共享端口，连接地址为：

```
ws://<HOST>:<PORT>
```

### 4.1 认证

- 若 `WEB_API_KEY` 未设置，直接连接。
- 若已设置，客户端需在连接时通过 `X-API-Key` Header 或 `?api_key=...` 查询参数传递密钥。
- 认证失败时，服务端会发送 `ERROR` 帧并关闭连接（close code `1008`）。

### 4.2 心跳机制

- 服务端每 **30 秒**发送一次 `ping` 帧。
- 若 **60 秒内**未收到任何客户端消息或 `pong` 响应，服务端将强制断开连接。
- 客户端可通过发送 `{ "type": "ping" }` 刷新存活时间。

### 4.3 消息信封

所有 WebSocket 消息均为 JSON 对象：

```json
{
  "type": "chat",
  "payload": { ... }
}
```

- `type`：消息类型（必填）
- `payload`：消息载荷（类型相关）

---

### 4.4 客户端 → 服务端

#### `chat`

发送一条聊天消息。

**payload**：

```json
{
  "sessionId": "sess_xxx",
  "content": "请帮我生成一份财报分析"
}
```

**字段约束**：

| 字段 | 类型 | 约束 |
|------|------|------|
| `sessionId` | string | 必填 |
| `content` | string | 必填；默认不超过 `INPUT_ENFORCE_LIMIT`（默认 1500）字符；整体消息不超过 1 MB |

**并发限制**：每个 WebSocket 连接同时只能处理一个 `chat` 请求；若当前请求未完成，服务端返回 `ERROR`。

---

#### `cancel`

取消当前正在处理的 `chat` 请求。

```json
{
  "type": "cancel"
}
```

---

#### `ping`

心跳/保活。

```json
{
  "type": "ping"
}
```

---

### 4.5 服务端 → 客户端

#### `connected`

连接成功后立即发送。

```json
{
  "type": "connected",
  "payload": {
    "connectionId": "conn_1"
  }
}
```

---

#### `pong`

对 `ping` 的响应。

```json
{
  "type": "pong",
  "payload": {}
}
```

---

#### `progress`

Agent 执行进度通知。

```json
{
  "type": "progress",
  "payload": {
    "phase": "thinking",
    "current": 1,
    "total": 3,
    "tools": ["read", "exec"],
    "toolCount": 2,
    "size": 1024
  }
}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| `phase` | string | 当前阶段，如 `thinking`、`executing_tools` |
| `current` | integer | 当前步数 |
| `total` | integer | 总步数 |
| `tools` | string[] \| null | 涉及的工具名列表 |
| `toolCount` | integer \| null | 工具数量 |
| `size` | integer \| null | 消息大小等辅助信息 |

---

#### `tool_call`

工具调用通知。

```json
{
  "type": "tool_call",
  "payload": {
    "sessionId": "sess_xxx",
    "id": "call_123",
    "name": "read",
    "arguments": { "path": "output/report.xlsx" }
  }
}
```

---

#### `tool_result`

工具执行结果。

```json
{
  "type": "tool_result",
  "payload": {
    "sessionId": "sess_xxx",
    "toolCallId": "call_123",
    "name": "read",
    "success": true,
    "content": "...工具返回内容...",
    "producedFiles": ["output/skill-xxx/file.xlsx"]
  }
}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| `toolCallId` | string | 对应 `tool_call.id` |
| `success` | boolean | 是否成功 |
| `content` | string | 工具返回文本 |
| `producedFiles` | string[] | 产生的文件相对路径（如有），可用于 `/api/v1/files/download` |

---

#### `assistant_message`

助手生成的内容片段（流式返回）。

```json
{
  "type": "assistant_message",
  "payload": {
    "sessionId": "sess_xxx",
    "content": "这是一个流式片段",
    "type": "content",
    "iteration": 1
  }
}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| `content` | string | 内容片段 |
| `type` | string | `content`（可见内容）或 `reasoning`（推理内容） |
| `iteration` | integer \| null | 当前 Agent 循环轮次 |

> 服务端会自动剥离 `<thinking>...</thinking>` 标签内容。

---

#### `complete`

当前请求处理完成。

```json
{
  "type": "complete",
  "payload": {
    "sessionId": "sess_xxx",
    "result": "完整的助手回复",
    "durationMs": 3200
  }
}
```

---

#### `error`

通用错误通知。

```json
{
  "type": "error",
  "payload": {
    "sessionId": "sess_xxx",
    "message": "处理失败",
    "durationMs": 1200
  }
}
```

---

#### `aborted`

请求被取消。

```json
{
  "type": "aborted",
  "payload": {
    "sessionId": "sess_xxx",
    "reason": "用户取消",
    "durationMs": 800
  }
}
```

---

#### `audit_block`

审计拦截。

```json
{
  "type": "audit_block",
  "payload": {
    "sessionId": "sess_xxx",
    "category": "data_exfiltration",
    "categoryName": "数据外泄",
    "reason": "检测到敏感数据导出意图",
    "confidence": 0.92
  }
}
```

---

#### `audit_warning`

审计警告（不阻断）。

```json
{
  "type": "audit_warning",
  "payload": {
    "sessionId": "sess_xxx",
    "category": "resource_abuse",
    "categoryName": "资源滥用",
    "warningMessage": "该请求可能消耗大量资源"
  }
}
```

---

#### `session_updated`

会话元数据更新（目前主要用于自动标题生成，未来可能扩展助手变更）。

```json
{
  "type": "session_updated",
  "payload": {
    "sessionId": "sess_xxx",
    "title": "财报分析请求",
    "assistantId": "ib-banker"
  }
}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| `sessionId` | string | 会话 ID |
| `title` | string \| undefined | 更新后的标题（如有） |
| `assistantId` | string \| undefined | 更新后的助手 ID（如有） |

---

## 5. 典型 WebSocket 聊天流程

```text
Client                                    Server
  |  Connect (with X-API-Key)               |
  |---------------------------------------->|
  |            { type: "connected", ... }   |
  |<----------------------------------------|
  |  { type: "chat", payload: {...} }       |
  |---------------------------------------->|
  |            { type: "progress", ... }    |
  |<----------------------------------------|
  |            { type: "tool_call", ... }   |
  |<----------------------------------------|
  |            { type: "tool_result", ... } |
  |<----------------------------------------|
  |            { type: "assistant_message", ... } xN
  |<----------------------------------------|
  |            { type: "complete", ... }    |
  |<----------------------------------------|
```

---

## 6. 附录：影响接口行为的环境变量

| 环境变量 | 默认值 | 影响 |
|----------|--------|------|
| `WEB_PORT` | `3000` | HTTP/WebSocket 端口 |
| `WEB_HOST` | `127.0.0.1` | 监听地址 |
| `WEB_API_KEY` | - | API Key 认证密钥 |
| `WEB_LOGIN_USERNAME` | `admin` | 登录用户名 |
| `WEB_LOGIN_PASSWORD` | `coqi@2026` | 登录密码 |
| `INPUT_ENFORCE_LIMIT` | `1500` | WebSocket 单条消息最大字符数 |
| `MAX_MESSAGES_SIZE` | `300000` | 会话上下文大小限制（字节） |
| `MAX_SINGLE_MESSAGE_SIZE` | `20000` | 单条工具返回值截断长度 |
| `ENABLE_AUDIT` | `false` | 是否启用审计审查 |
| `AUDIT_LLM_*` | - | 审计 LLM 独立配置 |
