# 会话上下文管理重构设计

## Context

用户报告会话上下文记不住上一次对话的现象。环境变量 `KEEP_LAST_EXCHANGES=15` 设置后不起作用。

经过代码审查，发现核心问题是参数混乱和双重截断。用户同意简化方向：**移除 `MAX_MESSAGES` 变量，统一使用 `KEEP_LAST_EXCHANGES`，保留 U 型设计优点并改进摘要功能**。

## Design Goals

1. **单一参数**：用户只需设置 `KEEP_LAST_EXCHANGES`，效果可预测
2. **U 型保留**：首轮（意图）+ 最近 N-1 轮（上下文）
3. **智能摘要**：中间省略部分生成摘要，保留关键信息
4. **避免双重截断**：统一在 `ContextManager` 中处理

## Architecture

### 简化后的数据流

```
┌─────────────────────────────────────────────────────────────────┐
│                      SQLite messages 表                          │
│  (role: user/assistant/tool, 按 created_at 排序)                │
└───────────────────────────┬─────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│  ContextManager.buildContext()                                   │
│  ┌─────────────────────────────────────────────────────────────┐ │
│  │  1. 计算总轮次 totalRounds                                    │ │
│  │  2. 若 totalRounds <= keepLastExchanges: 返回全部            │ │
│  │  3. 否则：U 型截断 + 摘要                                     │ │
│  │     - headRounds: 1 (首轮意图)                               │ │
│  │     - tailRounds: keepLastExchanges - 1 (最近上下文)         │ │
│  │     - middleRounds: 生成摘要                                 │ │
│  └─────────────────────────────────────────────────────────────┘ │
└───────────────────────────┬─────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│  Agent.runWithHistory()                                          │
│  - 添加 system prompt                                            │
│  - 添加当前 user message                                          │
│  - 不再调用 truncateMessages() (已移除)                          │
└───────────────────────────┬─────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│  AgentExecutor.execute()                                         │
│  - 检查 MAX_MESSAGES_SIZE (兜底，防止超出 LLM token 限制)         │
│  - 仅在超出大小时触发激进截断                                     │
└─────────────────────────────────────────────────────────────────┘
```

### U 型上下文结构

```
┌─────────────────────────────────────────────────────────────────┐
│  第1轮（意图）        [摘要]           最近N-1轮（上下文）         │
│  ┌─────────────┐   ┌─────────────┐   ┌─────────────┐           │
│  │ 用户：分析   │   │ [中间轮次   │   │ 用户：继续   │           │
│  │ 这个财报... │   │  摘要：     │   │ 助手：好的   │           │
│  │ 助手：好的   │   │  分析了X张表│   │ ...         │           │
│  └─────────────┘   │  发现营收...│   └─────────────┘           │
│                    └─────────────┘                             │
│                                                                  │
│  KEEP_LAST_EXCHANGES=15 时：                                     │
│  - 第1轮：完整保留                                               │
│  - 第2-?轮：生成摘要                                             │
│  - 最近14轮：完整保留                                            │
└─────────────────────────────────────────────────────────────────┘
```

## Implementation Details

### 1. 新增：SQL 统计轮次方法

**文件**: `src/sessions/manager.js`

一轮对话以 `user` 消息开始，所以 **轮次数 = user 消息数**。

```javascript
/**
 * 获取会话的对话轮次数
 * 一轮对话以 user 消息开始，所以轮次数 = user 消息数
 * O(1) 复杂度，利用索引
 * @param {string} sessionId - 会话 ID
 * @returns {number} 对话轮次数
 */
getRoundCount(sessionId) {
    const stmt = this.db.prepare(`
        SELECT COUNT(*) as count 
        FROM messages 
        WHERE session_id = @sessionId AND role = 'user'
    `);
    const row = stmt.get({ sessionId });
    return row.count;
}
```

### 2. 新增：按轮次查询消息的方法

**文件**: `src/sessions/manager.js`

新增 `getMessagesByRounds(sessionId, options)` 方法，支持按对话轮次进行 U 型查询：

```javascript
/**
 * 按对话轮次进行 U 型查询
 * @param {string} sessionId - 会话 ID
 * @param {Object} options
 * @param {number} options.headRounds - 保留的首部轮次数（意图）
 * @param {number} options.tailRounds - 保留的尾部轮次数（上下文）
 * @returns {{ head: Array, tail: Array, middle: Array, totalRounds: number }}
 */
getMessagesByRounds(sessionId, options = {}) {
    const { headRounds = 1, tailRounds = 10 } = options;

    // 1. 获取所有消息
    const allMessages = this.getMessages(sessionId, { order: 'asc' });

    // 2. 按轮次分组（一轮 = user 开始到下一个 user 之前）
    const rounds = this.groupMessagesByRounds(allMessages);
    const totalRounds = rounds.length;

    // 3. 短对话：全部返回
    if (totalRounds <= headRounds + tailRounds) {
        return {
            head: rounds,
            middle: [],
            tail: [],
            totalRounds,
            needsSummary: false
        };
    }

    // 4. U 型分割
    const head = rounds.slice(0, headRounds);
    const tail = rounds.slice(-tailRounds);
    const middle = rounds.slice(headRounds, -tailRounds);

    return { head, middle, tail, totalRounds, needsSummary: true };
}

/**
 * 将消息按对话轮次分组
 * 每轮以 user 消息开始，包含后续的 assistant/tool 消息
 */
groupMessagesByRounds(messages) {
    const rounds = [];
    let currentRound = null;

    for (const msg of messages) {
        if (msg.role === 'user') {
            // 新轮次开始
            if (currentRound) rounds.push(currentRound);
            currentRound = { messages: [msg] };
        } else if (currentRound) {
            // 添加到当前轮次
            currentRound.messages.push(msg);
        }
    }

    if (currentRound) rounds.push(currentRound);
    return rounds;
}
```

### 3. 重构：ContextManager.buildContext()

**文件**: `src/sessions/context-manager.js`

简化逻辑，统一处理 U 型截断和摘要：

```javascript
/**
 * 构建上下文（U 型保留 + 摘要）
 */
async buildContext(sessionManager, sessionId) {
    const keepRounds = this.keepLastExchanges;

    // 1. 先用 O(1) 查询判断是否需要截断
    const totalRounds = sessionManager.getRoundCount(sessionId);

    // 2. 短对话：直接返回全部消息（快速路径）
    if (totalRounds <= keepRounds) {
        const messages = sessionManager.getMessages(sessionId, { order: 'asc' });
        logger.debug('Context built (full)', { totalRounds });
        return this.formatMessages(messages);
    }

    // 3. 需要截断：按轮次 U 型查询
    const { head, middle, tail } = sessionManager.getMessagesByRounds(sessionId, {
        headRounds: 1,
        tailRounds: keepRounds - 1
    });

    // 4. U 型：首部 + 摘要 + 尾部
    const result = [];

    // 4.1 首部（首轮意图）
    result.push(...head.flatMap(r => r.messages));

    // 4.2 中间摘要
    const summary = await this.generateSummary(middle);
    if (summary) {
        result.push({
            role: 'system',
            content: `[中间轮次摘要（${middle.length}轮已省略）：${summary}]`
        });
    }

    // 4.3 尾部（最近上下文）
    result.push(...tail.flatMap(r => r.messages));

    logger.info('Context built (U-shape)', {
        totalRounds,
        headRounds: head.length,
        middleRounds: middle.length,
        tailRounds: tail.length
    });

    return this.formatMessages(result);
}

/**
 * 生成中间轮次摘要
 */
async generateSummary(middleRounds) {
    if (middleRounds.length === 0) return null;

    // 使用 LLM 摘要（如果启用且有客户端）
    if (this.useLlmSummary && this.llmClient) {
        try {
            const summary = await this.llmClient.summarizeConversation(
                middleRounds,
                { maxLength: this.summaryMaxLength },
                this.abortSignal
            );

            logger.info('Conversation summary generated', {
                roundsCount: middleRounds.length,
                summaryLength: summary.length
            });

            return summary;
        } catch (error) {
            logger.warn('LLM conversation summary failed, using fallback', {
                error: error.message
            });
        }
    }

    // Fallback：关键词提取
    return this.generateKeywordSummary(middleRounds);
}

/**
 * Fallback：关键词摘要
 */
generateKeywordSummary(rounds, maxLength = 300) {
    const keywords = rounds.slice(0, 5).map((round, i) => {
        const userMsg = round.messages.find(m => m.role === 'user');
        const assistantMsg = round.messages.find(m =>
            m.role === 'assistant' && !m.tool_calls
        );

        const q = userMsg?.content?.substring(0, 40) || '';
        const a = assistantMsg?.content?.substring(0, 60) || '';

        return a ? `#${i + 1} "${q}"→"${a}"` : `#${i + 1} "${q}"`;
    });

    let summary = keywords.join('；');

    if (rounds.length > 5) {
        summary += ` ...(共${rounds.length}轮)`;
    }

    // 确保不超过最大长度
    if (summary.length > maxLength) {
        summary = summary.substring(0, maxLength - 10) + '...';
    }

    return summary;
}
```

### 8. 新增：对话摘要方法

**文件**: `src/core/llm.js`

新增 `summarizeConversation()` 方法，专门用于多轮对话的中间轮次摘要。与现有的 `summarize()` 方法（用于技能匹配意图分析）分离。

```javascript
/**
 * 对话历史摘要（用于上下文压缩）
 * 专门用于多轮对话的中间轮次摘要
 * @param {Array} rounds - 轮次数组，每轮包含 { messages: [...] }
 * @param {Object} options - 配置选项
 * @param {number} options.maxLength - 摘要最大长度，默认 300
 * @param {string} options.focus - 摘要焦点（如"关键决策"、"执行过程"）
 * @param {AbortSignal} signal - 取消信号
 * @returns {Promise<string>} 摘要文本
 */
async summarizeConversation(rounds, options = {}, signal = null) {
    const { maxLength = 300, focus = null } = options;

    if (!rounds || rounds.length === 0) {
        return '';
    }

    // 格式化轮次信息
    const formattedRounds = this.formatConversationRounds(rounds, 2000);

    if (formattedRounds.length === 0) {
        return '';
    }

    // 构建 prompt
    const systemPrompt = focus
        ? `你是一个对话摘要助手。请总结以下对话的关键${focus}，控制在${maxLength}字以内。直接输出摘要，不要添加前缀。`
        : `你是一个对话摘要助手。请总结以下对话的关键内容和结论，控制在${maxLength}字以内。直接输出摘要，不要添加前缀。`;

    const userPrompt = `以下是对话历史（共${rounds.length}轮）：\n\n${formattedRounds}\n\n请总结关键内容：`;

    try {
        const requestOptions = {
            model: this.model,
            messages: [
                { role: 'system', content: systemPrompt },
                { role: 'user', content: userPrompt }
            ],
            temperature: 0.1,
            max_tokens: Math.ceil(maxLength * 1.5)
        };

        const response = await this.client.chat.completions.create(requestOptions);

        if (!response?.choices?.[0]?.message?.content) {
            throw new Error('Invalid response from LLM');
        }

        const summary = response.choices[0].message.content.trim();

        if (response.usage) {
            this.recordUsage(response.usage);
        }

        logger.debug('Conversation summarized', {
            roundsCount: rounds.length,
            inputLength: formattedRounds.length,
            outputLength: summary.length
        });

        return summary;
    } catch (error) {
        logger.error('Conversation summarization failed', { error: error.message });
        throw error;
    }
}

/**
 * 格式化对话轮次用于摘要
 * @param {Array} rounds - 轮次数组
 * @param {number} maxLength - 最大长度
 * @returns {string} 格式化后的文本
 */
formatConversationRounds(rounds, maxLength) {
    const quotaPerRound = Math.floor(maxLength / rounds.length);

    const lines = rounds.map((round, i) => {
        const userMsg = round.messages?.find(m => m.role === 'user');
        const assistantMsg = round.messages?.find(m =>
            m.role === 'assistant' && !m.tool_calls
        );

        const q = this.truncateAtSentence(userMsg?.content, Math.floor(quotaPerRound * 0.4));
        const a = this.truncateAtSentence(assistantMsg?.content, Math.floor(quotaPerRound * 0.6));

        if (q && a) {
            return `[${i + 1}] 用户：${q}\n    助手：${a}`;
        } else if (q) {
            return `[${i + 1}] 用户：${q}`;
        }
        return null;
    }).filter(Boolean);

    return lines.join('\n');
}

/**
 * 在句子边界截断
 */
truncateAtSentence(text, maxLength) {
    if (!text || text.length <= maxLength) return text || '';

    const truncated = text.substring(0, maxLength);
    const lastPunctuation = Math.max(
        truncated.lastIndexOf('。'),
        truncated.lastIndexOf('！'),
        truncated.lastIndexOf('？'),
        truncated.lastIndexOf('.'),
        truncated.lastIndexOf('!')
    );

    if (lastPunctuation > maxLength * 0.6) {
        return truncated.substring(0, lastPunctuation + 1);
    }

    return truncated.substring(0, maxLength - 3) + '...';
}
```

**方法对比**：

| 方法 | 用途 | 输入 | 特点 |
|------|------|------|------|
| `summarize()` | 技能匹配意图分析 | 单段文本 | 通用文本摘要 |
| `summarizeConversation()` | 上下文压缩 | 轮次数组 | 保留对话结构，支持焦点 |

**文件**: `src/core/agent.js`

- 移除 `truncateMessages()` 方法
- 移除 `_summarizeTruncatedHistory()` 方法
- `runWithHistory()` 中不再调用截断逻辑

```javascript
async runWithHistory(userInput, messageHistory = [], options = {}) {
    // ... 技能匹配逻辑 ...

    // 直接使用 messageHistory，不再截断
    let messages = [
        { role: 'system', content: systemPrompt },
        ...messageHistory.filter(m => m.role !== 'system'),
        { role: 'user', content: userInput }
    ];

    // 书挡策略（保留）
    // ...

    // 移除预判摘要逻辑（已在 ContextManager 中处理）

    return await executor.execute(messages);
}
```

### 4. 移除：MAX_MESSAGES 变量

**文件**: `src/tui/constants.js`

```javascript
// 修改前
export const CONFIG = {
    INTERRUPT_COOLDOWN: 5000,
    MAX_MESSAGES: envConfig.keepLastExchanges * 2,  // 移除
    PRESERVE_FIRST_N: 1
};

// 修改后
export const CONFIG = {
    INTERRUPT_COOLDOWN: 5000
};
```

**文件**: `src/tui/index.js`

```javascript
// 修改前
const cm = new ContextManager({
    maxMessages: CONFIG.MAX_MESSAGES,
    preserveFirstN: CONFIG.PRESERVE_FIRST_N
});

// 修改后
const cm = new ContextManager();
```

### 5. 简化：ContextManager 构造函数

**文件**: `src/sessions/context-manager.js`

```javascript
export class ContextManager {
    constructor(options = {}) {
        const config = loadConfig();
        // 只保留一个参数
        this.keepLastExchanges = options.keepLastExchanges || config.keepLastExchanges;
        this.maxMessagesSize = config.maxMessagesSize;
        this.useLlmSummary = config.useLlmContextSummary;
        this.llmClient = options.llmClient || null;
    }
}
```

### 6. 保留：AgentExecutor 的大小检查（兜底）

**文件**: `src/core/agent-executor.js`

保留 `MAX_MESSAGES_SIZE` 检查，作为兜底机制：

```javascript
// 仅在超出 MAX_MESSAGES_SIZE 时触发应急截断
if (cachedMessageSize > this.maxMessagesSize) {
    logger.warn(`Message history too large (${cachedMessageSize} bytes), applying emergency truncation`);
    this.emitProgress('truncating', iteration + 1, { size: cachedMessageSize });
    messages = this.emergencyTruncate(messages);
    cachedMessageSize = calculateMessagesSize(messages);
}
```

### 7. 新增：应急截断方法

**文件**: `src/core/agent-executor.js`

**设计目标**：保证 execute 循环不因上下文溢出而失败

**核心原则**：
- 只截断历史消息，不截断当前轮次（LLM 正在处理的上下文）
- 保留首轮意图 + 最近历史
- 当前轮次本身超限时，缩短内容而非移除消息

```javascript
/**
 * 应急截断（保证任务不失败）
 * 只截断历史消息，保留当前轮次的完整上下文
 */
emergencyTruncate(messages) {
    const maxSize = this.maxMessagesSize;

    // 1. 找到当前轮次的起始位置（最后一个 user 消息）
    const currentRoundStart = this.findCurrentRoundStart(messages);

    // 2. 分离历史消息和当前轮次
    const history = messages.slice(0, currentRoundStart);
    const currentRound = messages.slice(currentRoundStart);

    // 3. 计算当前轮次大小
    const currentRoundSize = calculateMessagesSize(currentRound);

    // 4. 如果当前轮次本身就超限，只能缩短内容
    if (currentRoundSize > maxSize * 0.8) {
        logger.warn('Current round too large, truncating content');
        const truncatedCurrent = currentRound.map(msg =>
            truncateSingleMessage(msg, 3000, 100)
        );
        return [...truncatedCurrent];
    }

    // 5. 计算历史可用空间
    const availableForHistory = maxSize - currentRoundSize;

    // 6. 截断历史：保留 system + 首轮 user + 最近几轮
    const systemMsg = history.find(m => m.role === 'system');
    const nonSystemHistory = history.filter(m => m.role !== 'system');

    // 按轮次分组
    const historyGroups = this.groupMessagesByRounds(nonSystemHistory);

    // 保留首轮 + 从后往前保留，直到填满可用空间
    const keptHistory = [];
    let historySize = 0;

    // 保留首轮（意图）
    if (historyGroups.length > 0) {
        const firstRound = historyGroups[0];
        const firstRoundSize = calculateMessagesSize(firstRound.messages);
        if (historySize + firstRoundSize < availableForHistory * 0.3) {
            keptHistory.push(...firstRound.messages);
            historySize += firstRoundSize;
        }
    }

    // 从后往前添加最近轮次
    for (let i = historyGroups.length - 1; i >= 1; i--) {
        const roundSize = calculateMessagesSize(historyGroups[i].messages);
        if (historySize + roundSize < availableForHistory) {
            keptHistory.unshift(...historyGroups[i].messages);
            historySize += roundSize;
        } else {
            break;
        }
    }

    // 7. 组装结果
    const result = [];
    if (systemMsg) result.push(systemMsg);
    result.push(...keptHistory);
    result.push(...currentRound);

    // 8. 添加警告标识
    const firstNonSys = result.findIndex(m => m.role !== 'system');
    if (firstNonSys >= 0) {
        result[firstNonSys] = {
            ...result[firstNonSys],
            content: result[firstNonSys].content + '\n\n[应急截断：部分历史已省略]'
        };
    }

    logger.warn('Emergency truncation applied', {
        originalSize: calculateMessagesSize(messages),
        newSize: calculateMessagesSize(result),
        historyKept: keptHistory.length,
        currentRoundSize
    });

    return result;
}

/**
 * 找到当前轮次的起始位置
 * 当前轮次 = 最后一个 user 消息开始
 */
findCurrentRoundStart(messages) {
    for (let i = messages.length - 1; i >= 0; i--) {
        if (messages[i].role === 'user') {
            return i;
        }
    }
    return 0;
}

/**
 * 按轮次分组消息
 */
groupMessagesByRounds(messages) {
    const rounds = [];
    let currentRound = null;

    for (const msg of messages) {
        if (msg.role === 'user') {
            if (currentRound) rounds.push(currentRound);
            currentRound = { messages: [msg] };
        } else if (currentRound) {
            currentRound.messages.push(msg);
        }
    }

    if (currentRound) rounds.push(currentRound);
    return rounds;
}
```

**上下文结构示意**：

```
┌─────────────────────────────────────────────────────────────────┐
│  messages 数组结构                                               │
│                                                                  │
│  [system] [历史轮次...] [当前轮次]                               │
│   ↑         ↑ 可截断      ↑ 必须完整保留                         │
│   │         │             │                                     │
│   │         │             └─ user → assistant(tool) → tool...   │
│   │         │                LLM 正在处理这个上下文              │
│   │         │                                                    │
│   │         └─ 可按轮次移除，保留首轮意图                        │
│   │                                                              │
│   └─ 始终保留                                                    │
└─────────────────────────────────────────────────────────────────┘
```

## Files to Modify

| 文件 | 修改内容 |
|------|----------|
| `src/sessions/manager.js` | 新增 `getRoundCount()`、`getMessagesByRounds()`、`groupMessagesByRounds()` |
| `src/sessions/context-manager.js` | 重构 `buildContext()`，新增 `generateSummary()`、`generateKeywordSummary()`，简化构造函数 |
| `src/core/llm.js` | 新增 `summarizeConversation()`、`formatConversationRounds()`、`truncateAtSentence()` |
| `src/core/agent.js` | 移除 `truncateMessages()`、`_summarizeTruncatedHistory()`，移除预判摘要逻辑（313-339行），清理构造函数中的 `contextSummaryThreshold` |
| `src/core/agent-executor.js` | 新增 `emergencyTruncate()`、`findCurrentRoundStart()`、`groupMessagesByRounds()`，新增 `truncateSingleMessage` 导入，移除构造函数中的 `truncateMessages` 依赖 |
| `src/tui/constants.js` | 移除 `MAX_MESSAGES` 和 `PRESERVE_FIRST_N` |
| `src/tui/index.js` | 简化 `ContextManager` 初始化，注入 `llmClient` |
| `src/utils/config.js` | 更新默认值，移除 `contextSummaryThreshold` 配置项 |
| `.env.example` | 更新配置说明 |

## Key Implementation Notes

### 1. AgentExecutor 不再依赖外部 truncateMessages

```javascript
// 修改前：构造函数接收 truncateMessages 回调
constructor(options = {}) {
    this.truncateMessages = options.truncateMessages;
}

// 修改后：内部实现 emergencyTruncate
constructor(options = {}) {
    // 移除 truncateMessages 依赖
    this.maxMessagesSize = options.maxMessagesSize;
}

// execute() 中直接调用内部方法
if (cachedMessageSize > this.maxMessagesSize) {
    messages = this.emergencyTruncate(messages);
}
```

### 2. Agent.runWithHistory 移除预判摘要逻辑

```javascript
// 移除 agent.js 313-339 行的预判摘要代码
// 摘要生成现在由 ContextManager.buildContext() 统一处理
```

### 3. ContextManager 依赖注入

```javascript
// tui/index.js 初始化时注入 LLMClient
const llmClient = new LLMClient(config);
const cm = new ContextManager({
    llmClient: llmClient
});
```

### 4. AgentExecutor 新增导入

```javascript
// agent-executor.js 顶部新增
import { truncateSingleMessage } from '../utils/message-utils.js';
```

### 5. cli.js 单轮模式不受影响

```javascript
// cli.js 调用 agent.run(userInput)
// 内部调用 runWithHistory(input, [])，空历史不走 ContextManager
// 无需修改
```

## Configuration Changes

### 参数默认值调整

| 参数 | 原默认值 | 新默认值 | 变化 | 理由 |
|------|----------|----------|------|------|
| `KEEP_LAST_EXCHANGES` | 10 | 15 | +5 轮 | 用户反馈 10 轮不够用 |
| `USE_LLM_CONTEXT_SUMMARY` | false | true | 启用 | 新设计有 fallback，启用 LLM 摘要质量更高 |
| `CONTEXT_SUMMARY_MAX_LENGTH` | 300 | 400 | +100 字 | 多轮对话摘要需要更多空间 |
| `MAX_MESSAGES_SIZE` | 300000 | 300000 | 不变 | 300KB 对大多数 LLM 足够 |
| `CONTEXT_SUMMARY_THRESHOLD` | 400 | (移除) | - | 新设计中不再需要此参数 |

### 保留的参数

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `KEEP_LAST_EXCHANGES` | 15 | 保留最近 N 轮对话（含首轮） |
| `MAX_MESSAGES_SIZE` | 300000 | 消息总大小限制（兜底） |
| `USE_LLM_CONTEXT_SUMMARY` | true | 是否使用 LLM 生成摘要 |
| `CONTEXT_SUMMARY_MAX_LENGTH` | 400 | 摘要最大长度 |

### 移除的参数

| 参数 | 原用途 |
|------|--------|
| `MAX_MESSAGES` | 消息数量限制（已废弃） |
| `PRESERVE_FIRST_N` | 首部保留轮次（固定为 1） |
| `CONTEXT_SUMMARY_THRESHOLD` | 单条消息摘要阈值（不再需要） |

## Verification

### 单元测试

```bash
npm run test:context
```

验证：
- `groupMessagesByRounds()` 正确分组
- `getMessagesByRounds()` 正确返回 U 型结构
- `generateSummary()` 生成有效摘要

### 集成测试

```bash
npm run chat
```

测试场景：
1. 新会话，进行 5 轮对话 → 验证全部保留
2. 进行 20 轮对话 → 验证 U 型保留（首轮 + 最近 14 轮 + 摘要）
3. 设置 `KEEP_LAST_EXCHANGES=15` → 验证保留 15 轮

### 日志验证

```bash
DEBUG=true npm run chat
```

观察日志：
- `Context built (U-shape)` 显示的轮次信息
- 摘要生成是否成功
