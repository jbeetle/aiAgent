# coqi-claw Web API 接入指南

本文档面向需要在 coqi-claw 后端之上自行封装前端的开发团队。

## 快速开始

```bash
# 1. 启动 coqi-claw Web 服务
npm run web

# 2. 内部 OpenAPI 规范见 docs/openapi.json
```

## 基础信息

| 项目 | 说明 |
|------|------|
| 基础 URL | `http://localhost:3000/api/v1` |
| 兼容路由 | `http://localhost:3000/api`（与 v1 等价，未来可能弃用） |
| 协议 | HTTP/1.1 + WebSocket |
| 内容格式 | JSON |
| 认证方式 | 可选 API Key（`X-API-Key` Header） |

## 认证

coqi-claw 的 API Key 认证默认**关闭**。当部署者通过环境变量 `WEB_API_KEY=your-key` 启用后，所有请求（除登录接口外）必须携带：

```
X-API-Key: your-key
```

### 登录获取 API Key

启用认证后，先通过登录接口获取 API Key，再用于后续调用：

```bash
curl -X POST http://localhost:3000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username": "admin", "password": "coqi@2026"}'
```

**成功响应：**
```json
{
  "success": true,
  "data": {
    "apiKey": "your-key"
  }
}
```

**失败响应（401）：**
```json
{
  "success": false,
  "error": {
    "code": "Unauthorized",
    "message": "用户名或密码错误"
  }
}
```

默认凭据：`admin` / `coqi@2026`，可通过 `WEB_LOGIN_USERNAME` 和 `WEB_LOGIN_PASSWORD` 环境变量覆盖。

未启用认证（`WEB_API_KEY` 未设置）时无需任何认证即可访问所有接口。

## 一事通扫码登录（企业 SSO）

网关支持一事通（招商银行内部 SSO）扫码登录，与用户名密码登录**同时并存**。前端与网关统一打包发布、同源部署时，扫码页通过网关代理后与页面同源，cookie 可管理（登录失败重置、登出清会话均可用）。

### 登录链路

```
前端扫码页(iframe) → window.ystJsApi.yhtLogin(code, type)
  → POST /api/v1/yst/token { code, type }    （网关 → 管理端 YST_TOKEN_URL）
  → { token: remoteToken, username }
  → POST /api/v1/auth/login { WEB_LOGIN_USERNAME/PASSWORD }
  → { apiKey }   （后续请求携带 X-API-Key，与密码登录共用同一认证体系）
```

### 一事通相关接口

| 接口 | 说明 | 认证 |
|------|------|------|
| `POST /api/v1/yst/token` | code 换取 remoteToken + 用户名（透传管理端 `YST_TOKEN_URL`） | 公开放行（登录链路） |
| `/api/v1/remote-login`（所有方法） | 密码/SSO 登录透传（`REMOTE_LOGIN_URL`），支持任意 HTTP 方法并透传响应头（含 Set-Cookie），行为与 vite 代理一致 | 公开放行（登录链路） |

### OA 扫码页代理

网关默认将一事通扫码页代理到 OA 认证域（iframe 沙箱，`YST_PROXY_ENABLED=false` 可关闭）。代理路径规则与 `web/vite.config.ts` 一致（一事通页面 URL、接口与资源路径均不可修改，由网关侧适配）：

| 网关路径 | 上游映射 | 规则 |
|----------|----------|------|
| `/yst-proxy/*` | `{OA_BASE}/*` | 去前缀 |
| `/zh-login`、`/zh-login/`、`/zh-login/*` | `{OA_BASE}/zh-login/...` | 整链路保留前缀（联调实测：页面与 JS/CSS 等子资源均部署在 `/zh-login/` 下，去前缀上游返回 404） |
| `/auth-server/*` | `{OA_BASE}/auth-server/*` | 保留前缀（与 vite 一致，无 rewrite） |

代理响应统一处理：**剥离 Content-Security-Policy**（否则 iframe 子资源被 https: CSP 拦截，扫码页空白）；**默认移除 Set-Cookie 的 HttpOnly**（与 vite 行为一致，让 JS 可清 cookie，登录失败后可重置 iframe 重新扫码；`YST_PROXY_STRIP_HTTPONLY=false` 可关闭）。3xx 重定向与 vite http-proxy 一致：原样透传给浏览器（不跟随，避免绕过代理直连 OA 域）。

### 环境变量

```env
# OA 扫码页代理（iframe 沙箱），默认开启；设为 false 关闭
YST_PROXY_ENABLED=true
YST_PROXY_OA_BASE=https://oa-auth.paas.cmbchina.com
YST_PROXY_STRIP_HTTPONLY=true                    # 默认开启（与 vite 一致）；false 保留 HttpOnly
YST_PROXY_TIMEOUT_MS=30000                       # 代理超时（毫秒）

# 一事通 code→token（管理端）
YST_TOKEN_URL=
```

### 前端集成要点

- iframe 指向 `{网关}/zh-login/...`（或一事通给定的扫码 URL），页面通过 `window.ystJsApi` 暴露 `getClientConfig`/`closeWindow`/`yhtLogin` 供三方页回调
- 代理路径为公开放行（不在 `/api` 前缀下，不参与 API Key 认证）
- 安全边界：代理目标固定白名单（`YST_PROXY_OA_BASE`），不接受请求指定目标，防 SSRF；代理接口不记录 cookie 原文

## REST API 速查表

### 认证登录

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/auth/login` | 用户登录，验证凭据后返回 API Key（无需认证） |

### 会话管理

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/sessions` | 列总会话（支持 `?limit=`、`?offset=`、`?status=`） |
| POST | `/sessions` | 创建会话 `{ title?, assistantId? }` |
| GET | `/sessions/:id` | 获取会话详情 |
| PATCH | `/sessions/:id` | 修改会话名称或状态 `{ title?, status? }` |
| DELETE | `/sessions/:id` | 删除会话 |
| GET | `/sessions/:id/messages` | 获取会话消息列表 |
| DELETE | `/sessions/:id/messages` | 清空会话消息 |

### 聊天接口

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/chat` | HTTP 非流式聊天（阻塞式，返回完整响应） |

**请求体：**
```json
{
  "sessionId": "sess_xxx",
  "content": "你好"
}
```

**成功响应：**
```json
{
  "success": true,
  "data": {
    "result": "你好！有什么可以帮你的吗？",
    "durationMs": 2345,
    "sessionId": "sess_xxx"
  }
}
```

**失败响应：**
```json
{
  "success": false,
  "error": {
    "code": "AUDIT_BLOCKED",
    "message": "内容触发合规审查规则",
    "category": "sanctions_evasion",
    "reason": "..."
  }
}
```

### 文件

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/upload` | 上传文件到沙箱（multipart/form-data，字段名 `file`） |
| GET | `/files/download?path=` | 下载沙箱文件（如 `?path=output/report.xlsx`） |

**上传请求示例：**
```bash
curl -X POST http://localhost:3000/api/v1/upload \
  -H "X-API-Key: your-key" \
  -F "file=@/path/to/document.pdf"
```

**上传成功响应：**
```json
{
  "success": true,
  "data": {
    "name": "document.pdf",
    "serverPath": "user/upload/document.pdf",
    "size": 102400
  }
}
```

### 助手与用户

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/assistants` | 列总可用助手 |
| GET | `/user` | 获取当前用户信息 |
| PATCH | `/user` | 更新用户偏好设置 |

### 系统

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/health` | 健康检查 |

## WebSocket 协议

WebSocket 用于实时聊天流，适合需要展示进度、工具执行状态等实时反馈的场景。

### 连接

```javascript
const ws = new WebSocket('ws://localhost:3000');
// 如需认证
const ws = new WebSocket('ws://localhost:3000', [], {
  headers: { 'X-API-Key': 'your-key' }
});
```

### 客户端消息（Client → Server）

| type | payload | 说明 |
|------|---------|------|
| `chat` | `{ sessionId, content }` | 发送聊天消息 |
| `cancel` | `{ requestId }` | 取消正在处理的请求 |
| `ping` | `{}` | 心跳保活 |

### 服务端消息（Server → Client）

| type | payload | 说明 |
|------|---------|------|
| `connected` | `{ connectionId }` | 连接成功确认 |
| `progress` | `{ phase, current, total, tools, toolCount, size }` | 执行进度更新 |
| `tool_call` | `{ sessionId, id, name, arguments }` | 工具调用开始 |
| `tool_result` | `{ sessionId, toolCallId, name, success, content }` | 工具执行结果 |
| `assistant_message` | `{ sessionId, content, type, iteration? }` | 流式内容片段（`type` 为 `content` 或 `reasoning`） |
| `complete` | `{ result, durationMs }` | 请求完成 |
| `error` | `{ message, durationMs? }` | 处理错误 |
| `aborted` | `{ reason, durationMs }` | 请求被取消 |
| `audit_block` | `{ category, categoryName, reason, confidence }` | 审查阻断 |
| `audit_warning` | `{ category, categoryName, warningMessage }` | 审查警告 |
| `pong` | `{}` | 心跳响应 |

### 完整聊天示例（JavaScript）

```javascript
const ws = new WebSocket('ws://localhost:3000');

ws.onopen = () => {
  console.log('已连接');

  // 发送消息
  ws.send(JSON.stringify({
    type: 'chat',
    payload: {
      sessionId: 'sess_xxx',
      content: '深圳明天的天气如何？'
    }
  }));
};

ws.onmessage = (event) => {
  const msg = JSON.parse(event.data);
  console.log('收到:', msg.type, msg.payload);

  switch (msg.type) {
    case 'progress':
      console.log(`进度: ${msg.payload.phase} (${msg.payload.current}/${msg.payload.total})`);
      break;
    case 'complete':
      console.log('结果:', msg.payload.result);
      break;
    case 'error':
      console.error('错误:', msg.payload.message);
      break;
    case 'audit_block':
      console.warn('审查阻断:', msg.payload.reason);
      break;
  }
};
```

## CORS 配置

默认仅允许 localhost 访问。如需跨域，部署方设置环境变量：

```bash
# 允许多个 origin
WEB_CORS_ORIGINS=http://example.com,https://app.example.com

# 允许所有 origin（不推荐生产环境）
WEB_CORS_ORIGINS=*
```

## 错误码说明

| HTTP 状态码 | 场景 |
|------------|------|
| 400 | 请求参数错误（缺少必填字段、格式错误等） |
| 401 | API Key 认证失败 / 登录凭据错误 |
| 403 | 内容触发审计阻断 |
| 404 | 资源不存在（会话、消息等） |
| 409 | 该会话已有请求正在处理 |
| 429 | 请求频率超过限制 |
| 500 | 服务端处理错误 |

## 接入示例：纯 HTTP 调用

适用于后端服务集成，不需要实时进度反馈的场景：

```javascript
const BASE_URL = 'http://localhost:3000/api/v1';

// 1. 登录获取 API Key（启用认证时需要）
async function login(username, password) {
  const res = await fetch(`${BASE_URL}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password })
  });
  const data = await res.json();
  if (!data.success) throw new Error(data.error.message);
  return data.data.apiKey;
}

// 2. 使用 API Key 调用其他接口
const API_KEY = await login('admin', 'coqi@2026'); // 未启用认证时可跳过此步

function headers() {
  return {
    'Content-Type': 'application/json',
    ...(API_KEY && { 'X-API-Key': API_KEY })
  };
}

async function chat(sessionId, content) {
  const res = await fetch(`${BASE_URL}/chat`, {
    method: 'POST',
    headers: headers(),
    body: JSON.stringify({ sessionId, content })
  });
  return res.json();
}

async function createSession(title) {
  const res = await fetch(`${BASE_URL}/sessions`, {
    method: 'POST',
    headers: headers(),
    body: JSON.stringify({ title })
  });
  return res.json();
}

// 使用
const session = await createSession('天气查询');
const result = await chat(session.id, '深圳明天天气如何？');
console.log(result.data.result);
```

## 环境变量参考

| 变量 | 说明 | 默认值 |
|------|------|--------|
| `WEB_PORT` | HTTP 服务端口 | `3000` |
| `WEB_HOST` | 服务绑定地址 | `127.0.0.1` |
| `WEB_API_KEY` | API Key，设置后启用认证 | 未设置（不启用） |
| `WEB_LOGIN_USERNAME` | 登录用户名 | `admin` |
| `WEB_LOGIN_PASSWORD` | 登录密码 | `coqi@2026` |
| `WEB_CORS_ORIGINS` | 允许的跨域 Origin，逗号分隔 | `localhost` |
| `WEB_RATE_LIMIT` | 速率限制，格式 `requests/seconds` | `60/60` |
