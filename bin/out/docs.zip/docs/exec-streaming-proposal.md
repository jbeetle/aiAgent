# exec 流式输出方案

> 状态：搁置 / 待优化  
> 分析时间：2026-05-21  
> 背景：Zed `terminal` 工具对比分析

---

## 问题

exec 执行长时间命令（`npm install`、大数据处理等）时，用户终端一片空白，不知道是卡死还是在正常执行，等待体验差。

## 根本原因

coqi-claw 的 exec 使用 `child_process.exec` 缓冲式 I/O——命令完全结束后一次性返回输出。消费者只有 LLM（等完整 JSON 做推理），用户看不到中间进度。

Zed 的 terminal 使用 PTY 伪终端——输出实时推送到 IDE 的 Terminal 卡片。消费者是**人类用户**，需要实时看到进度条和滚动日志。

**不是 CLI 做不了流式，是两个产品的输出消费者不同。**

---

## 方案：双通道输出

在不改变 LLM 行为的前提下，让用户也能实时看到 exec 进度：

```
exec({ command: "pip install pandas openpyxl" })

                   ┌─────────────────────────────┐
                   │     child_process.spawn       │
                   │     (替换 exec 为 spawn)       │
                   └──────────────┬──────────────┘
                                  │
                    ┌─────────────┴─────────────┐
                    │                           │
              stdout/stderr 流式              完整 JSON
              ↓                              ↓
           【用户终端】                    【LLM 上下文】
         实时看到进度条                 拿 exitCode 做决策
```

## 需要改动的文件

| 文件 | 改动 | 行数 |
|------|------|:--:|
| `src/tools/exec.js` | `execAsync` → `spawn` + stream 输出同时收集 | ~15 行 |
| `src/tui/processor.js` | `onProgress('tool_executing')` 时暂停 spinner，exec 结束时恢复 | ~10 行 |

## 关键交互流程

```
exec 开始
  → processor.js onProgress('tool_executing')
  → spinner.stop()                    // 暂停旋转动画
  → 打印 "⚙️ 执行: pip install..."
  → exec 实时流输出到终端              // 用户看到进度
  → exec 结束
  → spinner.succeed('完成 (45s)')      // 恢复
  → 返回 JSON 给 LLM                  // LLM 拿完整结果做推理
```

## 为什么不能只改 exec.js

TUI 使用 spinner（`createSpinner`）管理终端显示，每 80ms 执行一次：

```javascript
process.stdout.clearLine(0);      // 擦除当前行
process.stdout.cursorTo(0);       // 光标回行首
process.stdout.write(`  ⠋ 思考中...`); // 写新帧
```

如果 exec 直接往 stdout 写，输出会与 spinner 冲突，导致终端显示混乱。

因此 `processor.js` 必须感知到 "exec 正在流式输出" 并主动暂停 spinner。

## exec.js 具体改动思路

```javascript
// 将 child_process.exec 改为 spawn
const child = spawn(command, [], {
  shell: shellOption,
  cwd: resolvedCwd,
  env: { ... }
});

// 双通道：实时输出 + 完整收集
const stdoutChunks = [];
const stderrChunks = [];

child.stdout.on('data', (chunk) => {
  process.stdout.write(chunk);        // → 用户终端
  stdoutChunks.push(chunk);           // → 完整收集
});

child.stderr.on('data', (chunk) => {
  process.stderr.write(chunk);        // → 用户终端
  stderrChunks.push(chunk);           // → 完整收集
});

// 等待结束
const exitCode = await new Promise((resolve) => {
  child.on('close', resolve);
});

// LLM 拿到完整 JSON（与现在完全一致）
const stdout = Buffer.concat(stdoutChunks).toString('utf-8');
const stderr = Buffer.concat(stderrChunks).toString('utf-8');
return JSON.stringify({ exitCode, stdout, stderr, ... });
```

## processor.js 具体改动思路

```javascript
// 在 agent.runWithHistory 的 onProgress 回调中
if (evt.phase === 'tool_executing' && evt.tools?.includes('exec')) {
  spinner.stop();                      // 让路给 exec 流式输出
}
if (evt.phase === 'tool_completed') {
  spinner.start();                     // 恢复 spinner
}
```

---

## 副作用评估

| 风险 | 等级 | 说明 |
|------|:--:|------|
| JSON 模式下 stdout 字段出现 ANSI 转义序列 | 中 | 需要 strip ANSI：`stripAnsi(chunk)` |
| buffered 改 spawn 的行为差异 | 低 | spawn 不限制 buffer，需手动限制 maxBuffer |
| 并发 exec 调用时输出混乱 | 低 | coqi-claw 最多并发 5 个工具，同屏交错可接受 |

## 搁置原因

当前主要耗时瓶颈是 LLM 推理的迭代等待，而非 exec 执行速度。流式输出优化的是**用户感知等待体验**，在 LLM 推理延迟问题解决前，投入产出比不高。
