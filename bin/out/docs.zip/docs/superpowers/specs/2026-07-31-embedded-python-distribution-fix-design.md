# 内嵌 Python 发布问题修复设计

> 日期：2026-07-31  
> 背景：参考 `docs/embedded-python-distribution.md` 的事故复盘，对齐其 §5 已实现清单，补齐当前仓库缺失的修复与发布流程。  
> 范围：代码 + 脚本 + 配置流程，**不**在本次实际安装第三方包到 `plugins/python/Lib/site-packages`（由打包机下次执行）。

---

## 1. 目标

1. 消除 `exec` / `exec_skill` / 技能脚本因 PATH 前置而解析到缺包内嵌 Python 的根因。
2. 让 LLM 能看到失败命令的完整报错，并自动获得装包 hint，实现“一轮自愈”。
3. 建立依赖烘焙流水线：扫描 → 汇总 → 下载 whl → 离线安装（脚本先行，实际烘焙放到打包机）。
4. 加固内嵌 Python 首启可移植性：pip launcher 检测/重建、启用 `import site`。
5. 明确 `SKILL_PYTHON_VENV` 与内嵌 Python 的边界，避免静默失败。

---

## 2. 设计原则

- **最小侵入**：核心改动集中在 `src/bootstrap/manager.js`、`src/tools/exec-common/process.js`、`src/tools/exec-common/formatter.js`、`src/utils/shell-utils.js`；新增文件独立可测。
- **离线优先**：所有新增脚本必须支持无互联网环境（`--find-links` 离线安装）。
- **失败不阻断**：首启 pip launcher 修复失败仅告警，不影响应用启动。
- **可验证**：每项改动都有对应的 `node --check`、既有测试或手动 smoke test。

---

## 3. 模块设计

### 3.1 PATH 治理

**文件**：`src/bootstrap/manager.js`

内嵌 Python 目录由 prepend 改为 append：

```javascript
process.env.PATH = (process.env.PATH || '') + path.delimiter + paths.join(path.delimiter);
```

系统 Python（含完整依赖）优先；客户机无系统 Python 时内嵌兜底。`python_ptc` 使用绝对路径 spawn，不受影响。日志同步改为 `"appended to PATH"`。

### 3.2 错误输出挂载

**文件**：`src/tools/exec-common/process.js`

在 `execWithPid` 失败回调中把 `stdout`/`stderr` 挂到 error 对象，否则 `formatter.js` 在 Windows 下看不到任何报错：

```javascript
if (error) {
  error._childPid = child.pid;
  error.stdout = stdout;
  error.stderr = stderr;
  reject(error);
}
```

### 3.3 缺包自愈 hint

**新增函数**：`src/utils/shell-utils.js::buildDependencyHint(stdout, stderr)`

- Python：匹配 `ModuleNotFoundError: No module named 'xxx'`，映射到 pip 包名（`dotenv→python-dotenv`、`PIL→Pillow`、`fitz→pymupdf` 等）。
- Node：匹配 `Cannot find module 'xxx'` / `Cannot find package 'xxx'`，跳过相对路径、`node:` 内置、本地文件；处理 `@scope/pkg`。
- 返回字符串如 `"Try: python -m pip install python-docx"` 或 `"Try: npm install lodash"`。

**文件**：`src/tools/exec-common/formatter.js`

`formatError` 在返回前调用 `buildDependencyHint`（基于未截断原始输出检测），把 hint 注入 `jsonResult.hint`。

### 3.4 依赖聚合脚本

**新增文件**：`scripts/collect-skill-python-deps.js`

用法：

```bash
node scripts/collect-skill-python-deps.js [skills-dir] [-o requirements.txt]
```

功能：

1. 收集所有 `skills/**/requirements.txt`；
2. 扫描所有 `skills/**/*.py` 的 `import` / `from ... import`；
3. 过滤标准库、本地模块、测试目录；
4. import 名 → pip 包名映射（复用并抽离 `setup-skill-venv.js` 的映射表到共享模块，避免重复）；
5. 输出去重后的合并依赖清单。

### 3.5 离线 whl 下载脚本

**新增文件**：`scripts/download-runtime-wheels.js`

用法：

```bash
node scripts/download-runtime-wheels.js [--requirements <file>]
```

功能：

1. 创建 `plugins/python/wheels/`；
2. 下载 pip 自身 whl：`plugins/python/python.exe -m pip download pip -d plugins/python/wheels/`；
3. 下载业务依赖 whl：`plugins/python/python.exe -m pip download -r <requirements> -d plugins/python/wheels/`；
4. 默认 requirements 路径为 `plugins/python/requirements.txt`（如不存在则仅下载 pip）。

典型工作流：

```bash
node scripts/collect-skill-python-deps.js skills/ -o plugins/python/requirements.txt
npm run prepare:wheels
```

**`package.json` 新增脚本**：

```json
"prepare:wheels": "node scripts/download-runtime-wheels.js"
```

### 3.6 pip launcher 首启修复

**新增文件**：`src/bootstrap/python-launchers.js`

导出 `ensurePipLaunchers(pythonDir)`：

1. 读取 `Scripts/*.exe` 尾部 shebang，提取其指向的 python 路径；
2. 若与当前 `pythonDir/python.exe` 不一致，且 `wheels/pip-*.whl` 存在，则执行：
   ```bash
   python.exe -m pip install --force-reinstall --no-index --find-links=wheels pip
   ```
3. 失败仅 `logger.warn`，不阻断启动。

**文件**：`src/bootstrap/manager.js`

`initializeSystem()` 检测到内嵌 Python 后调用 `ensurePipLaunchers(pythonDir)`。

### 3.7 python-ptc Python 解析

**文件**：`src/tools/python-ptc/helpers.js`

`findPythonExecutable()` 修改查找顺序：

1. 若 `plugins/python/python.exe`（或 Linux 下 `plugins/python/bin/python3`）存在，直接返回绝对路径；
2. 否则按原逻辑在 PATH 中查找。

这样 PATH append 后，`python_ptc` 仍稳定使用内嵌解释器，不受系统 Python 波动影响。

### 3.8 `python._pth` 启用 site

**文件**：`plugins/python/python314._pth`

取消 `import site` 注释，确保 `site-packages` 被正常加入 `sys.path`，也是 pip 可靠工作的前提。

### 3.9 `SKILL_PYTHON_VENV` 边界

**文件**：`src/tools/skill-python.js`

`ensureAutoVenv` 在创建 venv 前先检测解释器是否支持 `ensurepip`（尝试 `python.exe -m ensurepip --help` 或 `import ensurepip`）。内嵌 Python 不支持时抛出清晰错误，不静默失败。`SKILL_PYTHON_VENV` 默认仍为 `false`。

**文件**：`scripts/setup-skill-venv.js`

若检测到正在用内嵌 Python（路径包含 `plugins/python`），提前退出并提示使用系统 Python。

---

## 4. 数据流

```
启动
  → manager.js append PATH
  → python-launchers.js ensurePipLaunchers()
  → 技能执行 exec_skill / exec
      → exec-common/process.js 失败挂载 stdout/stderr
      → exec-common/formatter.js 注入 dependency hint
      → LLM 看到 hint → 下一轮执行 python -m pip install xxx

打包机
  → collect-skill-python-deps.js 汇总依赖
  → download-runtime-wheels.js 下载 whl
  → 把 plugins/python/wheels/ + 烘焙后的 site-packages 一起打包
```

---

## 5. 错误处理

| 场景 | 行为 |
|------|------|
| ensurePipLaunchers 失败 | warn，不阻断启动 |
| 内嵌 Python 不支持 venv | 抛出清晰错误，建议用系统 Python |
| download-runtime-wheels 无网络 | 非零退出，CI/打包机捕获 |
| buildDependencyHint 未命中 | 返回 `null`，不注入 hint |

---

## 6. 验证计划

- `node --check` 所有新增/修改的 JS 文件。
- 既有测试：
  - `npm test`
  - `node test/test-exec-skill.js`
  - `node test/test-python-ptc.js`
- 手动 smoke test：
  1. `npm start` 启动，确认日志 `"appended to PATH"`；
  2. `exec_skill({skill_name: "resume-analyzer", command: "python -c 'import pandas'"})` 返回 `ModuleNotFoundError` + hint；
  3. `python_ptc` 执行 `print(__import__('sys').executable)` 指向内嵌 Python。

---

## 7. 后续工作（不在本次）

- 在打包机上执行 `npm run prepare:wheels` 并把业务包装入 `plugins/python/Lib/site-packages`；
- 清理 `__pycache__`；
- 评估 Tesseract/Poppler 等外部二进制依赖的随包策略；
- 按 SKU 拆分技能集以减小发布体积。
