# 设置页改造设计文档

## 1. 背景与目标

当前 `SettingsPanel` 以 **Modal 弹窗** 形式呈现，三个区块（个人资料 / 外观 / 连接）上下堆叠。参考设计图 `client-ui-design/setting.png` 采用 **左侧分类导航 + 右侧内容区** 的左右布局，信息层级更清晰，也更便于后续扩展。

**目标**：把现有设置功能从 Modal 弹窗改造为全屏 `/settings` 页面，采用左侧导航、右侧内容的左右布局，并保持现有 3 个设置区块的功能不变。

## 2. 范围

**包含**：
- 现有 3 个设置区块的左右布局重构：
  - 个人资料（ProfileSection）
  - 外观（AppearanceSection）
  - 连接（ConnectionSection）
- 左侧导航栏，按参考图风格加入分类标题“通用”
- 全屏 `/settings` 页面入口
- 响应式：桌面端左右布局，移动端左侧导航变为顶部 Tab

**不包含**：
- 新增参考图中的其他设置项（语言、字体、字号、快捷键、MCP、安全环境、实验特性等）
- 设置表单的业务逻辑变更（校验规则、保存接口不变）
- 主题、连接状态等业务 Hook 的改动

## 3. 关键设计决策

| 决策项 | 选择 | 理由 |
|---|---|---|
| 容器形式 | 全屏独立页面 `/settings` | 参考图为全屏页面，左右布局需要足够宽度 |
| 路由方案 | `react-router-dom` 嵌套路由 | 支持 `/settings/profile` 等语义化 URL、深链、刷新保持 |
| 导航组织 | 单分类“通用”下挂 3 个入口 | 当前只有 3 个区块，为后续扩展保留分类结构 |
| 响应式 | 桌面侧边栏 / 移动端顶部 Tab | 平衡可用性与实现复杂度 |
| 表单状态 | 继续由 `useSettingsForm` 管理 | 已有逻辑成熟，无需重写 |

## 4. 当前架构约束

- `web/src/App.tsx` 直接渲染 `ChatLayout`，**项目当前没有使用任何路由库**。
- `ChatLayout.tsx` 通过 `useUIStore.settingsOpen` 控制 `SettingsPanel` 弹窗显示。
- 因此实现 `/settings` 页面需要引入 `react-router-dom`，并轻度重构 `App.tsx` 的入口逻辑。

## 5. 路由结构

```
/                           → ChatLayout（聊天主界面）
/settings                   → 重定向到 /settings/profile
/settings/profile           → ProfileSection
/settings/appearance        → AppearanceSection
/settings/connection        → ConnectionSection
```

## 6. 组件结构

```
web/src
├── App.tsx                         # BrowserRouter + 认证守卫
├── components/
│   ├── AuthenticatedLayout.tsx     # 新增：认证后共享布局（ToastContainer + useWebSocket）
│   ├── ChatLayout.tsx              # 聊天主界面（不再包含 ToastContainer、SettingsPanel）
│   ├── SettingsPanel.tsx           # 废弃：Modal 形式不再使用
│   └── settings/
│       ├── SettingsPage.tsx        # 设置页外壳：sidebar + Outlet
│       ├── SettingsSidebar.tsx     # 左侧导航栏（含分类标题和 nav items）
│       ├── SettingsNavItem.tsx     # 单个导航项（active 状态、链接）
│       ├── ProfileSection.tsx      # 复用：个人资料表单展示
│       ├── AppearanceSection.tsx   # 复用：外观主题选择
│       ├── ConnectionSection.tsx   # 复用：连接状态 + 重连
│       ├── ProfilePage.tsx         # 新增：/settings/profile 路由组件，内部调用 useSettingsForm
│       ├── AppearancePage.tsx      # 新增：/settings/appearance 路由组件
│       ├── ConnectionPage.tsx      # 新增：/settings/connection 路由组件
│       ├── SettingsSection.tsx     # 复用：右侧内容区块标题容器
│       ├── FormInput.tsx           # 复用：标准输入框
│       └── FormSelect.tsx          # 复用：标准下拉框
```

### 6.1 AuthenticatedLayout.tsx（新增）

认证通过后所有页面共享的骨架：
- 渲染 `<ToastContainer />`（确保设置页也能显示 toast）。
- 调用 `useWebSocket()`（确保 WebSocket 在聊天页和设置页都保持连接）。
- 内部使用 `<Outlet />` 渲染子路由（`ChatLayout` 或 `SettingsPage`）。
- 不含全局导航注入；API Key / 401 / WS 1008 等错误直接通过 `useAuthStore` 触发登录对话框。

### 6.2 SettingsPage.tsx

- 全屏布局容器（`h-screen w-screen`）。
- 左侧固定宽度侧边栏（桌面端 `w-[240px]`）。
- 右侧 `<Outlet />` 渲染子路由内容。
- 移动端时，将 `<SettingsSidebar />` 渲染为顶部水平滚动 Tab。

### 6.3 SettingsSidebar.tsx

- 渲染分类标题“通用”。
- 渲染 3 个 `SettingsNavItem`：
  - 个人资料 → `/settings/profile`
  - 外观 → `/settings/appearance`
  - 连接 → `/settings/connection`
- 接收 `isMobile` prop 决定渲染为侧边栏或顶部 Tab。
- 外层包裹 `<nav aria-label="设置导航">`。

### 6.4 SettingsNavItem.tsx

- 使用 `NavLink`（来自 react-router-dom）实现 active 状态。
- props：`to`, `label`, `icon?`。
- active 状态样式通过 `NavLink` 的 `aria-current="page"` 辅助屏幕阅读器识别。

### 6.5 ProfilePage.tsx / AppearancePage.tsx / ConnectionPage.tsx（新增路由组件）

`ProfileSection` 和 `ConnectionSection` 当前是纯展示组件，不能直接作为路由元素使用。

- **ProfilePage**：内部调用 `useSettingsForm`，管理保存按钮、未保存提示、表单 dirty 状态；将状态与回调传给 `ProfileSection`。
- **AppearancePage**：直接渲染 `AppearanceSection`（主题切换即时生效，无需保存按钮）。
- **ConnectionPage**：从 `useUIStore` 读取 `connectionStatus`，传给 `ConnectionSection`。

## 7. 数据流

```
/settings/profile
  → AuthenticatedLayout
    → SettingsPage
      → Outlet → ProfilePage
        → useSettingsForm({ onSaved: () => toastSuccess(...) })
          → ProfileSection (props)
            → useChatStore (userProfile, assistants)
            → userApi.update
```

- `useSettingsForm` 的 `onClose` 回调语义需要调整：原设计是关闭 Modal，新设计下保存成功后不再关闭页面，而是 toast 成功提示并停留在当前设置页。
- 具体改动：将 `UseSettingsFormOptions` 中的 `onClose` 重命名为 `onSaved`（或新增 `onSaved`），保存成功后调用 `onSaved()` 而不是 `onClose()`。
- **无变更保存行为**：`useSettingsForm` 中“资料未变更”分支不应调用 `onSaved`，避免误报“保存成功”。可静默忽略或 toast “无修改”。
- **提交期间保护**：`useSettingsForm` 中同步 `userProfile` 的 `useEffect` 应增加 `if (submitting) return;`，防止保存期间外部更新覆盖用户输入。

## 8. 响应式设计

| 断点 | 布局 |
|---|---|
| `≥768px`（桌面） | 左侧 240px 固定侧边栏 + 右侧可滚动内容区 |
| `<768px`（移动） | 顶部水平滚动 Tab 导航，内容区在下方垂直滚动 |

- 复用 `ChatLayout` 中已有的 `useIsMobile` 逻辑（可提取为公共 hook 或复制简化版）。
- 移动端侧边栏不再使用抽屉，改为更轻量的顶部 Tab。

## 9. 入口与导航改动

### 9.1 打开设置页

- 原方式：点击头像/设置按钮 → `useUIStore.setSettingsOpen(true)`。
- 新方式：点击头像/设置按钮 → `navigate('/settings/profile')`。
- 需要把 UI store 中的 `settingsOpen` 状态移除或标记为废弃。

### 9.2 关闭设置页

- 原方式：`setSettingsOpen(false)`。
- 新方式：
  - 点击返回/关闭按钮 → `navigate('/')` 回到聊天页。
  - 保存成功后 →  toast 提示，可保留在当前页。

## 10. 关键生产细节

### 10.1 脏表单离开拦截

`/settings/profile` 包含可编辑表单。用户在未保存时通过浏览器后退、侧边栏切换、地址栏跳转离开，必须提示确认。

- 使用 `react-router-dom` 的 `useBlocker`（v6.20+/v7）实现路由级拦截。
- 拦截触发条件：`isDirty && !submitting`。
- 提示文案复用或新增未保存确认字符串。
- “取消”行为：关闭提示，留在当前页。
- “确认离开”行为：导航继续，表单状态丢弃。

### 10.2 Onboarding 与深链交互

- 未设置 `user.name` 时，`AppAfterLogin` 渲染 `OnboardingWizard`，URL 保持 `/settings/profile`。
- **Onboarding 完成后**：应调用 `navigate('/')` 进入聊天页，而不是留在设置页。因为 onboarding 的下一步是开始对话，而非继续配置。
- 如果业务上希望 onboarding 完成后留在设置页，需单独设计；默认行为选择返回聊天页。

### 10.3 404 兜底与认证守卫

- `App.tsx` 内部使用 `BrowserRouter`。
- `AppAfterLogin` 返回 `<Routes>`：
  - `/` → `<ChatLayout />`
  - `/settings` → `<Navigate to="/settings/profile" replace />`
  - `/settings/*` → `<SettingsPage />`（内部再嵌套子路由）
  - `*` → `<Navigate to="/" replace />`
- 未登录时 `App.tsx` 直接渲染 `<LoginModal />`，不进入 `BrowserRouter` 内部路由；登录后 `AppAfterLogin` 再提供路由。
- 或者更规范做法：把 `BrowserRouter` 上提到 `main.tsx`，`App.tsx` 内部根据认证状态返回不同内容。两种做法都可行，需保持团队一致。

### 10.4 非 React 模块的错误跳转

当前以下位置调用 `useUIStore.getState().setSettingsOpen(true)`：
- `web/src/api/websocket.ts:182`（WS close code 1008）
- `web/src/api/websocket.ts:295`（API Key 错误）
- `web/src/api/rest.ts:72`（REST 401 + API Key）
- `web/src/api/rest.ts:171`（上传 401）

**用户确认**：API Key / 连接类错误（401、WS 1008 等）应跳转到**系统登录对话框**，因为登录成功后自动写入 API Key。

改造后统一改为触发登录态：
- `useAuthStore.getState().setAuthenticated(false)` 或 `useAuthStore.getState().logout()`。
- 这样 `App.tsx` 中的 `if (!authenticated)` 会渲染 `<LoginModal />`。

同时确保登录成功后：
- `LoginModal` 调用 `setApiKey(key)` 写入 API Key；
- `setAuthenticated(true)` 标记已登录；
- 应用重新进入认证后路由，用户回到之前所在的页面（如 `/settings/connection`）。

如果登录成功后有额外重定向需求，可在 `LoginModal` 或 `App.tsx` 中按业务实现。

### 10.5 可访问性

- 侧边栏/顶部 Tab 包裹在 `<nav aria-label="设置导航">`。
- `NavLink` 自动处理 `aria-current="page"`。
- 进入设置页后，通过 `useEffect` 将焦点移动到页面主标题，避免焦点停留在触发按钮。
- 保存按钮和返回按钮保持清晰的 focus 样式。

### 10.6 页面标题

- `/settings/profile` → "设置 - 个人资料 | coqi-claw"
- `/settings/appearance` → "设置 - 外观 | coqi-claw"
- `/settings/connection` → "设置 - 连接 | coqi-claw"
- 通过 `useEffect` + `document.title` 在子路由组件中设置。

## 11. 迁移计划

1. **安装依赖**：`cd web && npm install react-router-dom`。
2. **新增认证后共享布局**：`web/src/components/AuthenticatedLayout.tsx`（包含 `ToastContainer`、`useWebSocket`）。
3. **改造 `App.tsx`**（或 `main.tsx`）：引入 `BrowserRouter`，配置 `/` 和 `/settings/*` 路由，统一由 `AuthenticatedLayout` 包裹。
4. **改造 `ChatLayout.tsx`**：
   - 移除 `ToastContainer` 和 `SettingsPanel`。
   - 把打开设置的入口从 `setSettingsOpen(true)` 改为 `navigate('/settings/profile')`。
5. **改造 `Sidebar` 设置入口**：从 `setSettingsOpen(true)` 改为 `navigate('/settings/profile')`。
6. **新增设置页组件**：
   - `components/settings/SettingsPage.tsx`
   - `components/settings/SettingsSidebar.tsx`
   - `components/settings/SettingsNavItem.tsx`
7. **新增子路由包装组件**：
   - `components/settings/ProfilePage.tsx`（内部调用 `useSettingsForm`，包含保存/取消/未保存拦截）
   - `components/settings/AppearancePage.tsx`
   - `components/settings/ConnectionPage.tsx`（内部读取 `connectionStatus`）
8. **改造 `useSettingsForm.ts`**：
   - `onClose` → `onSaved`。
   - 无变更保存时不再调用 `onSaved`。
   - `useEffect` 同步 `userProfile` 时增加 `if (submitting) return;`。
9. **改造非 React 模块错误跳转**：
   - `web/src/api/websocket.ts:182`（WS 1008）`setSettingsOpen(true)` → `useAuthStore.getState().setAuthenticated(false)`。
   - `web/src/api/websocket.ts:295`（API Key 错误）`setSettingsOpen(true)` → `useAuthStore.getState().setAuthenticated(false)`。
   - `web/src/api/rest.ts:72`（REST 401）`setSettingsOpen(true)` → `useAuthStore.getState().setAuthenticated(false)`。
   - `web/src/api/rest.ts:171`（上传 401）`setSettingsOpen(true)` → `useAuthStore.getState().setAuthenticated(false)`。
10. **移除/废弃**：
    - `components/SettingsPanel.tsx` 删除。
    - `useUIStore` 中的 `settingsOpen` / `setSettingsOpen` 删除。
    - `types/store.ts` 中相关类型删除。
11. **实现脏表单离开拦截**：在 `ProfilePage.tsx` 中使用 `useBlocker`。
12. **实现可访问性细节**：`aria-label`、焦点管理、`document.title`。
13. **测试验证**（详见第 15 节手动验证清单）。

## 12. 风险与注意事项

| 风险 | 缓解措施 |
|---|---|
| 引入路由库增加包体积 | `react-router-dom` v7 树摇良好，实际增量小；如介意可改用 `wouter` |
| `useSettingsForm` 的 `useEffect` 重置问题 | 已补充 `if (submitting) return;` 保护 |
| 移动端顶部 Tab 与现有聊天侧边栏冲突 | 设置页为独立全屏页面，不渲染 ChatLayout 的会话侧边栏 |
| 深链访问 /settings 时未登录 | 复用 App.tsx 现有的认证守卫；或把 `BrowserRouter` 上提到 `main.tsx` |
| API Key / 401 错误未触发登录框 | 非 React 模块统一调用 `useAuthStore.setAuthenticated(false)` |
| Toast 在设置页不显示 | 上提 `ToastContainer` 到 `AuthenticatedLayout` |
| 未保存离开导致数据丢失 | 使用 `useBlocker` 拦截 |

## 13. 待确认问题（均已确认）

1. **保存成功后是留在设置页还是返回聊天页？** → 确认：留在设置页并 toast 成功。
2. **是否需要保留从设置页返回聊天页的“返回”按钮？** → 确认：保留。
3. **`SettingsPanel` 是彻底删除还是暂时保留代码？** → 确认：删除，由 git 历史保留。
4. **API Key / 连接类错误（401、WS 1008 等）跳转到哪里？** → 确认：跳转到系统登录对话框，登录成功后自动写入 API Key。

## 14. 变更文件清单

- `web/package.json` — 新增 `react-router-dom`
- `web/src/main.tsx` 或 `web/src/App.tsx` — 引入 `BrowserRouter`
- `web/src/App.tsx` — 认证守卫 + `AuthenticatedLayout` 路由
- `web/src/components/AuthenticatedLayout.tsx` — 新增：共享布局（ToastContainer + useWebSocket）
- `web/src/components/ChatLayout.tsx` — 移除 `ToastContainer` 和 `SettingsPanel`；修改设置入口为 `navigate('/settings/profile')`
- `web/src/components/sidebar/Sidebar.tsx` — 修改设置入口为 `navigate('/settings/profile')`
- `web/src/components/settings/SettingsPage.tsx` — 新增：设置页外壳
- `web/src/components/settings/SettingsSidebar.tsx` — 新增：左侧导航
- `web/src/components/settings/SettingsNavItem.tsx` — 新增：导航项
- `web/src/components/settings/ProfilePage.tsx` — 新增：个人资料子路由
- `web/src/components/settings/AppearancePage.tsx` — 新增：外观子路由
- `web/src/components/settings/ConnectionPage.tsx` — 新增：连接子路由
- `web/src/hooks/useSettingsForm.ts` — `onClose` → `onSaved`，增加提交期间保护
- `web/src/components/SettingsPanel.tsx` — 删除
- `web/src/stores/ui-store.ts` — 移除 `settingsOpen` / `setSettingsOpen`
- `web/src/types/store.ts`（如有 ui-store 类型定义）— 移除相关类型

## 15. 手动验证清单

- [ ] 从聊天页点击头像/设置按钮进入 `/settings/profile`。
- [ ] 直接访问 `/settings` 自动重定向到 `/settings/profile`。
- [ ] 直接访问 `/settings/appearance`、`/settings/connection` 正常渲染。
- [ ] 未登录时直接访问 `/settings` 被拦截到登录页。
- [ ] onboarding 期间访问 `/settings/profile`，完成 onboarding 后回到聊天页 `/`。
- [ ] 在 `/settings/profile` 修改姓名后点击保存，toast 成功，页面停留。
- [ ] 在 `/settings/profile` 修改姓名后未保存点击浏览器返回，弹出确认提示。
- [ ] 在 `/settings/profile` 修改姓名后点击侧边栏“外观”，弹出确认提示。
- [ ] 移动端访问设置页，顶部 Tab 可横向切换。
- [ ] 刷新 `/settings/appearance` 后仍停留在外观页。
- [ ] 触发 API Key 错误时，页面跳转到系统登录对话框。
- [ ] 设置页保存失败后 toast 错误提示。
- [ ] 桌面端侧边栏 active 状态与右侧内容一致。
