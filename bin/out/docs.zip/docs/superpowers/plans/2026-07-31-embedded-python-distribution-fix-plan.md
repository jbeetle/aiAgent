# 内嵌 Python 发布问题修复实施计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 补齐 CoQiClaw 内嵌 Python 发布相关缺陷：PATH 顺序、错误输出挂载、缺包 hint、依赖烘焙脚本、pip launcher 修复、python-ptc 解析、site 启用、venv 边界。

**Architecture:** 小范围修改核心启动/执行路径 + 新增独立工具脚本；失败不阻断；离线优先。

**Tech Stack:** Node.js 22+ ESM (`"type": "module"`), `child_process`, embedded Python 3.14 in `plugins/python/`.

## Global Constraints

- 所有代码文件必须是 ESM；使用 `node --check <file>` 做基础语法验证。
- **不**在本次实际安装第三方包到 `plugins/python/Lib/site-packages`（仅建脚本/流程，实际烘焙放到打包机）。
- 离线优先：pip 安装使用 `--no-index --find-links=wheels`。
- 首启 `ensurePipLaunchers()` 失败仅 `logger.warn`，不阻断应用启动。
- 项目无统一测试框架，验证使用既有 `test/*.js` + 手动 smoke test。
- 保持最小变更原则；新增文件独立可测，不重构无关代码。

---

## File Structure

**修改文件：**
- `src/bootstrap/manager.js` — PATH append + 调用 `ensurePipLaunchers()`
- `src/tools/exec-common/process.js` — 失败时把 stdout/stderr 挂到 error
- `src/utils/shell-utils.js` — 新增并导出 `buildDependencyHint()`
- `src/tools/exec-common/formatter.js` — 失败结果注入 `hint`
- `src/tools/python-ptc/helpers.js` — `findPythonExecutable()` 优先绝对路径
- `plugins/python/python314._pth` — 取消 `import site` 注释
- `src/tools/skill-python.js` — 创建 venv 前检测 `ensurepip`
- `scripts/setup-skill-venv.js` — 检测到内嵌 Python 时提前退出并提示
- `package.json` — 新增 `"prepare:wheels"` 脚本

**新增文件：**
- `src/utils/python-package-map.js` — import 名 → pip 包名共享映射
- `src/bootstrap/python-launchers.js` — `ensurePipLaunchers()`
- `scripts/collect-skill-python-deps.js` — 依赖聚合扫描器
- `scripts/download-runtime-wheels.js` — 离线 whl 下载器

---

### Task 1: 共享 import → pip 包名映射模块

**Files:**
- Create: `src/utils/python-package-map.js`
- Modify: `scripts/setup-skill-venv.js`（复用该模块，删除本地映射表）

**Interfaces:**
- Produces: `PYTHON_PACKAGE_MAP` (Map<string, string>), `STDLIB_MODULES` (Set<string>)

- [ ] **Step 1: 创建 `src/utils/python-package-map.js`**

```javascript
/**
 * Python import 名到 pip 包名的共享映射，以及常用标准库集合。
 */

export const PYTHON_PACKAGE_MAP = new Map([
  ['fitz', 'pymupdf'],
  ['PIL', 'Pillow'],
  ['cv2', 'opencv-python'],
  ['yaml', 'pyyaml'],
  ['bs4', 'beautifulsoup4'],
  ['sklearn', 'scikit-learn'],
  ['dateutil', 'python-dateutil'],
  ['dotenv', 'python-dotenv'],
  ['markdown', 'Markdown'],
  ['pandas', 'pandas'],
  ['numpy', 'numpy'],
  ['matplotlib', 'matplotlib'],
  ['requests', 'requests'],
  ['openpyxl', 'openpyxl'],
  ['docx', 'python-docx'],
  ['pptx', 'python-pptx'],
  ['pdfplumber', 'pdfplumber'],
  ['reportlab', 'reportlab'],
  ['jinja2', 'Jinja2'],
  ['flask', 'Flask'],
  ['click', 'click'],
  ['rich', 'rich'],
  ['tqdm', 'tqdm'],
  ['lxml', 'lxml'],
  ['chardet', 'chardet'],
  ['camelot', 'camelot-py'],
  ['tabula', 'tabula-py'],
  ['xlrd', 'xlrd'],
  ['xlsxwriter', 'XlsxWriter'],
  ['pypdf', 'pypdf'],
  ['pikepdf', 'pikepdf'],
  ['httpx', 'httpx'],
  ['jieba', 'jieba'],
  ['wordcloud', 'wordcloud'],
  ['pytest', 'pytest'],
  ['defusedxml', 'defusedxml'],
]);

export function importToPackage(importName) {
  return PYTHON_PACKAGE_MAP.get(importName) || importName.toLowerCase();
}

// 注意：把 scripts/setup-skill-venv.js 中的完整 STDLIB 列表原样复制到这里，
// 避免把 stdlib 误判为第三方依赖。本处省略以保持计划简洁。
export const STDLIB_MODULES = new Set([
  // 复制 setup-skill-venv.js 中的完整 STDLIB 列表
]);
```

- [ ] **Step 2: 修改 `scripts/setup-skill-venv.js` 复用映射表**

删除文件中的 `IMPORT_TO_PACKAGE` 对象，改为：

```javascript
import { importToPackage, STDLIB_MODULES } from '../src/utils/python-package-map.js';
```

并把 `STDLIB.has(mod)` 改为 `STDLIB_MODULES.has(mod)`，`toPipPackage(importName)` 改为 `importToPackage(importName)`。

- [ ] **Step 3: 语法检查**

```bash
node --check src/utils/python-package-map.js
node --check scripts/setup-skill-venv.js
```

- [ ] **Step 4: 运行 setup-skill-venv 验证映射未破坏**

```bash
node scripts/setup-skill-venv.js skills/resume-analyzer --dry-run
```

Expected: 正常输出第三方依赖列表，无 `importToPackage is not defined` 等错误。

- [ ] **Step 5: Commit**

```bash
git add src/utils/python-package-map.js scripts/setup-skill-venv.js
git commit -m "refactor: extract python import-to-package map for reuse"
```

---

### Task 2: 修复 PATH 前置问题

**Files:**
- Modify: `src/bootstrap/manager.js:196-208`

**Interfaces:**
- No new exports.

- [ ] **Step 1: 修改 PATH 为 append**

当前代码：

```javascript
process.env.PATH = paths.join(path.delimiter) + path.delimiter + (process.env.PATH || '');
logger.info(`Embedded Python runtime detected at ${pythonDir}, prepended to PATH`);
```

改为：

```javascript
process.env.PATH = (process.env.PATH || '') + path.delimiter + paths.join(path.delimiter);
logger.info(`Embedded Python runtime detected at ${pythonDir}, appended to PATH`);
```

- [ ] **Step 2: 语法检查**

```bash
node --check src/bootstrap/manager.js
```

- [ ] **Step 3: 手动 smoke test**

```bash
npm start
```

Expected: 启动日志出现 `"appended to PATH"`；`process.env.PATH` 中系统 Python 路径出现在 `plugins/python` 之前。

- [ ] **Step 4: Commit**

```bash
git add src/bootstrap/manager.js
git commit -m "fix: append embedded python to PATH instead of prepending"
```

---

### Task 3: exec 失败时挂载 stdout/stderr

**Files:**
- Modify: `src/tools/exec-common/process.js:20-34`

**Interfaces:**
- No signature change; `execWithPid` reject 的 error 对象新增 `stdout`/`stderr` 属性。

- [ ] **Step 1: 修改失败回调**

```javascript
const child = exec(command, options, (error, stdout, stderr) => {
  if (error) {
    error._childPid = child.pid;
    error.stdout = stdout;
    error.stderr = stderr;
    reject(error);
  } else {
    resolve({ stdout, stderr });
  }
});
```

- [ ] **Step 2: 语法检查**

```bash
node --check src/tools/exec-common/process.js
```

- [ ] **Step 3: 运行既有测试**

```bash
node test/test-exec-skill.js
node test/test-exec-policy.js
```

Expected: 不引入回归。

- [ ] **Step 4: Commit**

```bash
git add src/tools/exec-common/process.js
git commit -m "fix: attach stdout/stderr to exec error for LLM visibility"
```

---

### Task 4: 新增 buildDependencyHint

**Files:**
- Modify: `src/utils/shell-utils.js`

**Interfaces:**
- Produces: `buildDependencyHint(stdout: string, stderr: string): string | null`

- [ ] **Step 1: 在 `shell-utils.js` 末尾新增函数**

```javascript
/**
 * 从命令输出中提取依赖缺失信息，返回装包提示。
 * @param {string} stdout
 * @param {string} stderr
 * @returns {string|null}
 */
export function buildDependencyHint(stdout, stderr) {
  const text = `${stdout || ''}\n${stderr || ''}`;

  // Python ModuleNotFoundError
  const pyMatch = text.match(/ModuleNotFoundError:\s*No module named ['"]([^'"]+)['"]/i);
  if (pyMatch) {
    const mod = pyMatch[1];
    // Map common mismatched names
    const pkgMap = {
      dotenv: 'python-dotenv',
      PIL: 'Pillow',
      fitz: 'pymupdf',
      yaml: 'pyyaml',
      bs4: 'beautifulsoup4',
      cv2: 'opencv-python',
      sklearn: 'scikit-learn',
      dateutil: 'python-dateutil',
    };
    const pkg = pkgMap[mod] || mod.toLowerCase();
    return `Python module "${mod}" is missing. Try: python -m pip install ${pkg}`;
  }

  // Node CJS: Cannot find module 'xxx'
  const cjsMatches = [...text.matchAll(/Cannot find module ['"]([^'"]+)['"]/g)];
  for (const m of cjsMatches) {
    const name = m[1];
    if (name.startsWith('node:')) continue;
    if (name.startsWith('.')) continue;
    if (name.startsWith('/')) continue;
    const pkg = name.startsWith('@') ? name.split('/').slice(0, 2).join('/') : name.split('/')[0];
    return `Node module "${pkg}" is missing. Try: npm install ${pkg}`;
  }

  // Node ESM: Cannot find package 'xxx'
  const esmMatches = [...text.matchAll(/Cannot find package ['"]([^'"]+)['"]/g)];
  for (const m of esmMatches) {
    const name = m[1];
    if (name.startsWith('node:')) continue;
    if (name.startsWith('.')) continue;
    const pkg = name.startsWith('@') ? name.split('/').slice(0, 2).join('/') : name.split('/')[0];
    return `Node package "${pkg}" is missing. Try: npm install ${pkg}`;
  }

  return null;
}
```

- [ ] **Step 2: 语法检查**

```bash
node --check src/utils/shell-utils.js
```

- [ ] **Step 3: 临时手动验证**

```bash
node -e "import('./src/utils/shell-utils.js').then(m => console.log(m.buildDependencyHint('', \"ModuleNotFoundError: No module named 'dotenv'\")))"
```

Expected: 输出包含 `python -m pip install python-dotenv` 的提示。

- [ ] **Step 4: Commit**

```bash
git add src/utils/shell-utils.js
git commit -m "feat: add buildDependencyHint for Python/Node missing packages"
```

---

### Task 5: formatter 注入 hint

**Files:**
- Modify: `src/tools/exec-common/formatter.js:188-214`

**Interfaces:**
- Consumes: `buildDependencyHint(stdout, stderr)` from `src/utils/shell-utils.js`

- [ ] **Step 1: 在 formatter.js 顶部引入**

```javascript
import { buildDependencyHint } from '../../utils/shell-utils.js';
```

- [ ] **Step 2: 在 `formatError` 的 JSON 分支注入 hint**

在 `formatError` 中 `jsonResult` 构建完成后、返回前添加：

```javascript
const hint = buildDependencyHint(error.stdout, error.stderr);
if (hint) {
  jsonResult.hint = hint;
}
```

注意：基于未截断的 `error.stdout`/`error.stderr` 检测，在 `processOutput` 之前或之后均可，只要传入原始值。

- [ ] **Step 3: 语法检查**

```bash
node --check src/tools/exec-common/formatter.js
```

- [ ] **Step 4: 运行既有测试**

```bash
node test/test-exec-skill.js
node test/test-exec-policy.js
```

- [ ] **Step 5: Commit**

```bash
git add src/tools/exec-common/formatter.js
git commit -m "feat: inject dependency hint into failed command output"
```

---

### Task 6: 创建依赖聚合脚本

**Files:**
- Create: `scripts/collect-skill-python-deps.js`

**Interfaces:**
- CLI: `node scripts/collect-skill-python-deps.js [skills-dir] [-o requirements.txt]`

- [ ] **Step 1: 创建脚本**

```javascript
#!/usr/bin/env node
/**
 * 扫描所有技能，聚合 Python 第三方依赖。
 * 输出去重后的 pip requirements 清单。
 */

import fs from 'fs';
import path from 'path';
import { importToPackage, STDLIB_MODULES } from '../src/utils/python-package-map.js';

const IS_WIN = process.platform === 'win32';

function parseArgs(argv) {
  let skillsDir = 'skills';
  let output = null;
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '-o' || argv[i] === '--output') {
      output = argv[++i];
    } else if (!argv[i].startsWith('-')) {
      skillsDir = argv[i];
    }
  }
  return { skillsDir: path.resolve(skillsDir), output };
}

function findPythonFiles(dir) {
  const files = [];
  if (!fs.existsSync(dir)) return files;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      files.push(...findPythonFiles(full));
    } else if (entry.name.endsWith('.py')) {
      files.push(full);
    }
  }
  return files;
}

function parseImports(filePath) {
  const content = fs.readFileSync(filePath, 'utf-8');
  const imports = new Set();
  const patterns = [
    /^\s*import\s+([\w.]+)/gm,
    /^\s*from\s+([\w.]+)\s+import\s+/gm,
  ];
  for (const pattern of patterns) {
    let match;
    while ((match = pattern.exec(content)) !== null) {
      imports.add(match[1].split('.')[0]);
    }
  }
  return [...imports];
}

function isLocalModule(moduleName, scriptsDir) {
  const candidates = [
    path.join(scriptsDir, `${moduleName}.py`),
    path.join(scriptsDir, moduleName),
    path.join(scriptsDir, 'lib', `${moduleName}.py`),
    path.join(scriptsDir, 'lib', moduleName),
    path.join(scriptsDir, 'utils', `${moduleName}.py`),
    path.join(scriptsDir, 'utils', moduleName),
  ];
  return candidates.some((c) => fs.existsSync(c));
}

function parseRequirements(filePath) {
  if (!fs.existsSync(filePath)) return [];
  return fs
    .readFileSync(filePath, 'utf-8')
    .split('\n')
    .map((l) => l.trim())
    .filter((l) => l && !l.startsWith('#'));
}

function main() {
  const { skillsDir, output } = parseArgs(process.argv.slice(2));

  if (!fs.existsSync(skillsDir)) {
    console.error(`Skills directory not found: ${skillsDir}`);
    process.exit(1);
  }

  const deps = new Set();

  for (const skillName of fs.readdirSync(skillsDir)) {
    const skillDir = path.join(skillsDir, skillName);
    if (!fs.statSync(skillDir).isDirectory()) continue;

    // requirements.txt
    const reqPath = path.join(skillDir, 'requirements.txt');
    for (const pkg of parseRequirements(reqPath)) {
      deps.add(pkg);
    }

    // .py imports
    const scriptsDir = path.join(skillDir, 'scripts');
    for (const pyFile of findPythonFiles(scriptsDir)) {
      for (const mod of parseImports(pyFile)) {
        if (STDLIB_MODULES.has(mod)) continue;
        if (isLocalModule(mod, scriptsDir)) continue;
        deps.add(importToPackage(mod));
      }
    }
  }

  const sorted = [...deps].sort();
  const text = sorted.join('\n') + '\n';

  if (output) {
    fs.mkdirSync(path.dirname(output), { recursive: true });
    fs.writeFileSync(output, text);
    console.log(`Wrote ${sorted.length} packages to ${output}`);
  } else {
    process.stdout.write(text);
  }
}

main();
```

- [ ] **Step 2: 语法检查**

```bash
node --check scripts/collect-skill-python-deps.js
```

- [ ] **Step 3: 运行脚本验证**

```bash
node scripts/collect-skill-python-deps.js skills/ -o /tmp/coqi-python-deps.txt
cat /tmp/coqi-python-deps.txt
```

Expected: 文件包含从 `skills/**/requirements.txt` 和 `.py` import 中提取的第三方包，无重复，按字母排序。

- [ ] **Step 4: Commit**

```bash
git add scripts/collect-skill-python-deps.js
git commit -m "feat: add skill python dependency aggregator"
```

---

### Task 7: 创建离线 whl 下载脚本

**Files:**
- Create: `scripts/download-runtime-wheels.js`

**Interfaces:**
- CLI: `node scripts/download-runtime-wheels.js [--requirements <file>]`

- [ ] **Step 1: 创建脚本**

```javascript
#!/usr/bin/env node
/**
 * 下载内嵌 Python 运行所需的 whl 包到 plugins/python/wheels/。
 * 打包机执行，客户机离线场景依赖这些 whl 做首启修复。
 */

import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import { getBaseDir } from '../src/utils/paths.js';

const IS_WIN = process.platform === 'win32';

function parseArgs(argv) {
  let requirements = null;
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '-r' || argv[i] === '--requirements') {
      requirements = path.resolve(argv[++i]);
    }
  }
  return { requirements };
}

function getEmbeddedPython() {
  const base = getBaseDir();
  return IS_WIN
    ? path.join(base, 'plugins', 'python', 'python.exe')
    : path.join(base, 'plugins', 'python', 'bin', 'python3');
}

function downloadWheels(pythonExe, wheelsDir, args) {
  fs.mkdirSync(wheelsDir, { recursive: true });

  // Always download pip itself first
  console.log('Downloading pip wheel...');
  execSync(
    `"${pythonExe}" -m pip download pip -d "${wheelsDir}"`,
    { stdio: 'inherit', timeout: 300000 }
  );

  if (args.requirements && fs.existsSync(args.requirements)) {
    console.log(`Downloading requirements from ${args.requirements}...`);
    execSync(
      `"${pythonExe}" -m pip download -r "${args.requirements}" -d "${wheelsDir}"`,
      { stdio: 'inherit', timeout: 600000 }
    );
  }
}

function main() {
  const pythonExe = getEmbeddedPython();
  if (!fs.existsSync(pythonExe)) {
    console.error(`Embedded Python not found: ${pythonExe}`);
    process.exit(1);
  }

  const wheelsDir = path.join(path.dirname(pythonExe), 'wheels');
  const args = parseArgs(process.argv.slice(2));

  const defaultReq = path.join(path.dirname(pythonExe), 'requirements.txt');
  if (!args.requirements && fs.existsSync(defaultReq)) {
    args.requirements = defaultReq;
  }

  try {
    downloadWheels(pythonExe, wheelsDir, args);
    console.log(`Wheels saved to ${wheelsDir}`);
  } catch (e) {
    console.error('Failed to download wheels:', e.message);
    process.exit(1);
  }
}

main();
```

- [ ] **Step 2: 语法检查**

```bash
node --check scripts/download-runtime-wheels.js
```

- [ ] **Step 3: 运行脚本验证（只下载 pip）**

```bash
node scripts/download-runtime-wheels.js
ls plugins/python/wheels/
```

Expected: 目录存在且包含 `pip-*.whl`。

- [ ] **Step 4: `package.json` 新增脚本**

```json
"prepare:wheels": "node scripts/download-runtime-wheels.js"
```

- [ ] **Step 5: 语法/配置检查**

```bash
node --check scripts/download-runtime-wheels.js
npm run prepare:wheels
```

- [ ] **Step 6: Commit**

```bash
git add scripts/download-runtime-wheels.js package.json
git commit -m "feat: add offline wheel downloader and prepare:wheels script"
```

---

### Task 8: 创建 pip launcher 首启修复模块

**Files:**
- Create: `src/bootstrap/python-launchers.js`
- Modify: `src/bootstrap/manager.js`（调用 `ensurePipLaunchers`）

**Interfaces:**
- Produces: `ensurePipLaunchers(pythonDir: string): void`

- [ ] **Step 1: 创建 `src/bootstrap/python-launchers.js`**

```javascript
/**
 * 内嵌 Python pip 启动器修复。
 * Windows 下 Scripts/*.exe 启动器可能烧录了打包机绝对路径，
 * 目录迁移后失效。首启时检测并离线重建。
 */

import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import { logger } from '../utils/logger.js';

const IS_WIN = process.platform === 'win32';

/**
 * 从 exe 启动器尾部读取 shebang 指向的 python 路径。
 * 不同 pip 版本格式不同：可能是 utf-16-le 的绝对路径，也可能是 PATH 模式。
 * @param {string} exePath
 * @returns {string|null}
 */
function extractShebangPython(exePath) {
  try {
    const data = fs.readFileSync(exePath);
    const block = data.slice(Math.max(0, data.length - 4096));

    // Try UTF-16-LE shebang (common for old pip launchers)
    const utf16 = block.toString('utf-16le');
    const shebang16 = utf16.match(/#!\s*(.+\.exe)/i);
    if (shebang16) return shebang16[1].trim().replace(/\0/g, '');

    // Try latin-1 fallback
    const latin = block.toString('latin-1');
    const shebangLatin = latin.match(/#!\s*(.+\.exe)/i);
    if (shebangLatin) return shebangLatin[1].trim().replace(/\0/g, '');
  } catch (e) {
    logger.warn(`Failed to read shebang from ${exePath}: ${e.message}`);
  }
  return null;
}

function findPipWheel(wheelsDir) {
  if (!fs.existsSync(wheelsDir)) return null;
  const wheels = fs.readdirSync(wheelsDir).filter((f) => /^pip-.+\.whl$/i.test(f));
  return wheels.length ? path.join(wheelsDir, wheels[0]) : null;
}

export function ensurePipLaunchers(pythonDir) {
  if (!IS_WIN) return; // Linux launchers are typically shell scripts with relative paths

  const scriptsDir = path.join(pythonDir, 'Scripts');
  const pythonExe = path.join(pythonDir, 'python.exe');
  const wheelsDir = path.join(pythonDir, 'wheels');

  if (!fs.existsSync(scriptsDir) || !fs.existsSync(pythonExe)) return;

  const pipExe = path.join(scriptsDir, 'pip.exe');
  if (!fs.existsSync(pipExe)) {
    logger.warn(`pip.exe not found at ${pipExe}, skipping launcher check`);
    return;
  }

  const shebangPath = extractShebangPython(pipExe);
  const expectedPath = path.resolve(pythonExe);

  // If shebang points to the current python or is PATH-based, nothing to do
  if (!shebangPath || shebangPath.toLowerCase() === expectedPath.toLowerCase()) {
    logger.debug('pip launcher shebang looks correct');
    return;
  }

  logger.warn(
    `pip launcher shebang mismatch: expected ${expectedPath}, found ${shebangPath}. Rebuilding...`
  );

  const pipWheel = findPipWheel(wheelsDir);
  if (!pipWheel) {
    logger.warn(`No pip wheel found in ${wheelsDir}, cannot rebuild launchers offline`);
    return;
  }

  try {
    execSync(
      `"${pythonExe}" -m pip install --force-reinstall --no-index --find-links="${wheelsDir}" pip`,
      { stdio: 'pipe', timeout: 120000, windowsHide: true }
    );
    logger.info('pip launchers rebuilt successfully');
  } catch (e) {
    logger.warn(`Failed to rebuild pip launchers: ${e.message}`);
  }
}
```

- [ ] **Step 2: 在 `manager.js` 中调用**

在 `initializeSystem()` 中 PATH 修改之后、`initWindowsEncoding()` 之前引入并调用：

```javascript
import { ensurePipLaunchers } from './python-launchers.js';
```

在 PATH 修改代码之后添加：

```javascript
ensurePipLaunchers(pythonDir);
```

- [ ] **Step 3: 语法检查**

```bash
node --check src/bootstrap/python-launchers.js
node --check src/bootstrap/manager.js
```

- [ ] **Step 4: 手动 smoke test**

```bash
npm start
```

Expected: 启动正常；若 shebang 匹配则输出 debug；若不匹配且有 whl 则尝试重建。

- [ ] **Step 5: Commit**

```bash
git add src/bootstrap/python-launchers.js src/bootstrap/manager.js
git commit -m "feat: ensure pip launchers point to current embedded python on startup"
```

---

### Task 9: python-ptc 优先使用内嵌 Python 绝对路径

**Files:**
- Modify: `src/tools/python-ptc/helpers.js:317-360`

**Interfaces:**
- `findPythonExecutable(): Promise<string | null>` 行为改变：优先返回内嵌解释器绝对路径。

- [ ] **Step 1: 修改查找逻辑**

在 `findPythonExecutable()` 开头、缓存检查之后加入：

```javascript
// Prefer embedded Python absolute path so PATH order does not affect us.
const baseDir = process.cwd(); // or use getBaseDir() if available
const embedded = IS_WINDOWS
  ? path.join(baseDir, 'plugins', 'python', 'python.exe')
  : path.join(baseDir, 'plugins', 'python', 'bin', 'python3');

if (fs.existsSync(embedded)) {
  _cachedPythonPath = embedded;
  _cachedAt = Date.now();
  return _cachedPythonPath;
}
```

注意：需要在该文件顶部引入 `fs` 和 `path`（当前已引入 `path`，`fs` 未引入，需添加）。

由于 `helpers.js` 在 `src/tools/python-ptc/` 目录，`getBaseDir()` 在 `../../utils/paths.js`，可使用：

```javascript
import { getBaseDir } from '../../utils/paths.js';
```

并把 `baseDir` 改为 `getBaseDir()`。

- [ ] **Step 2: 语法检查**

```bash
node --check src/tools/python-ptc/helpers.js
```

- [ ] **Step 3: 运行既有测试**

```bash
node test/test-python-ptc.js
```

Expected: 不引入回归。

- [ ] **Step 4: Commit**

```bash
git add src/tools/python-ptc/helpers.js
git commit -m "fix: python_ptc prefers embedded python absolute path over PATH"
```

---

### Task 10: 启用 `python._pth` 的 `import site`

**Files:**
- Modify: `plugins/python/python314._pth`

**Interfaces:**
- No code interface change.

- [ ] **Step 1: 取消注释**

当前内容：

```text
python314.zip
.

# Uncomment to run site.main() automatically
import site
```

改为：

```text
python314.zip
.

# Enable site-packages initialization
import site
```

- [ ] **Step 2: 验证内嵌 Python 仍正常**

```bash
./plugins/python/python.exe -c "import sys; print('site-packages' in str(sys.path))"
./plugins/python/python.exe -m pip --version
```

Expected: 两条命令均成功。

- [ ] **Step 3: Commit**

```bash
git add plugins/python/python314._pth
git commit -m "fix: enable import site in embedded python for proper site-packages"
```

---

### Task 11: skill-python 检测 ensurepip

**Files:**
- Modify: `src/tools/skill-python.js`

**Interfaces:**
- No new exports; `ensureAutoVenv()` 在解释器不支持 ensurepip 时抛出清晰错误。

- [ ] **Step 1: 新增 ensurepip 检测函数**

在文件中加入：

```javascript
function supportsEnsurepip(pythonPath) {
  try {
    // Use -c "import ensurepip" so it works with commands like "py -3" on Windows.
    execSync(`${pythonPath} -c "import ensurepip"`, {
      stdio: 'pipe', timeout: 10000, windowsHide: true,
    });
    return true;
  } catch {
    return false;
  }
}
```

- [ ] **Step 2: 在 `ensureAutoVenv` 开头检测**

```javascript
function ensureAutoVenv(skillName, reqPath) {
  const base = getAutoVenvBaseDir();
  const venvDir = path.join(base, skillName);
  const hashFilePath = path.join(base, `${skillName}.hash`);

  const sysPy = findSystemPython();
  if (!supportsEnsurepip(sysPy)) {
    throw Errors.unknown(
      `The selected Python interpreter "${sysPy}" does not support ensurepip. ` +
      'This is typical for the embedded Python runtime. ' +
      'Install a full system Python or pre-build skills/<name>/.venv manually.',
      { skillName, pythonPath: sysPy }
    );
  }

  // ... rest of function
```

- [ ] **Step 3: 语法检查**

```bash
node --check src/tools/skill-python.js
```

- [ ] **Step 4: Commit**

```bash
git add src/tools/skill-python.js
git commit -m "fix: detect ensurepip before creating skill venv to avoid silent failure"
```

---

### Task 12: setup-skill-venv.js 内嵌 Python 保护

**Files:**
- Modify: `scripts/setup-skill-venv.js`

**Interfaces:**
- CLI behavior: 若使用内嵌 Python，提前退出并提示。

- [ ] **Step 1: 在 findSystemPython 后增加检测**

在 `const sysPy = findSystemPython();` 之后、`if (!sysPy)` 之前添加：

```javascript
// Detect embedded Python by resolving sys.executable
let resolvedPy = sysPy;
try {
  resolvedPy = execSync(`${sysPy} -c "import sys; print(sys.executable)"`, {
    stdio: 'pipe', timeout: 10000, windowsHide: true, encoding: 'utf-8',
  }).trim();
} catch {
  // keep original
}

if (resolvedPy.toLowerCase().includes('plugins\\python') || resolvedPy.toLowerCase().includes('plugins/python')) {
  console.error('\n❌ 当前使用的是内嵌 Python（plugins/python），不支持创建 venv。');
  console.error('   请使用系统 Python 运行此脚本，例如：');
  console.error('   C:\\Python314\\python.exe scripts/setup-skill-venv.js <skill-dir>');
  process.exit(1);
}
```

- [ ] **Step 2: 语法检查**

```bash
node --check scripts/setup-skill-venv.js
```

- [ ] **Step 3: Commit**

```bash
git add scripts/setup-skill-venv.js
git commit -m "fix: setup-skill-venv refuses to run with embedded python"
```

---

## Self-Review Checklist

- [ ] **Spec coverage**: 设计文档 §3 的每个模块都有对应 Task。
- [ ] **Placeholder scan**: 计划无 TBD/TODO/"实现细节稍后补充" 等模糊描述。
- [ ] **Type consistency**: `buildDependencyHint` 在 Task 4 定义，Task 5 消费；`importToPackage`/`STDLIB_MODULES` 在 Task 1 定义，Task 6 消费；`ensurePipLaunchers` 在 Task 8 定义，`manager.js` 消费。
- [ ] **Import paths**: `src/utils/python-package-map.js` 被 `scripts/setup-skill-venv.js` 和 `scripts/collect-skill-python-deps.js` 引用，路径正确。
- [ ] **平台兼容**: `python-launchers.js` 在 Linux 下直接返回；`download-runtime-wheels.js` 区分 Win/Linux 解释器路径。
