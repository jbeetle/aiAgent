# 设置页改造实现计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 把现有 `SettingsPanel` Modal 弹窗改造为全屏 `/settings` 页面，采用左侧分类导航 + 右侧内容的左右布局，保持现有 3 个设置区块功能不变。

**Architecture:** 引入 `react-router-dom` 嵌套路由；新增 `AuthenticatedLayout` 作为认证后共享布局（ToastContainer + WebSocket）；新增 `SettingsPage` 及子路由包装组件；非 React 模块 API Key / 401 错误触发登录对话框。

**Tech Stack:** React 19, TypeScript, Tailwind CSS v4, Zustand, react-router-dom v7, Vite 6.

**设计文档参考：** `docs/superpowers/specs/2026-07-01-settings-page-redesign-design.md`

---

## 前置约束

- 所有变更在 `web/` 目录下。
- 项目使用 ESM，`web/package.json` 已设 `"type": "module"`。
- 不要修改 `.env`、签名文件或安全策略。
- 变更后用 `node --check` 或 `npx tsc --noEmit` 做基础语法/类型检查（如果后者可用）。

---

## Task 1: 安装 react-router-dom 并验证

**Files:**
- Modify: `web/package.json`

**Steps:**
- [ ] **Step 1: 安装依赖**
  Run: `cd C:/workdir/git/CoQiClaw/web && npm install react-router-dom`
  Expected: package.json 中出现 `react-router-dom` 条目，package-lock.json 更新。

- [ ] **Step 2: 语法验证**
  Run: `node --check web/src/App.tsx` 等已存在的 TSX 文件（不改它们之前先确认环境正常）。

---

## Task 2: 新增 AuthenticatedLayout 共享布局

**Files:**
- Create: `web/src/components/AuthenticatedLayout.tsx`

**要求：**
- 用 `Outlet` 渲染子路由。
- 渲染 `<ToastContainer />`。
- 调用 `useWebSocket()`。
- 用 `useEffect` 更新 `document.title` 基础标题（可选）。
- 导出默认组件。

---

## Task 3: 改造 App.tsx 认证后路由结构

**Files:**
- Modify: `web/src/App.tsx`
- Modify: `web/src/main.tsx`（可选，若选择把 BrowserRouter 上提）

**要求：**
- 在 `App.tsx` 内部引入 `BrowserRouter`、`Routes`、`Route`、`Navigate`。
- `AppAfterLogin` 返回：
  - `/` → `<ChatLayout />`
  - `/settings` → `<Navigate to="/settings/profile" replace />`
  - `/settings/*` → `<SettingsPage />`
  - `*` → `<Navigate to="/" replace />`
- 所有认证后路由由 `AuthenticatedLayout` 包裹（通过 `Route element` 嵌套或每个路由单独包）。
- 保持未登录时渲染 `<LoginModal />` 的逻辑不变。
- Onboarding 完成后调用 `navigate('/')` 回到聊天页（需要 import `useNavigate` 并在 `OnboardingWizard onComplete` 中调用）。

---

## Task 4: 改造 ChatLayout 与 Sidebar 设置入口

**Files:**
- Modify: `web/src/components/ChatLayout.tsx`
- Modify: `web/src/components/sidebar/Sidebar.tsx`

**要求：**
- 从 `ChatLayout.tsx` 移除 `ToastContainer` 和 `SettingsPanel` 的 import 与渲染。
- 把打开设置的入口改为 `const navigate = useNavigate(); navigate('/settings/profile')`。
- 同样修改 `Sidebar.tsx` 中触发 `setSettingsOpen(true)` 的入口。
- 移除或清理 `useUIStore` 中 `settingsOpen` 的使用（如果本任务中仍有引用）。

---

## Task 5: 新增 SettingsPage / SettingsSidebar / SettingsNavItem

**Files:**
- Create: `web/src/components/settings/SettingsPage.tsx`
- Create: `web/src/components/settings/SettingsSidebar.tsx`
- Create: `web/src/components/settings/SettingsNavItem.tsx`

**要求：**
- `SettingsPage`：全屏 `h-screen w-screen flex`，左侧固定 240px，右侧 `Outlet`；移动端渲染顶部 Tab。
- `SettingsSidebar`：渲染“通用”分类 + 3 个导航项；接收 `isMobile?: boolean` 决定渲染为侧边栏或顶部 Tab；外层 `<nav aria-label="设置导航">`。
- `SettingsNavItem`：使用 `NavLink`，props `{ to, label, icon? }`，active 样式明显。
- 复用现有设计令牌（`bg-background`、`border-border`、`text-foreground` 等）。

---

## Task 6: 新增 ProfilePage / AppearancePage / ConnectionPage

**Files:**
- Create: `web/src/components/settings/ProfilePage.tsx`
- Create: `web/src/components/settings/AppearancePage.tsx`
- Create: `web/src/components/settings/ConnectionPage.tsx`

**要求：**
- `ProfilePage`：
  - 内部调用 `useSettingsForm({ onSaved: () => toastSuccess(STR_SETTINGS_SAVE_PROFILE_SUCCESS) })`。
  - 渲染 `SettingsSection` 标题 + `ProfileSection`。
  - 包含保存按钮、取消/返回按钮。
  - 用 `useBlocker` 拦截未保存离开（条件 `isDirty && !submitting`）。
  - 用 `useEffect` 设置 `document.title`。
- `AppearancePage`：渲染 `SettingsSection` 标题 + `AppearanceSection`；设置 `document.title`。
- `ConnectionPage`：从 `useUIStore` 读取 `connectionStatus`，传给 `ConnectionSection`；设置 `document.title`。

---

## Task 7: 改造 useSettingsForm 支持页面化保存

**Files:**
- Modify: `web/src/hooks/useSettingsForm.ts`

**要求：**
- 接口 `UseSettingsFormOptions` 中 `onClose` 重命名为 `onSaved`。
- 保存成功且资料真正变更后调用 `onSaved()`；未变更时静默返回（不调用 `onSaved`）。
- `useEffect` 同步 `userProfile` 时开头增加 `if (submitting) return;`。
- 保存失败仍 toast 错误（保持现有行为）。

---

## Task 8: 改造非 React 模块错误跳转

**Files:**
- Modify: `web/src/api/websocket.ts`
- Modify: `web/src/api/rest.ts`

**要求：**
- 4 处 `useUIStore.getState().setSettingsOpen(true)` 改为 `useAuthStore.getState().setAuthenticated(false)`。
- 确保 import `useAuthStore`。
- 保持其他错误处理逻辑不变。

---

## Task 9: 清理 SettingsPanel 与 ui-store 废弃状态

**Files:**
- Delete: `web/src/components/SettingsPanel.tsx`
- Modify: `web/src/stores/ui-store.ts`
- Modify: `web/src/types/store.ts`（如存在相关类型）

**要求：**
- 删除 `SettingsPanel.tsx`。
- 从 `ui-store.ts` 移除 `settingsOpen` 状态和 `setSettingsOpen` action。
- 从 `types/store.ts` 移除相关类型字段。
- 全量搜索 `settingsOpen`、`setSettingsOpen`、`SettingsPanel`，确保无残留引用。

---

## Task 10: 实现脏表单离开拦截与 a11y 细节

**Files:**
- Modify: `web/src/components/settings/ProfilePage.tsx`
- Modify: `web/src/components/settings/SettingsPage.tsx`

**要求：**
- `ProfilePage` 使用 `useBlocker` 实现未保存离开拦截，弹窗文案复用现有未保存确认字符串或新增。
- `SettingsPage` 进入时将焦点设置到页面主标题（`h1` 或 `h2` 的 `ref.focus()`）。
- 确认 `NavLink` active 状态有视觉区分且 `aria-current` 正确。

---

## Task 11: 构建与手动验证

**Files:**
- 全部上述文件

**Steps:**
- [ ] **Step 1: 类型/语法检查**
  Run: `cd C:/workdir/git/CoQiClaw/web && npx tsc --noEmit`（如果项目配置支持；否则用 `node --check` 检查新建 JS 文件）。
  Expected: 无类型错误。

- [ ] **Step 2: 构建前端**
  Run: `cd C:/workdir/git/CoQiClaw/web && npm run build`
  Expected: 构建成功。

- [ ] **Step 3: 手动验证**
  按设计文档第 15 节手动验证清单逐条验证。

---

## 回滚策略

- 保留 git 工作区干净：每完成 2-3 个 task 后建议提交，方便回滚。
- 若 `react-router-dom` v7 与现有代码冲突，可降级至 v6 兼容模式。
- 若 `useBlocker` 在 v7 data API 下行为异常，可改用 `Prompt` 组件或自定义 `beforeunload` + 路由守卫。
