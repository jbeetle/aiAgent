# coqi-claw src/core/ 代码审查报告

**审查范围**: `src/core/` (HEAD~50..HEAD)  
**审查日期**: 2026-06-02  
**审查标准**: 最高严格度 — 召回优先，宁可误报也不漏报

---

## 严重级别说明

| 级别 | 含义 |
|------|------|
| 🔴 Critical | 会导致功能失效、数据损坏或安全漏洞 |
| 🟠 High | 会导致用户体验问题或资源泄漏 |
| 🟡 Medium | 边界情况下的潜在问题 |
| 🟢 Low | 代码异味或维护性问题 |

---

## 🔴 Critical (5项)

### 1. 工具调用 ID 不匹配 — 多站点随机UUID导致LLM无法匹配

**文件**: `src/core/agent-executor.js`  
**行号**: 206, 247, 425, 478, 523, 568

**问题描述**: 当 LLM 返回的 tool_call 缺少 `id` 时，多个代码路径独立生成 `randomUUID()` 作为回退。这导致同一个 tool_call 在 assistant message、event emission 和 tool response 中获得**不同的 ID**。

```javascript
// 助理消息中的 tool_calls 数组
id: tc.id || `tool_${randomUUID()}`,  // 生成 UUID #1

// tool_call 事件
id: tc.id || `tool_${randomUUID()}`,  // 生成 UUID #2

// 工具响应消息
toolCallId: toolCall.id || `tool_${randomUUID()}`,  // 生成 UUID #3
```

**失败场景**: LLM 省略 tool_call 的 id。Assistant message 存储 `tool_<uuid1>`，tool response 使用 `tool_<uuid2>`。LLM API 要求 `tool_call_id` 必须匹配 assistant 的 `tool_calls[].id`，不匹配会导致对话断裂或 API 拒绝。

**修复建议**: 在 tool_call 处理开始时统一生成一次 fallback ID，所有后续引用使用同一个 ID。

---

### 2. TUI 取消检测失效 — `isAbortError()` 不识别 `ToolError`

**文件**: `src/tui/utils.js:17`, `src/core/agent-executor.js:302`  
**行号**: 15-18 (utils.js), 76-82 (agent-executor.js)

**问题描述**: `AgentExecutor.checkAborted()` 现在抛出 `Errors.cancelled("Agent execution")`，产生 `ToolError` 实例（`name === 'ToolError'`）。但 `isAbortError()` 只检查：

```javascript
// src/tui/utils.js:17
return error.name === 'AbortError' || error.name === 'CanceledError';
```

**失败场景**: 用户在 TUI 中取消操作。`AgentExecutor` 抛出 `ToolError`（`name='ToolError'`, `type='cancelled'`）。`isAbortError()` 返回 `false`。TUI 跳过取消处理分支，显示通用错误消息，且可能错误地删除用户消息。

**修复建议**: 在 `isAbortError()` 中增加对 `error.type === 'cancelled'` 或 `error.name === 'ToolError'` 的检查。

---

### 3. CLI 取消消息字符串不匹配 — 精确匹配失败导致错误退出码

**文件**: `src/cli.js:96`, `src/core/agent-executor.js:78`  
**行号**: 96 (cli.js), 236-237 (errors.js)

**问题描述**: `cli.js` 通过精确字符串匹配检测取消：

```javascript
if (error.message === 'Agent execution cancelled by user') {
```

但 `Errors.cancelled("Agent execution")` 生成消息 `"Agent execution was cancelled"`，与旧字符串不匹配。

**失败场景**: 用户在 CLI 中取消操作。精确字符串匹配失败，CLI 执行 `logger.error()` 并以退出码 1 退出，而不是优雅地以退出码 0 退出。

**修复建议**: 更新 `cli.js` 的消息匹配字符串，或使用 `error.type === 'cancelled'` 进行类型检查。

---

### 4. LLM 客户端取消错误未被识别为中止

**文件**: `src/core/agent-executor.js:302`, `src/core/llm/client.js:364`  
**行号**: 302 (agent-executor.js)

**问题描述**: `agent-executor.js` 的 catch 块检查：

```javascript
if (error.name === "AbortError" || error.isAgentAbort) {
```

但 LLM 客户端（`llm/client.js`）在取消时抛出 `ToolError`（`type === ErrorTypes.CANCELLED`），其 `name` 为 `"ToolError"`，且没有 `isAgentAbort` 标志。

**失败场景**: 用户在 LLM 流式响应期间取消。`withRetry` 抛出 `ToolError(CANCELLED)`。`AgentExecutor` 无法识别为中止，将其包装为 `Errors.unknown()`，显示通用"Agent execution failed"错误。

**修复建议**: 在 abort 检测逻辑中增加 `error.type === ErrorTypes.CANCELLED` 检查。

---

### 5. `contextSummaryMaxLength` 未定义导致摘要功能静默失效

**文件**: `src/core/agent.js:377`  
**行号**: 377

**问题描述**: 修复将硬编码的 `400` 改为 `this.contextSummaryMaxLength`，但如果配置不完整，该值为 `undefined`：

```javascript
const shouldSummarize = this.useLlmContextSummary && answer.length > this.contextSummaryMaxLength;
// answer.length > undefined === false (无论 answer 多长)
```

**失败场景**: 配置省略 `contextSummaryMaxLength`。长答案永远不会被摘要，上下文无限增长直到触发紧急截断或 LLM 拒绝。

**修复建议**: 在 `Agent` 构造函数中为 `contextSummaryMaxLength` 提供默认值（如 400）。

---

## 🟠 High (5项)

### 6. 工具描述缺失导致系统提示构建崩溃

**文件**: `src/core/prompt-builder.js:282`  
**行号**: 281-282

**问题描述**: `buildToolsSection` 中：

```javascript
description.slice(0, 80) + (description.length > 80 ? "..." : "")
```

如果 `getToolDescriptions()` 返回的工具缺少 `description`（如插件工具），`description.slice()` 抛出 `TypeError`。

**失败场景**: 新插件注册时未提供 description。`buildSystemPrompt` 崩溃，Agent 无法启动。

**修复建议**: 添加空值保护：`description?.slice?.(0, 80) ?? ""`。

---

### 7. 中止信号传递给工具但多数工具不消费

**文件**: `src/core/agent-executor.js:460`, `src/tools/index.js:162`  
**行号**: 460 (agent-executor.js)

**问题描述**: `executeTool` 现在接收 `signal` 参数并传递给工具的 `execute(args, { signal })`，但多数工具未实现信号处理。

**失败场景**: 用户取消涉及慢速 `web_fetch` 或 `exec` 的请求。信号已传递但工具忽略，继续执行直到完成，UI 表现为冻结。

**修复建议**: 为关键工具（exec, web_fetch, http_request）添加 AbortSignal 支持，或在文档中明确说明哪些工具支持取消。

---

### 8. `resultPromise` 冗余 `.catch()` 破坏错误身份

**文件**: `src/core/llm/client.js:391`  
**行号**: 391-394

**问题描述**: 

```javascript
result: resultPromise.catch((error) => { throw error; }),
```

这创建了一个新的 Promise 包装器。如果消费者比较 `streamHandle.result === cachedPromise`，会失败。

**失败场景**: 测试代码缓存 `resultPromise` 引用进行断言。包装后的新 Promise 导致严格相等检查失败。

**修复建议**: 直接返回 `resultPromise` 而不包装。

---

### 9. 生成器提前中断导致 `resultPromise` 永久挂起

**文件**: `src/core/llm/client.js:202`  
**行号**: 202-387

**问题描述**: `processStream` 生成器没有 `finally` 块来 settle `resultPromise`。如果消费者提前 break，`resultPromise` 永远 pending。

**失败场景**: `for await` 循环因错误提前退出。生成器被废弃，`resultPromise` 未决，持有生成器闭包和底层 API 流引用，造成内存泄漏。

**修复建议**: 在生成器中添加 `try/finally` 确保 `resultPromise` 被 resolve 或 reject。

---

### 10. `ToolError.toJSON()` 丢失 `cause` 属性

**文件**: `src/utils/errors.js:90-98`, `src/core/agent-executor.js:311-313`  
**行号**: 90-98 (errors.js)

**问题描述**: `ToolError.toJSON()` 不序列化 `cause` 属性。`agent-executor.js` 手动设置 `wrapped.cause = error`，但 `toJSON()` 忽略它。

**失败场景**: 错误通过 `JSON.stringify()` 记录到远程监控系统。原始错误信息丢失，无法追溯根因。

**修复建议**: 在 `toJSON()` 中包含 `cause` 字段。

---

## 🟡 Medium (5项)

### 11. `executeToolCalls` 竞态条件 — pLimit 队列与中止信号

**文件**: `src/core/agent-executor.js:545`  
**行号**: 545-574

**问题描述**: `executeToolCalls` 使用 `pLimit` 并发控制，但不在队列前检查中止状态。工具已入队后即使取消也会执行。

**失败场景**: 5 个工具调用，并发 2。用户取消时工具 3-5 已入队，仍会执行。

**修复建议**: 在 `pLimit` 回调开始时检查 `this.abortController.signal.aborted`。

---

### 12. Web 版 `removeLastUserMessage` 缺少竞态保护

**文件**: `src/gateway/chat-common.js:76`  
**行号**: 76-85

**问题描述**: TUI 版有 `isRemovingMessage` 锁，Web 版没有。

**失败场景**: 并发取消+错误同时调用，可能删除错误的消息。

**修复建议**: 添加与 TUI 相同的锁机制。

---

### 13. `chat-handler.js` 早期返回导致连接状态卡住

**文件**: `src/gateway/chat-handler.js:96`  
**行号**: 96-99, 116-125

**问题描述**: `handleChat` 设置 `connection.isProcessing = true` 后有多个早期返回路径未重置。

**失败场景**: 用户发送到不存在的会话，返回后 `isProcessing` 保持 true，后续有效请求被拒绝。

**修复建议**: 确保所有返回路径重置 `isProcessing`。

---

### 14. 流式 token 循环缺少中止信号检查

**文件**: `src/core/agent-executor.js:157`  
**行号**: 157-164

**问题描述**: `for await` 循环只检查 `this.isDestroyed`，不检查 `this.abortController.signal.aborted`。

**失败场景**: 用户取消后，循环继续消费 token 直到流结束。

**修复建议**: 在循环内部增加 abort 信号检查。

---

### 15. `runWithHistory` 修改调用者的 `messageHistory`

**文件**: `src/core/agent.js:191`  
**行号**: 191-198

**问题描述**: 直接修改 `messageHistory` 数组元素的 `_errorType` 属性。

**失败场景**: 会话管理器的内部数组被污染，影响后续请求。

**修复建议**: 创建消息副本后再修改。

---

## 修复优先级建议

| 优先级 | 修复项 | 影响 |
|--------|--------|------|
| P0 | 修复 #1 (tool_call ID 不匹配) | 核心功能断裂 |
| P0 | 修复 #2 (TUI 取消检测) | 用户体验严重受损 |
| P0 | 修复 #3 (CLI 取消消息) | CLI 退出码错误 |
| P1 | 修复 #4 (LLM 取消识别) | 流式取消失效 |
| P1 | 修复 #5 (摘要默认值) | 上下文管理异常 |
| P1 | 修复 #6 (description 空值) | 系统提示构建崩溃 |
| P2 | 修复 #7-15 | 稳定性与资源管理 |
