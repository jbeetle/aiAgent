# Java 后台技能签名集成方案

## 1. 背景与目标

coqi-claw 采用 Skill Trust 框架对 `skills/` 下的技能目录进行完整性保护。当前签名由 Node.js 脚本 `scripts/skill-sign.js` 在本地或 CI 环境中完成。

本方案旨在将签名能力迁移至 Java 后台，使后台在管理 skill 目录内容的同时，能够直接生成 `.skill-trust` 信任文件，供 Agent 加载时验证。

**核心原则：**
- 签名算法、manifest 结构、输出格式必须与现有 Node.js 脚本**逐字节一致**
- 私钥由后台安全保管，不得泄露、不得硬编码、不得入版本库
- 生成的 `.skill-trust` 必须能被现有 Agent 的 skill-trust 验证模块通过

---

## 2. 密钥信息

| 项目 | 说明 |
|------|------|
| 非对称算法 | RSA |
| 密钥长度 | 4096-bit |
| 私钥格式 | PKCS#8 PEM (`-----BEGIN PRIVATE KEY-----`) |
| 公钥格式 | SPKI PEM (`-----BEGIN PUBLIC KEY-----`) |
| 签名算法 | RSA-SHA256（PKCS#1 v1.5 填充） |
| Key ID | `coqi-claw-internal`（默认值，与策略配置保持一致） |
| 公钥指纹 | `sha256:<public-skill.pem 的 SHA-256 hex>` |

**待交接的私钥文件：** `config/skill-private.pem`

**后台留存用于验签/指纹比对的公钥文件：** `config/public-skill.pem`

---

## 3. 私钥交接与保管要求

### 3.1 传输方式
- 通过加密通道或安全介质传递，禁止明文邮件、IM、网盘
- 建议分通道传递：文件本身一个通道，密码/解密密钥另一个通道

### 3.2 存储要求
- **禁止**将私钥字符串硬编码在源码中
- **禁止**将私钥提交到 Git/SVN 等版本控制系统
- 优先存储在：KMS、HSM、Vault、加密数据库、受限文件系统
- 若以文件形式存储，文件权限应限制为仅签名服务进程可读

### 3.3 访问控制
- 仅签名服务有权读取私钥
- 签名接口需鉴权，防止未授权调用
- 记录每次签名操作的审计日志（操作人、skill 名称、时间、IP）

### 3.4 泄露响应
- 一旦发现私钥可能泄露，立即停用当前密钥对
- 重新执行 `node scripts/gen-keys.js --force` 生成新密钥对
- 所有已签名的 skill 必须重新签名
- 同步更新 `config/skill-trust-policy.json` 中的受信任 fingerprint

---

## 4. 签名整体流程

```
┌─────────────────┐     ┌─────────────────────┐     ┌─────────────────┐
│  管理/上传 skill  │ --> │  Java 后台计算 manifest │ --> │ RSA-SHA256 签名  │
│   目录内容        │     │  并读取私钥            │     │                 │
└─────────────────┘     └─────────────────────┘     └────────┬────────┘
                                                             │
                                                             v
                                                    ┌─────────────────┐
                                                    │ 生成 .skill-trust │
                                                    │ 写入 skill 目录   │
                                                    └─────────────────┘
```

---

## 5. Manifest 计算规范

Manifest 是签名的核心输入，必须严格按以下规则生成。

### 5.1 目录遍历规则

1. 递归遍历 skill 目录下所有文件和子目录
2. **跳过** `.skill-trust` 文件（不能签名自己）
3. 在每个目录内，按**不区分大小写**的字母顺序排序后再处理
4. 排序后，**先处理目录，再处理文件**（与 Node.js 脚本一致）

> 注意：这不是对全量文件做全局排序，而是**逐层排序、目录优先**。

### 5.2 文件条目字段

每个文件生成一个对象，包含三个字段：

| 字段 | 类型 | 说明 |
|------|------|------|
| `path` | string | 相对于 skill 目录的相对路径，分隔符统一为 `/` |
| `hash` | string | 文件内容的 SHA-256，小写 hex 字符串 |
| `size` | number | 文件字节长度 |

### 5.3 路径处理

- Windows 平台 `\` 必须替换为 `/`
- 示例：`scripts\main.py` -> `scripts/main.py`

### 5.4 哈希计算

- 算法：`SHA-256`
- 输入：文件原始字节（不做任何编码转换）
- 输出：64 位小写十六进制字符串

### 5.5 最终结构

```json
{
  "files": [
    {"path": "SKILL.md", "hash": "...", "size": 1234},
    {"path": "scripts/main.py", "hash": "...", "size": 5678}
  ]
}
```

---

## 6. JSON 序列化规范

签名输入为 manifest 对象的 JSON 字符串，必须满足：

- 使用 **UTF-8** 编码
- **无缩进、无换行**（compact JSON）
- 字段顺序固定：`files` -> 数组中每个对象的 `path` -> `hash` -> `size`
- 数组顺序必须与第 5 节遍历顺序完全一致

> Java 注意：`ObjectMapper.writeValueAsString()` 默认输出 compact JSON，但需确保 POJO 字段顺序与 Node.js 一致。建议通过 `@JsonPropertyOrder({"path", "hash", "size"})` 显式控制。

---

## 7. 签名算法细节

### 7.1 算法标识

- Java 标准库：`Signature.getInstance("SHA256withRSA")`
- 对应 Node.js：`crypto.createSign('RSA-SHA256')`
- 填充方式：**PKCS#1 v1.5**（不是 PSS）

### 7.2 签名步骤

1. 将 manifest JSON 字符串转为 UTF-8 字节数组
2. 使用 PKCS#8 私钥初始化 `Signature`
3. 对 manifest 字节做 `update()`
4. 调用 `sign()` 得到原始签名字节
5. 使用 Base64 编码得到最终签名值

### 7.3 签名输出格式

- Base64 标准编码（非 URL-safe）
- 不包含换行

---

## 8. `.skill-trust` 文件格式

最终写入 skill 目录根目录的 `.skill-trust` 文件内容如下：

```json
{
  "version": "1.0.0",
  "signature": {
    "keyId": "coqi-claw-internal",
    "value": "<base64 签名值>",
    "signedAt": "2026-06-18T12:00:00.000Z",
    "expiresAt": "2027-06-18T12:00:00.000Z",
    "algorithm": "RSA-SHA256"
  },
  "manifest": {
    "files": [
      {"path": "SKILL.md", "hash": "...", "size": 1234},
      {"path": "scripts/main.py", "hash": "...", "size": 5678}
    ]
  },
  "fingerprint": "sha256:<public-skill.pem 的 SHA-256 hex>"
}
```

### 字段说明

| 字段 | 说明 |
|------|------|
| `version` | 固定 `"1.0.0"` |
| `signature.keyId` | 签名密钥标识，默认 `"coqi-claw-internal"` |
| `signature.value` | Base64 编码的 RSA-SHA256 签名 |
| `signature.signedAt` | 签名时间，ISO 8601 UTC 格式，带毫秒和 `Z` |
| `signature.expiresAt` | 过期时间，默认签名时间 + 365 天 |
| `signature.algorithm` | 固定 `"RSA-SHA256"` |
| `manifest` | 第 5 节定义的 manifest 对象 |
| `fingerprint` | 公钥指纹，`sha256:` + 公钥 PEM 文件内容的 SHA-256 hex |

### 指纹计算

```java
byte[] pubKeyBytes = Files.readAllBytes(Paths.get("config/public-skill.pem"));
MessageDigest digest = MessageDigest.getInstance("SHA-256");
String hash = bytesToHex(digest.digest(pubKeyBytes));
String fingerprint = "sha256:" + hash;
```

---

## 9. Java 参考实现

以下代码完整展示了 manifest 计算和签名流程，供后台团队参考。

```java
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.*;
import java.util.stream.Collectors;

public class SkillSigner {

    @JsonPropertyOrder({"path", "hash", "size"})
    public static class ManifestFile {
        public String path;
        public String hash;
        public long size;
    }

    public static class Manifest {
        public List<ManifestFile> files = new ArrayList<>();
    }

    public static class TrustData {
        public String version = "1.0.0";
        public SignatureBlock signature = new SignatureBlock();
        public Manifest manifest = new Manifest();
        public String fingerprint;
    }

    public static class SignatureBlock {
        public String keyId = "coqi-claw-internal";
        public String value;
        public String signedAt;
        public String expiresAt;
        public String algorithm = "RSA-SHA256";
    }

    /**
     * 计算 skill 目录的 manifest
     */
    public static Manifest computeManifest(Path skillDir) throws Exception {
        Manifest manifest = new Manifest();
        walk(skillDir, skillDir, "", manifest);
        return manifest;
    }

    private static void walk(Path dir, Path root, String prefix, Manifest manifest) throws Exception {
        List<Path> entries;
        try (var stream = Files.list(dir)) {
            entries = stream
                .sorted((a, b) -> {
                    String na = a.getFileName().toString().toLowerCase();
                    String nb = b.getFileName().toString().toLowerCase();
                    return na.compareTo(nb);
                })
                .collect(Collectors.toList());
        }

        for (Path entry : entries) {
            String name = entry.getFileName().toString();
            String relativePath = prefix.isEmpty() ? name : prefix + "/" + name;

            if (Files.isDirectory(entry)) {
                walk(entry, root, relativePath, manifest);
            } else if (Files.isRegularFile(entry)) {
                if (".skill-trust".equals(name)) {
                    continue;
                }
                byte[] content = Files.readAllBytes(entry);
                ManifestFile mf = new ManifestFile();
                mf.path = relativePath.replace("\\", "/");
                mf.hash = sha256Hex(content);
                mf.size = content.length;
                manifest.files.add(mf);
            }
        }
    }

    private static String sha256Hex(byte[] data) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        return bytesToHex(digest.digest(data));
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    /**
     * 加载 PKCS#8 PEM 私钥
     */
    public static PrivateKey loadPrivateKey(String pemPath) throws Exception {
        String pem = Files.readString(Paths.get(pemPath), StandardCharsets.UTF_8);
        String base64 = pem
            .replace("-----BEGIN PRIVATE KEY-----", "")
            .replace("-----END PRIVATE KEY-----", "")
            .replaceAll("\\s", "");
        byte[] encoded = Base64.getDecoder().decode(base64);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(encoded);
        return keyFactory.generatePrivate(spec);
    }

    /**
     * 对 manifest 进行 RSA-SHA256 签名
     */
    public static String signManifest(Manifest manifest, PrivateKey privateKey) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        String manifestJson = mapper.writeValueAsString(manifest);

        Signature signer = Signature.getInstance("SHA256withRSA");
        signer.initSign(privateKey);
        signer.update(manifestJson.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(signer.sign());
    }

    /**
     * 计算公钥指纹
     */
    public static String computeFingerprint(String publicKeyPath) throws Exception {
        byte[] pubKeyBytes = Files.readAllBytes(Paths.get(publicKeyPath));
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        return "sha256:" + bytesToHex(digest.digest(pubKeyBytes));
    }

    /**
     * 生成完整的 .skill-trust 内容
     */
    public static String generateTrustFile(Path skillDir, PrivateKey privateKey,
                                           String keyId, int expireDays) throws Exception {
        Manifest manifest = computeManifest(skillDir);
        String signatureValue = signManifest(manifest, privateKey);
        String fingerprint = computeFingerprint("config/public-skill.pem");

        String signedAt = java.time.Instant.now().toString(); // ISO-8601 UTC
        String expiresAt = java.time.Instant.now()
            .plusSeconds(expireDays * 24L * 60L * 60L)
            .toString();

        TrustData trust = new TrustData();
        trust.signature.keyId = keyId;
        trust.signature.value = signatureValue;
        trust.signature.signedAt = signedAt;
        trust.signature.expiresAt = expiresAt;
        trust.manifest = manifest;
        trust.fingerprint = fingerprint;

        ObjectMapper mapper = new ObjectMapper();
        return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(trust);
    }

    public static void main(String[] args) throws Exception {
        Path skillDir = Paths.get(args[0]);
        PrivateKey privateKey = loadPrivateKey("config/skill-private.pem");

        String trustContent = generateTrustFile(skillDir, privateKey, "coqi-claw-internal", 365);
        Files.writeString(skillDir.resolve(".skill-trust"), trustContent, StandardCharsets.UTF_8);
    }
}
```

### 依赖

```xml
<dependency>
    <groupId>com.fasterxml.jackson.core</groupId>
    <artifactId>jackson-databind</artifactId>
    <version>2.15.0</version>
</dependency>
```

---

## 10. 兼容性验证步骤

后台完成开发后，必须按以下步骤验证签名结果与现有 Node.js 脚本一致：

### 10.1 同一份 skill，两端分别签名

```bash
# Node.js 端
node scripts/skill-sign.js skills/<skill-name>

# 备份 .skill-trust
mv skills/<skill-name>/.skill-trust skills/<skill-name>/.skill-trust.node

# Java 端生成 .skill-trust
# ...
```

### 10.2 对比 manifest

提取两份 `.skill-trust` 中的 `manifest` 字段，JSON 字符串必须**完全一致**。

### 10.3 对比签名值

如果 manifest 一致但签名值不同，请检查：
- 私钥是否一致
- Java 签名算法是否为 `SHA256withRSA`（不是 PSS）
- manifest JSON 序列化是否完全一致（字段顺序、编码、无多余空格）

### 10.4 Agent 端验签

将 Java 生成的 `.skill-trust` 放入 skill 目录，启动 Agent，确认 skill 能正常加载且 trust 验证通过。

---

## 11. 常见问题

### Q1: 为什么必须把 `\` 替换为 `/`？

技能可能在 Windows 开发环境签名、Linux 运行环境加载。统一路径分隔符可保证跨平台 manifest 一致。

### Q2: 文件排序为什么要逐层进行，且目录优先？

必须与 `scripts/skill-sign.js` 的递归遍历逻辑完全一致。全局排序或文件优先都会导致 manifest 不同，签名失效。

### Q3: 如果后台已经有文件上传逻辑，是否还需要重新读取文件计算 hash？

是的。签名时必须以**当前磁盘上的实际文件内容**为准，不能依赖数据库中缓存的 hash 或上传时的元数据。

### Q4: 是否可以用 PSS 填充替代 PKCS#1 v1.5？

不可以。Node.js `crypto.createSign('RSA-SHA256')` 默认使用 PKCS#1 v1.5。使用 PSS 会导致签名无法通过 Agent 验证。

### Q5: 有效期如何设定？

默认 365 天，可通过参数配置。建议不要设置过长，以便密钥轮换。

---

## 12. 交付清单

后台团队完成集成后，请确认以下事项：

- [ ] 已安全接收并存储 `skill-private.pem`
- [ ] 已确认签名算法为 `SHA256withRSA`（PKCS#1 v1.5）
- [ ] manifest 遍历顺序与 Node.js 脚本一致
- [ ] `.skill-trust` 文件格式符合第 8 节规范
- [ ] 指纹计算使用 `config/public-skill.pem` 全文 SHA-256
- [ ] 已与 Node.js 脚本交叉验证至少一个 skill
- [ ] Agent 端能正常加载并验证 Java 签名的 skill
- [ ] 签名操作已记录审计日志

---

## 13. 联系与技术支持

如有实现细节疑问，建议直接对照参考源码：

- 签名脚本：`scripts/skill-sign.js`
- 密钥生成：`scripts/gen-keys.js`
- 验证逻辑：`src/security/skill-trust.js`
