# Messages 表全文检索实现方案

## 背景

messages 表存储所有 LLM 会话的完整对话历史。当对话轮次增多、LLM 上下文被截断时，Agent 可能"忘记"早期内容。通过在 messages 表上实现全文检索，提供 `search_memory` 工具，让 LLM 主动检索历史消息恢复记忆。

---

## 方案选型：C（FTS5 trigram tokenizer）

经过实测对比，采用 **FTS5 trigram tokenizer**。

### trigram vs unicode61 实测对比

**测试环境**：SQLite 3.51.3（bundled with better-sqlite3）

| 维度 | trigram | unicode61 |
|------|---------|-----------|
| 中文3字词（"数据库"→"数据库设计"） | **MATCH** | NO MATCH |
| 中文2字词（"数据"→"数据库设计"） | NO MATCH | NO MATCH |
| 中文1字（"数"→"数据库设计"） | NO MATCH | NO MATCH |
| 英文单词（"hello"→"hello world"） | MATCH | MATCH |
| 英文2字母（"JS"→"JavaScript"） | NO MATCH | NO MATCH |
| 子串搜索（"据库设"→"数据库设计"） | **MATCH** | NO MATCH |
| 短语搜索（"数据库设计"） | MATCH | MATCH（需完整token） |
| 多关键词AND（"数据库 设计"） | MATCH | NO MATCH |
| 索引体积（2000条样本） | 56 KB | 56 KB（**相同**） |
| 查询性能（100次） | 2 ms | 1 ms |

**关键发现**：
- unicode61 把整个中文字符串当作**单个 token**（"数据库设计文档" = 一个token），子串搜索完全失效
- trigram 将文本切成连续 **3字符窗口**（"数据库设计" → ["数据库","据库设","库设计"]），3字以上的子串都能精确匹配
- 索引体积**零膨胀**，性能差距**可忽略**

### trigram 行为原理

索引时：文本被切成连续的3字符窗口
- `"数据库设计"` → `"数据库"`, `"据库设"`, `"库设计"`
- `"hello world"` → `"hel"`, `"ell"`, `"llo"`, `"lo "`...（含空格）

搜索时：查询词同样被切分，然后匹配包含这些窗口的文档
- `"数据库"`（3字）→ 直接匹配索引中的 `"数据库"` -> 命中
- `"据库设"`（中间子串）→ 匹配索引中的 `"据库设"` -> 命中
- `"数据"`（2字）→ 无法切成3字符窗口 -> 无法匹配

### trigram 限制

1. **短查询不支持**：1-2个字符无法匹配（中文1-2字、英文1-2字母）
2. **前缀通配符不支持**：`数*` 不工作
3. **显式 AND 语法有歧义**：`"数据库 AND 设计"` 中 AND 被当作3字符token -> 语义异常。但**空格分隔的隐式AND完全正常**（`"数据库 设计"`）
4. **NOT 语法行为微妙**：减号 `-` 被当作列名前缀报错

### 适用性评估（个人助手场景）

- 用户通常搜索3字以上的关键词（"数据库设计"、"API接口"、"前端开发"）
- 短语搜索 `"数据库设计"` 完美工作
- 多关键词搜索 `数据库 设计`（隐式AND）完美工作
- 搜索 "API"（3字母）可以，但 "JS"（2字母）不行 -> 可在工具层对短查询 fallback 到 LIKE
- 单字搜索（如 "数"）不行 -> 实际场景中极少发生

### 结论

对于个人助手的 messages 全文检索：**trigram 是当前最优方案**。中文支持从"完全不可用"（unicode61）提升到"3字以上精确子串匹配"，且零额外依赖、零索引膨胀、性能可接受。

---

## 详细设计

### 1. FTS5 Schema（trigram）

```sql
CREATE VIRTUAL TABLE messages_fts USING fts5(
    content,
    role UNINDEXED,
    session_id UNINDEXED,
    tokenize='trigram'
);
```

- `content`: 消息内容，全文检索目标列
- `role` / `session_id`: UNINDEXED，仅存储用于过滤，不参与索引
- `tokenize='trigram'`: 3字符滑动窗口分词，支持中英文子串匹配

### 2. 触发器同步

```sql
-- INSERT
CREATE TRIGGER messages_fts_insert AFTER INSERT ON messages BEGIN
    INSERT INTO messages_fts(rowid, content, role, session_id)
    VALUES (new.id, new.content, new.role, new.session_id);
END;

-- DELETE
CREATE TRIGGER messages_fts_delete AFTER DELETE ON messages BEGIN
    INSERT INTO messages_fts(messages_fts, rowid, content, role, session_id)
    VALUES ('delete', old.id, old.content, old.role, old.session_id);
END;

-- UPDATE
CREATE TRIGGER messages_fts_update AFTER UPDATE ON messages BEGIN
    INSERT INTO messages_fts(messages_fts, rowid, content, role, session_id)
    VALUES ('delete', old.id, old.content, old.role, old.session_id);
    INSERT INTO messages_fts(rowid, content, role, session_id)
    VALUES (new.id, new.content, new.role, new.session_id);
END;
```

### 3. SessionManager.searchMessages()

```javascript
searchMessages(query, options = {})
// options: { limit = 10, sessionId = null }
```

查询 SQL：
```sql
SELECT 
    m.id,
    m.session_id,
    m.role,
    m.content,
    m.created_at,
    snippet(messages_fts, 0, '[', ']', '...', 15) as snippet,
    rank
FROM messages_fts
JOIN messages m ON m.id = messages_fts.rowid
WHERE messages_fts MATCH @query
  AND (@sessionId IS NULL OR m.session_id = @sessionId)
ORDER BY rank
LIMIT @limit
```

**短查询 fallback**：当 query 去掉空白后长度 < 3 时，回退到 LIKE 查询：
```sql
SELECT * FROM messages 
WHERE content LIKE '%' || @query || '%'
  AND (@sessionId IS NULL OR session_id = @sessionId)
ORDER BY created_at DESC
LIMIT @limit
```

### 4. 新工具：search_memory

**文件路径**：`src/tools/search-memory.js`

**参数**：
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| query | string | 是 | 搜索关键词。支持空格分隔的多关键词（隐式AND）、双引号短语精确匹配 |
| limit | number | 否 | 最大返回条数（默认 10，上限 50） |
| session_id | string | 否 | 限制在指定会话内搜索 |

**返回值**（JSON）：
```json
{
  "query": "搜索词",
  "count": 5,
  "results": [
    {
      "id": 123,
      "sessionId": "sess_xxx",
      "role": "user",
      "content": "完整消息内容...",
      "snippet": "...前文 [匹配词] 后文...",
      "createdAt": "2024-04-22 14:30:45"
    }
  ]
}
```

- `createdAt` 格式为 `YYYY-MM-DD HH:mm:ss`，便于 LLM 直接识别时间先后
- 若需精确排序，可比较 `id`（自增主键）

**错误处理**：
- query 为空或仅空白 -> `Errors.validation('query', 'Query is required')`
- limit 超过上限 -> 自动截断到 50
- FTS 表未初始化 -> `Errors.unknown('Full-text search not available')`

### 5. Migration

项目是新项目，不考虑已有数据库 migration。FTS 表和触发器在 `createSchema()` 中随 messages 表一起创建。

### 6. 注册

在 `src/tools/index.js` 导入并注册为 `search_memory`。工具描述自动进入系统提示词，无需额外修改 prompt-builder。

---

## 系统提示设计（LLM 如何正确使用 search_memory）

### 设计目标

1. **注入当前会话 ID**：让 LLM 知道自己在哪个会话中
2. **明确检索策略**：会话内优先，全局兜底
3. **区分语义**：用户说"当前会话"vs"之前"时，LLM 知道传不传 session_id

### i18n.js 新增翻译键

```javascript
// zh
instructionMemorySearch: '**记忆检索**：当用户提到之前讨论过但你当前上下文中不存在的内容时（如"你说过"、"上次"、"之前"），使用 `search_memory` 工具检索历史消息。检索策略：1. 先在当前会话内搜索（提供 session_id 参数），2. 若未命中再全局搜索（不提供 session_id）。若仍然找不到，明确告知用户"未在历史记录中找到相关内容"，禁止凭猜测编造历史内容。',
sessionInfoTitle: '## 当前会话',
sessionIdLabel: '会话ID',

// en
instructionMemorySearch: '**Memory Search**: When the user mentions something discussed before but not in your current context (e.g., "you said", "last time", "before"), use the `search_memory` tool to retrieve historical messages. Strategy: 1. Search within the current session first (provide session_id), 2. If not found, search globally (omit session_id). If still not found, clearly inform the user "No relevant content found in history" — never fabricate historical content based on guesswork.',
sessionInfoTitle: '## Current Session',
sessionIdLabel: 'Session ID',
```

### prompt-builder.js 修改

`buildSystemPrompt` 增加 `sessionId` 参数：

```javascript
export function buildSystemPrompt(matchedSkills = [], options = null, relevantTools = [], assistantIdentity = '', sessionId = '') {
    const locale = getLocale();
    const timeSection = buildTimeSection(new Date(), locale);
    const skillsSection = buildSkillsSection(matchedSkills, locale);
    const toolsSection = buildToolsSection(locale);
    const sandboxSection = buildSandboxSection(locale);

    // 会话信息区块（仅在多轮 chat 模式下注入）
    const sessionSection = sessionId
        ? `\n${t('sessionInfoTitle', locale)}\n${t('sessionIdLabel', locale)}: ${sessionId}\n`
        : '';

    const toolSuggestionSection = relevantTools.length > 0
        ? `\n## ${t('toolSuggestionTitle', locale)}\n${t('toolSuggestionPriority', locale)} ${relevantTools.map(t => `\`${t}\``).join(', ')}`
        : `\n## ${t('toolSuggestionTitle', locale)}\n${t('toolSuggestionNone', locale)}`;

    const sandboxBlock = sandboxSection ? `\n${sandboxSection}\n` : '';

    return `${assistantIdentity || t('assistantRole', locale)}

${timeSection}${sessionSection}

${skillsSection}

${t('toolsSection', locale)}
${toolsSection}${toolSuggestionSection}
${sandboxBlock}
${t('instructions', locale)}
1. ${t('instructionContextFirst', locale)}
2. ${t('instructionNetworkFirst', locale)}
3. ${t('instructionSkillExec', locale)}
4. ${t('instructionGeneralTools', locale)}
5. ${t('instructionDirectResponse', locale)}
6. ${t('instructionErrorHandling', locale)}
7. ${t('instructionFactualConstraint', locale)}
8. ${t('instructionPriorityReminder', locale)}
${sessionId ? `9. ${t('instructionMemorySearch', locale)}` : ''}`;
}
```

### agent.js 传递 sessionId

`buildPersonalizedSystemPrompt` 中调用 `buildSystemPrompt` 时传入 `this.sessionId`：

```javascript
let systemPrompt = buildSystemPrompt(
    matchedSkills, null, relevantTools, assistantIdentity, this.sessionId
);
```

### 条件控制

- **多轮 chat 模式**：`sessionId` 有值，注入会话信息区块 + 记忆检索指令
- **单轮 cli 模式**：`sessionId` 为空，不注入任何会话相关内容，避免 LLM 调用不存在的工具

### 系统提示中的最终效果（zh，sessionId 有值时）

```
## 当前会话
会话ID: sess_a1b2c3d4

## Tools
你可以使用以下工具...

## Instructions
...
9. **记忆检索**：当用户提到之前讨论过但你当前上下文中不存在的内容时...
```

---

## 修改文件清单

| 文件 | 修改内容 |
|------|----------|
| `src/core/i18n.js` | 新增 `instructionMemorySearch`、`sessionInfoTitle`、`sessionIdLabel` 翻译键 |
| `src/core/prompt-builder.js` | `buildSystemPrompt` 增加 `sessionId` 参数，注入会话信息区块和记忆检索指令 |
| `src/core/agent.js` | `buildPersonalizedSystemPrompt` 中传递 `this.sessionId` |
| `src/sessions/manager.js` | 1. `createSchema()` 新增 `messages_fts` 虚拟表和触发器<br>2. 新增 `searchMessages(query, options)` 方法 |
| `src/tools/search-memory.js` | 新建工具模块 |
| `src/tools/index.js` | 导入并注册 `search_memory` 工具 |

## 验证方案

1. **语法检查**：`node --check src/sessions/manager.js`、`node --check src/tools/search-memory.js`、`node --check src/tools/index.js`
2. **功能测试**：
   - 启动 chat 模式，发送几条消息后调用 search_memory 工具
   - 验证中文3字以上关键词能精确匹配（如搜索"数据库"匹配"数据库设计文档"）
   - 验证多关键词搜索（空格分隔）生效
   - 验证 session_id 过滤生效
   - 验证新消息发送后能被立即检索到（触发器同步）
   - 验证短查询（1-2字）能 fallback 到 LIKE 查询
