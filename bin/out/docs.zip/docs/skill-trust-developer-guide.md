# Skill 开发指南（面向业务部门开发者）

## 概述

本文档面向业务部门的技术人员，描述如何在金融企业场景中开发符合 coqi-claw 安全规范的 skill。开发完成后，需要提交给系统管理员审核、签名，才能在生产环境使用。

## 核心原则

1. **Skill 自包含**：不依赖外部模块，所有脚本/资源都在 skill 目录内
2. **明文开发**：开发阶段用明文编写，提交前不需要关心加密
3. **管理员终审**：只有管理员签名后的 skill 才能在生产环境使用

---

## 一、开发环境准备

### 1.1 目录结构

在 `skills/` 目录下创建你的 skill：

```
skills/your-skill-name/          ← 目录名必须 kebab-case（小写+连字符）
├── SKILL.md                     ← 必填：技能定义文件
├── scripts/                     ← 可执行脚本（Python/JS/Shell）
│   ├── main.py
│   └── utils.py
├── references/                  ← 参考文档（可选）
│   └── api-reference.md
├── assets/                      ← 静态资源（可选）
│   └── template.html
└── requirements.txt             ← Python 依赖（可选，尽量不用）
```

**命名规则**：
- 目录名：`your-skill-name`（小写字母、数字、连字符）
- `SKILL.md` 中 `name` 字段必须与目录名**完全一致**
- 脚本文件名：`main.py`、`utils.py`（描述性命名）

### 1.2 开发环境配置

开发阶段**不需要**配置 `SKILL_MASTER_KEY` 或 `skill-trust-policy.json`。在 `mode: "off"` 环境下直接开发测试：

```bash
# 确认环境为开发模式（默认）
cat config/skill-trust-policy.json
# 应显示：{ "mode": "off" }

# 直接运行测试
npm start "测试你的 skill"
```

---

## 二、SKILL.md 编写规范

### 2.1 文件格式

```markdown
---
name: your-skill-name
description: 一句话描述 skill 的用途和使用场景
version: "1.0.0"
metadata:
  author: 业务部-张三
  category: 报告生成
  tags: [pdf, financial-report]
---

# 你的 Skill 名称

## 概述

详细描述这个 skill 能做什么、适用场景、输入输出。

## 使用步骤

1. 第一步：调用 `skill_view` 查看可用脚本
2. 第二步：执行 `scripts/main.py` 传入必要参数
3. 第三步：查看产出文件

## 可用脚本

- `scripts/main.py`：主脚本，接收 `--input` 和 `--output` 参数
- `scripts/utils.py`：工具函数，不需要直接调用

## 参数说明

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `--input` | string | 是 | 输入数据文件路径 |
| `--output` | string | 是 | 输出报告路径 |

## 示例

```bash
python skills/your-skill-name/scripts/main.py \
  --input user/data.csv \
  --output output/report.pdf
```

## 注意事项

- 输入文件必须是 UTF-8 编码的 CSV
- 输出支持 PDF 和 DOCX 两种格式
```

### 2.2 Frontmatter 必填字段

| 字段 | 要求 | 说明 |
|------|------|------|
| `name` | 必填，1-64 字符，小写/数字/连字符 | 必须与目录名一致 |
| `description` | 必填，1-1024 字符 | 清晰的用途描述，LLM 用它来判断是否匹配用户请求 |
| `version` | 可选 | 语义化版本号 |
| `metadata.author` | 可选 | 开发者/团队标识 |
| `metadata.category` | 可选 | 分类，如"报告生成"、"数据分析" |
| `metadata.tags` | 可选 | 标签数组，辅助 LLM 匹配 |

### 2.3 Instructions 编写要点

Instructions（`## 使用步骤` 及之后的内容）是 LLM 执行 skill 的核心依据：

1. **步骤清晰**：明确告诉 LLM 先做什么、后做什么
2. **脚本路径准确**：使用相对路径 `scripts/xxx.py`，不要写绝对路径
3. **参数说明完整**：每个参数的名称、类型、是否必填都要说明
4. **给出示例**：提供至少一个完整可执行的命令示例
5. **注意事项前置**：容易出错的地方要在 instructions 中提醒

---

## 三、脚本开发规范

### 3.1 语言选择

- **优先 Python 3**：适合数据处理、报告生成
- **Node.js**：适合与项目内其他 JS 工具集成
- **Shell/Batch**：仅限简单文件操作

### 3.2 脚本自包含原则

**禁止**引用 skill 目录之外的文件或模块：

```python
# ❌ 错误：引用外部模块
import pandas  # 不要依赖非标准库

# ✅ 正确：只用标准库
import csv
import json

# ✅ 正确：引用 skill 目录内的本地模块
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from utils import helper  # 引用同目录下的 utils.py
```

### 3.3 支持 JSON 输出模式（`--json`）

Agent 解析脚本结果需要结构化数据，所有脚本必须支持 `--json` 参数：

```python
import argparse
import json

parser = argparse.ArgumentParser()
parser.add_argument('--json', '-j', action='store_true',
                    help='输出 JSON 格式结果')
# ... 其他参数 ...

args = parser.parse_args()

result = {
    'success': True,
    'output_path': '/abs/path/to/output.pdf',
    'data': { ... },
    'errors': []
}

if args.json:
    print(json.dumps(result, ensure_ascii=False, indent=2))
else:
    print(f"报告已生成：{result['output_path']}")
```

### 3.4 UTF-8 编码（Windows 必需）

所有 Python 脚本头部必须包含：

```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys

if sys.platform == 'win32':
    import subprocess
    subprocess.run(['chcp', '65001'], shell=True, capture_output=True)
    try:
        if hasattr(sys.stdout, 'reconfigure'):
            sys.stdout.reconfigure(encoding='utf-8')
        if hasattr(sys.stderr, 'reconfigure'):
            sys.stderr.reconfigure(encoding='utf-8')
    except Exception:
        pass
```

### 3.5 错误处理

脚本出错时返回非零退出码，并在 stderr 输出错误信息：

```python
import sys

try:
    # 业务逻辑
    pass
except FileNotFoundError as e:
    print(f"错误：输入文件不存在：{e}", file=sys.stderr)
    sys.exit(1)
except Exception as e:
    print(f"错误：{e}", file=sys.stderr)
    sys.exit(1)
```

### 3.6 环境变量读取

如果脚本需要调用 LLM API，使用 `TOOL_LLM_*` 前缀的环境变量：

```python
import os

config = {
    'api_key': os.environ.get('TOOL_LLM_API_KEY'),
    'base_url': os.environ.get('TOOL_LLM_BASE_URL', 'https://dashscope.aliyuncs.com/compatible-mode/v1'),
    'model': os.environ.get('TOOL_LLM_MODEL', 'qwen3.5-35b-a3b')
}
```

---

## 四、自测流程

开发完成后，在本地按以下步骤自测：

### 4.1 语法检查

```bash
# SKILL.md YAML frontmatter 格式检查
node -e "const { parseSkillFile } = require('./src/skills/parser.js'); console.log(parseSkillFile('./skills/your-skill-name/SKILL.md'));"

# Python 脚本语法检查
python -m py_compile skills/your-skill-name/scripts/*.py
```

### 4.2 功能测试

```bash
# 测试脚本独立执行
python skills/your-skill-name/scripts/main.py \
  --input test-data.csv \
  --output test-output.pdf \
  --json

# 验证 JSON 输出格式正确
```

### 4.3 Agent 集成测试

```bash
# 启动 Agent，测试 skill 匹配和执行
npm start "使用 your-skill-name 生成一份测试报告"

# 观察日志：
# 1. skill 是否被正确匹配
# 2. skill_view 是否返回正确的 instructions
# 3. exec 是否成功执行脚本
# 4. 产出文件是否在 output/skill-your-skill-name/ 下
```

### 4.4 测试用例设计

提交前建议编写以下测试：

| 测试场景 | 方法 | 期望结果 |
|---------|------|---------|
| 脚本独立执行 | `python scripts/main.py --input test.csv --output out.pdf --json` | 正常退出，JSON 格式正确 |
| 缺少必填参数 | `python scripts/main.py` | 非零退出码，stderr 输出错误 |
| 输入文件不存在 | `python scripts/main.py --input not-exist.csv --output out.pdf` | 非零退出码，stderr 提示文件不存在 |
| Agent 匹配 | `npm start "使用 your-skill-name"` | skill 出现在 matched skills 中 |
| skill_view | 调用 skill_view 工具 | 返回正确的 instructions 和 linked_files |
| exec 执行 | Agent 执行 skill 脚本 | 成功执行，产出文件在 output/ 下 |
| 并发执行 | 多个任务同时调用同一 skill | 无冲突，各自产出独立 |

### 4.5 沙箱边界测试

测试脚本是否只在允许的目录读写：

```bash
# 测试读取沙箱外文件（应该被拒绝）
# 测试写入到 output/ 目录（应该成功）
```

---

## 五、提交审核清单

自测通过后，准备以下材料提交给管理员：

### 5.1 提交内容

```
your-skill-name/
├── SKILL.md              ← 确保 name 与目录名一致
├── scripts/              ← 所有脚本可独立执行
├── references/           ← 如有
├── assets/               ← 如有
└── README.md（可选）     ← 给管理员看的补充说明
```

### 5.2 审核清单

提交前自查：

- [ ] 目录名与 `SKILL.md` 中 `name` 字段完全一致
- [ ] `description` 清晰描述了 skill 的用途
- [ ] 所有脚本使用标准库，无外部依赖
- [ ] 所有脚本支持 `--json` 参数
- [ ] 脚本在 Windows 和 Linux 上都能运行（如有条件）
- [ ] 脚本有基本的错误处理和退出码
- [ ] 测试过 Agent 端到端执行流程
- [ ] 没有硬编码的敏感信息（API Key、密码等）

### 5.3 提交方式

将 skill 目录打包为 zip 或通过 Git PR 提交给系统管理员：

```bash
# 打包提交
zip -r your-skill-name-v1.0.0.zip skills/your-skill-name/
```

**注意**：提交的是**明文** skill，不要自行加密。加密由管理员在审核后执行。

---

## 六、签名后的使用

管理员审核、签名（并可选加密）后，skill 会部署到生产环境的 `skills/` 目录。

此时 skill 目录会多出一个 `.skill-trust` 文件：

```
skills/your-skill-name/
├── SKILL.md
├── .skill-trust          ← 管理员添加，不要删除或修改
├── scripts/
│   ├── main.py.enc       ← 如管理员加密，变为 .enc 文件
│   └── utils.py.enc
└── ...
```

**开发者后续维护**：
- 如需修改 skill，从管理员处获取最新版本（含 `.skill-trust`）
- 修改后重新提交审核，管理员会重新签名
- **不要**自行修改 `.skill-trust` 文件，否则签名验证会失败

---

## 七、常见问题

### Q1: 为什么我的 skill 在开发环境能用，到了生产环境不行？

生产环境可能开启了 `mode: "enforce"`，你的 skill 没有 `.skill-trust` 文件。联系管理员签名。

### Q2: 我的脚本依赖 pandas/numpy，怎么办？

尽量用标准库重写。如确实需要，在 `requirements.txt` 中列出，并在提交时说明原因。管理员会评估风险。

### Q3: skill 可以读写数据库吗？

**不推荐**。skill 脚本通过 `exec` 工具执行，应限制为文件操作。如需数据库访问，建议：
1. 在脚本中使用 `http_request` 工具调用内部 API
2. 或由 Agent 主流程处理数据库操作，skill 只负责数据转换

### Q4: 如何调试 skill 脚本？

```bash
# 直接执行脚本，查看输出
python skills/your-skill-name/scripts/main.py --input test.csv --output out.pdf --json

# 查看 exec 工具执行日志
tail -f logs/agent.log
```

### Q5: 版本更新需要重新签名吗？

**必须重新签名**。任何文件内容的修改都会导致 manifest hash 变化，旧签名失效。修改后重新提交管理员审核。

---

## 八、参考文档

- `doc/specification.md` — Agent Skills 规范原文
- `.claude/rules/skill-development.md` — 项目内部的 skill 开发标准
- `doc/skill-trust-admin-guide.md` — 管理员操作手册（了解签名/加密流程）
