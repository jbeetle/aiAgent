# config/skill-trust-policy.json 分析总结

Skill Trust Framework 的总开关和核心配置，控制 Agent 加载 skill 时的信任验证策略。

---

## 配置结构

| 字段 | 当前值 | 作用 |
|------|--------|------|
| `version` | `1.0.0` | 策略文件版本 |
| `mode` | `enforce` | **最严格模式** — 无 `.skill-trust` 签名文件的 skill 会被拒绝加载 |
| `signatures.trustedKeys` | 1 条 | 信任的 RSA 公钥列表，用于验证 `.skill-trust` 中的签名 |
| `signatures.requireTimestamp` | `true` | 强制要求 `.skill-trust` 包含 `signedAt` 时间戳 |
| `whitelist.enabled` | `false` | 白名单未启用，所有有效签名的 skill 均可加载 |
| `encryption.enabled` | `true` | 声明启用 skill 内容加密 |
| `encryption.masterKeyEnv` | `SKILL_MASTER_KEY` | 声明 Master Key 从该环境变量读取 |

---

## 当前信任公钥配置

```
id:           coqi-claw-internal
name:         coqi-claw Internal Key
publicKeyPath: config/public-skill.pem
fingerprint:  sha256:af418c86b6a64d320035dc52c4a57eeaee17655a3ddd7cfafe8ebddea59ecaea
```

验证链：
1. `skill-trust.js` 读取 `.skill-trust` 中的 `keyId`
2. 在 `trustedKeys` 中查找匹配的 `id`
3. 读取 `publicKeyPath` 指定的公钥文件
4. 计算公钥 SHA-256 指纹，与配置中的 `fingerprint` 比对
5. 指纹匹配后，用公钥验证 RSA-SHA256 签名

---

## 验证流程（由 `src/security/skill-trust.js` 执行）

```
.skill-trust 文件存在?
  ├─ No → mode=enforce: 拒绝加载
  │
  └─ Yes → 结构合法?
           ├─ No → 拒绝 (invalid-trust-file)
           │
           └─ Yes → keyId 在 trustedKeys 中?
                     ├─ No → 拒绝 (unknown-signer)
                     │
                     └─ Yes → 公钥指纹匹配?
                               ├─ No → 拒绝 (fingerprint-mismatch)
                               │
                               └─ Yes → RSA 签名验证通过?
                                         ├─ No → 拒绝 (signature-invalid)
                                         │
                                         └─ Yes → 时间戳合法?
                                                   ├─ No → 拒绝 (expired/future)
                                                   │
                                                   └─ Yes → manifest 与文件一致?
                                                             ├─ No → 拒绝 (manifest-mismatch)
                                                             │
                                                             └─ Yes → 白名单检查通过?
                                                                       ├─ No → 拒绝 (whitelist-denied)
                                                                       │
                                                                       └─ Yes -> 允许加载
```

---

## 发现的问题：配置与实现脱节

| 配置项 | 配置声明 | 代码实际 | 状态 |
|--------|---------|---------|------|
| `encryption.enabled` + `masterKeyEnv` | Skill 内容加密使用 Master Key | `skill-cipher.js` 的 `getMasterKey()` 存在但**返回值未被任何调用方使用** | **未生效** |

当前 skill 加密解密实际使用的是 **RSA-OAEP + AES-256-GCM 信封加密**，由 `skill-private.pem` / `public-skill.pem` 密钥对完成，与 `SKILL_MASTER_KEY` 无关。`SKILL_MASTER_KEY` 机制在配置中存在但代码层面是一个"死配置"。

---

## 三种运行模式对比

| 模式 | `skill-trust-policy.json` 存在？ | `mode` | 无 `.skill-trust` 的 skill |
|------|-------------------------------|--------|---------------------------|
| 关闭 | 不存在 或 `mode: "off"` | — | 允许加载 |
| 警告 | `mode: "warn"` | warn | 允许加载，但记录警告 |
| 强制 | `mode: "enforce"` | enforce | **拒绝加载**（当前配置） |

当前 `enforce` 模式意味着：**所有 skill 必须经过签名认证才能被 Agent 加载**。

---

## 安全影响评估

**正面：**
- `enforce` 模式 + 指纹校验 + 时间戳要求，形成较完整的信任链
- 公钥指纹防止公钥文件被替换攻击

**风险/问题：**
- `SKILL_MASTER_KEY` 配置未实际生效，文档与代码不一致
- `trustedKeys` 只有单条，无密钥轮换机制（重新生成密钥后所有已有 `.skill-trust` 失效）
- 白名单当前关闭，任何被 `coqi-claw-internal` 签名的 skill 都可加载（无 skill 级粒度控制）
