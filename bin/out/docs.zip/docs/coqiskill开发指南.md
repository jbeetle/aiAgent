# coqi-claw Skill 第三方开发交付规范

> 本文档面向**第三方合作开发者**。请严格按照本规范开发 Skill，确保交付产物能通过我方审核并正常在沙箱环境中运行。**数字签名由我方统一处理，开发者无需关心。**
>
> 适配 coqi-claw v1.0.6。基于 [Agent Skills 规范](https://agentskills.io/specification)。

## 目录

1. [什么是 Skill](#1-什么是-skill)
2. [目录结构](#2-目录结构)
3. [SKILL.md 规范](#3-skillmd-规范)
4. [Python 脚本开发标准](#4-python-脚本开发标准)
5. [CLI 设计规范](#5-cli-设计规范)
6. [安全规范 —— 沙箱必读](#6-安全规范--沙箱必读)
7. [文档输出技能](#7-文档输出技能)
8. [测试与验证](#8-测试与验证)
9. [常见陷阱](#9-常见陷阱)
10. [交付审查清单](#10-交付审查清单)

---

## 1. 什么是 Skill

Skill 是一个**自包含的目录**，包含元数据、使用说明和可执行脚本。Agent 在需要时加载 Skill，按照其中的指令完成任务。

在 CoQi 平台中，Skill 是**标准的能力扩展包**，符合 [Agent Skills 规范](https://agentskills.io/specification)。第三方开发者按照本规范编写的 Skill 目录，经审核签名后即可被 CoQi Agent 动态加载和执行。

## 2. 目录结构

```
skills/<skill-name>/           # 必须与 SKILL.md 中 name 字段一致
├── SKILL.md                   # [必需] 元数据 + 使用说明
├── scripts/                   # [可选] 可执行脚本
│   ├── main.py                # 入口脚本
│   └── lib/                   # 内部模块（自包含）
│       ├── encoding.py        # Windows UTF-8 处理
│       └── helpers.py         # 业务逻辑
├── references/                # [可选] 附加参考文档
│   └── REFERENCE.md
└── assets/                    # [可选] 模板、静态资源
    └── template.docx

# .skill-trust 签名文件由我方在审核通过后统一生成，开发者无需提交
```

**交付约束：**
- `name` 必须与目录名完全一致
- Skill 必须**完全自包含**，不依赖外部模块（Skill 将在沙箱隔离环境中执行）
- 主文件（`SKILL.md`）建议 < 500 行 / < 5000 tokens，长内容拆分到 `references/`
- **所有产物必须能在沙箱中正常运行**——这是审核通过的前置条件（详见第 6 章）
- Agent 按渐进式披露原则加载 Skill：元数据在启动时加载（~100 tokens），正文在激活时加载（建议 < 5000 tokens），资源文件按需加载
- `.skill-trust` 签名文件由我方统一生成，开发者不要手动创建

## 3. SKILL.md 规范

### 3.1 Frontmatter

```yaml
---
name: word-summary              # [必需] 1-64字符，仅小写字母/数字/连字符
description: >-                 # [必需] 1-1024字符，功能 + 触发场景
  Summarize Word documents (.doc/.docx) in multiple styles.
  Use when the user uploads a Word file and asks to summarize.
  Trigger words: summarize, 总结, 摘要, TL;DR.
license: Proprietary            # [可选]
compatibility: requires python3, soffice  # [可选] 1-500字符，按需填写
allowed-tools:                  # 禁止填写，工具权限由 CoQi 统一管理
metadata:                       # [可选] 字符串键值映射（值必须为字符串）
  author: starcrest0218
  version: "1.0"
---
```

**`name` 字段规则：**
- ✅ `word-summary`、`data-analysis`、`code-review`
- ❌ `Word-Summary`（大写）、`-pdf`（首连字符）、`pdf--tool`（连续连字符）

**`description` 字段最佳实践：**
- 前 1-2 句说明功能
- 中间说明使用场景
- 末尾列出触发词（覆盖中英文）
- **不要**只写 `Helps with Word documents.`

**`compatibility` 字段约束：**
- 1-500 字符
- 仅在有特定环境要求时填写，大多数 Skill 不需要此字段
- 示例：`requires python3, git, docker` 或 `requires Python 3.10+ and uv`

**`allowed-tools` 字段：**
- **禁止填写**。Skill 可使用的工具由 CoQi 平台根据安全策略统一分配
- 如果填写了任何工具，审核时将被要求删除

**`metadata` 字段约束：**
- 必须是字符串键到字符串值的扁平映射，不能包含嵌套对象或数组

### 3.2 正文结构

推荐包含以下章节：

```markdown
# Skill 标题（中文名）

一句话简述。

## When to Use This Skill（何时使用）

列举触发场景，用 bullet list + 中英文触发词。

## Inputs（输入参数）

| Parameter | Required | Default | Description |
|-----------|----------|---------|-------------|
| ...       | ...      | ...     | ...         |

## Instructions（操作步骤）

### Step 1: ...
### Step 2: ...
...

## Edge Cases（边界情况）

## Examples（示例）

### Example 1: 中文文档
### Example 2: 英文报告
```

**关键原则：**

1. **命令使用项目相对路径**，如 `python3 scripts/extract.py`，不要写绝对路径
2. **输出路径使用 `output/` 目录**（沙箱允许的目录之一），如 `--output output/result.md`
3. **示例要具体**：包含真实的用户输入、文件路径、期望输出
4. **边界情况覆盖**：空文件、超大文件、加密文件、扫描件、混合语言等

### 3.3 触发词策略

好的 description 应包含 Agent 用于语义匹配的**关键词**：

| 类型 | 示例 |
|------|------|
| 英文动词 | summarize, extract, convert, generate, compare |
| 英文名词 | summary, brief, digest, report, document |
| 中文动词 | 总结、提取、转换、生成、对比 |
| 中文名词 | 摘要、概要、要点、简报、报告 |
| 缩写 | TL;DR, OCR, PDF, DOCX |
| 领域词 | executive summary, 管理层摘要, redline |

## 4. Python 脚本开发标准

### 4.1 文件头模板

```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""<一句话描述脚本功能>

<详细说明，含输入输出>

Usage:
    python main.py <input> [--options]
    python main.py <input> --format json -o output/result.json

Dependencies (pre-installed in sandbox):
    - Standard library only
    - python-docx (for .docx processing)
"""

import argparse
import json
import sys
from pathlib import Path
```

### 4.2 Windows UTF-8 处理（必需）

**所有输出中文的 Python 脚本必须在 `main()` 开头添加：**

```python
def main():
    # Handle Windows UTF-8 encoding for CJK output
    if sys.platform == "win32":
        import subprocess
        subprocess.run(["chcp", "65001"], shell=True, capture_output=True)
        try:
            if hasattr(sys.stdout, "reconfigure"):
                sys.stdout.reconfigure(encoding="utf-8")
            if hasattr(sys.stderr, "reconfigure"):
                sys.stderr.reconfigure(encoding="utf-8")
        except Exception:
            pass
    # ... rest of main
```

**⚠️ 警告**：不要在可能被 import 的模块中使用 `io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')`，会导致多次 import 时 "I/O operation on closed file" 错误。

### 4.3 加载 .env 模板

```python
def _load_env_file():
    """Load .env from project root into os.environ."""
    from pathlib import Path
    current = Path(__file__).resolve()
    for parent in [current.parent] + list(current.parents):
        env_file = parent / ".env"
        if env_file.exists():
            with open(env_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#") and "=" in line:
                        key, _, value = line.partition("=")
                        key = key.strip()
                        if key not in os.environ:
                            os.environ[key] = value.strip().strip("\"'")
            break

_load_env_file()
```

### 4.4 LLM 调用配置（Skill 脚本调用 LLM 时）

Skill 脚本如需调用 LLM，**必须使用环境变量中预置的 `TOOL_LLM_*` 配置**。这些变量由 CoQi 平台在 Skill 执行时自动注入，开发者直接读取即可：

```python
import os
import json
import urllib.request

def call_llm(prompt: str, system_prompt: str = "") -> str:
    """Call LLM via OpenAI-compatible API using TOOL_LLM_* config."""
    api_key = os.environ.get("TOOL_LLM_API_KEY")
    base_url = os.environ.get("TOOL_LLM_BASE_URL", "https://api.openai.com/v1")
    model = os.environ.get("TOOL_LLM_MODEL", "gpt-4o")

    if not api_key:
        raise RuntimeError("TOOL_LLM_API_KEY not set in environment")

    url = f"{base_url.rstrip('/')}/chat/completions"
    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.append({"role": "user", "content": prompt})

    data = json.dumps({
        "model": model,
        "messages": messages,
        "temperature": 0.3,
    }, ensure_ascii=False).encode("utf-8")

    req = urllib.request.Request(url, data=data, headers={
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}",
    })

    max_retries = 3
    for attempt in range(max_retries):
        try:
            with urllib.request.urlopen(req, timeout=120) as resp:
                result = json.loads(resp.read().decode("utf-8"))
                return result["choices"][0]["message"]["content"]
        except Exception as e:
            if attempt == max_retries - 1:
                raise
            import time
            time.sleep(2 ** attempt)

# Usage
result = call_llm("Summarize: ...", system_prompt="You are a document summarizer.")
```

> **重要**：只允许使用 `TOOL_LLM_*` 前缀的环境变量。不要尝试读取或硬编码其他 LLM 相关环境变量。

### 4.5 依赖管理

**优先使用 Python 标准库**，零外部依赖是最佳实践。

如需第三方 Python 包，CoQi 平台支持以下方式（按优先级）：

**方式一：`requirements.txt`（推荐）**

在 Skill 根目录放置 `requirements.txt`，平台在首次执行时自动创建隔离 venv 并安装依赖。后续执行通过 SHA256 缓存复用已有 venv，无需等待：

```
skills/<name>/
├── SKILL.md
├── requirements.txt
└── scripts/
```

`requirements.txt` 示例：

```
python-docx>=1.0.0
openpyxl>=3.1.0
```

**方式二：预构建 `.venv/`**

如果依赖需要编译或安装耗时过长，可直接在 Skill 目录下放置预构建的 `.venv/`。平台检测到后直接激活使用，跳过 `requirements.txt` 处理：

```
skills/<name>/
├── SKILL.md
├── .venv/
└── scripts/
```

**平台注入的环境变量**

平台执行 Skill 脚本时自动注入以下变量：

| 变量 | 值 | 用途 |
|------|-----|------|
| `COQI_PROJECT_ROOT` | 项目根目录路径 | 定位资源 |
| `COQI_FONTS_DIR` | `plugins/fonts/` 路径 | 加载字体 |

```python
import os
fonts_dir = os.environ.get("COQI_FONTS_DIR")
```

### 4.6 输入文件大小检查

处理用户上传文件时，必须检查文件大小防止 DoS：

```python
import os

MAX_FILE_SIZE = 100 * 1024 * 1024  # 100 MB

file_size = os.path.getsize(input_path)
if file_size > MAX_FILE_SIZE:
    print(json.dumps({
        "success": False,
        "errors": [f"File too large: {file_size / 1024 / 1024:.1f} MB (max {MAX_FILE_SIZE / 1024 / 1024:.0f} MB)"]
    }, ensure_ascii=False))
    sys.exit(1)
```

### 4.7 压缩包安全检查

处理 DOCX/XLSX/PPTX 等 ZIP 格式时：

```python
import zipfile

MAX_UNCOMPRESSED = 200 * 1024 * 1024   # 总解压大小上限
MAX_SINGLE_ENTRY = 50 * 1024 * 1024    # 单个条目上限

with zipfile.ZipFile(path) as z:
    # 检查压缩比（压缩炸弹检测）
    total_compressed = sum(info.compress_size for info in z.infolist())
    total_uncompressed = sum(info.file_size for info in z.infolist())
    if total_compressed > 0 and total_uncompressed / total_compressed > 100:
        raise ValueError("Suspicious compression ratio (possible zip bomb)")

    if total_uncompressed > MAX_UNCOMPRESSED:
        raise ValueError(f"Uncompressed size exceeds limit")

    for info in z.infolist():
        if info.file_size > MAX_SINGLE_ENTRY:
            raise ValueError(f"Entry '{info.filename}' too large")
```

### 4.8 XML 解析安全

DOCX 内部 XML 使用标准库解析时：

```python
import defusedxml.ElementTree as ET  # 推荐：防 XXE
# 或
from xml.etree import ElementTree as ET  # Python 3.8+ 已默认禁用外部实体
```

### 4.9 CJK 文本处理

处理中日韩文本时：

```python
# 字数统计应支持 CJK（每字符 = 1 词）
def count_words(text: str) -> int:
    """CJK-aware word count."""
    if not text:
        return 0
    cjk_ranges = [
        (0x4E00, 0x9FFF),    # CJK Unified
        (0x3400, 0x4DBF),    # CJK Extension A
        (0xF900, 0xFAFF),    # CJK Compatibility
        (0x3040, 0x309F),    # Hiragana
        (0x30A0, 0x30FF),    # Katakana
        (0xAC00, 0xD7AF),    # Hangul
    ]
    cjk_count = sum(1 for ch in text if any(lo <= ord(ch) <= hi for lo, hi in cjk_ranges))
    en_words = len(__import__("re").findall(r"[a-zA-Z]+", text))
    return cjk_count + en_words

# JSON 输出确保中文不被转义
json.dumps(data, ensure_ascii=False, indent=2)

# 文件操作显式指定编码
Path(output).write_text(content, encoding="utf-8")
```

## 5. CLI 设计规范

Skill 脚本的**唯一调用方是 Agent**，因此只需支持 Agent JSON 输出模式。开发者调试时可以额外输出人类可读内容到 stdout，但交付验收以 `--json` 模式为准。

### 5.1 参数设计

```python
parser = argparse.ArgumentParser(description="...")
parser.add_argument("input", help="Input file path")

# Agent JSON 模式（唯一交付模式）
parser.add_argument("--json", "-j", action="store_true", required=True,
                    help="JSON 格式输出 (Agent 调用时必须使用)")

# 输出路径
parser.add_argument("--output", "-o", default=None,
                    help="Output file path (default: stdout)")

# 静默模式（减少 stderr 日志干扰 Agent 解析）
parser.add_argument("--quiet", "-q", action="store_true",
                    help="减少日志输出")
```

### 5.2 Agent JSON 输出格式

```python
# 标准输出结构（始终输出 JSON 到 stdout）
result = {
    "success": True,              # bool: 执行是否成功
    "output_path": "output/result.md",  # str|null: 输出文件绝对路径
    "data": {                     # dict: 结构化结果数据
        "metadata": {...},        # 核心元数据
        "content": "...",         # 完整输出内容
    },
    "errors": []                  # list[str]: 错误信息
}

print(json.dumps(result, ensure_ascii=False, indent=2))
```

### 5.3 日志与错误处理

```python
def log(msg: str):
    """所有日志输出到 stderr，不污染 stdout 的 JSON 结果。"""
    if not args.quiet:
        print(msg, file=sys.stderr)

def fail(errors, exit_code=1):
    """统一错误退出，始终输出 JSON 格式。"""
    error_list = errors if isinstance(errors, list) else [errors]
    print(json.dumps({
        "success": False,
        "output_path": None,
        "data": {},
        "errors": error_list,
    }, ensure_ascii=False))
    sys.exit(exit_code)
```

### 5.4 输出文件路径规范

```
# ✅ 正确：使用沙箱允许的目录
--output output/result.md
--output output/skill-name/report.pdf

# ✅ 正确：stdout 输出（无需写文件时）
（不传 --output 参数）

# ❌ 错误：硬编码 Linux 路径
--output /home/user/workspace/result.md

# ❌ 错误：项目源码目录
--output src/result.md
--output config/result.md
```

沙箱允许的目录（隔离执行时）：`user/`、`output/`、`temp/`、`database/`、`logs/`。

### 5.5 写入前创建父目录

```python
if args.output:
    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)  # 防止目录不存在报错
    out_path.write_text(output, encoding="utf-8")
```

## 6. 安全规范 —— 沙箱必读

> **这是交付审核中最严格的检查项。** Skill 将在隔离沙箱中执行，违反以下任何一条规则都会导致 Skill 被沙箱拦截，审核不通过。

### 6.1 沙箱核心规则（一票否决）

| 规则 | 说明 |
|------|------|
| **输出目录** | 所有文件写入必须落在 `output/`、`user/`、`temp/`、`database/`、`logs/` 之一 |
| **禁止读取** | 不能读取 `src/`、`config/`、`.env` 等源码和配置目录 |
| **禁止绝对路径** | 不能硬编码 `/home/...`、`C:\Users\...` 等系统绝对路径 |
| **禁止跨 Skill** | 不能依赖其他 Skill 的文件或产物 |
| **禁止假设 CWD** | 不能假设脚本运行在项目根目录，CWD 是临时隔离目录 |

### 6.2 执行隔离

- Skill 脚本在 `temp/skills/skill-{name}-{uuid}/` 下执行
- CWD 锁定在隔离目录，`--output` 自动重写到 `output/`
- 产物收集到 `output/skill-{name}/`
- 执行后延时 1 分钟清理临时文件

因此 Skills **不能**依赖：
- 全局文件路径（如 `/home/user/...`）
- 假设脚本在项目根目录运行的相对路径
- 跨 Skill 的共享文件

### 6.3 路径安全

```python
# Skill 脚本应使用安全路径构造
from pathlib import Path

# ✅ 基于输入路径推导输出路径
input_path = Path(args.input)
output_path = Path("output") / f"{input_path.stem}_result.md"

# ❌ 直接拼接用户输入
output_path = args.input + "_result.md"  # 路径遍历风险
```

### 6.4 网络安全

Skill 脚本如需访问网络：
- 禁止访问私有 IP 段和云元数据端点（如 `169.254.169.254`）
- 始终使用 `TOOL_LLM_*` 配置的端点，不要硬编码 URL

## 7. 字体使用

生成 PDF、DOCX、HTML 等文档时，应使用项目预置的共享字体，确保中文排版效果一致。

### 7.1 可用字体

字体文件位于 `plugins/fonts/`，包含以下字体：

| 字体文件 | 字体名称 | 推荐用途 |
|----------|----------|----------|
| `PlayfairDisplay-VF.ttf` | Playfair Display | 大标题、封面标题 |
| `Sora-VF.ttf` | Sora | 章节标题、副标题 |
| `SourceSerif4-VF.ttf` | Source Serif 4 | 正文段落 |
| `NotoSerifSC-VF.ttf` | Noto Serif SC | 中文衬线（正文） |
| `NotoSansSC-VF.ttf` | Noto Sans SC | 中文无衬线（标题） |

> 以上均为可变字体（VF），支持多种字重，无需额外的 Bold/Regular 文件。

### 7.2 加载字体

脚本直接使用平台注入的 `COQI_FONTS_DIR` 环境变量即可，无需遍历目录：

```python
from pathlib import Path

def load_fonts():
    """加载项目共享字体。优先使用 COQI_FONTS_DIR 环境变量。"""
    import os
    fonts_dir = os.environ.get("COQI_FONTS_DIR")
    if not fonts_dir:
        raise FileNotFoundError("COQI_FONTS_DIR not set")
    # matplotlib 示例
    # import matplotlib.font_manager as fm
    # for f in Path(fonts_dir).glob("*.ttf"):
    #     fm.fontManager.addfont(str(f))
    # plt.rcParams["font.family"] = "Noto Serif SC"
    return Path(fonts_dir)
```

### 7.3 多语言排版建议

| 内容类型 | 推荐字体栈 |
|----------|-----------|
| 中英文混合正文 | `Source Serif 4, Noto Serif SC, serif` |
| 中英文混合标题 | `Sora, Noto Sans SC, sans-serif` |
| 纯中文正文 | `Noto Serif SC, serif` |
| 纯中文标题 | `Noto Sans SC, sans-serif` |
| 英文大标题 | `Playfair Display, serif` |

## 8. 测试与验证

### 8.1 基础验证

```bash
# 检查 Python 脚本语法
python3 -c "import py_compile; py_compile.compile('skills/<name>/scripts/main.py', doraise=True)"

# 测试解析 SKILL.md（项目中已有解析器）
node test/test-skill-parser.js
```

### 8.2 Skill 专用测试

为 Skill 编写独立测试文件 `test/test-skill-<name>.js`：

```javascript
// test/test-skill-word-summary.js
import { SkillLoader } from '../src/skills/loader.js';
import { SkillParser } from '../src/skills/parser.js';

const loader = new SkillLoader();
const skills = await loader.loadAll();

const skill = skills.find(s => s.name === 'word-summary');
console.assert(skill, 'Skill should be loaded');
console.assert(skill.description.includes('Word'), 'Description should mention Word');
console.assert(skill.name === 'word-summary', 'Skill name should match directory');

console.log('✓ All tests passed');
```

### 8.3 集成测试

```bash
# 测试 Skill 脚本执行
node test/test-exec-skill.js

# 测试上下文匹配
node test/test-context-matching.js

# 测试集成匹配
node test/test-integration-matching.js
```

### 8.4 交付前自测 Checklist

- [ ] `SKILL.md` YAML frontmatter 有效
- [ ] `name` 与目录名一致
- [ ] Python 脚本在 Windows 和 Linux 均能运行
- [ ] `--json` 模式输出 JSON 结构正确
- [ ] stderr 日志不干扰 stdout JSON 输出
- [ ] 多种输入格式/大小均处理正确
- [ ] 错误输入有清晰的错误信息
- [ ] 边界情况（空文件、超大文件、损坏文件）不会崩溃
- [ ] CJK 内容正确显示

## 9. 常见陷阱

### 9.1 路径硬编码

```python
# ❌ 错误：Linux 硬编码路径
output = "/home/user/workspace/result.md"

# ❌ 错误：假设当前目录在项目根
output = "output/result.md"  # Skill 隔离执行时 CWD 不是项目根

# ✅ 正确：使用脚本自身路径推导
script_dir = Path(__file__).resolve().parent
output = script_dir / "output" / "result.md"

# ✅ 正确：通过 --output 参数传入
# Agent 调用时自动重写到沙箱 output/
```

### 9.2 缺少 UTF-8 处理

Windows 上输出中文会乱码。**每个 Python 脚本的 `main()` 必须处理。**

### 9.3 未创建输出目录

```python
# ❌ 错误：目录不存在时直接报错
Path("output/subdir/result.md").write_text(content)

# ✅ 正确：先创建父目录
p = Path("output/subdir/result.md")
p.parent.mkdir(parents=True, exist_ok=True)
p.write_text(content, encoding="utf-8")
```

### 9.4 XML/压缩包无大小限制

处理 DOCX/XLSX 时，不检查大小可能导致：
- Zip 炸弹耗尽内存
- XML 实体扩展攻击 (XXE/billion laughs)

**必须**在读取前检查解压大小和压缩比。

### 9.5 Skill 脚本长度超标

`SKILL.md` > 500 行 → 拆分详细内容到 `references/`。  
`scripts/main.py` > 500 行 → 拆分工具函数到 `scripts/lib/`。

### 9.6 LLM 配置混用

```python
# ❌ 错误：使用非 TOOL_LLM_* 前缀的环境变量
api_key = os.environ.get("SOME_OTHER_API_KEY")
model = "gpt-4"  # 硬编码模型名

# ✅ 正确：只使用 TOOL_LLM_* 前缀的变量
api_key = os.environ.get("TOOL_LLM_API_KEY")
model = os.environ.get("TOOL_LLM_MODEL")
```

### 9.7 错误输出到 stdout

```python
# ❌ 错误：日志输出到 stdout，干扰 --json 模式的解析
print("Processing file...")

# ✅ 正确：日志输出到 stderr
import sys
print("Processing file...", file=sys.stderr)
```

### 9.8 CJK 字数统计不准

只用 `len(text.split())` 统计中文会严重低估。必须分别处理 CJK 字符（每字 = 1 词）和拉丁语系单词。

### 9.9 违反沙箱输出目录限制

Skill 在隔离环境中执行，CWD 不是项目根目录，**唯一可写入的目录是 `output/`**：

```python
# ❌ 错误：写入源码目录或硬编码绝对路径
output = "src/result.md"
output = "/tmp/result.md"
output = "C:/Users/xxx/result.md"

# ❌ 错误：直接写当前目录（隔离执行时 CWD 在 temp 下）
output = "./result.md"

# ✅ 正确：写入 output/ 目录
output = "output/result.md"
# 或通过 --output 参数传入（Agent 会自动处理路径）
```

> 沙箱只允许写入 `user/`、`output/`、`temp/`、`database/`、`logs/` 目录。写入其他任何路径都会触发 `sandbox_blocked` 错误导致 Skill 执行失败。

## 10. 审查清单

**交付前必须逐项自查**，未通过以下项目的 Skill 将被我方审核退回。

### SKILL.md

- [ ] `name` 符合规范（小写/数字/连字符，与目录名一致）
- [ ] `description` ≥ 50 字符，含中英文触发词
- [ ] `metadata` 所有值均为字符串，无嵌套对象或数组
- [ ] 正文含：使用场景、参数表、分步指令、边界情况、示例
- [ ] 命令使用相对路径 (`scripts/...`)
- [ ] 输出路径使用 `output/` 目录
- [ ] 主文件 < 500 行（正文 < 5000 tokens）

### 脚本安全

- [ ] `main()` 开头有 Windows UTF-8 处理
- [ ] 使用 `TOOL_LLM_*` 配置（非 `LLM_*`）
- [ ] 输入文件有大小检查（如适用）
- [ ] ZIP/XML 解析有大小/压缩比检查（如适用）
- [ ] 日志输出到 stderr
- [ ] 第三方依赖在 `compatibility` 字段中注明
- [ ] CJK 字数统计准确

### CLI 设计

- [ ] 支持 `--json` 模式，始终输出 JSON 到 stdout
- [ ] 日志输出到 stderr（支持 `--quiet` 静默）
- [ ] 错误输出结构正确（含 `success`/`errors` 字段）
- [ ] `--output` 写入前创建父目录
- [ ] JSON 输出使用 `ensure_ascii=False`
- [ ] 空输入/损坏输入/超大输入不会崩溃
- [ ] 所有输出写入 `output/` 目录，不写入其他路径

### 沙箱合规

- [ ] 所有文件输出路径在允许目录内（`output/`、`user/`、`temp/`、`database/`、`logs/`）
- [ ] 不使用硬编码绝对路径（`/home/...`、`C:\...`等）
- [ ] 不依赖项目根目录的当前工作目录（CWD）
- [ ] 不读取 `src/`、`config/`、`.env` 等沙箱禁止目录
- [ ] 网络请求使用 `TOOL_LLM_*` 配置的端点（非硬编码）

### 文档输出（如适用）

- [ ] 使用 `plugins/styles/` 设计令牌
- [ ] 加载 `plugins/fonts/` 共享字体
- [ ] 默认使用 v2 (Editorial Red) 风格

### 测试

- [ ] `python3 -c "import py_compile"` 语法检查通过
- [ ] 手动测试过 Windows 和 Linux
- [ ] `--json` 模式输出可被 `json.loads()` 解析
- [ ] 空输入/损坏输入/超大输入不会崩溃
