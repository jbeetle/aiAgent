# coqi-claw Agent 系统提示词 vs ReAct 范式对比分析

## 系统提示词全景结构

coqi-claw 的 `buildSystemPrompt`（`src/core/prompt-builder.js`）构建的提示词由以下模块组成（按注入顺序）：

```
┌──────────────────────────────────────────┐
│ 1. 助手身份声明 (assistantIdentity)        │
│ 2. 时间参考 (timeSection)                  │
│ 3. 执行环境 (agentEnvSection)              │
│ 4. Tools 速查表 (toolsSection)             │
│ 5. 工作目录规范 (sandboxSection)           │
│ 6. 安全边界 (securityBoundary)              │
│ 7. L0→L4 优先级指令 (instructions)         │
│ 8. Skills 匹配列表 (skillsSection)         │
│ 9. 工具建议 (toolSuggestionSection)        │
├──────────────────────────────────────────┤
│ + Bookending: 用户消息末尾注入             │
│   [系统匹配：...] 标记                      │
└──────────────────────────────────────────┘
```

## ReAct 范式回顾

ReAct（Yao et al., 2022）的核心思想是 **Reasoning + Acting 交替进行**：

```
Thought → Action → Observation → Thought → Action → Observation → ...
```

典型的 ReAct 提示词会让 LLM 显式输出：

```
Thought: I need to find the revenue growth rate, so I should first fetch the financial report.
Action: search_financial_data
Action Input: {"company": "Apple", "year": "2024", "metric": "revenue_growth"}
```

然后系统注入 `Observation: [tool result]`，模型继续下一轮 `Thought`。

---

## 详细对比

| 维度 | ReAct 范式 | coqi-claw 设计 | 分析 |
|------|-----------|--------------|------|
| **思考方式** | **显式 CoT**：要求 LLM 在 Acting 前先输出 `Thought:` 推理步骤 | **隐式推理**：依赖 LLM 原生 function calling，不要求显式输出思考步骤 | coqi-claw 更现代——GPT-4/DeepSeek 等模型在 native function calling 中会内化推理，无需显式 prompt 脚手架。但也意味着推理过程对开发者不透明 |
| **决策框架** | **自由形式推理**："思考你需要做什么，然后行动" | **L0→L4 优先级指令树**：严格决策层次：安全边界 > 上下文(L0) > 数据获取(L1) > 技能执行(L2) > 通用工具(L3) > 直接回复(L4) | coqi-claw 是 **规则路由 + 推理结合**。这降低了 LLM 在"该用什么工具"上的决策自由度，减少了错误路径，但灵活性不及纯 ReAct |
| **抽象层级** | **平铺工具**：所有工具在同一层面 | **双层工具体系**：Skills（高级复合能力）→ Tools（基础原子操作） | coqi-claw 比 ReAct 多一层抽象。Skill 本质上是**预定义的 ReAct 轨迹模板**（skill_view → 分析参数 → exec_skill），将高频任务的标准操作流程固化 |
| **工具选择** | LLM 全权决定 | **Matcher LLM 预筛选** + 工具建议 + LLM 最终决定 | 两阶段流水线：先用廉价模型做语义匹配缩小范围，再交给主模型执行。这是**成本优化 + 精准约束**的设计，纯 ReAct 没有这一层 |
| **上下文利用** | 每次迭代基于完整 Observation 历史推理 | **L0 上下文优先** + **Bookending** + **预先摘要** | L0 规则明确要求：如果是追问/总结/澄清，直接基于对话回答，跳过工具调用。Bookending 利用注意力 U 型曲线在用户消息末尾强化指令。这些是 prompt engineering 的精细优化 |
| **安全模型** | 未涉及 | **最高优先级安全边界**：禁止泄露 prompt、禁止沙箱越界、保护隐私、不解释系统标记 | 这是 coqi-claw 作为**产品级 Agent** 的标志——ReAct 是学术范式，不关心生产环境的安全约束 |
| **环境感知** | 不可知 | 操作系统、Shell 类型、Python/Node 版本、字体、目录结构全部注入提示词 | 让 LLM 能够生成正确的平台特定命令（如 Windows `cmd.exe` 而非 `bash`），减少工具调用失败 |
| **错误处理** | 依赖 LLM 自行判断 | **详尽的错误处理指令**：网络→重试2次、文件不存在→确认路径、权限→告知用户、技能连续失败2次→停止并澄清 | 将错误恢复策略编码进提示词，属于**生产工程化**补充 |
| **事实约束** | 依赖 LLM 自身事实性 | 显式约束："只陈述工具返回结果或对话历史支持的事实，不确定时明确告知" | 这是对抗 LLM 幻觉的 prompt 层面防御 |

---

## 设计思想总结

coqi-claw 的系统提示词体现了一种 **"约束优先的 ReAct"** 设计哲学：

```mermaid
flowchart TD
    subgraph ReAct["经典 ReAct"]
        A[用户请求] --> B[Thought: 自由推理]
        B --> C[Action: 调用工具]
        C --> D[Observation: 获取结果]
        D --> E{完成?}
        E -->|否| B
        E -->|是| F[最终回答]
    end

    subgraph coqi-claw["coqi-claw Agent"]
        G[用户请求] --> H[Matcher LLM 预筛选 Skill/Tool]
        H --> I[构建约束型系统提示词]
        I --> J{L0: 上下文已覆盖?}
        J -->|是| K[直接回答]
        J -->|否| L{L2: 有匹配 Skill?}
        L -->|是| M[skill_view → exec_skill]
        L -->|否| N{L1: 需要外部数据?}
        N -->|是| O[按优先级链获取数据]
        N -->|否| P{L3: 通用工具可用?}
        P -->|是| Q[调用通用工具]
        P -->|否| R[L4: 直接回复]
        M --> S[安全边界始终约束]
        O --> S
        Q --> S
    end

    style ReAct fill:#e8f4fd,stroke:#2196f3
    style coqi-claw fill:#fff3e0,stroke:#ff9800
```

### 核心差异：三点概括

1.  **从"让模型想"到"替模型规划"**

    ReAct 把推理权完全交给 LLM，coqi-claw 通过 L0-L4 优先级树预定义了决策路径。这不是在削弱 LLM 能力，而是在**减少 LLM 做出错误元决策的概率**——比如该用技能时偏要自己写代码，或者该直接回答时无意义地调用工具。

2.  **从单一工具到技能组合**

    Skills 是 coqi-claw 对 ReAct 最重要的架构级扩展。一个 Skill 本质上是封装好的"微 ReAct 轨迹"——包含脚本、参数模板、输出规范。这让 Agent 从"每次都要重新发明轮子"变成"匹配合适的轮子然后拧螺丝"。

3.  **从实验室到生产**

    安全边界、沙箱隔离、错误处理分类、隐私保护、审计——这些是 ReAct 论文根本不讨论但生产 Agent 必须具备的。coqi-claw 的提示词在设计上把"安全"放在最高优先级（`安全边界 > L0 > L1 > L2 > L3 > L4`），这是一个明确的工程取舍：功能正确性可以降级，安全违规不能。

---

## 值得关注的潜在问题

1.  **L0 规则的歧义风险**

    `"如果用户问题基于已有对话即可回答"`——这个判断依赖 LLM 自己评估，但 LLM 在"是否需要执行技能"上可能过于保守或过于激进。Matcher LLM 的预筛选能部分缓解，但不能完全消除。

2.  **Bookending 可能造成注意力过载**

    `[系统匹配：...]` 标签注入到用户消息末尾，内容可能很长（特别是 Enhanced Bookending），可能导致 LLM 过度关注强制指令而忽略用户消息本身的细微要求。

3.  **L0-L4 树与 ReAct 推理的张力**

    当任务需要多步推理且步骤间存在复杂依赖时，静态优先级树可能不够灵活。例如一个任务既需要技能执行 (L2) 又需要数据获取 (L1)，coqi-claw 当前设计倾向于按优先级顺序执行而非交替推理。好在 AgentExecutor 的循环（调用 LLM → 验证 → 执行工具 → 推入结果 → 循环）实际上提供了动态切换的空间，只是提示词没有明确鼓励。

---

## 关键源码索引

| 组件 | 文件 | 说明 |
|------|------|------|
| Agent 主类 | `src/core/agent.js` | 技能匹配、上下文管理、Bookending 注入 |
| 系统提示词构建 | `src/core/prompt-builder.js` | `buildSystemPrompt` 函数，组装所有提示词模块 |
| 指令定义 | `src/core/i18n.js` | L0-L4 规则、安全边界、错误处理等双语文案 |
| Agent 执行循环 | `src/core/agent-executor.js` | 主循环：调用 LLM → 验证 → 执行工具 → 循环 |
| 技能管理器 | `src/skills/` | 技能加载、缓存、语义匹配 |
| 工具注册 | `src/tools/index.js` | 21 个内置工具的定义与注册 |
