# Skill 隔离模式开发指引

## 背景

coqi-claw 的 `exec_skill` 工具在 `ENABLE_EXEC_ISOLATION=true`（默认）时，会在隔离目录中执行技能脚本：

```
temp/skills/skill-{name}-{uuid}/skills/{name}/   ← cwd
```

只复制 `skills/{name}/` 目录到隔离 cwd，**不复制 `plugins/`**（styles、fonts）。
这意味着脚本中的 `__file__` 向上搜索找不到 `plugins/styles/` 或 `plugins/fonts/`，
相对路径的输入文件也找不到（Agent 写到 `temp/`，但 cwd 是 `temp/skills/skill-xxx/`）。

如果不遵循本指引，技能脚本在隔离模式下会静默失败，Agent 陷入 30+ 次盲目重试。

---

## 三条核心规则

### 1. 输出参数必须用 `--output/-o` 标志，不能用位置参数

`resolveOutputParam` 只重写 `--output/-o`、`--dest`、`--file` 标志参数，**不处理位置参数**。

```python
# 错误 — 位置参数不会被重写，文件写入隔离 cwd 外的非法路径
parser.add_argument('output', help='输出文件路径')

# 正确 — 标志参数会被 resolveOutputParam 识别和重写
parser.add_argument('--output', '-o', dest='output_flag', help='输出文件路径')
output_target = args.output or args.output_flag
```

```javascript
// 正确
options.output = args[--output/-o] || positionalFallback;
```

### 2. 资源定位必须用环境变量优先，不能只靠 `__file__` 向上搜索

exec_skill 已注入以下环境变量：

| 环境变量 | 值 | 用途 |
|----------|---|------|
| `COQI_PROJECT_ROOT` | 项目根目录绝对路径 | 定位项目根目录 |
| `COQI_STYLES_DIR` | `plugins/styles/` 绝对路径 | 定位设计令牌文件 |
| `COQI_FONTS_DIR` | `plugins/fonts/` 绝定路径 | 定位字体文件 |

Python 和 JavaScript 的资源定位函数都必须按此优先级查找：

```python
def get_styles_dir():
    # 1. COQI_STYLES_DIR 环境变量（隔离模式注入）
    env_dir = os.environ.get('COQI_STYLES_DIR')
    if env_dir and os.path.isdir(env_dir):
        return env_dir

    # 2. COQI_PROJECT_ROOT 回退
    env_root = os.environ.get('COQI_PROJECT_ROOT')
    if env_root and os.path.isdir(env_root):
        styles_dir = os.path.join(env_root, 'plugins', 'styles')
        if os.path.exists(styles_dir):
            return styles_dir

    # 3. __file__ 硬编码层级（仅开发模式有效）
    # 4. __file__ 向上搜索标记文件（仅开发模式有效）
```

```javascript
function getStylesDir() {
  // 1. COQI_STYLES_DIR 环境变量
  const envDir = process.env.COQI_STYLES_DIR;
  if (envDir && existsSync(envDir)) return envDir;

  // 2. COQI_PROJECT_ROOT 回退
  const envRoot = process.env.COQI_PROJECT_ROOT;
  if (envRoot && existsSync(join(envRoot, 'plugins', 'styles'))) {
    return join(envRoot, 'plugins', 'styles');
  }

  // 3. __dirname 硬编码层级
  // 4. 向上搜索标记文件
}
```

**fonts 目录同理**，用 `COQI_FONTS_DIR` 和 `COQI_PROJECT_ROOT/plugins/fonts/`。

### 3. 输入文件必须支持候选目录搜索

隔离模式下 cwd 是 `temp/skills/skill-xxx/`，而 Agent 通常将输入文件写入 `temp/`。
相对路径在 cwd 下无法找到文件。

```python
from lib.path_validator import resolve_input_path

# resolve_input_path 自动：
#   1. validate_input_path() 沙箱验证
#   2. os.path.exists() 检查
#   3. 在 COQI_PROJECT_ROOT/temp/、output/、user/、cwd/../.. 中搜索
input_path = resolve_input_path(args.input_file)
```

```javascript
import { loadData } from './lib/script-utils.js';

// loadData 自动在候选目录中搜索输入文件
const data = loadData(args.input, defaultData);
```

---

## 完整 Checklist

开发新技能或审查现有技能时，逐项检查：

### CLI 接口

| 检查项 | 要求 |
|--------|------|
| 输出参数 | 使用 `--output/-o` 标志（或 `--dest`/`--file`），不用位置参数 |
| 输入参数 | 使用 `--input/-i` 标志，配合 `resolve_input_path()` 或 `loadData()` |
| JSON 模式 | 支持 `--json/-j`，结构化输出包含 `success`、`output_path`、`errors` |

### 资源定位

| 资源 | 定位方式 |
|------|---------|
| 设计令牌 (`design-tokens-v2.json`) | `COQI_STYLES_DIR` → `COQI_PROJECT_ROOT/plugins/styles/` → `__file__` 向上搜索 |
| 字体文件 (`NotoSansSC-VF.ttf` 等) | `COQI_FONTS_DIR` → `COQI_PROJECT_ROOT/plugins/fonts/` → `__file__` 向上搜索 |
| 项目根目录 | `COQI_PROJECT_ROOT` → `__file__` 向上搜索 `package.json/.git/pyproject.toml` |

### 路径安全

| 检查项 | 要求 |
|--------|------|
| 输出路径验证 | `validate_output_path(output_target)` — 沙箱校验 |
| 输入路径验证 | `resolve_input_path(input_file)` — 沙箱校验 + 候选搜索 |
| path_validator.py `_find_project_root()` | `COQI_PROJECT_ROOT` 环境变量优先于 `__file__` 向上搜索 |

### .env 加载

| 检查项 | 要求 |
|--------|------|
| Python 脚本 | `path_validator.py` 的 `_load_env_file()` 在模块加载时执行 |
| JavaScript 脚本 | 不需要单独加载 .env（Node.js 进程由 Agent 启动，环境变量已注入） |

### UTF-8 编码

| 检查项 | 要求 |
|--------|------|
| Python | `sys.stdout.reconfigure(encoding='utf-8')`（不用 `TextIOWrapper`） |
| JavaScript | `initWindowsEncoding()`（幂等，`chcp 65001` + `_handle.setEncoding`） |

---

## 目录结构模板

```
skills/{skill-name}/
├── SKILL.md
├── scripts/
│   ├── main_script.py              # 主脚本，用 argparse
│   └── lib/
│       ├── path_validator.py       # 必须包含 COQI_PROJECT_ROOT + resolve_input_path
│       ├── design_tokens.py        # 必须包含 COQI_STYLES_DIR + COQI_PROJECT_ROOT
│       ├── chinese_fonts.py        # 必须包含 COQI_FONTS_DIR + COQI_PROJECT_ROOT（如需）
│       ├── encoding.py             # Windows UTF-8 初始化
│       └── script-utils.js         # loadData 候选搜索（JS 技能）
│   └── references/                 # 可选：详细文档
│   └── assets/                     # 可选：静态资源
```

---

## 隔离模式执行流程

```
Agent 调用 exec_skill(command="python scripts/create.py --output result.pdf --input data.json")
│
├─ exec-skill.js:
│   ├─ 创建隔离 cwd: temp/skills/skill-{name}-{uuid}/
│   ├─ 复制 skills/{name}/ → cwd/skills/{name}/
│   ├─ resolveOutputParam: --output → 沙箱 output/ 目录
│   ├─ 注入 env: COQI_PROJECT_ROOT, COQI_STYLES_DIR, COQI_FONTS_DIR
│   ├─ 执行命令
│   └─ collectAndAttach: 扫描新文件 → 移动到 output/skill-{name}/
│
├─ 脚本内部:
│   ├─ path_validator._load_env_file() → 加载 .env
│   ├─ validate_output_path() → 沙箱校验输出路径
│   ├─ resolve_input_path() → 沙箱校验 + 候选目录搜索输入文件
│   ├─ design_tokens.get_styles_dir() → COQI_STYLES_DIR → COQI_PROJECT_ROOT → __file__
│   ├─ chinese_fonts.get_fonts_dir() → COQI_FONTS_DIR → COQI_PROJECT_ROOT → __file__
│   └─ 输出结果 JSON: { success, output_path, errors }
```

---

## 常见失败模式与对照修复

| 失败现象 | 根因 | 修复 |
|----------|------|------|
| 设计令牌加载失败 / FileNotFoundError | `__file__` 在隔离 cwd 向上找不到 `plugins/styles/` | 添加 `COQI_STYLES_DIR` 环境变量优先级 |
| 字体文件找不到 | `__file__` 在隔离 cwd 向上找不到 `plugins/fonts/` | 添加 `COQI_FONTS_DIR` 环境变量优先级 |
| `_find_project_root()` 返回 None | 隔离 cwd 没有 `package.json/.git` | 添加 `COQI_PROJECT_ROOT` 环境变量优先级 |
| 输出文件不在 `output/` 目录 | 位置参数不被 `resolveOutputParam` 重写 | 改用 `--output/-o` 标志参数 |
| `--input` 文件找不到 | Agent 写到 `temp/`，脚本 cwd 是 `temp/skills/skill-xxx/` | 使用 `resolve_input_path()` 或 `loadData()` 候选搜索 |
| 沙箱 PermissionError | 输出路径在 cwd 外，未通过沙箱校验 | `validate_output_path()` 检查 + `resolveOutputParam` 重写 |
| Agent 30+ 次重试 | 脚本静默失败（设计令牌缺失 → 空输出 → Agent 疯狂猜测） | 以上所有修复 |

---

## 添加新 plugins 资源类型

如果项目新增 `plugins/` 下的共享资源目录（如 `plugins/templates/`、`plugins/icons/`），需要：

1. **exec-skill.js** 注入对应环境变量：
   ```javascript
   env: {
     COQI_PROJECT_ROOT: getBaseDir(),
     COQI_STYLES_DIR: path.join(getBaseDir(), "plugins", "styles"),
     COQI_FONTS_DIR: path.join(getBaseDir(), "plugins", "fonts"),
     COQI_TEMPLATES_DIR: path.join(getBaseDir(), "plugins", "templates"),  // 新增
     ...env,
   },
   ```

2. **技能脚本** 的定位函数添加环境变量优先级：
   ```python
   def get_templates_dir():
       env_dir = os.environ.get('COQI_TEMPLATES_DIR')
       if env_dir and os.path.isdir(env_dir):
           return env_dir
       env_root = os.environ.get('COQI_PROJECT_ROOT')
       ...
   ```

命名约定：`COQI_{DIRNAME}_DIR`，其中 `DIRNAME` 是 `plugins/` 下的目录名大写（如 `styles` → `STYLES`，`fonts` → `FONTS`）。