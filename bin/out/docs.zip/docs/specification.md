# Agent Skills 开发规范

> 来源：https://agentskills.io/specification

## 概述

Agent Skills 是为 AI Agent 提供专业化能力的模块化扩展包。每个 skill 是一个包含元数据和指令的目录，可以被 AI Agent 动态加载和使用。

---

## 目录结构

一个 skill 至少包含一个 `SKILL.md` 文件，推荐结构如下：

```
skill-name/
├── SKILL.md          # 必需：元数据 + 使用说明
├── scripts/          # 可选：可执行脚本代码
├── references/       # 可选：附加文档
├── assets/           # 可选：模板、资源文件
└── ...               # 任何其他文件或目录
```

---

## SKILL.md 格式

`SKILL.md` 文件必须包含 YAML frontmatter，后接 Markdown 内容。

### Frontmatter 字段

| 字段 | 必需 | 约束条件 |
|------|------|----------|
| `name` | 是 | 最多64字符，仅限小写字母、数字和连字符，不能以连字符开头或结尾 |
| `description` | 是 | 最多1024字符，非空，描述 skill 功能和使用场景 |
| `license` | 否 | 许可证名称或指向捆绑许可证文件的引用 |
| `compatibility` | 否 | 最多500字符，指示环境要求（目标产品、系统包、网络访问等） |
| `metadata` | 否 | 任意键值对，用于存储附加元数据 |
| `allowed-tools` | 否 | 预批准的工具列表，以空格分隔（实验性功能） |

### 最小示例

```markdown
---
name: skill-name
description: A description of what this skill does and when to use it.
---
```

### 完整示例

```markdown
---
name: pdf-processing
description: Extract PDF text, fill forms, merge files. Use when handling PDFs.
license: Apache-2.0
metadata:
  author: example-org
  version: "1.0"
---
```

---

## 字段详细规范

### `name` 字段

命名规则：
- 长度：1-64 字符
- 仅允许小写字母（a-z）、数字和连字符（-）
- **不能**以连字符开头或结尾
- **不能**包含连续连字符（--）
- 必须与父目录名称匹配

**有效示例：**
```yaml
name: pdf-processing
name: data-analysis
name: code-review
```

**无效示例：**
```yaml
name: PDF-Processing  # 错误：包含大写字母
name: -pdf            # 错误：以连字符开头
name: pdf--processing # 错误：连续连字符
```

### `description` 字段

编写规范：
- 长度：1-1024 字符
- 应描述 skill 的功能**以及**使用场景
- 应包含帮助 Agent 识别相关任务的关键词

**优秀示例：**
```yaml
description: Extracts text and tables from PDF files, fills PDF forms, and merges multiple PDFs. Use when working with PDF documents or when the user mentions PDFs, forms, or document extraction.
```

**糟糕示例：**
```yaml
description: Helps with PDFs.
```

### `license` 字段

建议保持简短（许可证名称或指向捆绑许可证文件的引用）：

```yaml
license: Proprietary. LICENSE.txt has complete terms
```

### `compatibility` 字段

用于指定环境要求，最多500字符：

```yaml
# 示例
compatibility: Designed for Claude Code (or similar products)
compatibility: Requires git, docker, jq, and access to the internet
compatibility: Requires Python 3.14+ and uv
```

> 注意：大多数 skills 不需要此字段。

### `metadata` 字段

键值对映射，用于存储附加属性：

```yaml
metadata:
  author: example-org
  version: "1.0"
```

建议使用独特的键名以避免冲突。

### `allowed-tools` 字段（实验性）

预批准的工具列表，以空格分隔：

```yaml
allowed-tools: Bash(git:*) Bash(jq:*) Read
```

---

## 正文内容（Body Content）

YAML frontmatter 后的 Markdown 内容包含 skill 的使用说明。推荐包含的章节：

- 分步指令
- 输入输出示例
- 常见边界情况

> 注意：Agent 在决定激活 skill 后会加载整个文件。内容较长时，建议拆分到引用文件中。

---

## 可选目录详解

### `scripts/` 目录

包含 Agent 可运行的可执行代码：
- 应自包含或明确记录依赖
- 包含有帮助的错误信息
- 优雅地处理边界情况

支持的语言取决于 Agent 实现，常见选项：Python、Bash、JavaScript。

### `references/` 目录

包含 Agent 按需读取的附加文档：
- `REFERENCE.md` - 详细技术参考
- `FORMS.md` - 表单模板或结构化数据格式
- 领域特定文件（`finance.md`, `legal.md` 等）

保持单个参考文件聚焦。Agent 按需加载这些文件，小文件意味着更少的上下文使用。

### `assets/` 目录

包含静态资源：
- 模板（文档模板、配置模板）
- 图片（图表、示例）
- 数据文件（查找表、模式定义）

---

## 渐进式披露原则

Skills 应结构化以高效使用上下文：

| 层级 | 内容 | 加载时机 | 建议大小 |
|------|------|----------|----------|
| **元数据** | `name` 和 `description` | 启动时加载所有 skills | ~100 tokens |
| **指令** | `SKILL.md` 正文 | 激活 skill 时加载 | < 5000 tokens |
| **资源** | `scripts/`、`references/`、`assets/` 中的文件 | 按需加载 | 视需求 |

保持主 `SKILL.md` 在 500 行以内。将详细参考资料移到单独文件中。

---

## 文件引用

引用 skill 内其他文件时，使用相对于 skill 根目录的路径：

```markdown
See [the reference guide](references/REFERENCE.md) for details.

Run the extraction script:
scripts/extract.py
```

保持文件引用在 `SKILL.md` 的下一级深度。避免深层嵌套的引用链。

---

## 验证

使用 [skills-ref](https://github.com/agentskills/agentskills/tree/main/skills-ref) 参考库验证 skills：

```bash
skills-ref validate ./my-skill
```

这将检查 `SKILL.md` frontmatter 是否有效，以及是否遵循所有命名规范。

---

## 设计原则总结

1. **聚焦**：每个 skill 只做一件事，并做好
2. **自描述**：清晰的描述帮助 Agent 正确选择 skill
3. **模块化**：通过 `scripts/` 和 `references/` 分离关注点
4. **高效**：遵循渐进式披露，优化上下文使用
5. **可验证**：使用工具确保格式正确
