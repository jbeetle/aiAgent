# Skill Trust Framework 管理员操作手册

## 概述

本文档面向 coqi-claw 的系统管理员，描述如何在金融企业场景中部署 Skill Trust Framework，包括密钥管理、skill 签名/加密、部署配置和日常运维。

## 前提条件

- Node.js >= 22.0.0
- OpenSSL（用于生成 RSA 密钥对）
- 项目已初始化（`npm install` 完成）

---

## 一、密钥管理

### 1.1 生成 RSA 密钥对

企业首次部署时，生成一对 4096-bit RSA 密钥：

```bash
# 在项目根目录执行
openssl genrsa -out config/private.pem 4096
openssl rsa -in config/private.pem -pubout -out config/public.pem
```

**文件用途**：

| 文件 | 用途 | 存放位置 |
|------|------|---------|
| `config/private.pem` | 签名 skill + 解封 Skill Key | **安全保管，不进入代码仓库** |
| `config/public.pem` | 验证签名 + 封装 Skill Key | 随项目部署到所有 Agent 节点 |

### 1.2 私钥安全

`config/private.pem` 必须严格保护：

- **不提交到 Git**：在 `.gitignore` 中追加 `config/private.pem`
- **不随项目分发**：打包/部署脚本排除该文件
- **存储在密钥管理系统（KMS）或 HSM 中**：生产环境推荐方案
- **权限设置为 600**：`chmod 600 config/private.pem`

### 1.3 密钥轮换

当需要轮换密钥时：

1. 生成新密钥对
2. 用新私钥重新签名所有已部署的 skill
3. 更新所有 Agent 节点的 `config/public.pem`
4. 旧私钥安全销毁

---

## 二、Skill 签名流程

### 2.1 管理员审核 Skill

在签名前，管理员必须审核 skill 内容：

1. 检查 `SKILL.md` 中的 frontmatter（name、description）
2. 检查 `scripts/` 目录下的脚本内容，确认无恶意代码
3. 检查 `references/` 和 `assets/` 中的文件
4. 确认 skill 无外部依赖（或依赖已审计）

### 2.2 执行签名

审核通过后，在**项目根目录**执行：

```bash
node scripts/skill-sign.js skills/department-report \
  --key-id coqi-claw-internal \
  --expire-days 365
```

参数说明：

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `skill-dir` | skill 目录路径（必填） | - |
| `--key-id` | 签名密钥标识 | `coqi-claw-internal` |
| `--expire-days` | 签名有效期（天） | `365` |

执行后，会在 skill 目录下生成 `.skill-trust` 文件：

```
skills/department-report/
├── SKILL.md
├── .skill-trust          ← 新生成
├── scripts/
└── ...
```

### 2.3 验证签名

签名后可立即验证：

```bash
node -e "
const { verifySkillSignature, loadTrustPolicy } = require('./src/security/skill-trust.js');
const policy = loadTrustPolicy('.');
const result = verifySkillSignature('./skills/department-report', policy);
console.log(result);
"
```

期望输出：`{ valid: true, reason: 'signature-verified', ... }`

### 2.4 签名过期处理

`.skill-trust` 中的 `expiresAt` 字段控制签名有效期。过期后：

1. Agent 加载时检测到过期，拒绝加载该 skill
2. 管理员重新执行 `skill-sign.js` 更新签名
3. 无需修改 skill 内容，只需更新 `.skill-trust` 文件

---

## 三、Skill 加密流程（可选，针对敏感业务 Skill）

如果 skill 包含敏感业务逻辑（如交易算法、客户数据处理），在签名后进一步加密：

### 3.1 执行加密

```bash
node scripts/skill-encrypt.js skills/department-report \
  --files "scripts/*,references/*"
```

参数说明：

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `skill-dir` | skill 目录路径（必填） | - |
| `--files` | 要加密的文件匹配模式 | `scripts/*,references/*` |

执行后：
- 匹配的明文文件被加密为 `.enc` 文件
- 原始明文文件**保留**（管理员自行决定是否删除）
- `.skill-trust` 文件更新，新增 `encryption` 字段

**大文件注意事项**：AES-GCM 需要一次性将整个文件读入内存。`assets/` 中大于 10MB 的文件（如 PPT 模板、数据集）**不建议加密**，否则解密时会占用大量内存。只对 scripts/ 和 references/ 中的文本文件加密即可。

### 3.2 确认加密结果

```bash
ls skills/department-report/scripts/
# 应看到：
# generate.py.enc
# utils.py.enc
```

### 3.3 删除明文原文件（生产环境必须）

```bash
# 在确认加密和签名均无误后
cd skills/department-report/scripts
rm -f *.py          # 删除明文 Python 脚本
cd ../references
rm -f *.md          # 删除明文参考文档
```

**注意**：删除前务必确认 `.enc` 文件可正常解密（可用 `skill-cipher.js` 中的 `decryptContent` 测试）。

---

## 四、Agent 部署配置

### 4.1 金融企业完整配置

#### 4.1.1 环境变量（`.env`）

```bash
# === LLM 配置（已有） ===
LLM_PROVIDER=custom
LLM_API_KEY=xxx
LLM_BASE_URL=https://api.xxx.com/v1
LLM_MODEL=xxx

# === 沙箱配置（已有） ===
SANDBOX_PATHS=/data/projects,/data/reports
SANDBOX_MODE=enforce
ENABLE_EXEC_ISOLATION=true

# === Skill Trust Framework（新增） ===
# Master Key：用于解封 Skill Key（AES 对称密钥）
# 从 private.pem 派生，或独立生成 64 字符 hex 字符串
SKILL_MASTER_KEY=abcdef1234567890...

# 签名私钥路径（仅在签名/加密工具中使用，Agent 运行时不需要）
# SKILL_SIGNING_KEY_PATH=/secure/path/to/private.pem
```

#### 4.1.2 信任策略文件（`config/skill-trust-policy.json`）

```json
{
  "version": "1.0.0",
  "mode": "enforce",
  "signatures": {
    "trustedKeys": [
      {
        "id": "coqi-claw-internal",
        "name": "coqi-claw Internal Key",
        "publicKeyPath": "config/public.pem",
        "fingerprint": "sha256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
      }
    ],
    "requireTimestamp": true,
    "maxAgeDays": 365
  },
  "whitelist": {
    "enabled": false,
    "skills": []
  },
  "encryption": {
    "enabled": true,
    "masterKeyEnv": "SKILL_MASTER_KEY"
  }
}
```

### 4.2 一般企业配置

#### 4.2.1 环境变量

```bash
# === LLM 配置 ===
LLM_PROVIDER=custom
LLM_API_KEY=xxx
LLM_BASE_URL=https://api.xxx.com/v1
LLM_MODEL=xxx

# === 沙箱配置（可选） ===
# SANDBOX_MODE=warn
# ENABLE_EXEC_ISOLATION=false

# === Skill Trust Framework（不配置，保持默认关闭） ===
# 不设置 SKILL_MASTER_KEY
```

#### 4.2.2 信任策略文件

```json
{
  "version": "1.0.0",
  "mode": "off"
}
```

或**不创建** `config/skill-trust-policy.json` 文件（框架自动关闭）。

---

## 五、部署后验证

### 5.1 启动 Agent 验证日志

```bash
npm start "使用部门报告 skill"
```

观察日志：

**金融企业场景预期日志**：
```
[INFO] Loaded 5 skill(s)
[DEBUG]   - department-report: trust verified (signature-verified)
[DEBUG]   - open-source-tool: trust verification failed: missing-trust-file
[ERROR] Skill "open-source-tool" rejected: missing-trust-file
[INFO] LLM matched 1 skill(s): ["department-report"]
```

**一般企业场景预期日志**：
```
[INFO] Loaded 8 skill(s)
[DEBUG]   - department-report: trust framework off
[DEBUG]   - open-source-tool: trust framework off
[INFO] LLM matched 2 skill(s): ["department-report", "open-source-tool"]
```

### 5.2 验证加密 skill 执行

```bash
# 检查隔离目录是否生成并清理
tail -f logs/agent.log | grep -E "copied|cleanup| Skill isolation"
```

---

## 六、日常运维

### 6.1 新增 Skill

1. 业务部门提交 skill 目录
2. 管理员审核内容
3. 签名：`node scripts/skill-sign.js skills/new-skill`
4. （可选）加密：`node scripts/skill-encrypt.js skills/new-skill`
5. 部署到 Agent 节点的 `skills/` 目录
6. 重启 Agent 或等待缓存过期（15 分钟）

### 6.2 更新 Skill

1. 修改 skill 内容
2. 重新签名（必须，因为 manifest hash 已变）
3. （如已加密）重新加密或只更新签名
4. 部署到 Agent 节点

### 6.3 删除 Skill

直接从 `skills/` 目录移除即可。Agent 缓存过期后自动生效，或手动重启清除缓存。

### 6.4 查看 Skill 信任状态

```bash
# 查看所有已加载 skill 的信任状态
node -e "
const { loadSkills } = require('./src/skills/loader.js');
const skills = loadSkills('./skills');
skills.forEach(s => {
  console.log(s.name, s._trustInfo ? s._trustInfo.reason : 'no-trust');
});
"
```

---

## 七、故障排查

### 7.1 Skill 加载数为 0

检查 `config/skill-trust-policy.json` 是否存在且 `mode` 设置正确。

### 7.2 "Missing Master Key" 错误

确认 `SKILL_MASTER_KEY` 环境变量已设置，且长度正确（64 字符 hex）。

### 7.3 "Signature verification failed"

- 确认 `config/public.pem` 与签名时使用的私钥匹配
- 确认 `.skill-trust` 文件未被篡改
- 确认 skill 文件未被修改（修改后需要重新签名）

### 7.4 "Signature expired"

重新执行 `skill-sign.js` 更新签名。

---

## 八、安全审计日志

`src/security/skill-trust.js` 中内置审计日志，关键事件自动记录：

| 事件 | 日志级别 | 说明 |
|------|---------|------|
| `skill_rejected` | ERROR | skill 被拒绝加载（原因：无签名、签名无效、过期等）|
| `skill_loaded` | INFO | skill 成功加载（含信任状态）|
| `signature_verified` | DEBUG | 签名验证通过 |
| `decryption_failed` | ERROR | 加密 skill 解密失败（MasterKey 错误、文件损坏）|

日志格式（结构化 JSON，便于 SIEM 接入）：
```json
{"timestamp":"2025-05-11T10:00:00Z","event":"skill_rejected","skillName":"open-source-tool","reason":"missing-trust-file","policyMode":"enforce","osUser":"admin"}
```

生产环境建议将 `logs/agent.log` 接入企业日志平台，配置告警规则：
- skill_rejected 事件 > 10 次/小时 → 告警（可能攻击）
- decryption_failed 事件 > 1 次 → 告警（配置错误或密钥泄露）

---

## 九、安全最佳实践

1. **私钥不在生产环境**：生产环境的 Agent 节点只保留 `public.pem`，私钥留在管理员的工作站或 KMS 中
2. **定期轮换密钥**：建议每年轮换一次 RSA 密钥对
3. **审计签名记录**：维护一个签名日志，记录谁、何时、对哪个 skill 进行了签名
4. **加密 skill 的明文备份**：加密后的 `.enc` 文件无法恢复，保留一份明文备份在安全存储中
5. **限制 skill 目录权限**：`chmod 700 skills/`，防止未授权用户添加 skill
6. **大文件不加密**：`assets/` 中 >10MB 的文件保持明文，避免内存压力
