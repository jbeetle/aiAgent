# safe-solution-2 生产部署 Review 报告

> **状态：已落地生产** — 2026-04-19
> 全部 P0 项已完成，P1/P2 项部分完成。

## 结论

方案方向正确，覆盖 90% 场景。**6 个关键补强点已全部实现或部分实现**，已部署生产。

---

## 一、已覆盖（已实现并部署）

| 项 | 说明 | 状态 |
|----|------|------|
| Agent 提示词约束 | 系统提示中的工作目录规范已存在，约束 Agent 调用工具时的路径选择 | 已存在 |
| exec cwd 隔离 | 锁定工作目录到 `temp/skills/` 下的 UUID 隔离目录，脚本写相对路径自然收敛 | 已实现 |
| 产出文件命名空间隔离 | 产出文件放入 `output/skill-{name}/` 子目录，防止覆盖 | 已实现 |
| 参数路径防逃逸校验 | `resolveOutputParam()` 中调用 `validatePath()`，越界路径重映射或拒绝 | 已实现 |
| 文件归集容错 | 重试扫描（3 次/500ms）、大文件（>500MB）不搬运、搬运失败保留原路径 | 已实现 |
| 临时目录延迟清理 | 执行后 1 分钟自动清理隔离目录 | 已实现 |
| UUID 临时目录命名 | `randomUUID().slice(0, 8)` 确保唯一，避免并发冲突 | 已实现 |
| 功能开关 | `ENABLE_EXEC_ISOLATION` 环境变量，默认 true，设 false 回退 | 已实现 |
| SANDBOX_PATHS 生效 | 沙箱根目录扩展机制不变，作为整个方案的地基 | 已存在 |
| SANDBOX_MODE 生效 | enforce/warn/off 三种模式保持原语义，不影响隔离层 | 已存在 |
| read 路径锚定 | `skills/` 路径强制解析到项目根，不受 cwd 变化影响 | 已实现 |
| skill 模式校验 | security.js 区分 general/skill 校验策略，防止命令误杀 | 已实现 |
| 自动 skill 检测 | exec.js 从命令中自动检测 `skills/xxx/scripts/` 路径模式 | 已实现 |
| 文件操作路径校验 | exec.js 对 copy/move/del 等命令和 PowerShell cmdlet 做路径校验 | 已实现 |
| 引号内命令替换放行 | `$()` 和 `` ` `` 在引号内作为参数值时放行 | **代码实际阻断，文档与代码不一致** |
| 纯文件操作链放行 | `move A && move B` 等纯文件操作命令链放行 | 已实现 |

---

## 二、必须补强（实现状态）

### 1. 临时目录命名：用 UUID，不用时间戳 ✅

**实现**：
```javascript
const workDirName = `skill-${name}-${randomUUID().slice(0, 8)}`;
const workDir = path.join(sandboxTempDir, 'skills', workDirName);
```

**状态**：已部署

---

### 2. 产出文件命名空间隔离：防止覆盖 ✅

**实现**：产出文件放入 `output/skill-{name}/` 命名空间子目录：
```javascript
const namespaceDir = path.join(outputDir, `skill-${skillName}`);
fs.mkdirSync(namespaceDir, { recursive: true });
```

**状态**：已部署

---

### 3. 参数路径补全的防逃逸校验 ✅

**实现**：`resolveOutputParam()` 中补全前调用 `validatePath()`：
```javascript
result = result.replace(pattern, (match, prefix, paramPath) => {
  const resolved = path.resolve(paramPath);
  try {
    validatePath(resolved);
    return match; // 已在沙箱内，不做处理
  } catch {
    const fileName = path.basename(paramPath);
    const newPath = path.join(sandboxOutputDir, fileName);
    return prefix + newPath; // 重映射到 output/
  }
});
```

**状态**：已部署

---

### 4. 文件归集的原子性和容错 ✅（部分）

**已实现**：
- ✅ 重试扫描（3 次，500ms 间隔，应对异步写文件）
- ✅ 大文件（>500MB）不搬运，直接返回原路径
- ✅ 搬运失败降级：保留原路径并记录日志

**未实现**：
- 磁盘空间不足检测（搬运前检查目标磁盘空间）

**状态**：核心容错已部署，磁盘空间检测建议后续补充

---

### 5. 临时目录生命周期和清理策略 ✅（部分）

**已实现**：
- ✅ 自动延迟清理：exec 返回后 1 分钟清理
```javascript
setTimeout(() => {
  fs.rmSync(workDir, { recursive: true, force: true });
}, 60 * 1000);
```

**未实现**：
- 启动时清理超过 24 小时的残留目录

**建议**：作为运维脚本定期执行，或在下个版本中补充启动时清理。

**状态**：核心清理已部署，启动时清理建议后续补充

---

### 6. 安全事件统一日志格式 ⏳（未实现）

**现状**：仍使用原有 `logger.error/warn` 格式，未统一为结构化安全事件格式。

**示例当前格式**：
```javascript
logger.error('Blocked dangerous command', {
  command, pattern: pattern.toString(), shell, context, skillName
});
```

**建议格式**（供后续参考）：
```javascript
logger.warn('Security event', {
  event: 'sandbox.path_blocked',
  inputPath: 'C:\\escape\\file.txt',
  allowedRoots: [...],
  mode: 'enforce',
  tool: 'exec',
  context: 'skill',
  skillName: 'pdf-reader'
});
```

**状态**：未实现，P2 优先级，不影响生产运行

---

## 三、需要额外配套措施（状态更新）

### 1. 操作系统级隔离（长期）⏳

当前方案是**应用层隔离**，无法防御：
- 脚本创建符号链接/硬链接/junction 指向外部路径
- 脚本 spawn 子进程执行任意命令
- 脚本通过网络外泄数据（归 network-policy.js，但可配黑白名单）

**建议**：生产环境评估容器化（Docker）或 Windows Sandbox 作为最终防线。应用层隔离 + OS 级隔离 = 纵深防御。

**状态**：建议评估，未实施

### 2. Skill 市场审核流程（前置拦截）⏳

当前方案将恶意 skill 的拦截前置到市场审核，但审核流程本身需要落地：

- 审核脚本自动扫描源码中的硬编码绝对路径
- 审核脚本检查脚本是否支持 `--output` 参数
- 人工抽检高风险 skill

**状态**：流程设计已完成，审核脚本待开发

### 3. 磁盘配额监控 ⏳

`output/` 和 `temp/` 可能无限增长。建议：
- 启动时检查磁盘空间，低于阈值告警
- 定期清理 `output/` 中超过 N 天的旧文件
- 单 skill 产出文件大小上限

**状态**：建议实施，未开发

---

## 四、已知风险（接受并记录）

| 风险 | 说明 | 缓解措施 |
|------|------|---------|
| 符号链接绕过 | 脚本在隔离目录创建 symlink 指向外部 | 应用层无法拦截，靠 OS 级隔离 + 市场审核 |
| 子进程绕过 | 脚本内部 spawn/exec 新进程执行任意命令 | 同上 |
| 网络外泄 | 脚本通过网络把数据发出去 | network-policy.js 管控，可配 allowlist |
| LLM 不遵守提示词 | Agent 可能把路径参数传错 | 参数补全兜底 + 校验拒绝越界路径 |
| 大文件搬运失败 | 产出文件过大导致搬运失败 | 超 500MB 不搬运，返回原路径 |
| 异步写文件遗漏 | 脚本返回后异步写文件，扫描时文件未就绪 | 3 次重试扫描机制 |
| 临时目录残留 | 进程崩溃导致临时目录未清理 | 运维脚本定期清理 |

---

## 五、实现阶段总结

### Phase 1（已上线）✅

1. ✅ UUID 临时目录命名（P0）
2. ✅ 产出文件命名空间隔离（P0）
3. ✅ 参数路径防逃逸校验（P0）
4. ✅ 功能开关 `ENABLE_EXEC_ISOLATION`（P0）

### Phase 2（已上线，部分完成）✅/⏳

5. ✅ 文件归集原子性和容错（P1）— 重试、大文件保护、降级
6. ✅ 临时目录延迟自动清理（P1）— 1 分钟后清理
7. ⏳ 启动时清理超过 24 小时的残留目录（P1）— 建议运维脚本处理
8. ⏳ 安全事件统一日志格式（P2）— 未实现

### Phase 3（长期）⏳

9. ⏳ 操作系统级隔离评估
10. ⏳ Skill 市场审核流程落地
11. ⏳ 磁盘配额监控

---

## 六、Review Checklist（更新）

- [x] 临时目录使用 UUID 命名
- [x] 产出文件放入 skill 命名空间子目录
- [x] 参数路径补全前调用 validatePath 防逃逸
- [x] 文件搬运失败时降级返回 temp 路径
- [x] 大文件（>500MB）不自动搬运
- [x] 执行后扫描加入重试机制
- [x] 临时目录延迟自动清理（1分钟）
- [ ] 启动时清理超过 24 小时的残留目录（建议运维脚本）
- [x] 功能开关 ENABLE_EXEC_ISOLATION
- [ ] 安全事件统一日志格式（P2，未实现）
- [x] 向后兼容：无 context 参数的 exec 调用保持原行为
- [x] Windows 路径分隔符、大小写、空格处理正确
- [x] 自动检测 skill 模式（skills/xxx/scripts/ 路径模式）
- [x] 文件操作命令路径校验（copy/move/del 等）
- [x] PowerShell cmdlet 路径校验（Remove-Item 等）
- [ ] 引号内命令替换放行（**代码实际阻断，2 个测试用例失败，见第八节**）
- [x] 纯文件操作链放行（move && move）

---

## 七、测试覆盖

| 测试文件 | 用例数 | 通过 | 失败 | 说明 |
|----------|--------|------|------|------|
| `test/test-exec-skill.js` | 22 | 20 | **2** | Skill 模式、文件操作链、命令替换、脚本路径验证 |
| `test/test-security-command.js` | 39 | 39 | 0 | 安全命令校验（含 npm 白名单、危险模式阻断） |
| `test/test-path-sandbox.js` | 14 | 14 | 0 | 路径沙箱校验（含 traversal、enforce/warn/off 模式） |
| `test/test-dlp.js` | 51 | 51 | 0 | DLP 脱敏（含信用卡、JWT、邮箱等） |

**总计：124 passed, 2 failed**

> **注意**：`test-exec-skill.js` 中 2 个失败用例均与"引号内 `$()` 放行"相关（见下文第八节）。现有 review 报告中的"126 passed, 0 failed"数据有误。

---

## 八、代码审查发现的问题

本次 review 通过对比 `safe-solution-2.md` 文档描述与实际代码实现，发现以下问题：

### 8.1 引号内命令替换 —— 文档、代码、测试三方不一致

| 来源 | 态度 |
|------|------|
| `safe-solution-2.md` 文档 | "引号内 `$(cmd)` 放行" |
| `test-exec-skill.js` 测试 | 期望引号内放行（2 个用例因此失败） |
| `security.js` 代码 | **直接阻断，不区分引号内外** |

**代码依据**（`src/security/security.js:163-168`）：

```javascript
// 命令替换 ($() 和 ` `)：直接阻断，不区分引号内外
// bash 双引号内的 $() 仍会执行命令替换，因此不能因"在引号内"而放行
if (pattern.test(command)) {
  throw Errors.security(...);
}
```

**相关死代码**：`isIndexInQuotes()` 函数（`security.js:14-30`）存在但**从未被调用**。该函数是实现"引号内放行"策略所需的基础设施，但当前策略已改为"一律阻断"。

**建议**：统一三方。安全优先的方案是保持代码的严格阻断策略，修改文档和测试以匹配代码行为。

---

### 8.2 涉及文件列表遗漏两个核心实现文件

`safe-solution-2.md` 的"涉及文件"表格遗漏：

| 遗漏文件 | 职责 | 在文档中被引用但未列入表格 |
|---------|------|--------------------------|
| `src/tools/exec-skill.js` | 工作目录隔离的核心实现：`resolveOutputParam()`、`collectProducedFiles()`、`scanDirectory()`、`scheduleWorkDirCleanup()` | 伪代码多处引用 |
| `src/security/command-path-validator.js` | Layer 2.5 路径校验实现：`validateFileOperationPaths()`、`validateCommandPathArguments()` | 第 2.5 节整节描述 |

---

### 8.3 `resolveOutputParam` 重映射后缺少二次校验

文档描述（2.2 防逃逸校验）："如果重映射后的路径仍越界，拒绝执行"

实际代码（`src/tools/exec-skill.js:64-74`）：重映射后直接拼接 `sandboxOutputDir + fileName`，未调用 `validatePath()` 二次校验。虽然 `sandboxOutputDir` 来自 `getSandboxBaseDir()` 本身可信，但文档描述与代码实现存在表述差异。

**建议**：在 `resolveOutputParam` 中对重映射后的 `newPath` 增加显式的 `validatePath()` 调用，消除文档与代码的不一致。

---

### 8.4 跨盘搬运降级的代码增强未在文档中体现

文档中的文件归集伪代码只写了 `fs.renameSync(file, dest)`，未提及跨盘场景。

实际代码（`src/tools/exec-skill.js:117-133`）在遇到 `EXDEV`（跨磁盘/分区）时自动降级为 `copyFileSync` + `unlinkSync`，增强了健壮性。

**建议**：在文档中补充此降级逻辑的描述。

---

### 8.5 `cd /d` Windows 语法导致脚本路径解析错误（已修复）

**问题**：Agent 生成的命令 `cd /d C:\clawSandbox && python skills/henry-city-weather/scripts/weather.py` 被安全层阻断。

**根因**：三个正则表达式在提取 `cd` 目标路径时，将 `/d` 错误捕获为路径的一部分：
- `isCdToScriptRunner()` 的 `scriptRunnerMatch` 和 `bashScriptMatch`
- `extractScriptPath()` 的 `cdMatch`

提取出的 `cdPath` 为 `/d C:\clawSandbox`，导致：
1. `path.resolve('/d C:\\clawSandbox', 'skills/...')` 在 Windows 下解析为 `C:\d C:\clawSandbox\skills\...`（错误路径）
2. `validateSkillScriptPath()` 判定路径越界，阻断执行

**修复**（`src/security/security.js`）：
1. 三个正则增加 `(?:\/[dD]\s+)?` 以剥离 Windows `cd /d` 标志：
   ```javascript
   // 修复前
   /^cd\s+["']?([^"']+)["']?\s+&&\s+/
   // 修复后
   /^cd\s+(?:\/[dD]\s+)?["']?([^"']+)["']?\s+&&\s+/
   ```
2. `extractScriptPath()` 中增加 `skills/` 路径保护：不以 `cd` 目标解析 `skills/` 开头的路径，保持相对形式返回，由 `validateSkillScriptPath()` 以项目根锚定（与 `read.js` 行为一致）。

**状态**：已修复并验证。

---

### 8.6 JSON 参数中的 `/` 分隔符被误判为 Unix 绝对路径（已修复）

**问题**：Agent 调用 `python skills/henry-docx-tools/scripts/docx_create.py ... --structure '[{..."CNN / NBC / Fox"...}]' --json` 被安全层阻断，错误信息：`Path "/" is outside the allowed sandbox directories`。

**根因**：`validateCommandPathArguments()` 使用 `command.split(/\s+/)` 提取未引号 token 进行路径校验。JSON 内容中的 `CNN / NBC / Fox` 被空格拆分后，`/` 成为独立 token。`^[\/\\]/.test("/")` 将其判定为 Unix 绝对路径 `/`，传给 `validatePath` 后越界阻断。

**修复**（`src/security/command-path-validator.js`）：在未引号 token 循环中增加常见操作符过滤：

```javascript
// 跳过命令操作符和常见分隔符（避免 JSON/文本内容中的空格分隔被误判为路径）
if (/^[|&;<>>]+$/.test(token) || token === '/') {
  continue;
}
```

**状态**：已修复并验证。真正的越界路径（如 `C:/outside/file.txt`、`/etc/passwd`）仍正常拦截。
