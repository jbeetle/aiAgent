# Plan: 新增 python_ptc 工具（Python Programmatic Tool Calling）

## Context

coqi-claw 当前的 `exec` 工具是命令优先的：LLM 调用 exec 执行 shell 命令，stdout/stderr 直接返回上下文。当任务需要多步工具链（搜索→读取→处理→写入）时，LLM 必须每步一个工具调用，中间结果全部进入上下文，导致 token 膨胀和推理轮数增加。

Hermes Agent 的 `execute_code` 通过 PTC（Programmatic Tool Calling）模式解决了这个问题：LLM 写一个 Python 脚本，脚本内通过生成的 stub 模块调用工具（RPC 代理），中间结果不进入上下文，只有最终 stdout 返回。我们希望在 coqi-claw 中引入同模式工具，但不替换现有 `exec`。

## Design Goals

1. **不替换 exec**：`python_ptc` 作为新增内置工具，与 `exec` 共存
2. **多步工具链压缩**：LLM 写 Python 脚本，脚本内调用 CoQi 工具，单次推理完成多步操作
3. **中间结果不出上下文**：工具调用通过 RPC 代理，只有最终 stdout 返回 LLM
4. **跨平台**：支持 Windows（不用 Unix Domain Socket）
5. **安全**：环境变量过滤、工具白名单、Secrets 脱敏、超时/次数限制
6. **零额外依赖**：Python 用标准库 `urllib.request`，Node.js 用内置 `http`

## Architecture

```
LLM 调用 python_ptc({ code: "..." })
    → Node.js 启动临时 HTTP server（127.0.0.1:随机端口）
        → 生成 coqi_tools.py stub（含各工具函数 + HTTP client）
            → spawn python3 子进程，注入 COQI_RPC_URL / COQI_RPC_TOKEN
                → 脚本运行：import coqi_tools → coqi_tools.read(...) → HTTP POST → Node server
                    → Node server 收到请求 → 调用 executeTool(name, args) → 返回 JSON
                        → 脚本拿到结果继续执行 ...
                            → 脚本 exit → stdout（head+tail 截断）→ 返回 LLM
```

## Key Design Decisions

### IPC 机制：HTTP localhost server

- Python `urllib.request`（标准库）+ Node.js `http`（内置）
- 绑定 `127.0.0.1:0`（随机端口），仅本地可访问
- 一次性随机 token（32 字节 hex）鉴权，防止外部伪造请求
- 无文件轮询延迟，跨平台（含 Windows）

### 工具白名单

定义常量 `PYTHON_PTC_ALLOWED_TOOLS`，与当前 session 的 `ENABLED_TOOLS` 取交集后生成 stub。初始白名单：

- `read`, `write`, `list`, `glob`, `search`
- `web_fetch`, `download`, `http_request`
- `time`, `system_info`, `clipboard`
- `archive`

**不含 `exec`**：脚本本身已经是 Python 执行环境（可写 `os.system(...)`），通过 exec 反而增加不可控面。如果后续需求强烈，可单独评估加入受限 exec。

### 环境安全

类似 Hermes 的 env scrubbing：

```javascript
const SAFE_ENV_PREFIXES = ['PATH', 'HOME', 'USER', 'LANG', 'LC_', 'TEMP', 'TMP',
                           'PYTHON', 'PYTHONIOENCODING', 'PYTHONUTF8', 'COQI_'];
const SECRET_SUBSTRINGS = ['KEY', 'TOKEN', 'SECRET', 'PASSWORD', 'CREDENTIAL', 'PASSWD', 'AUTH'];

const childEnv = {};
for (const [k, v] of Object.entries(process.env)) {
    if (SECRET_SUBSTRINGS.some(s => k.toUpperCase().includes(s))) continue;
    if (SAFE_ENV_PREFIXES.some(p => k.toUpperCase().startsWith(p))) {
        childEnv[k] = v;
    }
}
childEnv.COQI_RPC_URL = serverUrl;
childEnv.COQI_RPC_TOKEN = authToken;
childEnv.PYTHONDONTWRITEBYTECODE = '1';
childEnv.PYTHONIOENCODING = 'utf-8';
childEnv.PYTHONUTF8 = '1';
```

### 输出处理

- **stdout**：head+tail 截断（40% head / 60% tail），默认上限 50KB，保证最终 `print()` 可见
- **stderr**：head-only，默认上限 10KB
- **ANSI 剥离**：返回前 `stripAnsi(stdout)`，防止终端格式污染 LLM 上下文
- **Secrets 脱敏**：扫描 stdout/stderr 中是否包含环境变量值（如 API key），替换为 `[REDACTED]`

### 执行控制

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `timeout` | 300s | 脚本最大运行时间 |
| `maxToolCalls` | 50 | 脚本内最大工具调用次数 |
| `maxStdoutBytes` | 50KB | stdout 上限 |
| `maxStderrBytes` | 10KB | stderr 上限 |

超时处理：先 `SIGTERM`（非 Windows）等待 5s，再 `SIGKILL`。超时返回部分输出 + `status: timeout`。

## Files to Modify / Create

### New Files

1. **`src/tools/python-ptc.js`**（~350 行）
   - `description` / `parameters` / `execute(args)` 导出
   - `execute(args)`：参数校验 → 启动 HTTP server → 生成 stub → spawn Python → 收集 stdout/stderr → 等待退出/超时 → 关闭 server → 后处理 → 返回 JSON
   - HTTP request handler：验证 token → 检查工具白名单 → 检查调用次数 → `await dispatchToolCall()` → 返回 JSON
   - `dispatchToolCall`：动态 `import('./index.js')` 获取 `executeTool`，避免循环依赖
   - `generateStubModule(enabledTools)`：生成 Python stub 源码字符串
   - `filterEnv()`：环境变量 scrubbing
   - `stripAnsi(str)`：ANSI escape 剥离（可复用或内联简单实现）

2. **`src/tools/python-ptc-stub.js`**（可选，若 stub 生成逻辑过长则拆分）
   - 仅包含 `generateStubModule()`，被 `python-ptc.js` import

### Modified Files

3. **`src/tools/index.js`**（+3 行）
   - `import * as pythonPtcTool from './python-ptc.js';`
   - `python_ptc: buildTool(pythonPtcTool)` 加入 `buildBuiltInTools()`

4. **`src/core/i18n.js`**（+2 行）
   - 添加 `python_ptc` 描述的中英文翻译键

## Detailed Implementation Notes

### HTTP Server 生命周期

```javascript
async function startRpcServer(dispatchFn) {
    return new Promise((resolve, reject) => {
        const server = http.createServer(async (req, res) => {
            if (req.method !== 'POST') { res.statusCode = 405; res.end(); return; }
            let body = '';
            req.on('data', chunk => body += chunk);
            req.on('end', async () => {
                const { tool, args, token } = JSON.parse(body);
                if (token !== expectedToken) { res.statusCode = 403; res.end(); return; }
                try {
                    const result = await dispatchFn(tool, args);
                    res.writeHead(200, {'Content-Type': 'application/json'});
                    res.end(JSON.stringify({success: true, result}));
                } catch (e) {
                    res.writeHead(500, {'Content-Type': 'application/json'});
                    res.end(JSON.stringify({success: false, error: e.message}));
                }
            });
        });
        server.listen(0, '127.0.0.1', () => {
            const port = server.address().port;
            const token = randomBytes(16).toString('hex');
            resolve({ server, url: `http://127.0.0.1:${port}`, token });
        });
    });
}
```

关闭：`server.close()` 在 finally 块中执行。

### Stub 模块生成

生成的 `coqi_tools.py` 放在临时目录，与子进程同目录，确保 `import coqi_tools` 可解析。

```python
"""Auto-generated CoQi tools RPC stubs."""
import json
import os
import urllib.request

_SERVER_URL = os.environ.get("COQI_RPC_URL", "")
_TOKEN = os.environ.get("COQI_RPC_TOKEN", "")

def _call(tool_name, args):
    req = urllib.request.Request(
        _SERVER_URL,
        data=json.dumps({"tool": tool_name, "args": args, "token": _TOKEN}).encode("utf-8"),
        headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req, timeout=300) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    if not data.get("success"):
        raise RuntimeError(data.get("error", "Unknown RPC error"))
    return data.get("result")

def read(path, offset=1, limit=500):
    return _call("read", {"path": path, "offset": offset, "limit": limit})

# ... 其他工具函数
```

### stdout 收集（head+tail）

借鉴 Hermes 实现：

```javascript
const MAX_STDOUT = config.maxStdoutBytes || 50_000;
const HEAD_BYTES = Math.floor(MAX_STDOUT * 0.4);
const TAIL_BYTES = MAX_STDOUT - HEAD_BYTES;

let headBuf = Buffer.alloc(0);
let tailDeque = [];      // rolling buffer for tail
let tailTotal = 0;
let totalBytes = 0;

proc.stdout.on('data', chunk => {
    totalBytes += chunk.length;
    if (headBuf.length < HEAD_BYTES) {
        const keep = Math.min(chunk.length, HEAD_BYTES - headBuf.length);
        headBuf = Buffer.concat([headBuf, chunk.slice(0, keep)]);
        chunk = chunk.slice(keep);
    }
    if (chunk.length) {
        tailDeque.push(chunk);
        tailTotal += chunk.length;
        while (tailTotal > TAIL_BYTES && tailDeque.length) {
            tailTotal -= tailDeque.shift().length;
        }
    }
});
```

最终 `stdout = headBuf + "... [TRUNCATED] ..." + Buffer.concat(tailDeque)`。

### Secrets 脱敏

```javascript
function redactSecrets(text) {
    for (const [k, v] of Object.entries(process.env)) {
        if (!v || v.length < 4) continue;
        if (SECRET_SUBSTRINGS.some(s => k.toUpperCase().includes(s))) {
            text = text.split(v).join('[REDACTED]');
        }
    }
    return text;
}
```

简单但有效——把 env 中的 secret 值从输出中全局替换。

### Description / Schema 设计（借鉴 Hermes 决策矩阵）

`description` 必须让 LLM 明确知道**什么时候用 python_ptc、什么时候用普通工具调用**。参照 Hermes 的决策矩阵设计：

```
Run a Python script that can call CoQi tools programmatically.
Use this when you need 3+ tool calls with processing logic between them,
need to filter/reduce large tool outputs before they enter your context,
need conditional branching (if X then Y else Z), or need to loop
(fetch N pages, process N files, retry on failure).

Use normal tool calls instead when: single tool call with no processing,
you need to see the full result and apply complex reasoning after each step,
or the task requires interactive user input.

Available via `import coqi_tools`:
  read(path, offset=1, limit=500) -> dict
  write(path, content) -> dict
  search(pattern, target="content", path=".", ...) -> dict
  web_fetch(url) -> dict
  ... (仅当前 session 启用的工具)

Limits: 5-minute timeout, 50KB stdout cap, max 50 tool calls per script.

Print your final result to stdout. Use Python stdlib (json, re, math, csv,
datetime, collections, etc.) for processing between tool calls.

Also available (no import needed — built into coqi_tools):
  json_parse(text: str) — json.loads with strict=False
  shell_quote(s: str) — shlex.quote()
  retry(fn, max_attempts=3, delay=2) — retry with exponential backoff
```

决策矩阵（内化到 description）：

| 条件 | 用 python_ptc | 用普通工具 |
|------|---------------|-----------|
| 工具调用次数 | 3+ 次 | 1-2 次 |
| 调用之间有处理逻辑 | 脚本内 if/else/for/while | 没有 |
| 需要过滤/压缩工具输出 | 脚本内处理 | 直接看结果 |
| 需要重试机制 | retry() | 没有 |
| 需要循环（处理 N 个） | 脚本内循环 | 逐个调用 |
| 需要交互式调试 | 没有 | terminal/exec |
| 需要复杂推理后决定下一步 | 脚本是预设逻辑 | 每次看结果再决定 |
| 单次简单操作 | 不适用 | 直接调用 |

### Parameters Schema

```javascript
export const parameters = {
  type: 'object',
  properties: {
    code: {
      type: 'string',
      description: 'Python source code to execute. Import tools with `import coqi_tools` and print your final result to stdout.'
    },
    timeout: {
      type: 'number',
      description: 'Custom timeout in seconds (default: 300)'
    },
    max_stdout_bytes: {
      type: 'number',
      description: 'Max stdout bytes to return (default: 50000)'
    }
  },
  required: ['code']
};
```

## Edge Cases

1. **Python 不可用**：执行前检查 `python3` 或 `python`，返回明确错误提示
2. **脚本语法错误**：Python 子进程非零退出，stderr 中包含 traceback，返回 `status: error`
3. **工具调用失败**：RPC 返回 `success: false`，stub 抛出 `RuntimeError`，脚本可 `try/except` 捕获
4. **无限循环/死循环**：依赖 `timeout` 硬限制，超时后强制终止
5. **并发工具调用**：Node.js `http` 天然并发，但 `executeTool` 内部各工具可能有文件锁等限制
6. **循环依赖**：`python-ptc.js` 通过 `await import('./index.js')` 动态获取 `executeTool`，避免与 `index.js` 的静态循环依赖
7. **LLM 误用**：通过清晰的 description + 决策矩阵降低 LLM 在简单场景下滥用 python_ptc 的概率

## Verification

### 测试计划

1. **单元测试** `test/test-python-ptc.js`：
   - 测试 stub 生成函数：验证白名单交集、函数签名正确
   - 测试 env scrubbing：验证 KEY/TOKEN 被过滤，PATH/PYTHON 被保留
   - 测试 HTTP server：启动 → 发送请求 → 验证 token 鉴权 → 关闭

2. **集成测试**：
   ```bash
   npm start "用 python_ptc 写一个脚本，读取 README.md 前 10 行，统计字符数，把结果打印出来"
   ```
   期望：单次 `python_ptc` 调用，脚本内调用 `read` + Python 处理，最终只返回统计结果。

3. **边界测试**：
   - 脚本内调用 51 次工具 → 第 51 次返回 `Tool call limit reached`
   - 脚本运行 301s → 返回 `status: timeout` + 部分输出
   - 脚本 print API key → 输出中被 `[REDACTED]` 替换

### 回归检查

- `node --check src/tools/python-ptc.js`
- `node --check src/tools/index.js`
- `npm run test:parser` / `npm run test:loader`（确保工具注册未破坏）
- 手动运行 `npm start` 验证现有 exec 工具不受影响
