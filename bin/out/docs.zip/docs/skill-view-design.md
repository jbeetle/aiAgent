# skill_view 工具设计文档

## 背景

当前系统让 LLM 用 `read` 工具读取 `skills/xxx/SKILL.md` 原始文本，LLM 需要自己解析 YAML frontmatter 和 Markdown 正文。对于 qwen3-235b-a22b（MoE 架构，激活参数有限），结构化消费比自由解析更稳定。

参考 hermes-agent 的 `skills_tool.py` 实现后，决定新增 `skill_view` 工具：
- 预解析 SKILL.md 的 frontmatter，返回结构化 JSON
- 一次调用返回 `linked_files`（scripts/references/assets 列表），减少 LLM 的额外 `list` 调用
- 支持 `file_path` 参数安全读取 skill 目录下的子文件

## 范围

- **新增**：`src/tools/skill-view.js`（工具实现）
- **修改**：`src/tools/index.js`（注册工具）
- **修改**：`src/core/i18n.js`（更新 L2 指令，引导 LLM 使用 `skill_view` 替代 `read`）
- **新增**：`test/test-skill-view.js`（测试覆盖）
- **不引入**：`skills_list`（现有 LLM matcher 已承担 skill 发现职责）
- **不引入**：环境依赖检测（当前项目无此概念）

## 关键设计决策

### parser.js 改进：YAML 库原生多文档解析

**问题：** 当前 `parseSkillFile` 用正则 `^---\s*\n([\s\S]*?)\n---\s*(?:\n|$)([\s\S]*)$` 分割 frontmatter 和正文。正则的非贪婪匹配在正文中遇到 `---`（Markdown 水平线）时会提前截断，导致正文被错误分割。

**方案：** 利用 `yaml` 库（v2.3.4，已在依赖中）的 `parseAllDocuments()` 原生多文档解析能力替代正则分割：

```javascript
const docs = YAML.parseAllDocuments(content);
if (docs.length === 0) throw ...

const frontmatter = docs[0].toJS();
// 利用 docs[0].contents.srcRange.end 精确定位第一个文档结束位置
// 后续内容即为 Markdown body
```

**优势：**
- YAML 库正确识别文档边界，不受正文 `---` 干扰
- 不需要正则表达式分割
- 解析错误由 YAML 库提供详细的行号/列号信息

### 容错设计

代码解析是默认路径，解析失败时透明降级让 LLM 自己处理，绝不阻断工作流：

1. **解析失败降级**：`parseSkillFile` 异常时返回原始内容 + 错误信息
2. **结果校验**：校验 name/description 必填、格式、长度
3. **解析警告透传**：校验不通过时返回 `_warnings` 字段供 LLM 参考

---

## 实现步骤

### 1. `src/skills/parser.js`（改进 frontmatter 分割逻辑）

**变更：** 用 `YAML.parseAllDocuments()` 替代正则分割。

```javascript
export function parseSkillFile(filePath) {
    let content;
    try {
        content = fs.readFileSync(filePath, 'utf-8');
    } catch (error) { ... }

    // Remove BOM
    if (content.charCodeAt(0) === 0xFEFF) {
        content = content.slice(1);
    }

    // === 改进：用 YAML.parseAllDocuments 替代正则分割 ===
    let docs;
    try {
        docs = YAML.parseAllDocuments(content);
    } catch (e) {
        throw Errors.validation('YAML', `Failed to parse YAML: ${e.message}`, { path: filePath });
    }

    if (docs.length === 0) {
        throw Errors.validation('frontmatter', `No YAML frontmatter found in ${filePath}`, { path: filePath });
    }

    const frontmatter = docs[0].toJS();

    // 精确提取正文：取第一个 YAML 文档结束位置之后的内容
    let bodyStart = 0;
    const firstDocEnd = docs[0].contents?.srcRange?.end?.pointer;
    if (firstDocEnd !== undefined && firstDocEnd >= 0) {
        bodyStart = firstDocEnd;
    } else {
        // Fallback：找第二个 ---
        const secondDelimiter = content.indexOf('---', 3);
        if (secondDelimiter !== -1) {
            bodyStart = secondDelimiter + 3;
        }
    }
    const markdownContent = content.slice(bodyStart).replace(/^\s*[\n\r]+/, '');

    return {
        name: frontmatter.name || '',
        description: frontmatter.description || '',
        metadata: frontmatter,
        content: markdownContent,
        filePath
    };
}
```

### 2. `src/tools/skill-view.js`（新建）

**导入：**
- `fs`, `path` — Node.js 内置
- `{parseSkillFile}` from `../skills/parser.js` — 复用改进后的解析
- `{validatePath}` from `../security/path-sandbox.js` — 沙箱校验
- `{Errors}` from `../utils/errors.js` — 统一错误类型
- `{getSkillsDir}` from `../utils/paths.js` — 获取 skills 根目录

**核心逻辑：**

```
resolveSkillDir(name) → path.join(getSkillsDir(), name)

validateSubPath(skillDir, subPath):
  resolved = path.resolve(skillDir, subPath)
  确保 resolved.startsWith(path.resolve(skillDir) + path.sep)
  否则抛 security error (path_traversal)
  再调用 validatePath(resolved) 确保在沙箱内

discoverLinkedFiles(skillDir):
  扫描 scripts/, references/, assets/ 子目录
  返回 { scripts: [...], references: [...], assets: [...] }

execute(args):
  skillDir = resolveSkillDir(args.name)
  校验 skillDir 存在且是目录
  校验 SKILL.md 存在

  if args.file_path:
    resolved = validateSubPath(skillDir, args.file_path)
    校验文件存在且是普通文件
    content = fs.readFileSync(resolved, 'utf-8')
    return JSON({ name, file_path, content })
  else:
    skill = parseSkillFile(skillMdPath)
    linked = discoverLinkedFiles(skillDir)
    return JSON({
      name: skill.name,
      description: skill.description,
      metadata: skill.metadata,
      instructions: skill.content,
      linked_files: linked
    })
```

**容错设计：**

```javascript
// 解析 SKILL.md，带容错降级
let skill;
let parseWarnings = [];

try {
  skill = parseSkillFile(skillFilePath);
} catch (parseError) {
  // 降级：返回原始内容 + 错误信息，让 LLM 自己解析
  const raw = fs.readFileSync(skillFilePath, 'utf-8');
  return JSON.stringify({
    name: skillName,
    description: `[Parse error] ${parseError.message}`,
    metadata: { _parse_error: parseError.message },
    instructions: raw,
    linked_files: discoverLinkedFiles(skillDir),
    _parse_fallback: true
  }, null, 2);
}

// 校验解析结果（agentskills.io 规范）
const validationErrors = [];
if (!skill.name || skill.name.trim() === '') {
  validationErrors.push('missing "name" in frontmatter');
}
if (!skill.description || skill.description.trim() === '') {
  validationErrors.push('missing "description" in frontmatter');
}
if (!/^[a-z0-9-]+$/.test(skill.name)) {
  validationErrors.push(`invalid name format: "${skill.name}"`);
}
if (skill.description.length > 1024) {
  validationErrors.push(`description too long: ${skill.description.length} chars (max 1024)`);
}
parseWarnings = validationErrors;
```

**错误处理：**
| 场景 | 错误类型 | 说明 |
|------|---------|------|
| Skill 目录不存在 | `not_found` | `Skill: {name}` |
| SKILL.md 不存在 | `not_found` | `Skill file for: {name}` |
| file_path 路径遍历 | `security` | `file_path escapes skill directory` |
| 子文件不存在 | `not_found` | `File: {path} in skill {name}` |
| 子文件不是普通文件 | `validation` | `Path is not a file` |

### 2. `src/tools/index.js`（修改）

新增 import：
```javascript
import * as skillViewTool from './skill-view.js';
```

在 `buildBuiltInTools()` 中新增注册（在 `system_info` 之前或之后均可）：
```javascript
skill_view: buildTool(skillViewTool),
```

### 3. `src/core/i18n.js`（修改）

更新 `instructionSkillExec`，引导 LLM 使用 `skill_view` 替代 `read`：

**zh 区域（第 22 行）：**
```javascript
instructionSkillExec: '**L2 - Skill执行**：匹配技能后，使用 `skill_view` 工具获取技能的完整元数据和指引（含可用脚本、参考资料列表），然后严格遵循指示执行；SKILL.md 中引用的文件路径基于技能目录解析；如需读取技能目录下的其他文件，可在 `skill_view` 中指定 `file_path` 参数；skill_view 也无法解决时回退到 L3',
```

**en 区域（第 106 行）：**
```javascript
instructionSkillExec: '**L2 - Skill Execution**: When a skill is matched, use the `skill_view` tool to load its metadata and instructions (including available scripts and reference files), then strictly follow the instructions; file paths referenced in SKILL.md are relative to the skill directory; to read other files within the skill directory, use the `file_path` parameter in `skill_view`; fall back to L3 if skill_view cannot resolve',
```

### 4. `test/test-skill-view.js`（新建）

测试用例：
1. **读取 SKILL.md**：`skill_view({ name: 'skill-creator' })` → 返回 name/description/metadata/instructions/linked_files
2. **读取子文件**：`skill_view({ name: 'skill-creator', file_path: 'references/workflows.md' })` → 返回 name/file_path/content
3. **Skill 不存在**：`skill_view({ name: 'nonexistent' })` → 抛 not_found
4. **路径遍历阻断**：`skill_view({ name: 'skill-creator', file_path: '../../../package.json' })` → 抛 security
5. **子文件不存在**：`skill_view({ name: 'skill-creator', file_path: 'nonexistent.txt' })` → 抛 not_found
6. **linked_files 发现**：验证 `linked_files.scripts` 等数组正确填充

## 复用的工具函数

| 函数 | 来源 | 用途 |
|------|------|------|
| `parseSkillFile()` | `src/skills/parser.js` | 解析 SKILL.md 的 YAML frontmatter + Markdown body |
| `validatePath()` | `src/security/path-sandbox.js` | 沙箱路径校验 |
| `getSkillsDir()` | `src/utils/paths.js` | 获取 skills 根目录路径 |
| `Errors.notFound()` / `Errors.security()` / `Errors.validation()` | `src/utils/errors.js` | 统一错误构造 |

## 验证

1. 语法检查：`node --check src/tools/skill-view.js`
2. 运行测试：`node test/test-skill-view.js`
3. 集成测试：启动 agent，让 LLM 调用 `skill_view` 读取一个 skill，验证返回 JSON 结构正确
