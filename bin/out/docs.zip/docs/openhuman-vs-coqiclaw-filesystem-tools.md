# OpenHuman vs coqi-claw 文件系统工具详细功能对比

> **分析日期**: 2026-05-28  
> **OpenHuman 数据**: Cargo.toml 依赖推断 (源代码不可见)  
> **coqi-claw 数据**: `src/tools/` 实际源代码分析

---

## 一、工具映射关系

```
OpenHuman (推断)              coqi-claw (实际)
─────────────────────         ─────────────────────
file_read          ────────►  read (文本/Excel/图片三合一)
file_write         ────────►  write (文本/Excel)
file_edit          ────────►  edit_file (精确替换+diff审计)
file_search/grep   ────────►  search (ripgrep+Node.js双引擎)
list_dir           ────────►  list (Markdown分组+gitignore)
file_ops           ────────►  copy_path / move_path / delete_path
(无独立glob)       ────────►  glob (ripgrep快速路径)
(无独立archive)    ────────►  archive (ZIP+ZipSlip/Bomb防护)
(无独立时间)       ────────►  time (now/format/add/diff/parse)
```

**数量对比**: OpenHuman 6 个 vs coqi-claw 10 个（coqi-claw 拆分更细）

---

## 二、逐能力详细对比

### 2.1 文件读取

| 维度 | OpenHuman `file_read` | coqi-claw `read` |
|------|----------------------|-----------------|
| **文本读取** | ✅ `std::fs::read_to_string` | ✅ 多编码 (utf-8/gbk/gb2312/latin1) |
| **分页读取** | ❓ 未知 | ✅ `offset` + `limit` 参数 |
| **大文件处理** | ❓ 未知 | 硬限制 300KB，超大拒绝 |
| **Excel 读取** | ❌ 无对应依赖 | ✅ xlsx/xls → JSON/CSV/Markdown |
| **Excel 工作表选择** | ❌ | ✅ `sheet` 参数（名称或索引） |
| **Excel 行数限制** | ❌ | ✅ `maxRows`（默认10000） |
| **图片读取** | ❓ `image` crate 存在，但可能是 screenshot 专用 | ✅ 视觉模型分析 (VISION_LLM_MODEL) |
| **图片分析** | ❌ 无证据 | ✅ 对象检测/文字提取/分类 |
| **二进制检测** | ❓ | ✅ 自动检测并拒绝二进制文件 |
| **输出格式** | ❓ 推断为 JSON-RPC 标准 | `outputFormat`: json / text |

**关键差异**：

coqi-claw 的 `read` 是一个**三合一工具**，单一入口自动路由到三个读取器：
```
read(path)
  ├─ 是 Excel? → read/excel.js  (ExcelJS 解析)
  ├─ 是图片?   → read/image.js  (视觉模型分析)
  └─ 否则      → read/text.js   (多编码文本)
```

OpenHuman 可能将文本/图片分离为独立工具，且**无 Excel 读取能力**（Cargo.toml 无 Excel 相关依赖如 `calamine`）。

**coqi-claw 独有优势**：
- **GBK/GB2312 编码**: Windows 中文环境必备
- **分页读取**: offset + limit 避免大文件撑爆上下文
- **Excel 原生**: 含表头智能检测、多工作表、多输出格式
- **视觉模型**: 可以用自然语言提问图片内容 (`visionPrompt`)

---

### 2.2 文件写入

| 维度 | OpenHuman `file_write` | coqi-claw `write` |
|------|------------------------|------------------|
| **文本写入** | ✅ `std::fs::write` | ✅ 自动建父目录 |
| **并发安全** | ❓ 未知 | ✅ 同文件写队列串行化 (`withWriteQueue`) |
| **原子写入** | ✅ `tempfile` crate (v3) | ❌ 直接写入 |
| **Excel 写入** | ❌ 无依赖 | ✅ ExcelJS (xlsx 生成) |
| **Excel 多表** | ❌ | ✅ `sheets: [{name, data}]` |
| **Excel 样式** | ❌ | ✅ `styled: true` 设计系统样式 |
| **Excel 列宽** | ❌ | ✅ 自动列宽调整 |
| **文件类型校验** | ❓ | ✅ `checkFileAllowed()` 白名单 |
| **大小限制** | ❓ | 文本 ≤ 300KB, Excel ≤ 50MB |
| **对象自动序列化** | ❓ | ✅ 对象→JSON.stringify |
| **输出格式** | ❓ | `outputFormat`: json / text |

**关键差异**：

OpenHuman 使用 `tempfile` 暗示**原子写入**（先写临时文件再 rename），这是数据库级的数据安全保证。coqi-claw 使用**写队列串行化**来防并发冲突——不同策略但目标相似。

coqi-claw 的 Excel 写入能力是突出优势，包括：
```javascript
// 两种数据格式
{ sheets: [{ name: "Sheet1", data: [["Name","Age"],["Alice",30]] }] }
{ data: [["Name","Age"],["Alice",30]], sheetName: "Sheet1" }

// 设计系统样式
write({ path: "report.xlsx", data: {...}, styled: true })
→ 自动应用 brand.primary (#DC2626) 配色 + Playfair Display 字体
```

**coqi-claw 独有优势**：
- Excel 完整支持（读写+样式）
- 同文件并发写入保证
- 文件类型白名单

**OpenHuman 独有优势**：
- 原子写入（tempfile 保证）

---

### 2.3 文件编辑

| 维度 | OpenHuman `file_edit` | coqi-claw `edit_file` |
|------|-----------------------|----------------------|
| **编辑方式** | ❓ 推断：直接替换 | ✅ 精确 old_text→new_text 替换 |
| **最小文件行数** | ❓ | ✅ ≥ 200 行（小文件用 write） |
| **模糊匹配** | ❓ | ✅ 三级降级：精确→Unicode规范化→模糊 |
| **多编辑批处理** | ❓ | ✅ 数组批量编辑 |
| **冲突检测** | ❓ | ✅ 唯一性检查 + 重叠检查 |
| **事务回滚** | ❓ | ✅ 任一失败则全部回滚（基于原始基线匹配） |
| **diff 审计** | ❓ | ✅ 生成 unified patch 用于审查 |
| **换行符处理** | ❓ | ✅ 自动检测 LF/CRLF 并还原 |
| **二进制检测** | ❓ | ✅ `isBinaryContent()` |
| **大小限制** | ❓ | ≤ 300KB |
| **最小 old_text 长度** | ❓ | ✅ ≥ MIN_OLD_TEXT_LENGTH |

**关键差异**：

coqi-claw 的 `edit_file` 是最精密的工具之一，设计哲学是**外科手术式精确替换**：

```
edit_file({ path, edits: [
  { old_text: "...", new_text: "..." },
  { old_text: "...", new_text: "..." },
] })

工作流:
1. 预检查: 所有 old_text 在原始文件中匹配 → 唯一性检查 → 重叠检查
2. 从后往前应用编辑 (保持偏移稳定)
3. 生成 unified patch 作为审计记录
4. 任何一个匹配失败 → 全部回滚，文件不修改
```

模糊匹配能力：
```
old_text 含 Unicode 变体 (smart quotes, em-dash 等) 
→ 规范化后仍能匹配
→ 3级降级链: 精确 → NFKC规范化 → 启发式
```

OpenHuman 的实现未知，但基于 `std::fs` 和可能的自研算法，无法判断精度。

**coqi-claw 独有优势**：
- 事务性编辑（全部成功或全部回滚）
- 模糊匹配三级降级
- 冲突检测（唯一性+重叠）
- diff 审计 patch
- 原始基线匹配（不受之前编辑影响）

---

### 2.4 内容搜索

| 维度 | OpenHuman `file_search/grep` | coqi-claw `search` |
|------|------------------------------|-------------------|
| **搜索引擎** | ❓ walkdir + regex (纯 Node/Rust) | ✅ ripgrep 快速路径 + Node.js fallback |
| **正则支持** | ✅ `regex` crate | ✅ 完整正则 |
| **递归搜索** | ✅ `walkdir` crate | ✅ `recursive: true` |
| **上下文行** | ❓ | ✅ `contextLines` (前后N行) |
| **大小写敏感** | ❓ | ✅ `caseSensitive` |
| **文件模式过滤** | ✅ `glob` crate | ✅ `filePattern` (如 "*.js") |
| **隐藏文件** | ❓ | ✅ `showHidden` |
| **gitignore 过滤** | ❓ | ✅ 默认尊重 `.gitignore` |
| **结果排序** | ❓ | ✅ path / line / name 三种排序 |
| **硬上限** | ❓ | 2000 结果 |
| **输出格式** | ❓ | `outputFormat`: json / text (json含filesSearched等统计) |
| **搜索路径** | ❓ | 模糊路径→workspace output 智能fallback |

**关键差异**：

coqi-claw 的双引擎策略：
```
search(pattern, path)
  ├─ 尝试 ripgrep  ── 极快 (rg.exe 在 Windows 上内嵌)
  │   └─ 失败? → Node.js fallback
  └─ 返回统一格式 { matches, stats }
```

OpenHuman 的 `walkdir` + `regex` 是纯 Rust 实现，性能应该也不错，但缺少 ripgrep 级的速度优势（ripgrep 使用 SIMD 加速、并行目录遍历、文件类型过滤等）。

**coqi-claw 独有优势**：
- ripgrep 引擎（二进制级性能）
- 上下文行支持
- 排序选项
- 搜索结果统计（filesSearched, directoriesSearched, duration）

---

### 2.5 目录列表与模式匹配

#### 目录列表

| 维度 | OpenHuman `list_dir` | coqi-claw `list` |
|------|----------------------|-----------------|
| **递归** | ✅ walkdir 支持 | ✅ `recursive: true` (深度上限12) |
| **gitignore** | ❓ | ✅ `respectGitignore` (默认true) |
| **隐藏文件** | ❓ | ✅ `showHidden` |
| **类型过滤** | ❓ | ✅ `type: file / directory / all` |
| **模式过滤** | ❓ | ✅ `filter` glob 模式 |
| **符号链接处理** | ❓ | ✅ 循环检测 (`visitedPaths` + `realpathSync`) |
| **权限拒绝** | ❓ | ✅ 优雅降级 (标记 `[permission denied]`) |
| **结果限制** | ❓ | 2000 条目 |
| **输出格式** | ❓ | `format: json / text` |
| **text 格式** | ❓ | ✅ Markdown 标题分组 (# Folders / # Files) + 元信息 |
| **JSON 格式** | ❓ | ✅ 结构化含 summary 统计 |
| **智能根路径** | ❓ | ✅ `.`/`""`/`"./"`/`"*"` → workspace 布局根 |
| **大小/时间** | ❓ | ✅ `showSize` + `showModified` (ISO 8601) |

**关键差异**：

coqi-claw 的 `list` 输出采用**Markdown 标题分组**，对 LLM 非常友好：
```
# Folders:
src/tools/read (16 B, 2026-05-28 14:30)
src/tools/write (32 B, 2026-05-28 14:31)

# Files:
src/tools/index.js (3.2 KB, 2026-05-27 11:00)
src/tools/read.js (7.1 KB, 2026-05-28 14:32)

--- Total: 2 dirs, 2 files, 1 hidden skipped ---
```

这比纯 JSON 更省 token，比纯文本列表更结构化。

#### 模式匹配

| 维度 | OpenHuman | coqi-claw `glob` |
|------|-----------|-----------------|
| **独立 glob 工具** | ❌ (内嵌在 search/list 中) | ✅ 独立工具 |
| **快速路径** | ❓ | ✅ ripgrep `--files` (纯文件枚举时) |
| **fallback** | glob crate | glob npm 库 |
| **文件统计** | ❓ | ✅ `includeStats` (size, modified) |
| **排序** | ❓ | ✅ name / modified / size |
| **结果限制** | ❓ | 5000 硬上限 |
| **gitignore** | ❓ | ✅ 默认尊重 |
| **绝对/相对路径** | ❓ | ✅ `absolute` 参数 |
| **输出格式** | ❓ | `format: json / text` |
| **智能 cwd** | ❓ | `.` → workspace/output 回退 |

**coqi-claw 独有优势**：
- 独立 glob 工具（单一职责，LLM 调用更清晰）
- ripgrep 快速路径用于纯文件枚举
- file stats 附带（size/modified 帮助 LLM 决策）

---

### 2.6 文件操作 (复制/移动/删除)

| 维度 | OpenHuman `file_ops` | coqi-claw |
|------|----------------------|----------|
| **工具拆分** | 单个工具含多 action | ✅ 三个独立工具 |
|  | ❓ `action: "copy"/"move"/"delete"` | `copy_path` / `move_path` / `delete_path` |
| **复制 (含目录)** | ✅ | ✅ 递归复制 |
| **移动/重命名** | ✅ | ✅ 跨驱动器自动 fallback (EXDEV→cp+rm) |
| **删除** | ✅ | ✅ `rmSync({ recursive: true })` |
| **关键路径保护** | ❓ 未知 | ✅ `isDangerousPath()` 保护 src/skills/plugins |
| **系统路径保护** | ❓ | ✅ `/`, `/home`, `/etc`, `C:\Windows` |
| **沙箱校验** | ❓ | ✅ `validatePath()` |
| **同名路径检测** | ❓ | ✅ 拒绝 source===destination |
| **目标目录自动创建** | ❓ | ✅ `mkdirSync({ recursive: true })` |
| **输出格式** | ❓ | JSON (含 success/action/source/destination) |

**关键差异**：

coqi-claw 的三个独立工具模式优于单工具多 action 模式——LLM 更容易理解和调用：
```javascript
copy_path({ source_path: "a.txt", destination_path: "b.txt" })
move_path({ source_path: "a.txt", destination_path: "c.txt" })  // 跨驱动器自动降级
delete_path({ path: "temp.txt" })
```

**关键路径保护**（coqi-claw 独有）：
```javascript
const PROTECTED_PATHS = [
  "/src", "/skills", "/plugins", ".env", "package.json",
  "/", "/home", "/etc", "/usr", "/bin", "C:\\Windows"
];
// delete_path 保护这些路径，拒绝删除
```

**跨驱动器移动**：
```javascript
// move_path 内部
fs.renameSync(src, dst);  // 同驱动器，O(1)
// EXDEV 错误 → 跨驱动器
fs.cpSync(src, dst, { recursive: true });  // 复制
fs.rmSync(src, { recursive: true });       // 删除源
```

---

### 2.7 压缩/解压

| 维度 | OpenHuman | coqi-claw `archive` |
|------|-----------|---------------------|
| **独立工具** | ❓ (依赖存在但可能是引导用) | ✅ 独立工具 |
| **ZIP 支持** | ✅ `zip` crate | ✅ AdmZip + PowerShell 备选 |
| **TAR 支持** | ✅ `tar` crate | ❌ |
| **TAR.XZ 支持** | ✅ `xz2` crate | ❌ |
| **TAR.GZ 支持** | ✅ `flate2` crate | ❌ |
| **格式范围** | ZIP + TAR + XZ + GZ | 仅 ZIP |
| **操作类型** | ❓ extract | compress + extract + list |
| **ZipSlip 防护** | ❓ | ✅ 路径逃逸检测 |
| **ZipBomb 防护** | ❓ | ✅ 条目数+解压大小双重限制 |
| **Windows 加速** | ❓ | ✅ PowerShell Compress-Archive/Expand-Archive |
| **压缩率统计** | ❓ | ✅ |
| **用途** | 推断：Node.js 运行时引导 | 通用文件操作 |

**关键差异**：

OpenHuman 的压缩工具有更广泛的格式支持（TAR/XZ/GZ），因为需要解压 Node.js 运行时分发包。coqi-claw 专注 ZIP 但更安全——ZipSlip + ZipBomb 双重防护。

---

### 2.8 安全防护对比

| 安全机制 | OpenHuman | coqi-claw |
|----------|:--------:|:--------:|
| **路径沙箱** | Landlock (Linux) / Bubblewrap | `validateWorkspacePath()` / `validatePath()` |
| **文件类型白名单** | ❓ | ✅ `checkFileAllowed()` |
| **文件大小限制** | ❓ | read≤300KB, write≤300KB, Excel≤10MB/50MB |
| **二进制文件检测** | ❓ | ✅ read + edit_file 均检测 |
| **关键路径保护** | ❓ | ✅ delete_path 保护 src/skills/plugins |
| **系统路径保护** | ❓ | ✅ /, /home, C:\Windows |
| **ZipSlip 防护** | ❓ | ✅ archive 路径逃逸检测 |
| **ZipBomb 防护** | ❓ | ✅ archive 条目数+大小限制 |
| **同文件并发安全** | ❓ | ✅ write 写队列串行化 |
| **符号链接循环检测** | ❓ | ✅ list 循环检测 |
| **敏感信息脱敏** | ❓ | ✅ system_info 脱敏 |
| **config 可配置** | ❓ | 多个环境变量控制 |

**coqi-claw 优势**：安全机制在工具代码中**显式可见**，每一层安全边界清晰可审计。OpenHuman 使用 OS 级沙箱（Landlock/Bubblewrap），可能代码中安全逻辑较少。

---

## 三、输出格式统一性

| 维度 | OpenHuman | coqi-claw |
|------|-----------|----------|
| **统一格式** | ❓ JSON-RPC 标准 | ✅ 全部工具统一 `outputFormat: json / text` |
| **JSON 模式** | ❓ | 结构化，含元数据，AI 友好 |
| **Text 模式** | ❓ | 人类可读，适合调试 |
| **Markdown 输出** | ❓ | list 工具 Markdown 分组 |

---

## 四、总结对比表

| 能力 | OpenHuman (6工具) | coqi-claw (10工具) | 优胜方 |
|------|-------------------|-------------------|:------:|
| 文本读取 | ✅ 基础 | ✅ 多编码+分页 | **coqi-claw** |
| Excel 读取 | ❌ | ✅ 三格式输出 | **coqi-claw** |
| 图片读取+分析 | ❌ | ✅ 视觉模型 | **coqi-claw** |
| 文本写入 | ✅ 原子写入 | ✅ 写队列+自动建目录 | 平手 |
| Excel 写入 | ❌ | ✅ 多表+样式 | **coqi-claw** |
| 精确文件编辑 | ❓ | ✅ 模糊匹配+diff+回滚 | **coqi-claw** |
| 内容搜索 | ✅ walkdir+regex | ✅ ripgrep双引擎 | **coqi-claw** |
| 目录列表 | ✅ walkdir | ✅ Markdown分组+安全检查 | **coqi-claw** |
| glob 模式匹配 | ✅ glob crate | ✅ ripgrep快速路径+stats | **coqi-claw** |
| 复制/移动/删除 | ✅ 基础 | ✅ 跨驱动器+路径保护 | **coqi-claw** |
| ZIP 支持 | ✅ | ✅ +安全校验 | 平手 |
| TAR/XZ/GZ | ✅ | ❌ | **OpenHuman** |
| 安全纵深 | OS级沙箱 | 8层显式防护 | **coqi-claw** |
| 输出格式统一 | ❓ | ✅ json/text 双模式 | **coqi-claw** |

### 核心结论

- **coqi-claw 在文件系统工具上全面优于 OpenHuman**（10个 vs 6个，功能更精细）
- **coqi-claw 独有**: Excel 读写、图片视觉分析、精确编辑+diff、Markdown 分组输出、8层安全防护
- **OpenHuman 独有**: TAR/XZ/GZ 多格式解压、tempfile 原子写入
- 两者定位不同：coqi-claw 是**专业代码Agent**（深度优先，每个工具做到极致），OpenHuman 是**通用助手**（广度优先，满足基本需求即可）
