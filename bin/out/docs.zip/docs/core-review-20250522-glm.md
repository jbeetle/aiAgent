# src/core/ 代码审查报告

**审查日期**：2026-05-22
**审查范围**：`agent.js`、`agent-executor.js`、`prompt-builder.js`、`message-utils.js`、`i18n.js`、`llm.js` 及 `llm/` 子包（`client.js`、`metrics.js`、`pricing.js`、`res-helper.js`、`summarize.js`）

---

## 整体评价

架构清晰，Agent（编排）与 AgentExecutor（执行循环）职责分离合理，EventEmitter 进度上报、AbortController 取消控制、p-limit 并发工具执行等设计都是正确的方向。代码质量总体较高，错误处理模式规范。以下问题多为边界情况和可维护性改进，而非正确性缺陷。

---

## 高优先级

### 1. 工具执行不支持 abort 取消 — `agent-executor.js`

`executeSingleTool` 只在调用前通过 `checkAborted()` 检查取消状态，执行期间无法中断。长耗时工具（`exec`、`web_fetch`、`http_request`）一旦启动就无法取消。`AbortController.signal` 未传递给工具的 `execute()` 函数。

```javascript
// 当前：只检查一次，执行中途无法取消
checkAborted();
const result = await this.tools[toolCall.name].execute(parsedArgs);

// 建议：传递 signal，让工具自行支持取消
const result = await this.tools[toolCall.name].execute(parsedArgs, { signal: this.abortController.signal });
```

**影响**：用户点击取消后，后台进程可能仍在运行，浪费资源且用户感知不到"已取消"。

---

## 中优先级

### 2. 内容安全检测过于宽泛 — `llm/client.js`

`chat()` / `chatStream()` 中错误信息匹配使用 `errorMessage.includes("safety")`，会误匹配任何包含 "safety" 的错误（如网络代理的 safety check、内部 safety 断言等）。

**建议**：改用更精确的模式，如 provider-specific 错误码或正则匹配完整错误类型字符串。

### 3. `buildPersonalizedSystemPrompt` 硬编码中文字符串 — `agent.js`

多处长字符串（assistantIdentity 描述、开头/结尾引导语）直接内联，未走 i18n 系统。虽然这些是 system prompt 不是 UI 文案，但与项目 i18n 规范不一致，且难以维护。

**建议**：提取到 i18n 配置或 `config/assistants.json` 等配置文件中。

### 4. `extractRecentContext` 串行摘要 — `agent.js`

`formatPair` 中逐条串行调用 `_summarizeAnswer`，多轮时延迟累加。各轮摘要互不依赖，可以并行化。

```javascript
// 当前：串行，N 轮 = N × 单次延迟
for (const pair of recentPairs) {
  formatted += await this._summarizeAnswer(pair);
}

// 建议：并行
const results = await Promise.all(recentPairs.map(p => this._summarizeAnswer(p)));
formatted = results.join('\n\n');
```

### 5. `emergencyTruncate` 丢弃中间轮次无摘要 — `agent-executor.js`

紧急截断保留"首轮 + 最近 N 轮"，中间轮次直接丢弃。丢失的上下文可能导致后续对话产生幻觉。

**建议**：对丢弃部分生成简短摘要，或至少标记 `[...已省略 ${count} 轮对话...]` 提示模型上下文不完整。

---

## 低优先级

### 6. `chatStream` 返回的 `result.catch` 冗余 — `llm/client.js:386-389`

`.catch((error) => { throw error; })` 等价于不加 catch，建议移除以减少不必要的 Promise 包装。

### 7. fallback ID 生成 IIFE 重复 — `llm/client.js:330-337` & `459-465`

`chat()` 和 `chatStream()` 中相同逻辑各写了一遍 IIFE 生成 fallback tool call ID。

**建议**：提取为 `_generateFallbackToolCallId()` 辅助方法，消除重复。

### 8. 同时发送 `max_tokens` 和 `max_completion_tokens` — `llm/summarize.js:99-100` & `165-166`

两个参数含义不同（前者用于 GPT-4 等，后者用于 o1+），但都发给同一个请求。Provider 会忽略不识别的参数，但容易造成维护混乱。

**建议**：根据模型类型选择发送哪一个，或统一使用 provider 推荐的参数名。

### 9. `CONTENT_FILTERS.patterns` 正则带 `g` 标志 — `message-utils.js`

当前仅用于 `String.replace()`，功能正确。但若未来有人用 `pattern.test()` 检测，`g` 标志会导致 `lastIndex` 状态残留、结果不一致。

**建议**：在注释中标注仅限 replace 使用，或改用不带 `g` 的正则 + `replaceAll()`。

---

## 架构观察

- **Agent/AgentExecutor 分离**：做得好，Executor 可独立销毁、事件驱动，适合 TUI/Web 多场景复用。
- **LLM 子包拆分**：`client.js`（高层封装）、`res-helper.js`（响应处理）、`summarize.js`（摘要）职责清晰。`metrics.js` 和 `pricing.js` 作为独立模块合理。
- **i18n 覆盖**：大部分 UI 文案已国际化，但 system prompt 构建部分仍有遗漏（见 #3）。
- **内存管理**：`destroy()` 方法清理 EventEmitter 和 AbortController 是正确的做法，但 `removeAllListeners()` 过于激进——如果外部注册了非执行相关的监听器会被误清。建议改为仅移除已知事件名的监听器，或在构造时记录已注册的事件名列表后逐一移除。
