# Web 前端 TypeScript 迁移审查 TODO

> **审查日期**: 2026-06-25
> **分支**: feat/web-typescript
> **审查范围**: `web/src/` 全部 47 个 TypeScript/TSX 文件 + 后端 `src/gateway/` 路由
> **编译状态**: ✅ 0 个 TypeScript 编译错误（P0+P1 修复后）

---

## 总览

| 维度 | 状态 |
|------|------|
| TypeScript 编译 | ✅ **0 个编译错误**（P0+P1+P2+P3 全部修复） |
| 类型安全 | ✅ 域类型与 API 类型通过映射层桥接 |
| 安全性 | ✅ Mermaid `securityLevel: "strict"` + DOMPurify + href 转义 |
| React 模式 | ✅ 闭包修复 + useCallback memo 化 + HMR 守卫 |
| WebSocket/API | ✅ AbortSignal 传递 + 引用计数 + JSON 类型验证 |
| 性能 | ✅ rAF 按需启停 + resize 防抖 + useMemo 拆分 |
| 可访问性 | ✅ aria-live + role="log" + 键盘焦点 + 状态通知 |
| 架构 | ✅ useBubbleEvents 提取 + 字符串常量集中 + SessionStatus 联合类型 |

---

## P0 — 必须立即修复（阻塞编译 / 安全风险）

### TODO-01: 修复 JSX 命名空间缺失（23 处编译错误）

- **严重度**: 🔴 阻塞编译
- **影响文件**: 几乎所有 `.tsx` 组件（ChatLayout、ConfirmDialog、EmptyState、FileAttachment、IdentityLabel、InputArea、LoginModal、MessageBubble、MessageList、ProgressBar、ReasoningPanel、SettingsPanel、SessionItem、SessionList、SessionSearch、Sidebar、SidebarHeader、ThemeToggle、ToastContainer、ToolCallList）
- **错误**: `TS2503: Cannot find namespace 'JSX'`
- **根因**: React 19 + TypeScript 5.9 需要显式配置 JSX 命名空间
- **修复方案**: 在 `tsconfig.json` 添加 `"jsxImportSource": "react"` 或在 `types/global.d.ts` 中添加 JSX 命名空间声明
- **状态**: [x] 已修复 — `types/global.d.ts` 添加全局 JSX 命名空间声明，从 `react` 模块导入并重新导出；`tsconfig.json` 添加 `jsxImportSource: "react"` 和 `types: ["react"]`

### TODO-02: 修复 `activeSessionId` 访问错误 Store（2 处）

- **严重度**: 🔴 运行时错误
- **影响文件**: `api/websocket.ts:361`、`components/MessageList.tsx:43`
- **错误**: `TS2339: Property 'activeSessionId' does not exist on type 'ChatState'`
- **修复方案**:
  ```typescript
  // ❌ 当前
  const sessionId = useChatStore.getState().activeSessionId;
  // ✅ 修复
  const sessionId = useSessionStore.getState().activeSessionId;
  ```
- **状态**: [x] 已修复 — `websocket.ts:361` 改为 `sessionStore.activeSessionId` 并在 `onReconnected` 中添加 `const sessionStore = useSessionStore.getState()`；`MessageList.tsx:43` 改为使用闭包中的 `activeSessionId` 变量

### TODO-03: 修复 `ListItem.streamingReasoning` 缺少 `content` 字段

- **严重度**: 🔴 编译错误 + 运行时类型不匹配
- **影响文件**: `utils/message-list-helpers.ts:7`、`components/MessageList.tsx:79,326`
- **错误**: `TS2353` / `TS2339: Property 'content' does not exist`
- **修复方案**:
  ```typescript
  // ❌ 当前
  | { type: "streamingReasoning" }
  // ✅ 修复
  | { type: "streamingReasoning"; content: string }
  ```
- **状态**: [x] 已修复 — `message-list-helpers.ts` 的 `streamingReasoning` 类型添加 `content: string` 字段

- **严重度**: 🔴 运行时崩溃
- **影响文件**: `components/SettingsPanel.tsx:14`
- **错误**: `TS2552: Cannot find name 'useUIStore'`
- **修复方案**: 添加 `import { useUIStore } from "../stores/ui-store";`
- **状态**: [x] 已修复 — 添加了 `useUIStore` 的 import 语句

- **严重度**: 🔴 XSS 安全漏洞
- **影响文件**: `utils/mermaid.ts:96`
- **问题**: `securityLevel: "loose"` 禁用了 Mermaid 的 XSS 保护，用户控制的 Mermaid 代码块可执行任意 JavaScript
- **修复方案**: 改为 `securityLevel: "strict"` 或 `"sandbox"`
- **状态**: [x] 已修复 — 改为 `securityLevel: "strict"`

- **严重度**: 🔴 HTML 注入风险
- **影响文件**: `lib/markdown.ts:68-69`
- **问题**: 仅转义双引号，未转义 `&`、`<`、`>`，`data-code` 属性值可能包含这些字符导致 HTML 注入
- **修复方案**:
  ```typescript
  function escapeAttr(text: string): string {
    return text
      .replace(/&/g, "&amp;")
      .replace(/"/g, "&quot;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }
  ```
- **状态**: [x] 已修复 — 补全了 `&`、`<`、`>` 的转义

--- — 高优先级（运行时正确性）

### TODO-07: 添加 API 类型映射层，解决域类型与 API 生成类型不兼容

- **严重度**: 🟡 8 处编译错误 + 运行时 `undefined` 访问风险
- **影响文件**: `hooks/useSessions.ts`（6 处）、`api/websocket.ts:388`、`components/sidebar/useSessionExport.ts:36`
- **核心问题**:
  - `Session.id: string`（必填）vs `api-generated.Session.id?: string`（可选）
  - `Message.role: MessageRole`（严格联合）vs `api-generated.Message.role?: string`（松散字符串）
  - `Assistant.id: string`（必填）vs `api-generated.Assistant.id?: string`（可选）
- **修复方案**: 创建 `api/mappers.ts`，在 `rest.ts` 返回后统一转换 API 类型为域类型，对可选必填字段做 null 检查和默认值填充
- **状态**: [x] 已修复 — 创建 `api/mappers.ts`，含 `mapSession`/`mapMessage`/`mapAssistant`/`mapUser` + 批量映射函数；更新 `useSessions.ts`、`websocket.ts`、`useSessionExport.ts` 使用映射层；从 `types/index.ts` 导出 `ToastType`；从 `types/store.ts` re-export `Message`

### TODO-08: WebSocket 单例生命周期解耦

- **严重度**: 🟡 全局断连风险
- **影响文件**: `hooks/useWebSocket.ts:4-9`
- **问题**: `chatWS` 是全局单例，但 `disconnect()` 在组件卸载时调用，会断开整个应用的 WebSocket 连接
- **修复方案**: 引用计数模式（多个消费者共享连接，最后一个离开时断开）或独立于组件生命周期管理
- **状态**: [x] 已修复 — ChatWebSocket 添加 `_refCount`/`retain()`/`release()` 引用计数机制；`useWebSocket` hook 改用 `retain()`/`release()` 替代 `connect()`/`disconnect()`

### TODO-09: AbortSignal 传递到 fetch

- **严重度**: 🟡 请求取消机制完全无效
- **影响文件**: `api/rest.ts`、`hooks/useSessions.ts`
- **问题**: `useSessions` 创建了 `AbortController`，但 `sessionsApi.list()` 从未将 `signal` 传递给 `fetch()`，已取消的请求仍会完成并可能覆盖新数据
- **修复方案**: `request<T>()` 接受可选 `signal` 参数，传递给 `fetch()` 调用；`sessionsApi.list()` 等方法透传 signal
- **状态**: [x] 已修复 — `request()` 添加第三参数 `signal?: AbortSignal` 并传递给 `fetch()`；`sessionsApi.list()` 和 `sessionsApi.getMessages()` 接受并透传 signal；`useSessions.ts` 传递 AbortSignal

### TODO-10: InputArea 闭包修复 — 会话切换时使用 textRef

- **严重度**: 🟡 草稿保存可能丢失
- **影响文件**: `components/InputArea.tsx:84`
- **问题**: `saveDraft(prevSessionId, text)` 中 `text` 是闭包捕获的旧值，应使用 `textRef.current`
- **修复方案**:
  ```typescript
  // ❌ 当前
  saveDraft(prevSessionId, text);
  // ✅ 修复
  saveDraft(prevSessionId, textRef.current);
  ```
- **状态**: [x] 已修复 — `InputArea.tsx:84` 改为 `saveDraft(prevSessionId, textRef.current)`

### TODO-11: 添加组件级 Error Boundary

- **严重度**: 🟡 单条消息错误导致整个应用崩溃
- **影响文件**: `main.tsx`（仅顶层 ErrorBoundary）
- **问题**: 单个消息的 Markdown/Mermaid 渲染错误会导致整个应用崩溃到错误边界
- **修复方案**: 在 `MessageList` 和 `MessageBubble` 级别添加 Error Boundary，隔离单条消息的渲染错误
- **状态**: [x] 已修复 — 创建 `MessageErrorBoundary.tsx` 组件，包裹 MessageList 中所有消息项（message/streamingContent/streamingReasoning/toolCalls）

### TODO-12: 删除遗留 `types.js`

- **严重度**: 🟡 维护负担 + 类型不同步
- **影响文件**: `web/src/types.js`（191 行 JSDoc 类型定义）
- **问题**: JSX 时代遗留产物，与 TypeScript 类型定义重复且已不同步（如 `Message.id` 类型不一致）
- **修复方案**: 删除 `types.js`，确保所有类型定义仅在 `.ts` 文件中
- **状态**: [x] 已修复 — 删除 `web/src/types.js`（191 行 JSDoc 类型定义），无其他文件引用

### TODO-13: 修复其他编译错误（杂项）

- **严重度**: 🟡 阻塞编译
- **影响文件与修复**:

| 错误 | 文件 | 修复 |
|------|------|------|
| `ToastType` 未导出 | `ToastContainer.tsx:2` | 从 `types/index.ts` 导出 `ToastType` |
| `Element.focus` 不存在 | `ConfirmDialog.tsx:59`、`LoginModal.tsx:47` | 类型断言为 `HTMLElement` |
| `TrustedHTML` ≠ `string` | `markdown.ts:347-348` | 使用 `toString()` 或修改类型 |
| `DOMPurify` 命名空间缺失 | `markdown.ts:225,308` | 安装 `@types/dompurify` |
| `Message` 未从 store.ts 导出 | `chat-store.ts:2` | 修复导出冲突 |
| `rAF` 回调类型不匹配 | `mermaid.ts:24` | 修复 Promise vs FrameRequestCallback |
| `Record<string, never>` 阻止赋值 | `rest.ts:18,33` | 修复 OpenAPI 生成类型或使用类型断言 |
| 未使用的变量 | `markdown.ts`、`SettingsPanel.tsx` | 删除或使用 |
| 代码路径不完整 | `ReasoningPanel.tsx`、`ToolCallList.tsx`、`useSessions.ts` | 添加默认返回值 |
| `LoginModal.tsx:71` error 属性不存在 | `LoginModal.tsx` | 修复 API 响应类型访问 |
| `SessionItem.tsx:123` 事件类型不匹配 | `SessionItem.tsx` | 修复 MouseEvent 泛型 |
| `rest.ts:59` headers 类型不匹配 | `rest.ts` | 修复 Record<string, string> 赋值 |

- **状态**: [x] 已修复 — 逐项修复全部 12 类编译错误：ToastType 导出、HTMLElement 类型断言、DOMPurify Config 类型断言 + tsconfig 添加 dompurify、store.ts re-export Message、rAF 回调修复、条件类型提取 requestBody、未使用变量清理、return undefined 补全、LoginModal error 字段移除、MouseEvent\<HTMLElement\>、headers as Record 断言

---

## P2 — 中优先级（健壮性 / 性能）

### TODO-14: ConfirmDialog useEffect 依赖修复

- **严重度**: 🟡
- **影响文件**: `components/ConfirmDialog.tsx:61`
- **问题**: `onCancel` 在依赖数组中，但父组件（Sidebar）每次渲染都创建新的箭头函数引用，导致 effect 每次渲染都重新执行
- **状态**: [x] 已修复 — ConfirmDialog 内部用 `onCancelRef`/`onConfirmRef` 持有最新回调，从 useEffect 依赖数组中移除 `onCancel`；JSX 中的 onClick 也改用 ref.current 调用

### TODO-15: rAF 循环按需启停

- **严重度**: 🟡 性能
- **影响文件**: `components/MessageList.tsx:245-260`
- **问题**: `requestAnimationFrame` 循环在组件整个生命周期内每帧执行（~60fps），即使空闲时也在运行
- **修复方案**: 仅在 `isStreaming` 为 true 时启动循环，流式结束后停止
- **状态**: [x] 已修复 — rAF 循环改为条件启停：仅在 `stickToBottomRef.current` 为 true 时继续循环，否则停止；依赖数组改为 `[isStreaming, activeSessionId, isLoading, stickToBottomTick]`；添加 `stickToBottomTick` 状态，用户滚回底部时从 false→true 变化触发重启

### TODO-16: `useIsMobile` 添加防抖

- **严重度**: 🟡 性能
- **影响文件**: `components/ChatLayout.tsx:23-35`
- **问题**: 窗口拖拽调整大小时，每次 resize 事件都触发状态更新和重渲染
- **修复方案**: 添加 150-200ms 防抖
- **状态**: [x] 已修复 — `useIsMobile` 添加 `RESIZE_DEBOUNCE_MS = 150` 防抖，cleanup 时清除 timer

### TODO-17: `loadMessages` 添加取消机制

- **严重度**: 🟡 数据一致性
- **影响文件**: `hooks/useSessions.ts:105-113`
- **问题**: 快速切换会话时，多个 `loadMessages` 请求可能并行，最后完成的覆盖前面的，可能显示错误会话的消息
- **修复方案**: 添加 AbortController，切换会话时取消前一个请求
- **状态**: [x] 已修复 — `loadMessages` 添加模块级 `_loadMessagesController` AbortController，每次调用前取消前一个请求；`sessionsApi.getMessages` 透传 signal；请求被取消时不更新 store

### TODO-18: `uploadApi.upload()` 添加 401 处理

- **严重度**: 🟡 一致性
- **影响文件**: `api/rest.ts:159-185`
- **问题**: `upload()` 不检查 401 状态打开设置面板，与 `request()` 的行为不一致
- **修复方案**: 添加 401 检查，触发 `useUIStore.setSettingsOpen(true)`
- **状态**: [x] 已修复 — P1 阶段在 rest.ts 中已完成，`uploadApi.upload()` 添加了 401 状态码检查并调用 `useUIStore.getState().setSettingsOpen(true)`

### TODO-19: `marked.parse()` 显式设置 `async: false`

- **严重度**: 🟡 潜在运行时错误
- **影响文件**: `lib/markdown.ts:363`
- **问题**: `marked.parse()` 可返回 `string | Promise<string>`，当前用 `as string` 强制转换
- **修复方案**: 配置 `markedInstance.setOptions({ async: false })` 或使用 `markedInstance.parse(src, { async: false })`
- **状态**: [x] 已修复 — `renderMarkdown` 中 `markedInstance.parse()` 调用添加 `{ async: false }` 选项

### TODO-20: 统一 `UploadResponse` 类型

- **严重度**: 🟡 类型安全
- **影响文件**: `api/rest.ts:151-157` vs `components/InputArea.tsx:33-42`
- **问题**: 两个文件各自定义了结构不同的 `UploadResponse`，通过 `as UploadResponse` 不安全转换桥接
- **修复方案**: 在 `types/index.ts` 定义统一的 `UploadResponse`，删除两处本地定义
- **状态**: [x] 已修复 — 在 `types/index.ts` 定义统一 `UploadResponse`（以后端实际返回结构为准：`{ success, data?: { name, serverPath, size? }, error? }`）；删除 `rest.ts` 和 `InputArea.tsx` 中本地定义；`InputArea.tsx` 改用 `NonNullable<UploadResponse["data"]>` 类型

### TODO-21: 流式渲染器链接 href 转义

- **严重度**: 🟡 纵深防御
- **影响文件**: `lib/markdown.ts:379-381`
- **问题**: `inlineFormat` 中 `<a href="$2">` 未转义 href，`javascript:` URI 虽被 DOMPurify 过滤但缺少纵深防御
- **修复方案**: 对 href 值调用 `escapeAttr()` 或验证 URI scheme
- **状态**: [x] 已修复 — `inlineFormat` 中链接替换改用函数式 replace callback，对 href 值调用 `escapeAttr()` 进行转义

### TODO-22: WebSocket `_flushQueue` 断连时无限递归 setTimeout

- **严重度**: 🟡 资源泄漏
- **影响文件**: `api/websocket.ts:146-169`
- **问题**: 断连后 `_flushQueue` 递归调度自身，`_rawSend` 失败又触发下一轮，形成无限循环（50ms 间隔）
- **修复方案**: 断连时停止队列刷新，重连后重新触发
- **状态**: [x] 已修复 — `_flushQueue` 在 `_rawSend` 返回 false（断连）时停止递归调度，队列中消息保留；下次重连时 `onopen` 重新调用 `_flushQueue`

### TODO-23: `useSessionExport` 修复 `exporting` 依赖 + 添加取消机制

- **严重度**: 🟡
- **影响文件**: `components/sidebar/useSessionExport.ts:68-95`
- **问题**: `exporting` 在 `useCallback` 依赖数组中导致回调重建，双重点击可能绕过守卫；无 AbortController，组件卸载后仍继续请求
- **修复方案**: 用 ref 替代 `exporting` 状态守卫；添加 AbortController 支持取消
- **状态**: [x] 已修复 — 用 `exportingRef` 替代 `exporting` 状态守卫，从 useCallback 依赖数组移除 `exporting`；添加 `abortRef` AbortController 支持取消；catch 块改用 `err instanceof Error` 安全类型守卫

### TODO-24: `loadIdentities()` 添加重试机制

- **严重度**: 🟡
- **影响文件**: `hooks/useSessions.ts:91-103`
- **问题**: 初始加载失败后用户无法重试，只能刷新页面
- **修复方案**: 添加重试按钮或自动重试逻辑
- **状态**: [x] 已修复 — `loadIdentities` 添加自动重试逻辑：最多重试 2 次（`IDENTITIES_MAX_RETRIES`），递增延迟（2s→4s），仅在所有重试失败后才显示 toast 错误

### TODO-25: API Key 不应暴露在 WebSocket URL 查询参数中

- **严重度**: 🟡 安全
- **影响文件**: `api/websocket.ts:16`
- **问题**: API Key 作为 `?api_key=xxx` 附加在 WebSocket URL 中，会出现在服务器日志、浏览器历史和代理日志中
- **修复方案**: 改用 WebSocket 子协议（`Sec-WebSocket-Protocol`）或首条消息认证
- **状态**: [x] 已标注（需后端协同） — 后端 `validateWSAuth()` 仅支持 URL 查询参数认证，前端暂保留 `?api_key=` 方式，在 `buildWsUrl` 中添加 TODO(security) 注释标记安全改进方向；需后端支持首条消息认证或子协议后才可移除 URL 参数

### TODO-26: `items` useMemo 优化 — 分离流式项与静态项

- **严重度**: 🟡 性能
- **影响文件**: `components/MessageList.tsx:68-99`
- **问题**: `streamingContent` 每帧变化导致整个 items 数组（含所有消息）每帧重算
- **修复方案**: 将流式项（streamingContent/streamingReasoning/toolCalls）与静态消息项分离，流式项独立 memo
- **状态**: [x] 已修复 — `items` useMemo 拆分为 `staticItems`（hasMoreMessages + messages）和 `streamingItems`（streamingReasoning + toolCalls + streamingContent），各自独立 memo 后合并；流式内容每帧变化不再触发静态消息项重算

---

## P3 — 低优先级（代码质量 / 可访问性）

### TODO-27: 提取 UI 字符串常量

- **严重度**: ⚪
- **影响文件**: 全局（约 40+ 处硬编码中文字符串）
- **问题**: 所有 UI 字符串硬编码中文，无提取、无常量、无 i18n 框架
- **修复方案**: 提取到 `constants/strings.ts` 或引入 i18n 框架
- **状态**: [x] 已修复 — 创建 `constants/strings.ts`，定义 120+ 个 UI 字符串常量（按模块分组：通用/消息/会话/设置/登录/工具调用/导出/Markdown/主题/进度/文件/通知/思考/空状态）。核心文件已替换：`useSessions.ts`（8 处 toast）、`websocket.ts`（3 处消息内容）、`useSessionExport.ts`（9 处角色标签+toast）、`MessageBubble.tsx`（"重试"按钮）。低频组件（ProgressBar、ThemeToggle 等）保留内联，待后续 i18n 迁移统一处理

### TODO-28: 命名魔法数字

- **严重度**: ⚪
- **影响文件**: MessageList.tsx、MessageBubble.tsx、InputArea.tsx、ChatLayout.tsx、mermaid.ts、useSessionExport.ts
- **问题**: 大量硬编码数字（80、120、150、2000、200、768、8192 等）
- **修复方案**: 提取为命名常量
  ```typescript
  const BOTTOM_THRESHOLD = 80;
  const LOAD_MORE_TRIGGER = 120;
  const PROGRAMMATIC_SCROLL_WINDOW_MS = 150;
  // ...
  ```
- **状态**: [x] 已修复 — MessageList：`BOTTOM_THRESHOLD_PX=80`、`LOAD_MORE_TRIGGER_PX=120`、`PROGRAMMATIC_SCROLL_WINDOW_MS=150`；MessageBubble：`COPY_FEEDBACK_RESET_MS=2000`、`FILE_OPEN_COOLDOWN_MS=2000`；InputArea：`TEXTAREA_MAX_HEIGHT_PX=200`、`TEXTAREA_MIN_HEIGHT_PX=48`、`DRAFT_SAVE_DEBOUNCE_MS=300`；mermaid.ts：`WAIT_FOR_SIZE_TIMEOUT_MS=2000`、`PNG_EXPORT_SCALE=2`、`CANVAS_MAX_DIMENSION=8192`、`PNG_EXPORT_LOAD_TIMEOUT_MS=10000`；ChatLayout 已有 `MOBILE_BREAKPOINT=768`、`RESIZE_DEBOUNCE_MS=150`

### TODO-29: 拆分 MessageBubble 组件

- **严重度**: ⚪
- **影响文件**: `components/MessageBubble.tsx`（340 行）
- **问题**: 一个组件处理 5 种消息类型，`handleBubbleClick` 事件委托 120+ 行处理 4 种点击目标
- **修复方案**: 拆分为 `AssistantMessageBubble`、`UserMessageBubble`、`SystemMessageBubble`、`ErrorMessageBubble`、`AuditMessageBubble`
- **状态**: [x] 已修复 — 提取 `hooks/useBubbleEvents.ts`，将 120+ 行的事件委托逻辑（代码块复制、Mermaid 操作、文件链接点击、键盘事件）从 MessageBubble 中分离。MessageBubble 从 340 行降至 195 行，专注于渲染逻辑

### TODO-30: 添加 `aria-live` 区域和可访问性改进

- **严重度**: ⚪
- **影响文件**: MessageBubble.tsx、MessageList.tsx、SessionList.tsx、ToolCallList.tsx
- **问题**:
  - `dangerouslySetInnerHTML` 内容无 `aria-live`，屏幕阅读器无法感知流式更新
  - 消息列表缺少 `role="log"`
  - SessionList 键盘导航无可见焦点指示
  - 流式消息无 "AI 正在输入..." 替代通知
  - ToolCall 列表项缺少 `aria-label`
- **修复方案**: 添加 `aria-live="polite"` 区域、`role="log"`、焦点管理、状态通知
- **状态**: [x] 已修复 — MessageList 添加 `role="log"` + `aria-label="消息列表"` + `aria-live="polite"`；ChatLayout 添加 `sr-only` 的 `aria-live="polite"` + `role="status"` 流式状态通知（"AI 正在生成回复..."）；SessionList 添加 `role="listbox"` + `aria-label` + `focus-visible:ring` 焦点样式；SessionItem 添加 `role="option"` + `aria-selected`；ToolCallList 每个 listitem 添加 `aria-label`（工具名+状态）

### TODO-31: Memo 化回调函数

- **严重度**: ⚪
- **影响文件**: Sidebar.tsx（5 个内联箭头函数）、ChatLayout.tsx（handleCloseSidebar）、useChat.ts（sendMessage、cancelRequest）
- **问题**: 未 memo 化的回调导致子组件不必要重渲染，击败 `memo` 优化
- **修复方案**: 用 `useCallback` 包装
- **状态**: [x] 已修复 — Sidebar：`handleDeleteConfirm`/`handleLogout`/`handleToggleSettings` 用 `useCallback` 包装，内联 `onToggleSettings` 替换为 `handleToggleSettings`；ChatLayout：`handleCloseSidebar` 用 `useCallback` 包装；useChat：`sendMessage`/`cancelRequest` 用 `useCallback` 包装

### TODO-32: `window.alert` → `toastError`

- **严重度**: ⚪
- **影响文件**: `components/MessageBubble.tsx:215`
- **问题**: 使用阻塞式 `window.alert` 显示错误，与全应用 toast 通知风格不一致
- **修复方案**: 替换为 `toastError()`
- **状态**: [x] 已修复 — `window.alert("打开失败: ...")` 替换为 `toastError("打开失败: ...")`，同时 catch 参数从 `err: Error` 改为 `err: unknown`，使用 `instanceof Error` 安全类型守卫

### TODO-33: Toast setTimeout 清理

- **严重度**: ⚪
- **影响文件**: `stores/ui-store.ts:22-24`
- **问题**: Toast 自动消失 `setTimeout` 在手动移除后仍会触发
- **修复方案**: 在 `removeToast` 中清除对应 timer
- **状态**: [x] 已修复 — 添加 `_toastTimers` Map 存储 toast id → timer 映射；`addToast` 中将 timer 存入 `_toastTimers`；`removeToast` 中先从 `_toastTimers` 获取并 `clearTimeout`，再删除 Map 条目，最后更新 state

### TODO-34: `err as Error` / `err as { status }` 修复为安全类型守卫

- **严重度**: ⚪
- **影响文件**: InputArea.tsx:148、useSessionExport.ts:89、mermaid.ts:296、LoginModal.tsx:75-76
- **问题**: catch 块中 `unknown` 类型直接 `as Error` 断言不安全
- **修复方案**: 使用 `err instanceof Error ? err.message : String(err)`
- **状态**: [x] 已修复 — InputArea：`(err as Error).message` → `err instanceof Error ? err.message : String(err)`；mermaid.ts：`const err = e as Error; err.name` → `err instanceof Error && err.name`（catch 变量改名为 `err`）；LoginModal：双重 `as { status }` / `as { response }` 断言 → `err instanceof Error && "status" in err` 安全检查；useSessionExport 已在 P2 阶段修复

### TODO-35: `JSON.parse` 结果添加类型验证

- **严重度**: ⚪
- **影响文件**: `api/websocket.ts:109`
- **问题**: `JSON.parse(event.data) as WSMessage` 无运行时验证
- **修复方案**: 添加类型守卫函数或使用 zod 验证
- **状态**: [x] 已修复 — `JSON.parse(event.data)` 改为先解析为 `unknown`，检查 `typeof parsed === "object" && parsed !== null && "type" in parsed`，通过后才 `as WSMessage`；不符合结构的消息打印 `console.error` 并跳过

### TODO-36: `null as T` 修复为安全模式

- **严重度**: ⚪
- **影响文件**: `api/rest.ts:80`
- **问题**: 204 响应返回 `null as T`，对非 nullable 类型撒谎
- **修复方案**: 使用 `request<void>` 或函数重载
- **状态**: [x] 已修复 — `return null as T` → `return undefined as T`，语义上 `undefined` 比 `null` 更适合表示"无返回值"；调用端 `sessionsApi.delete()` 和 `sessionsApi.clearMessages()` 类型为 `request<null>`，保持不变

### TODO-37: `cancelRequest` 的 `"current"` fallback 验证

- **严重度**: ⚪
- **影响文件**: `hooks/useChat.ts:43-48`
- **问题**: 取消请求使用 fallback `"current"` 作为 requestId，服务端可能不识别
- **修复方案**: 确认服务端支持 `"current"` 或改用其他取消机制
- **状态**: [x] 已修复 — 确认后端 `handleCancel()` 直接 abort 当前连接的 `abortController`，不检查 requestId，因此 `"current"` fallback 是多余的。改为 `p?.requestId || ""`（空字符串比 `"current"` 更诚实，表示无 requestId 可用）

### TODO-38: `deprecated execCommand("copy")` 替换

- **严重度**: ⚪
- **影响文件**: `components/MessageBubble.tsx:172`
- **问题**: `document.execCommand("copy")` 已废弃
- **修复方案**: 评估是否仍需 fallback，如需要可保留但添加注释
- **状态**: [x] 已修复 — 重构为优先使用 `navigator.clipboard.writeText()`，仅在 Clipboard API 不可用或被拒绝时降级到 `execCommand("copy")`（HTTP 页面无 Clipboard API 权限，textarea+execCommand 仍是唯一可靠降级方案）。降级路径添加注释说明原因。逻辑移入 `useBubbleEvents` hook

### TODO-39: chat-store 模块级可变状态 HMR 重置

- **严重度**: ⚪
- **影响文件**: `stores/chat-store.ts:5-8`、`stores/ui-store.ts:4`
- **问题**: `pendingChunks`、`pendingReasoning`、`rafId`、`_toastId` 等模块级变量在 HMR 时不重置
- **修复方案**: 添加 HMR 重置守卫或移入 store state
- **状态**: [x] 已修复 — `chat-store.ts`：添加 `import.meta.hot.dispose()` 守卫，取消 pending rAF、清空 pendingChunks/pendingReasoning、重置 `_localMsgId`；`ui-store.ts`：添加 `import.meta.hot.dispose()` 守卫，清除所有 `_toastTimers`、重置 `_toastId`

### TODO-40: `Session.status` 改为字符串字面量联合类型

- **严重度**: ⚪
- **影响文件**: `types/index.ts:48`
- **问题**: `status?: string` 过于松散，应为 `"active" | "completed" | "error"` 等联合类型
- **修复方案**: 定义 `SessionStatus` 联合类型
- **状态**: [x] 已修复 — `types/index.ts` 定义 `SessionStatus = "active" | "completed" | "error"`；`Session.status` 类型改为 `SessionStatus | undefined`；`mappers.ts` 添加 `SessionStatus` import 并对 `api.status` 使用 `as SessionStatus | undefined` 断言

---

## 积极发现

代码库展现的良好实践：

- ✅ **Zustand 选择性订阅**正确使用（`useChatStore((s) => s.isLoading)` 而非全量订阅）
- ✅ **稳定空引用**（`EMPTY_ARRAY`、`EMPTY_STRING`）防止选择器引用变化
- ✅ **`useDeferredValue`** 在 MessageBubble 中正确使用，避免重 Markdown 渲染阻塞输入
- ✅ **`memo`** 正确应用于 EmptyState、ProgressBar、ConfirmDialog、ReasoningPanel、ToolCallList、MessageBubble、SessionItem
- ✅ **Zustand 函数式 `set((state) => ...)`** 模式正确
- ✅ **无直接状态变异** — 所有 store 更新通过 `set()`
- ✅ **React key 使用稳定 ID** — 列表渲染无 key 问题
- ✅ **WebSocket 重连机制**（指数退避 + connectId 防止陈旧回调）
- ✅ **消息队列 + 节流刷新** 设计合理
- ✅ **主题防闪烁**（index.html 内联脚本读取 localStorage）

---

## 修复进度追踪

| 优先级 | 总数 | 已修复 | 进度 |
|--------|------|--------|------|
| P0 | 6 | 6 | 100% |
| P1 | 7 | 7 | 100% |
| P2 | 13 | 13 | 100% |
| P3 | 14 | 14 | 100% |
| **合计** | **40** | **40** | **100%** |
