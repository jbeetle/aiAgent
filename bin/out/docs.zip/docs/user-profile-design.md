# coqi-claw 用户画像机制设计方案

> 基于 Hermes Agent `USER.md` 实现的完整分析，结合 coqi-claw 现有架构的务实方案。
>
> 核心思路：后台线程定时扫描 SQLite 中已有会话记录，每次扫描一个会话，用 LLM 提取用户偏好，按会话粒度管理画像条目。

## 一、设计原则

1. **不照搬 Hermes** — Hermes 用纯文本 `§` 分隔。coqi-claw 有 SQLite，用关系表
2. **不搞 embedding** — 向量检索太重
3. **离线提取，零感知延迟** — 后台线程会话结束后异步扫描，不影响用户交互
4. **复用已有基础设施** — 会话消息已在 `messages` 表中，只需新增两张表

## 二、存储层：两张新表

```sql
-- 画像条目表：一条记录 = 一个画像条目
CREATE TABLE IF NOT EXISTS user_profile (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     TEXT NOT NULL DEFAULT 'default',
  content     TEXT NOT NULL,              -- 条目内容
  category    TEXT NOT NULL CHECK(category IN ('language','style','role','constraint','habit','fact')),
  importance  INTEGER NOT NULL DEFAULT 3 CHECK(importance BETWEEN 1 AND 5),
  source      TEXT NOT NULL CHECK(source IN ('auto','manual')),
  session_id  TEXT,                       -- 来源会话 ID（溯源用，不设外键：会话是软删除）
  created_at  INTEGER NOT NULL,
  updated_at  INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_user_profile_user ON user_profile(user_id, category, importance DESC, created_at DESC);

-- 扫描日志表：一条记录 = 一次扫描记录
CREATE TABLE IF NOT EXISTS profile_extraction_log (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id    TEXT NOT NULL,
  message_count INTEGER NOT NULL,         -- 扫描时该会话的消息数（用于判断增量）
  extracted_at  INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_extraction_log_session ON profile_extraction_log(session_id, extracted_at DESC);
```

### 与 Hermes 的对比

| 维度 | Hermes (USER.md) | coqi-claw 方案 |
|------|------------------|---------------|
| 存储介质 | 纯文本 § 分隔 | SQLite 关系表 |
| 条目分离 | `§` 分隔符 | 行记录 |
| 元数据 | 无 | category + importance + source + session_id + timestamp |
| 并发安全 | fcntl/msvcrt 文件锁 | SQLite 事务天然保证 |
| 捕获方式 | LLM 自主调用 memory 工具 | 后台线程 + LLM 离线分析 |
| 条目管理粒度 | 全文件级 | 会话级（重扫不影响其他会话） |

## 三、扫描线程设计

### 3.1 扫描参数

```javascript
const SCAN_INTERVAL      = 30 * 60 * 1000;       // 每 30 分钟醒来一次
const SETTLE_WINDOW      = 30 * 60 * 1000;        // 会话需稳定 30 分钟无新消息
const MIN_MESSAGES       = 4;                      // 低于 4 条消息的会话不扫
const MIN_USER_MESSAGES  = 4;                      // 低于 4 条用户消息不值得调 LLM
const RESCAN_RATIO       = 0.3;                    // 消息增量 > 30% 才重新扫
```

### 3.2 候选会话筛选

每轮周期只选一个会话（LIMIT 1），优先扫更新最多的：

```sql
SELECT s.id, s.message_count
FROM sessions s
WHERE s.status = 'active'
  AND s.message_count >= ?
  AND s.updated_at < ?
  AND (
    -- 从未扫过
    NOT EXISTS (
      SELECT 1 FROM profile_extraction_log p
      WHERE p.session_id = s.id
    )
    OR
    -- 消息增量 > 50%
    s.message_count > (
      SELECT p.message_count * (1 + ?)
      FROM profile_extraction_log p
      WHERE p.session_id = s.id
      ORDER BY p.extracted_at DESC
      LIMIT 1
    )
  )
ORDER BY s.updated_at DESC
LIMIT 1
```

### 3.3 提取数据范围

只传 `role='user'` 的消息给提取 LLM。assistant 的回复（代码块、工具输出、长解释）对提取用户偏好没有帮助，反而大幅增加 token 消耗。

### 3.4 提取 prompt

```javascript
const EXTRACTION_PROMPT = `分析以下用户消息，提取该会话中当前仍然有效的全部用户画像信息。

提取范围：
1. 语言/风格偏好
2. 用户角色/职位
3. 约束条件（"不要调用外部API"）
4. 工作习惯
5. 稳定的用户事实

注意：只提取稳定的、长期有效的偏好，不要提取临时性或一次性的表达。

如果这段对话中没有值得保存的画像信息，返回空 JSON。

输出格式：JSON
{
  "language": "zh",               // 单值（为空则省略）
  "style": "简洁直接",            // 单值
  "role": "后端开发",             // 单值
  "constraints": ["不用emoji"],   // 多值（数组，为空则省略）
  "habits": [],                   // 多值（数组）
  "facts": []                     // 多值（数组）
}

示例1：
用户消息："帮我用Python写个脚本，不要用第三方库"
输出：{"constraints": ["不用第三方库"], "habits": ["偏好Python"]}

示例2：
用户消息："我是做量化交易的，回答尽量简洁，别废话"
输出：{"style": "简洁直接", "role": "量化交易"}

示例3：
用户消息："用英文回答，我是伦敦的交易员，不要给我看A股数据"
输出：{"language": "en", "role": "伦敦交易员", "constraints": ["不看A股数据"]}`;
```

### 3.5 主循环

```javascript
// src/memory/background-extractor.js

function startBackgroundExtractor(sessionManager, llmClient) {
  let running = false;

  const timer = setInterval(async () => {
    if (running) return;  // 上一周期未完成，跳过
    running = true;

    try {
      // 1. 找候选会话
      const candidate = findCandidate(db);
      if (!candidate) return;

      // 2. 只读用户消息（role='user'），assistant 的回复对提取偏好没用
      const messages = sessionManager.getSessionMessages(candidate.id);
      const userMsgs = messages
        .filter(m => m.role === 'user')
        .map(m => m.content);

      // 3. 用户消息太少 → 不值得调 LLM，但记录日志避免后续死循环
      if (userMsgs.length < MIN_USER_MESSAGES) {
        markScanned(db, candidate.id, candidate.message_count);
        return;
      }

      // 4. 调 LLM 提取（限制消息长度 + 超时）
      const MAX_USER_CHARS = 30000;
      let userContent = userMsgs.join('\n\n');
      if (userContent.length > MAX_USER_CHARS) {
        userContent = userContent.slice(-MAX_USER_CHARS);
      }
      const result = await llmClient.chat({
        messages: [
          { role: 'system', content: EXTRACTION_PROMPT },
          { role: 'user', content: userContent },
        ],
        temperature: 0.1,
        maxTokens: 500,
        timeout: 15000,
      });
      // JSON 解析降级：LLM 不总是返回纯 JSON
      let profile;
      try {
        profile = JSON.parse(result.content);
      } catch {
        const match = result.content.match(/\{[\s\S]*\}/);
        if (!match) {
          logger.warn('Profile extraction returned non-JSON', { sessionId: candidate.id });
          markScanned(db, candidate.id, candidate.message_count);
          return;
        }
        profile = JSON.parse(match[0]);
      }

      if (!profile || Object.keys(profile).length === 0) {
        markScanned(db, candidate.id, candidate.message_count);
        return;
      }

      // 6. 有画像 → 会话级先删后插（事务）
      upsertSessionProfile(db, candidate.id, candidate.message_count, profile);

    } catch (error) {
      // 统一使用项目错误处理（D-4）
      if (error.name === 'TimeoutError' || error.code === 'ETIMEDOUT') {
        logger.warn('Profile extraction timed out', { sessionId: candidate?.id, error: error.message });
      } else if (error.name === 'NetworkError' || error.code === 'ECONNREFUSED') {
        logger.warn('Profile extraction network error', { sessionId: candidate?.id, error: error.message });
      } else {
        logger.warn('Background extraction failed', { error: error.message });
      }
      // 失败不记录扫描日志，下次周期重试
    } finally {
      running = false;
    }
  }, SCAN_INTERVAL);

  return () => clearInterval(timer);
}
```

关键设计点：
- **日志与条目写入分离**：无论 LLM 返回什么，只要扫描尝试完成就记录日志，避免死循环
- **用户消息数前置检查**：`sessions.message_count` 是总消息数，读取后二次判断避免无效 LLM 调用

```javascript
function markScanned(db, sessionId, messageCount) {
  db.prepare(`
    INSERT INTO profile_extraction_log (session_id, message_count, extracted_at)
    VALUES (?, ?, ?)
  `).run(sessionId, messageCount, Date.now());
}
```

## 四、会话级写入

每次扫描一个会话时，先删掉该会话之前产生的旧条目，再插入新条目。

```javascript
function upsertSessionProfile(db, sessionId, messageCount, entries) {
  const now = Date.now();

  const transaction = db.transaction(() => {
    // 1. 删掉这个会话之前产生的所有条目
    db.prepare(`
      DELETE FROM user_profile
      WHERE user_id = 'default' AND source = 'auto' AND session_id = ?
    `).run(sessionId);

    // 2. 插入新条目
    const insert = db.prepare(`
      INSERT INTO user_profile (user_id, content, category, importance, source, session_id, created_at, updated_at)
      VALUES (?, ?, ?, ?, 'auto', ?, ?, ?)
    `);

    const ITEMS = [
      { key: 'language',    category: 'language',    importance: 5, multi: false },
      { key: 'style',       category: 'style',       importance: 4, multi: false },
      { key: 'role',        category: 'role',        importance: 4, multi: false },
      { key: 'constraints', category: 'constraint',  importance: 5, multi: true  },
      { key: 'habits',      category: 'habit',       importance: 3, multi: true  },
      { key: 'facts',       category: 'fact',        importance: 3, multi: true  },
    ];

    for (const { key, category, importance, multi } of ITEMS) {
      const val = entries[key];
      if (!val || (Array.isArray(val) && val.length === 0)) continue;
      // LLM 可能返回字符串而不是数组（如 "不用emoji" vs ["不用emoji"]）
      const items = multi ? (Array.isArray(val) ? val : [val]) : [val];
      for (const item of items) {
        insert.run('default', item, category, importance, sessionId, now, now);
      }
    }

  });

  transaction();

  // 3. 记录扫描日志（事务外：画像写入成功才记录，失败则下次周期重试）
  markScanned(db, sessionId, messageCount);
}
```

## 五、profile_set 工具（立即生效出口）

后台线程有延迟（最近 30 分钟 + 30 分钟轮询），当用户明确要求"记住xxx"时，LLM 可以通过此工具立即写入。写入后触发 `invalidateSystemPrompt()`，当前会话后续轮次立即生效。

```javascript
// src/tools/profile-set.js

export const name = 'profile_set';

export const description = `立即设置用户画像条目。用户明确要求"记住xxx"、"以后都xxx"时使用。
后台线程也会自动提取，此工具用于需要立即生效的场景。

category 说明：
- language: 语言偏好（如 "zh", "en"）
- style: 回答风格（如 "简洁直接", "详细解释"）
- role: 用户角色（如 "后端开发", "投行VP"）
- constraint: 约束条件（如 "不要调用外部API"）
- habit: 工作习惯（如 "工作日9-17点在线"）
- fact: 稳定的用户事实（如 "使用Windows开发"）`;

export const parameters = {
  category:   { type: 'string', enum: ['language', 'style', 'role', 'constraint', 'habit', 'fact'] },
  content:    { type: 'string', description: '条目内容' },
  importance: { type: 'integer', description: '1-5，默认5', enum: [1, 2, 3, 4, 5] },
};

export async function execute({ category, content, importance = 5 }, { db }) {
  const now = Date.now();

  // 同 category 单值的替换旧条目
  if (['language', 'style', 'role'].includes(category)) {
    db.prepare(`
      DELETE FROM user_profile
      WHERE user_id = 'default' AND category = ? AND source = 'manual'
    `).run(category);
  }

  // 精确去重
  const dup = db.prepare(`
    SELECT id FROM user_profile
    WHERE user_id = 'default' AND category = ? AND content = ?
  `).get(category, content);
  if (dup) return JSON.stringify({ success: true, note: '已存在相同条目' });

  db.prepare(`
    INSERT INTO user_profile (user_id, content, category, importance, source, created_at, updated_at)
    VALUES ('default', ?, ?, ?, 'manual', ?, ?)
  `).run(content, category, importance, now, now);

  // 立即生效：触发系统提示词刷新，当前会话后续轮次使用新画像
  if (typeof invalidateSystemPrompt === 'function') {
    invalidateSystemPrompt();
  }

  return JSON.stringify({ success: true, category, content });
}
```

条目 `source = 'manual'`，注入时 `manual` 优先级高于 `auto`（同样 category 时 manual 条目排前面）。

## 六、画像注入

系统提示词构建时，从 `user_profile` 表读取，按 category + content 去重聚合（多个会话可能产生相同条目）：

```javascript
function buildProfileBlock(db) {
  // 按 (category, content) 聚合去重，manual 优先，importance 取最大值
  const rows = db.prepare(`
    SELECT content, category,
           MAX(CASE WHEN source = 'manual' THEN 1 ELSE 0 END) AS is_manual,
           MAX(importance) AS importance
    FROM user_profile
    WHERE user_id = 'default'
    GROUP BY category, content
    ORDER BY is_manual DESC, importance DESC
  `).all();

  if (!rows.length) return '';

  const seen = new Set();
  const lines = [];

  for (const r of rows) {
    if (['language', 'style', 'role'].includes(r.category) && seen.has(r.category)) {
      continue;  // 单值 category 只取最高 importance 的
    }
    seen.add(r.category);

    switch (r.category) {
      case 'language':   lines.push(`语言: ${r.content}`); break;
      case 'style':      lines.push(`风格: ${r.content}`); break;
      case 'role':       lines.push(`角色: ${r.content}`); break;
      case 'constraint': lines.push(`约束: ${r.content}`); break;
      case 'habit':      lines.push(`习惯: ${r.content}`); break;
      case 'fact':       lines.push(`信息: ${r.content}`); break;
    }
  }

  return lines.length
    ? `用户画像:\n${lines.map(l => `- ${l}`).join('\n')}`
    : '';
}
```

在 `Agent.constructor()` 或 prompt-builder 中调用，结果注入系统提示词。

**Frozen Snapshot**：画像在 agent 初始化时查询一次并缓存，整会话不变。不在每轮 LLM 调用时重新查询——避免前缀缓存被破坏。上下文压缩时通过 `invalidateSystemPrompt()` 使缓存失效并重新加载（复用 coqi-claw 已有机制）。`profile_set` 写入后也触发 `invalidateSystemPrompt()`，实现当前会话内立即生效。

## 七、完整流程图

```
sessions 表（已有）
  每个会话的消息已存储
      ↓
profile_extraction_log（新增）
  记录哪些会话被扫过 + 当时的消息数
      ↓
后台线程每 30min 醒来
  ├─ 找候选会话（未扫过 或 消息增量 > 30%）
  ├─ 只取一个（LIMIT 1）
  ├─ 读该会话所有用户消息
  ├─ 调 LLM 提取画像
  └─ 事务：
      ├─ DELETE FROM user_profile WHERE session_id = ?（先删后插）
      └─ INSERT 新条目
  └─ markScanned()（事务外，独立写入日志）
      ↓
user_profile 表（新增）
  每个条目绑定 session_id + category + importance
      ↓
系统提示词注入时
  ├─ SELECT ... GROUP BY category, content
  ├─ 单值 category 去重（取最高 importance）
  └─ 渲染为文本注入系统提示词
```

## 八、线程生命周期

在 bootstrap 中启动，注册退出清理：

```javascript
// src/bootstrap/bootstrap-manager.js
import { startBackgroundExtractor } from '../memory/background-extractor.js';

let stopExtractor = null;

export async function initBootstrap() {
  // ... 现有初始化代码 ...
  stopExtractor = startBackgroundExtractor(sessionManager, llmClient);
}

const cleanup = () => {
  if (stopExtractor) stopExtractor();
};
process.on('SIGINT', cleanup);
process.on('SIGTERM', cleanup);
```

注意：不能使用 `beforeExit`，因为 `setInterval` 使事件循环永不清空。

## 九、生产注意事项

### 9.1 日志清理

`profile_extraction_log` 表持续增长。建议每次扫描周期末尾清理 90 天前的日志：

```javascript
db.prepare(`DELETE FROM profile_extraction_log WHERE extracted_at < ?`)
  .run(Date.now() - 90 * 24 * 60 * 60 * 1000);
```

### 9.2 LLM Client API 适配

`llmClient.chat()` 的实际接口参考 `src/core/llm/client.js`：

```javascript
const response = await llmClient.chat({ messages, temperature: 0.1, maxTokens: 500, timeout: 15000 });
const content = response.content || response.choices?.[0]?.message?.content;
```

### 9.3 profile_set 工具注册

```javascript
// src/tools/index.js
import { name, description, parameters, execute } from './profile-set.js';
builtInTools[name] = buildTool({ name, description, parameters, execute });
// src/core/i18n.js 中补双语描述
```

### 9.4 后台任务 LLM 配置

画像提取使用独立的后台任务 LLM，与主模型、Matcher 隔离，无 Fallback 链。调用失败记录日志，下次扫描周期重试。

```bash
# 画像提取开关（默认 false，需明确开启）
ENABLE_PROFILE_EXTRACTION=true

# 后台任务 LLM 配置（独立配置，不降级到其他模型）
BACKGROUND_LLM_API_KEY=xxx
BACKGROUND_LLM_BASE_URL=https://api.xxx.com/v1
BACKGROUND_LLM_MODEL=xxx
BACKGROUND_LLM_REQUEST_TIMEOUT=60000        # 请求超时（毫秒）
BACKGROUND_LLM_MAX_RETRIES=3                 # 最大尝试次数（含首次）
BACKGROUND_LLM_TEMPERATURE=0.1               # 温度参数
BACKGROUND_LLM_HTTP_MAX_SOCKETS=10           # 最大并发连接数
BACKGROUND_LLM_KEEP_ALIVE_TIMEOUT=300000     # 空闲连接保活超时
```

后台任务 LLM 配置命名 `BACKGROUND_LLM_*`，不限于画像提取，未来其他后台分析场景也可复用。

### 9.5 本地开发

```javascript
const SCAN_INTERVAL = process.env.NODE_ENV === 'production'
  ? 30 * 60 * 1000 : 2 * 60 * 1000;  // 生产 30min / 本地 2min
```

## 十、与 Hermes 的差异分析

| 维度 | Hermes USER.md | coqi-claw 方案 | 差异原因 |
|------|---------------|---------------|----------|
| 存储 | 纯文本 § 分隔 | SQLite 两张关系表 | coqi-claw 已有 SQLite |
| 捕获方式 | LLM 自主调用 memory 工具 | 后台线程 + 离线 LLM 分析 | 零感知延迟，不依赖 LLM 自觉 |
| 扫描粒度 | 全量（一个文件） | 单会话 | 会话间独立，重扫不互相影响 |
| 条目管理 | 先读全量再修改（全文件级） | 会话级先删后插 | 简单可靠，LLM 每次返回会话全部有效偏好 |
| 注入时机 | Frozen Snapshot（会话启动时） | 同上（直接借鉴） | 保护前缀缓存 |
| 元数据 | 无 | category + importance + session_id | 按 category 聚合去重 |
| 去重 | 精确字符串 | 精确字符串 + category 分组 | 同上 |

## 十一、实施路径

```
Phase 1: 数据库 + 核心逻辑（~3 天）
  - 创建 user_profile 和 profile_extraction_log 表
  - 实现 upsertSessionProfile()
  - 实现 buildProfileBlock() 注入逻辑
  - 统一使用 Errors / ErrorTypes 错误处理
  - 验证：node --check

Phase 2: 后台线程（~2 天）
  - 实现 startBackgroundExtractor()
  - 在 bootstrap 中启动线程
  - 增加 ENABLE_PROFILE_EXTRACTION 开关 + BACKGROUND_LLM_* 配置
  - 手动测试：创建几个测试会话 → 等待扫描 → 查看 user_profile 表
```
