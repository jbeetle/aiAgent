# Web 环境配置保存机制

本文档总结 coqi-claw Web UI 中「设置 → 环境配置」页面的保存、持久化与热更新机制。

## 1. 整体流程

```
EnvConfigPage.tsx
       │
       ▼
useConfigStore.saveConfig()
       │
       ▼
PATCH /api/config { changes: { LLM_ENABLE_THINKING: "false", ... } }
       │
       ▼
ConfigService.applyChanges()
       │
       ├── 校验 key 合法性、webEditable、guarded 安全键限制
       ├── convertValue / validateWithSchema 类型转换与校验
       ├── 加密字段 RSA 加密（schema.encrypted === true）
       ├── process.env[key] = value  立即影响当前进程
       └── writeEnvChanges(targetFile, envChanges)  持久化落盘
       │
       ▼
_persistAndHotReload()
       ├── clearConfigCache()
       ├── loadConfig()  重新加载运行时配置
       ├── agent.setRuntimeConfig(newConfig)
       ├── primaryClient.setRuntimeConfig(newConfig)
       ├── matcherClient.setRuntimeConfig(newConfig)
       └── 尝试启动未初始化的模块
```

## 2. 前端状态管理

- `web/src/stores/config-store.ts`
  - `loadConfig()`：`GET /api/config`，获取分组配置、当前值、原始值、`envHash`、未初始化模块等。
  - `setFieldValue()`：仅修改 `currentValues`，不立即持久化。
  - `saveConfig()`：计算 `currentValues` 与 `originalValues` 的差异，调用 `PATCH /api/config`，成功后更新 `originalValues` 与 `pendingRestartKeys`。
  - `resetDraft()`：把 `currentValues` 恢复为 `originalValues`。

## 3. 后端路由与配置服务

- `src/gateway/routes/config.js`
  - `PATCH /api/config` 调用 `configService.applyChanges(changes, { envHash, isGuarded })`。
  - `POST /api/config/reload` 用于强制从磁盘重新加载。

- `src/services/config-service.js`
  - 核心方法 `applyChanges()`：负责校验、加密、更新 `process.env`、落盘、热更新。
  - `_persistAndHotReload()`：完成持久化后触发运行时热更新。
  - 通过 `SchemaProvider` 合并 `config/env-config-schema.json` 与 `src/utils/config/schema.js`。

## 4. 持久化目标文件

| 场景 | 目标文件 | 跨重启保留 |
|------|---------|-----------|
| `personal` / `dev` | 项目根目录 `.env` | ✅ 保留 |
| `enterprise` / `financial` | 项目根目录 `.env.runtime` | ❌ 不保留，仅运行时覆盖层 |

- `.env.runtime` 的设计意图：在 guarded 场景下，敏感运行时变更不污染主 `.env`，服务重启后失效，降低持久化泄露风险。

## 5. 文件写入策略

`src/utils/config/env-writer.js` 提供 `writeEnvChanges()`：

- **原子写入**：先写入 `.env.tmp`，再 `rename` 到目标文件，避免写入过程中崩溃导致文件截断。
- **逐行修改**：只修改目标 key 所在行，保留注释、空行、未修改行和引号风格。
- **自动追加**：若文件中不存在该 key，则在文件末尾追加。
- **注释保护**：按引号状态识别真正的行尾注释，避免误修改。

注意：`env-writer.js` 本身**不做加密**，只负责明文/密文字符串的安全写入。

## 6. 加密机制

加密在 `ConfigService.applyChanges()` 中完成：

- 仅当 `config/env-config-schema.json` 中对应条目 `"encrypted": true` 时才加密。
- 使用 `config/public-config.pem` 进行 RSA 公钥加密。
- 加密后的值以 `{...}` 格式写入 `.env`。
- 如果公钥缺失，会降级为明文写入，并记录 warn 日志。

当前标记为加密的敏感字段：

| 字段 | 是否加密 |
|------|---------|
| `LLM_API_KEY` | ✅ |
| `VISION_LLM_API_KEY` | ✅ |
| `DB_ENCRYPTION_KEY` | ✅ |
| `SMTP_PASS` | ✅ |
| `MATCHER_LLM_API_KEY` | ❌ |
| `AUDIT_LLM_API_KEY` | ❌ |
| `BACKGROUND_LLM_API_KEY` | ❌ |
| `TOOL_LLM_API_KEY` | ❌ |

> 如需让其他 `*_API_KEY` 也加密保存，将 `config/env-config-schema.json` 中对应条目的 `"encrypted"` 改为 `true` 即可。

## 7. 热更新与需要重启的项

保存后，以下组件会立即用热更新方式接收新配置：

- `Agent`：`agent.setRuntimeConfig(newConfig)` 更新 `maxIterations`、`maxMessagesSize`、上下文摘要等。
- `LLMClient`：`primaryClient.setRuntimeConfig(newConfig)` / `matcherClient.setRuntimeConfig(newConfig)` 更新 `model`、`temperature`、`llmEnableThinking`、`llmReasoningEffort`、`maxRetries` 等非连接参数。
- 日志级别：若修改 `LOG_LEVEL`，会调用 `reloadLogLevel()`。
- 未初始化模块：若保存的 key 属于某个未运行模块，会尝试 `moduleLifecycle.start(moduleId)` 启动它。

但以下变更**需要重启服务**才能完全生效（由 `web-config-policy.js` 标记为 `restartRequired`）：

- 连接池参数：`LLM_HTTP_MAX_SOCKETS`、`LLM_KEEP_ALIVE_TIMEOUT` 等。
- 凭证参数：`LLM_PROVIDER`、`LLM_BASE_URL`、`LLM_API_KEY`、`MATCHER_LLM_*`、`AUDIT_LLM_*` 等。
- 启动期一次性参数：`COQI_SCENE`、`DB_ENCRYPTION_KEY`、`SANDBOX_PATHS`、`WEB_PORT`、安全策略相关等。

前端通过 `RestartBanner` 展示这些 `pendingRestartKeys`。

## 8. 并发控制

- 前端在 `PATCH /api/config` 请求头中携带 `If-Match: envHash`。
- 后端 `ConfigService.applyChanges()` 计算当前 `.env` 文件 hash，与 `If-Match` 比较，不一致时返回 `409 Conflict`。
- 前端收到 409 后提示用户刷新页面。

## 9. 相关文件

| 文件 | 职责 |
|------|------|
| `web/src/stores/config-store.ts` | 前端配置状态管理 |
| `web/src/components/settings/EnvConfigPage.tsx` | 环境配置页面 |
| `web/src/components/settings/EnvConfigField.tsx` | 动态配置字段渲染 |
| `src/gateway/routes/config.js` | Config REST 路由 |
| `src/services/config-service.js` | 配置变更编排核心 |
| `src/services/module-lifecycle.js` | 模块启动/停止生命周期 |
| `src/utils/config/env-writer.js` | `.env` / `.env.runtime` 原子写入 |
| `src/utils/config/index.js` | `loadConfig()` / `clearConfigCache()` |
| `src/utils/config/schema-provider.js` | Schema 合并与缓存 |
| `src/utils/config/web-config-policy.js` | webEditable / restartRequired / moduleId 策略 |
| `src/utils/config/schema.js` | CONFIG_SCHEMA（类型转换与校验） |
| `config/env-config-schema.json` | 默认值、分组、加密标记、说明 |
