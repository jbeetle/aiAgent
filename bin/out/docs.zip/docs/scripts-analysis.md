# scripts/ 目录分析总结

`scripts/` 目录共有 **6 个 Node.js 脚本**，按功能可分为 **构建打包**、**密钥管理**、**Skill 安全** 三大类。

---

## 一、构建打包（2 个）

| 脚本 | 作用 | 关键行为 |
|------|------|----------|
| **`build-sea.js`** | 构建单文件可执行程序（SEA） | 1. 生成 `sea-entry.cjs` + `sea-config.json`<br>2. 用 `postject` 将 blob 注入 node 二进制<br>3. 复制 `src/`、`skills/`、`node_modules/`（原生模块）、`package.json` 到 `dist/`<br>4. 输出 `dist/cmbi-claw.exe`（Windows）或 `cmbi-claw`（Unix） |
| **`build-obfuscated.js`** | 混淆构建到 `dist/` | 1. 用 `javascript-obfuscator` 对 `src/**/*.js` 做控制流扁平化、死代码注入、字符串数组混淆等<br>2. 失败时回退到原样复制<br>3. 复制 `package.json`、`.env.example`、`skills/`、生产依赖的 `node_modules` 到 `dist/` |

---

## 二、密钥管理（1 个）

| 脚本 | 作用 | 关键行为 |
|------|------|----------|
| **`gen-keys.js`** | 生成两套 RSA 密钥对 | 1. **4096-bit** → `config/skill-private.pem` + `config/public-skill.pem`（Skill Trust 签名用）<br>2. **2048-bit** → `config/public-config.pem` + `src/utils/secure-key.js`（环境变量加密用）<br>3. 2048 私钥通过 XOR 分片混淆后硬编码到 JS 文件中，运行时动态还原<br>4. 两套密钥均做加解密自检 |

---

## 三、Skill 安全 + 配置加密（3 个）

| 脚本 | 作用 | 关键行为 |
|------|------|----------|
| **`skill-sign.js`** | 为 Skill 目录生成信任签名 | 1. 递归计算 Skill 目录下所有文件的 SHA-256 哈希（排除 `.skill-trust`）<br>2. 用 RSA-SHA256 对 manifest 签名<br>3. 生成 `.skill-trust` 文件，包含签名、指纹、过期时间、文件清单 |
| **`skill-encrypt.js`** | 加密 Skill 中的敏感文件 | 1. 用 RSA 公钥加密随机生成的 AES-256-GCM 密钥（envelope encryption）<br>2. 默认加密 `scripts/*` 和 `references/*`，支持 `--files` 指定模式<br>3. 加密 SKILL.md 的 body（frontmatter 保留明文），生成 `.enc` 文件<br>4. 加密后重新签名，更新 `.skill-trust` 中的 `encryption` 字段 |
| **`encrypt-config.js`** | 加密环境变量配置值 | 1. 读取 `config/public-config.pem`（2048-bit 公钥）<br>2. 用 RSA-OAEP-SHA256 加密明文（最大 190 字节）<br>3. 输出 `{base64}` 格式密文，直接贴入 `.env` |

---

## 整体关系图

```
┌─────────────┐     ┌─────────────────┐
│ gen-keys.js │────▶│  4096-bit 密钥对 │──▶ skill-sign.js, skill-encrypt.js (Skill Trust)
│  (密钥生成)  │     │  2048-bit 密钥对 │──▶ encrypt-config.js (环境变量加密)
└─────────────┘     └─────────────────┘
                            │
        ┌───────────────────┼───────────────────┐
        ▼                   ▼                   ▼
   skill-sign.js      skill-encrypt.js    encrypt-config.js
   (签名 .skill-trust)  (AES-256-GCM 加密)  (RSA-OAEP 加密)
        │                   │
        └───────────────────┘
                          ▼
                   构建输出
              ┌─────────────┐
              │ build-sea.js │──▶ 单文件可执行程序
              │build-obfuscated│──▶ 混淆后的 dist/
              └─────────────┘
```

---

## 总结

`scripts/` 是一个完整的**安全构建工具链**——从密钥生成、Skill 签名/加密、环境变量加密，到最终打包为 SEA 可执行程序或混淆分发包，覆盖了 coqi-claw 项目的安全发布全流程。
