# 对话交互审计功能设计方案

## 背景

coqi-claw 首个客户为投行，有严格的安全合规要求。现有安全体系（命令拦截、网络隔离、路径沙箱、DLP 脱敏）覆盖了技术层面的安全控制，但缺少对使用者和 Agent 交互对话的内容审计能力。需要新增审计功能，防止用户通过 AI Agent 执行违规操作。

## 现状分析

### 已有能力

| 安全层 | 机制 | 覆盖范围 |
|--------|------|----------|
| 命令拦截 | `validateCommand()` 71+ 危险模式 | 所有 exec 工具调用 |
| 路径语义验证 | `validateCommandPathArguments()` | exec 工具的文件路径参数 |
| 文件系统沙箱 | `validatePath()` | 14 个文件操作工具 |
| 下载路径限制 | `validateDownloadPath()` | 仅限 output/ 和 temp/ |
| 网络策略 | `validateUrl()` | web_fetch, http_request, download |
| DLP 密钥脱敏 | `redactSecrets()` 12 种模式 | 仅工具输出（进入 LLM 前） |
| 压缩包安全 | ZipSlip + zip bomb 检测 | archive 解压操作 |
| 技能脚本隔离 | workDir 隔离 + 文件快照 | skill 模式 exec |
| npm 安全策略 | 仅允许 install/list/show/config | exec npm 命令 |
| 严格模式 | `EXEC_MODE=strict` 命令白名单 | 可选的全局限制 |
| 日志 | Pino 结构化日志 + 日滚动 | 全项目 43 个模块 |

### 缺失能力

1. **无用户 prompt 内容审查** — 无法阻止用户提出违规问题
2. **DLP 覆盖不对称** — 工具输出有脱敏，但用户输入未经过滤
3. **无专用审计日志** — 安全事件与操作日志混在同一 Pino 管道
4. **无追溯关联** — 安全事件缺少 session_id / user_id
5. **无结构化审计事件 schema** — 各模块日志格式不一致
6. **无身份认证体系** — 仅有 `default` 用户
7. **无合规报告能力** — 无查询/聚合/导出审计数据的功能
8. **无防篡改保护** — 日志文件可被修改或删除
9. **无告警机制** — 无阈值触发或异常通知

---

## 功能开关

审计功能通过环境变量控制，默认关闭：

```bash
ENABLE_AUDIT=true    # 启用合规审计（投行等强合规场景）
ENABLE_AUDIT=false   # 关闭（默认，一般企业无需审计）
```

关闭时，审查层和审计记录完全跳过，零性能开销，行为与当前版本一致。

---

## 审计架构：四层模型

```
用户输入
  │
  ▼ (ENABLE_AUDIT=true 时生效)
┌─────────────────────────────────┐
│ 第1层：内容合规审查（新增）      │
│ - LLM 语义审查（独立轻量模型） │
│ - Phase 1: block 级别         │
└──────────────┬──────────────────┘
               │ 通过
               ▼
┌─────────────────────────────────┐
│ 第2层：现有安全沙箱（已有，增强） │
│ - 命令拦截 / 网络策略 / 路径沙箱 │
│ - DLP 扩展到用户输入             │
│ - 统一关联 session_id           │
└──────────────┬──────────────────┘
               │
               ▼
       Agent 执行引擎
               │
               ▼
┌─────────────────────────────────┐
│ 第3层：审计记录存储（新增）      │
│ - audit_events 表               │
│ - 结构化事件 schema              │
│ - 防篡改 / 分离存储             │
└──────────────┬──────────────────┘
               │
               ▼
┌─────────────────────────────────┐
│ 第4层：合规报告与查询（新增）    │
│ - 按时间/用户/类型查询           │
│ - 合规报告生成                   │
│ - 告警阈值配置                   │
└─────────────────────────────────┘
```

---

## 各层详细设计

### 第1层：Prompt 内容合规审查

**目标**：在用户输入进入 Agent 之前进行前置拦截，阻止违规问题。

#### 1.1 LLM 语义审查

用户输入通过独立的轻量级审查模型进行合规判断：

- 将用户 prompt 发送给独立审查模型，判断是否存在违规意图
- 复用现有 Matcher LLM 架构，使用低成本模型（如 qwen3.5-35b-a3b）
- 返回：`{violation: true/false, category: string, confidence: number, reason: string}`
- 支持跨轮次上下文理解，识别结合上下文的隐含违规

**超时处理**：审查 LLM 超时（如 5s）直接报超时错误，提示用户稍后重试。不做超时回退放行，审计优先级高于可用性。

**违规分类参考**：

| 类别 | 说明 | 响应级别 |
|------|------|----------|
| 市场违规 | 内幕交易、市场操纵、洗钱、老鼠仓 | block |
| 制裁规避 | 制裁名单、规避管制、受制裁实体 | block |
| 客户隐私 | 客户持仓、交易记录、身份信息 | block |
| 系统越权 | 关闭安全、绕过审计、删除日志 | block |
| 敏感策略 | 交易策略、定价模型、风控参数 | warn（Phase 2） |
| 合规问询 | 合规咨询、法规解释 | log（Phase 2） |

#### 1.2 分级响应策略

```
block  → 拒绝执行，返回合规提示，记录审计
warn   → 显示警告但允许继续，记录审计（Phase 2）
log    → 静默记录审计，不影响执行（Phase 2）
```

Phase 1 仅实现 block 级别，warn 和 log 在 Phase 2 引入。

#### 1.3 审查时机

- **Phase 1**：仅用户输入前置审查
- **Phase 2**：评估 Agent 响应后置审查

---

### 第2层：现有安全沙箱增强

保持现有安全控制不变，增加以下增强：

1. **DLP 扩展到用户输入**：合规审查通过后、消息存入 `messages` 表之前，执行 `redactSecrets()` 脱敏。顺序：审查 → 通过 → DLP 脱敏 → 存储（审查 LLM 看原始输入做合规判断，DLP 不干扰意图识别）
2. **安全事件审计记录**：Phase 1 仅审计审查事件（`prompt_blocked`、`prompt_passed`）。现有安全事件（command_blocked 等）的审计记录推迟到后续阶段，改动面太大
3. **统一事件关联**：审计事件携带 `session_id`、`user_id`、`correlation_id`

---

### 第3层：审计记录存储

#### 3.1 数据库表设计

```sql
CREATE TABLE IF NOT EXISTS audit_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id TEXT NOT NULL UNIQUE,          -- UUID 唯一标识
    session_id TEXT NOT NULL,               -- 关联会话
    user_id TEXT NOT NULL,                  -- 操作用户
    correlation_id TEXT,                    -- 请求链路追踪 ID
    event_type TEXT NOT NULL,               -- 事件类型
    severity TEXT NOT NULL DEFAULT 'info',  -- info / warn / critical
    source TEXT NOT NULL,                   -- content_review / security / network / dlp / sandbox
    action TEXT NOT NULL,                   -- block / warn / log / redact
    rule_id TEXT,                           -- 触发规则标识
    detail TEXT NOT NULL,                   -- JSON: 事件详情
    message_id INTEGER,                     -- 关联 messages 表（违规时溯源原文），单轮模式为 NULL
    created_at INTEGER NOT NULL,            -- Unix epoch milliseconds
    FOREIGN KEY (session_id) REFERENCES sessions(id)
    -- 注意：不设 ON DELETE CASCADE，审计记录必须在会话删除后仍可追溯
);

CREATE INDEX idx_audit_events_session ON audit_events(session_id);
CREATE INDEX idx_audit_events_type ON audit_events(event_type);
CREATE INDEX idx_audit_events_severity ON audit_events(severity);
CREATE INDEX idx_audit_events_created ON audit_events(created_at);
CREATE INDEX idx_audit_events_user ON audit_events(user_id);
```

#### 3.2 事件类型枚举

| event_type | 说明 |
|------------|------|
| `prompt_blocked` | 用户输入被内容审查拦截 |
| `prompt_passed` | 用户输入通过内容审查（Phase 1 记录，保障审计完整性） |
| `prompt_review_error` | 审查 LLM 调用失败（超时/解析错误），效果等同 block |
| `prompt_warned` | 用户输入触发警告（Phase 2） |
| `command_blocked` | 危险命令被拦截（Phase 2+） |
| `network_blocked` | 网络请求被策略拦截（Phase 2+） |
| `sandbox_blocked` | 文件系统访问被沙箱拦截（Phase 2+） |
| `dlp_redaction` | DLP 脱敏执行（Phase 2+） |
| `session_access` | 会话访问记录（Phase 2+） |
| `config_change` | 安全配置变更（Phase 2+） |

#### 3.3 防篡改设计

**初期方案**（推荐先实施）：
- 应用层 append-only：不提供 audit_events 的 UPDATE/DELETE API
- 文件系统权限保护 SQLite 文件
- 分离存储：审计库可与业务库分离

**进阶方案**（后续迭代）：
- 哈希链：每条记录 `hash = SHA256(prev_hash + event_data)`
- 定期导出到只读冷存储
- 集成外部 SIEM 系统

---

### 第4层：合规报告与查询

#### 4.1 基本查询能力

- 按时间范围查询审计事件
- 按用户/会话/事件类型过滤
- 违规趋势统计（按日/周/月）
- 单个会话的完整审计追溯

#### 4.2 合规报告模板

- **安全事件汇总报告**：期间内各类事件数量、处理结果
- **用户行为审计报告**：单用户的操作记录和违规情况
- **系统安全状态报告**：安全策略配置、拦截统计

#### 4.3 告警机制

- 单用户短时间内多次被拦截 → 告警
- 特定时间（非工作时间）异常活动 → 告警
- 可通过 webhook/邮件通知合规管理员

---

## 设计决策（已确认）

### 决策 1：审查粒度 → **B: 纯 LLM 语义审查**

选择理由：
- **漏报不可接受**：投行场景下漏报成本远大于误报和延迟成本。关键词匹配无法应对对抗变体（如"根据尚未公开的信息"绕过"内幕交易"关键词）。
- **上下文理解**：LLM 能做跨轮次上下文判断，识别结合上下文的隐含违规意图。
- **规则即模型**：制裁名单更新、新法规无需修改代码或配置。
- **审计可解释**：LLM 返回 `{violation, category, reason}`，reason 字段比正则 pattern 编号对合规部门更有意义。

实施要点：
- 使用 Matcher LLM 架构的轻量低成本模型（如 qwen3.5-35b-a3b 或更小），审查判断不需要强推理能力
- **超时 = 阻断**：审查 LLM 超时直接报超时错误，提示用户稍后重试。不做超时回退放行，审计优先级高于可用性

### 决策 2：审查时机 → **A: 仅用户输入**（Phase 1）

理由：
- 用户输入是最关键的拦截点——人的意图是违规源头
- 工具层已有命令拦截、网络策略、DLP 三重保护，再加语义审查性价比低且增加延迟
- Agent 响应审查后续阶段再评估

### 决策 3：违规处理 → **B: 拒绝 + 提示 + 允许重试**

- 单次违规：拒绝执行 + 给出合规原因提示 + 允许用户修改后重试
- 不做累计计数和锁定机制（简单、可预期）

### 决策 4：身份认证 → **OS 身份透传，无需额外登录**

- 投行环境为 Windows AD 域控管理，用户登录 Windows 即完成身份验证
- Agent 启动时通过 `os.userInfo().username` 自动获取当前用户身份
- 用于审计归因，不增加任何登录流程或密码存储
- Security: 域账号安全由投行 IT 的 AD 策略保障（密码策略、账户生命周期等）

### 决策 5：防篡改级别 → **A: 应用层 append-only**

- `audit_events` 表应用代码仅提供 INSERT，不暴露 UPDATE/DELETE
- 应用层保证写入后不可修改，轻量实用

### 决策 6：规则配置方式 → **A: 配置文件**

- 配置文件 `config/audit-policy.json`，与现有 `config/dlp-policy.json`、`config/network-policy.json` 风格统一
- 支持热重载，权限靠文件系统保护

---

## 审查 LLM 配置（`AUDIT_LLM_*`）

审计审查使用独立的 LLM 配置，与主模型和 Matcher 分离：

```bash
# 审计审查 LLM（不配置则 fallback 到 MATCHER_LLM_*，再 fallback 到主模型）
AUDIT_LLM_PROVIDER=custom
AUDIT_LLM_API_KEY=xxx
AUDIT_LLM_BASE_URL=https://api.xxx.com/v1
AUDIT_LLM_MODEL=qwen3.5-35b-a3b      # 轻量模型，判断不需要强推理
AUDIT_LLM_REQUEST_TIMEOUT=120000     # 审查超时 120s（独立控制）
AUDIT_LLM_TEMPERATURE=0               # 确定性输出
```

Fallback 链：`AUDIT_LLM_*` → `MATCHER_LLM_*` → 主模型配置

在 `src/utils/config.js` 新增 `loadAuditConfig()`，逻辑与 `loadMatcherConfig()` 一致。

---

## `config/audit-policy.json` 完整 schema

```json
{
  "enabled": true,
  "review": {
    "timeout_ms": 120000,
    "temperature": 0,
    "max_context_rounds": 5,
    "max_answer_chars": 500,
    "system_prompt": "你是金融合规审查专家。根据以下违规类别判断用户输入是否违规。\n\n违规类别：\n- 内幕交易：使用非公开信息进行交易建议或预测\n- 市场操纵：散布虚假信息、操纵市场价格\n- 客户隐私：获取、泄露客户个人信息或持仓数据\n- 系统越权：尝试绕过安全控制、删除审计记录\n- 制裁规避：涉及受制裁国家、实体或个人的交易\n\n审查原则：\n1. 结合对话上下文判断用户真实意图\n2. 用户用词不敏感但意图违规 → 判定为违规\n3. 金融专业术语的正常使用 → 不判定为违规\n4. 模糊不清时倾向于保守判断\n\n返回 JSON：\n{\"violation\": true/false, \"category\": \"类别\", \"reason\": \"理由\", \"confidence\": 0.95}",
    "categories": [
      {"name": "内幕交易", "level": "block", "description": "使用非公开信息进行交易建议或预测"},
      {"name": "市场操纵", "level": "block", "description": "散布虚假信息、操纵市场价格"},
      {"name": "客户隐私", "level": "block", "description": "获取、泄露客户个人信息或持仓数据"},
      {"name": "系统越权", "level": "block", "description": "尝试绕过安全控制、删除审计记录"},
      {"name": "制裁规避", "level": "block", "description": "涉及受制裁国家、实体或个人的交易"}
    ],
    "response_format": {
      "violation": "boolean",
      "category": "string",
      "reason": "string",
      "confidence": "number"
    }
  },
  "storage": {
    "record_passed_events": true,
    "passed_severity": "debug"
  }
}
```

- `max_context_rounds`：审查时携带的近期对话轮数
- `max_answer_chars`：每轮 assistant 回答截断长度（避免 token 超限）
- `record_passed_events`：是否记录审查通过事件（Phase 1 建议 true，保障审计完整性）
- `categories`：Phase 1 全部 block，Phase 2 可配置 warn/log

---

## 单轮模式处理

`cli.js` 单轮模式无 SessionManager、无 messages 表，处理方式：

- `session_id`：自动生成一次性 ID，格式 `oneshot_` + UUID
- `message_id`：设为 NULL（单轮不持久化消息，无法关联）
- `user_id`：同样使用 `os.userInfo().username`
- 上下文：`recentContext` 为 null，审查仅基于当前输入

```js
// cli.js 中
if (process.env.ENABLE_AUDIT === 'true') {
    const auditReviewer = initAuditReviewer();  // 独立初始化
    const reviewResult = await auditReviewer.review(userInput, null);
    if (reviewResult.violation) {
        console.log(colors.error(`\n合规审查拦截: ${reviewResult.reason}`));
        process.exit(1);
    }
}
```

---

## 启动检查

`ENABLE_AUDIT=true` 时，启动阶段验证：

1. 审查 LLM 配置可用（`AUDIT_LLM_*` 或 fallback 链至少一个有效）
2. `config/audit-policy.json` 存在且合法
3. 若任一项不满足 → **启动失败，明确报错**（而非运行时崩溃）

```js
// tui/index.js 中，initializeTools() 之后
if (process.env.ENABLE_AUDIT === 'true') {
    const auditLLMConfig = loadAuditConfig();
    if (!auditLLMConfig) {
        console.error(colors.error('ENABLE_AUDIT=true 但审查 LLM 未配置'));
        console.error('请设置 AUDIT_LLM_API_KEY / AUDIT_LLM_BASE_URL / AUDIT_LLM_MODEL');
        process.exit(1);
    }
    // ... 初始化 auditReviewer
}
```

---

## 测试策略

| 测试类型 | 内容 | 方法 |
|----------|------|------|
| 单元测试 | `AuditReviewer.buildSystemPrompt()` | 验证 prompt 正确构建 |
| 单元测试 | `AuditReviewer.parseResponse()` | 覆盖合法 JSON、非法 JSON、空响应、thinking tag 污染 |
| 单元测试 | `AuditReviewer.buildUserPrompt()` | 验证上下文格式化 |
| 单元测试 | 违规/通过/超时三种结果处理 | mock LLMClient |
| 集成测试 | `ENABLE_AUDIT=false` 零开销 | 验证无审查调用 |
| 集成测试 | `ENABLE_AUDIT=true` 完整流程 | mock LLM，验证拦截和通过路径 |
| 集成测试 | 审查 LLM 不可用时的行为 | 验证超时=阻断 |
| 集成测试 | 单轮模式审查 | 验证 oneshot_ session_id |

mock 方式：`AuditReviewer` 构造函数接收 `llmClient`，测试注入 mock 实现即可。

---

## 实施阶段建议

### Phase 1：基础审计（最小可行）
- `ENABLE_AUDIT` 环境变量开关（默认 false）
- 启动时检查：`ENABLE_AUDIT=true` 但审查 LLM 未配置 → 启动报错
- OS 身份透传（`os.userInfo().username`），自动同步到 `users` 表
- audit_events 表（append-only，不级联删除）
- 纯 LLM 语义审查（block 级别，拒绝+提示+可重试）
- 审查通过/拦截/错误均记录审计事件（`prompt_blocked`、`prompt_passed`、`prompt_review_error`）
- DLP 扩展到用户输入（审查通过后、存储前执行脱敏）
- 配置文件 `config/audit-policy.json`
- 单轮模式：自动生成一次性 session_id（`oneshot_` + UUID）
- 测试：单元测试 mock LLM 客户端、集成测试验证流程

### Phase 2：企业级合规
- LLM 审查的 warn / log 分级响应
- 合规报告与查询
- 哈希链防篡改
- 告警通知（webhook/邮件）

### Phase 3：外部集成
- 客户 SSO/LDAP 对接
- 外部 SIEM 集成
- 合规报告自动生成与导出
