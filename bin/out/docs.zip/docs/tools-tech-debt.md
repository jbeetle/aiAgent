# Tools 技术债务记录

> 记录日期: 2026-06-03
> 记录来源: code-review-core-20260602.md Bug #7 修复过程

---

## exec 工具 abort 信号支持（P0 遗留）

### 问题描述

`exec` 工具（`src/tools/exec.js`）是核心工具，执行 shell 命令。当前实现仅在启动时检查一次 `signal.aborted`，未监听执行过程中的 abort 事件。

### 当前实现

`src/tools/exec-common/process.js:20-34`:

```javascript
export function execWithPid(command, options) {
  return new Promise((resolve, reject) => {
    const child = exec(command, options, (error, stdout, stderr) => {
      if (error) {
        error._childPid = child.pid;
        reject(error);
      } else {
        resolve({ stdout, stderr });
      }
    });
    if (options.signal?.aborted) {
      child.kill(KILL_SIGNAL);
    }
  });
}
```

### 问题分析

1. **只在启动时检查**: `if (options.signal?.aborted)` 只检查一次，执行过程中用户取消不会被处理
2. **未监听 abort 事件**: 需要 `signal.addEventListener('abort', ...)`
3. **子进程清理不完整**: `child.kill()` 只杀当前进程，不杀子进程（如 `npm install` 会 spawn 多个子进程）
4. **跨平台兼容性**: `SIGKILL` 在 Windows 上行为不同
5. **竞态条件**: abort 后 `exec` 回调会收到 error，需要区分是用户取消还是其他错误

### 修复方案（草案）

```javascript
export function execWithPid(command, options) {
  return new Promise((resolve, reject) => {
    const child = exec(command, options, (error, stdout, stderr) => {
      if (error) {
        error._childPid = child.pid;
        reject(error);
      } else {
        resolve({ stdout, stderr });
      }
    });
    
    // 启动时检查
    if (options.signal?.aborted) {
      child.kill(KILL_SIGNAL);
    }
    
    // 监听执行过程中的 abort
    if (options.signal) {
      options.signal.addEventListener('abort', () => {
        child.kill(KILL_SIGNAL);
        // 延迟清理子进程（给 SIGTERM 一点时间）
        setTimeout(() => {
          if (!child.killed) {
            child.kill('SIGKILL');
          }
        }, 5000);
      }, { once: true });
    }
  });
}
```

### 注意事项

- **Windows 兼容性**: `SIGKILL` 在 Windows 上可能行为不同，需要测试
- **子进程清理**: 需要调用 `killProcessTree(child.pid)` 递归清理子进程
- **错误处理**: abort 后 `exec` 回调会收到 error，需要区分是用户取消还是其他错误
- **安全影响**: exec 工具涉及 shell 命令执行，修改需谨慎

### 建议

1. 先写一个测试用例验证当前行为
2. 小范围修改，只添加 abort 监听
3. 验证 Windows 和 Linux 行为一致
4. 考虑是否需要 killProcessTree 递归清理

### 相关文件

- `src/tools/exec-common/process.js` — execWithPid 实现
- `src/tools/exec-common/index.js` — runCommand 入口
- `src/tools/exec.js` — exec 工具入口
- `src/core/agent-executor.js` — 调用方

### 优先级

**P0** — 用户取消慢速命令后 UI 冻结，影响体验

### 关联 Bug

- code-review-core-20260602.md Bug #7: 中止信号传递给工具但多数工具不消费
