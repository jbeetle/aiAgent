# Config 模块技术债

## 1. `dotenv.config({ override: true })` 覆盖容器注入的环境变量

> 状态：已知风险，暂不处理 | 优先级：P3 | 记录日期：2026-07-15

### 背景

`src/utils/config/env.js` 在模块加载时调用 `dotenv.config({ path: envPath, override: true })`。`override: true` 意味着 `.env` 文件中的值会覆盖 `process.env` 中已有的同名变量。

### 风险

在 Docker/K8s 等容器化部署场景中，运维通常通过 `-e`、`envFrom`、ConfigMap/Secret 等方式注入环境变量。`override: true` 会导致 `.env` 文件中的值优先于容器注入的配置，违背 12-Factor App 第三条（"Config: Store config in the environment"）——环境变量应优先于 `.env` 文件。

### 为什么保留 `override: true`

当前项目以本地桌面部署为主（Windows 单机），`.env` 是配置的唯一真实来源。用户修改 `.env` 后重启，期望新值生效。如果去掉 `override`，`dotenv` 默认不覆盖已有变量，在以下场景会出问题：

- Windows 系统环境变量中残留旧值（用户曾通过系统设置配置过）
- 多次启动时 `process.env` 中已有上次 `dotenv` 注入的值（虽然 Node.js 进程重启后 env 会重置，但某些嵌入场景如 Electron/tray 可能复用进程）

### 建议方案

#### 方案 A：环境感知的 override 策略（推荐）

检测是否运行在容器环境中，动态决定 override 行为：

```js
const isContainer = fs.existsSync('/.dockerenv')
  || fs.existsSync('/run/.containerenv')
  || process.env.KUBERNETES_SERVICE_HOST !== undefined;

dotenv.config({ path: envPath, override: !isContainer });
```

优点：本地桌面保持现有行为，容器环境遵循 12-Factor。
缺点：容器检测可能不完整（如自定义镜像可能删除 `/.dockerenv`）。

#### 方案 B：新增 `DOTENV_OVERRIDE` 环境变量

```js
const override = process.env.DOTENV_OVERRIDE !== 'false';
dotenv.config({ path: envPath, override });
```

优点：显式可控，运维可按需关闭。
缺点：增加一个配置项，且该配置项本身也依赖环境变量（鸡生蛋问题——需在 dotenv 加载前设置）。

#### 方案 C：去掉 override，改用 `--set-KEY=VALUE` CLI 参数覆盖

去掉 `override: true`，需要覆盖 `.env` 值时通过 CLI 参数传入。

优点：语义清晰，符合 12-Factor。
缺点：改变现有用户习惯，CLI 参数不适合大量覆盖。

### 决策

暂不处理。当前部署场景以本地桌面为主，`override: true` 行为符合用户预期。未来若正式支持容器化部署，应优先实施方案 A。

### 相关文件

- `src/utils/config/env.js`

---

## 2. `loadConfig()` 被 ESM 模块级副作用过早调用

> 状态：已缓解 | 优先级：P2 | 修复日期：2026-07-17

### 背景

`loadConfig()` 有缓存机制（`cachedConfig`），首次调用后直接返回缓存对象。但 `fast-json.js` 在 ESM import 阶段（模块级代码）调用了 `loadConfig()`，此时 `.env.runtime` 尚未被 `BootstrapManager.loadEnvironment()` 加载，导致缓存了 `.env` 的过期值。后续所有 `loadConfig()` 调用都返回这个过期缓存，`.env.runtime` 的覆盖值（如 `LLM_BASE_URL`、`LLM_MODEL`）无法生效。

### 调用链

```
fast-json.js:181  ensureInitialized()    ← 模块级 fire-and-forget
  → initFastJSON() → loadConfig()        ← 缓存 .env 的值（.env.runtime 尚未加载）
```

`logger.js` 曾有相同问题（`pino({ level: getLevel() })` → `loadConfig().logLevel`），已通过 `markConfigReady()` 机制修复。

### 缓解措施

1. **`BootstrapManager.loadConfiguration()`** 中先调用 `clearConfigCache()` 再调用 `loadConfig()`，清除过早缓存后重新读取 `.env.runtime` 覆盖后的 `process.env`。
2. **`logger.js`** 的 `getLevel()` 引入 `configReady` 标志：在 `loadConfig()` 正式就绪前，仅从 `process.env.LOG_LEVEL` 读取，不触发 `loadConfig()`。
3. **入口点调整**：`server.js` 和 `tui/index.js` 将 `loadConfiguration()` 移到 `SessionManager.initialize()` 之前，确保所有依赖配置的组件获得正确的值。

### 残留风险

`fast-json.js` 仍在模块级调用 `loadConfig()`，虽然 `clearConfigCache()` 会修复缓存，但模块级调用本身不理想。更彻底的修复应让 `fast-json.js` 也采用类似 `logger.js` 的延迟初始化策略。

### 相关文件

- `src/utils/config/index.js` — `loadConfig()` / `clearConfigCache()`
- `src/utils/fast-json.js` — 模块级 `ensureInitialized()` 调用
- `src/utils/logger.js` — `markConfigReady()` / `getLevel()` 延迟配置
- `src/bootstrap/manager.js` — `loadConfiguration()` 中 `clearConfigCache()`
- `src/gateway/server.js` — 调整初始化顺序
- `src/tui/index.js` — 调整初始化顺序
