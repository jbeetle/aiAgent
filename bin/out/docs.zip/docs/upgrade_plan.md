# 升级计划：支持多轮会话的通用AI智能体助手

## 背景与目标

将现有的 coqi-claw CLI 工具升级为支持多轮会话的通用AI智能体助手，同时保持向后兼容和轻量级架构。

**当前限制：**
- 仅支持单次执行的CLI模式
- 会话历史仅存于内存中（80KB截断限制）
- 每次CLI调用都是独立的，无法恢复之前的对话
- 无服务端能力，无法作为服务部署

**升级目标：**
- **入口分离**：`cli.js` 保持单轮任务执行，`chat.js` 提供多轮会话能力
- 支持会话持久化（SQLite存储），仅多轮模式需要
- 保持轻量级，会话依赖可选安装
- 为未来HTTP服务模式预留架构空间

---

## 架构设计

### 入口分离架构

```
┌─────────────────────────────────────────────────────────────────┐
│                          入口层 (分离设计)                        │
├─────────────────────────────┬───────────────────────────────────┤
│     单轮任务模式 (cli.js)     │      多轮会话模式 (chat.js)        │
│  - 执行单次任务立即退出        │  - REPL交互式界面                  │
│  - 无会话存储依赖              │  - 自动保存会话历史                 │
│  - 完全向后兼容               │  - 支持 /new /list /switch 命令    │
│  npm start "任务"            │  npm run chat                     │
└───────────┬─────────────────┴──────────────┬────────────────────┘
            │                                │
            │   ┌────────────────────────────┘
            │   │
            ▼   ▼
┌─────────────────────────────────────────────────────────────────┐
│                     核心Agent引擎 (core/)                        │
├─────────────────────────────────────────────────────────────────┤
│  Agent类 (agent.js)                                             │
│  - run(userInput) ───────────────────── 单轮模式专用 (保持兼容)    │
│  - runWithHistory(userInput, history) ─ 多轮模式专用             │
│  - *runStream(userInput, history) ───── 多轮模式流式输出(可选)   │
└──────────────────────────┬──────────────────────────────────────┘
                           │
       ┌───────────────────┼───────────────────┐
       ▼                   ▼                   ▼
┌──────────────┐   ┌──────────────┐   ┌──────────────┐
│SkillManager  │   │ LLMClient    │   │   工具注册表   │
│(skills/)     │   │ (core/llm.js)│   │(tools/*.js)  │
└──────────────┘   └──────────────┘   └──────────────┘
                           │
            ┌──────────────┴──────────────┐
            │                             │
            ▼                             ▼
┌─────────────────────────┐    ┌─────────────────────────────┐
│  SessionAgent包装器      │    │       会话存储层 (SQLite)    │
│(core/session-agent.js)  │◄───┤  (sessions/)                │
│ - 加载/保存会话历史      │    │ - manager.js                │
│ - 管理会话生命周期       │    │ - 自动检测/创建数据库文件    │
│ - 智能加载算法          │    │ - 智能会话选择策略          │
└─────────────────────────┘    │                             │
                               │ cli.js不依赖此层            │
                               └─────────────────────────────┘
```

### 职责分离

| 组件 | 单轮模式 (cli.js) | 多轮模式 (chat.js) |
|------|------------------|-------------------|
| **Agent类** | ✅ `run()` 直接调用 | ✅ `runWithHistory()` 注入历史 |
| **会话存储** | ❌ 不依赖 | ✅ SQLite持久化 |
| **消息历史** | ❌ 仅当前任务 | ✅ 自动加载/保存 |
| **交互方式** | ❌ 命令行参数 | ✅ REPL交互 |
| **技能系统** | ✅ 共享 | ✅ 共享 |
| **工具系统** | ✅ 共享 | ✅ 共享 |

---

## 技术选型决策

### chat.js 交互技术栈（已确定）

| 库 | 用途 | 体积 | 理由 |
|----|------|------|------|
| **@clack/prompts** | 交互框架 | ~30KB | 现代化一问一答体验，流式输出友好 |
| **picocolors** | 终端颜色 | ~5KB | 轻量、标准、与 @clack 完美配合 |
| **better-sqlite3** | 数据库存储 | ~5MB | 同步API，性能优异 |

**选型理由：**
- 控制台应保持简洁（一问一答），复杂UI留给Web
- @clack/prompts 提供清晰的输入/输出分区、加载动画、指令补全
- better-sqlite3 同步 API 避免异步嵌套，代码更简洁
- 渲染效果通过 Markdown + 颜色实现，不依赖重型UI框架

---

## 核心实现方案

### 1. 会话存储层设计（SQLite 唯一）

**文件位置：** 默认 `./data/sessions.db`，可配置

**启动检测逻辑：**
```javascript
// sessions/manager.js
export class SessionManager {
  constructor(dbPath = './data/sessions.db') {
    this.dbPath = dbPath;
    this.db = null;
  }

  async initialize() {
    const dbExists = fs.existsSync(this.dbPath);

    // 确保目录存在
    await fs.mkdir(path.dirname(this.dbPath), { recursive: true });

    // 连接数据库（不存在会自动创建）
    this.db = new Database(this.dbPath);

    if (!dbExists) {
      console.log(pc.yellow('首次使用，创建会话数据库...'));
      await this.createSchema();
    }

    // 运行迁移（如果有）
    await this.migrate();
  }

  async createSchema() {
    this.db.exec(`
      CREATE TABLE sessions (
        id TEXT PRIMARY KEY,
        title TEXT,
        status TEXT DEFAULT 'active',
        model TEXT,
        created_at INTEGER NOT NULL,
        updated_at INTEGER NOT NULL,
        message_count INTEGER DEFAULT 0,
        total_tokens INTEGER DEFAULT 0,
        metadata TEXT
      );

      CREATE INDEX idx_sessions_updated ON sessions(updated_at);
      CREATE INDEX idx_sessions_status ON sessions(status);

      CREATE TABLE messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id TEXT NOT NULL,
        role TEXT NOT NULL,
        content TEXT,
        tool_calls TEXT,
        tool_call_id TEXT,
        tokens INTEGER DEFAULT 0,
        created_at INTEGER NOT NULL,
        FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE
      );

      CREATE INDEX idx_messages_session ON messages(session_id);
      CREATE INDEX idx_messages_created ON messages(created_at);
    `);
  }
}
```

### 2. 智能会话加载算法

**场景：** 用户启动 chat.js 时，自动决定加载哪个会话

```javascript
// sessions/loader.js
export class SessionLoader {
  constructor(sessionManager) {
    this.manager = sessionManager;
  }

  /**
   * 智能加载最佳会话
   * 策略优先级：
   * 1. 最近活跃且有未完成任务（基于消息状态）
   * 2. 最近活跃且消息数适中（5-20条，有上下文但不长）
   * 3. 最近创建的活跃会话
   * 4. 无合适会话则返回 null（创建新会话）
   */
  async loadBestSession() {
    const sessions = await this.manager.listSessions({
      status: 'active',
      limit: 10
    });

    if (sessions.length === 0) {
      return null;
    }

    // 计算每个会话的得分
    const scored = sessions.map(s => ({
      session: s,
      score: this.calculateScore(s)
    }));

    // 按得分排序
    scored.sort((a, b) => b.score - a.score);

    return scored[0].session;
  }

  calculateScore(session) {
    const now = Date.now();
    const hoursSinceUpdate = (now - session.updatedAt) / (1000 * 60 * 60);

    let score = 0;

    // 时间衰减：越近越好
    if (hoursSinceUpdate < 1) score += 100;
    else if (hoursSinceUpdate < 4) score += 80;
    else if (hoursSinceUpdate < 24) score += 60;
    else if (hoursSinceUpdate < 72) score += 40;
    else score += 20;

    // 消息数偏好：5-20条最佳（有上下文但不过长）
    const msgCount = session.messageCount;
    if (msgCount >= 5 && msgCount <= 20) score += 30;
    else if (msgCount > 0 && msgCount < 5) score += 20;
    else if (msgCount > 20 && msgCount < 50) score += 10;

    // 有自定义标题的会话（说明用户重视）
    if (session.title && !session.title.startsWith('会话 ')) score += 15;

    return score;
  }

  /**
   * 启动时交互选择
   * 如果有高分会话直接加载，否则让用户选择
   */
  async selectOnStartup() {
    const best = await this.loadBestSession();

    // 如果最佳会话分数很高（最近1小时内活跃），直接加载
    if (best && this.calculateScore(best) >= 120) {
      console.log(pc.gray(`恢复会话: ${best.title || '未命名'} (${best.messageCount}条消息)`));
      return best.id;
    }

    // 否则显示选择菜单
    return this.showSelectionMenu();
  }

  async showSelectionMenu() {
    const sessions = await this.manager.listSessions({ limit: 5 });

    const choices = [
      { value: 'new', label: '🆕 创建新会话' },
      ...sessions.map(s => ({
        value: s.id,
        label: `${s.title || '未命名'} (${s.messageCount}条, ${this.formatTime(s.updatedAt)})`
      }))
    ];

    const selected = await p.select({
      message: '选择会话或创建新会话',
      options: choices
    });

    return selected === 'new' ? null : selected;
  }

  formatTime(timestamp) {
    const hours = (Date.now() - timestamp) / (1000 * 60 * 60);
    if (hours < 1) return '刚刚';
    if (hours < 24) return `${Math.floor(hours)}小时前`;
    return `${Math.floor(hours / 24)}天前`;
  }
}
```

**启动流程：**
```
npm run chat

↓
检测 ./data/sessions.db 是否存在
├─ 不存在 → 创建数据库 → 创建新会话 → 进入对话
└─ 存在 → 查询活跃会话
         ↓
    是否有高相关性会话？
    ├─ 是（1小时内活跃）→ 自动恢复 → "已恢复 'Excel分析' 会话"
    └─ 否 → 显示选择菜单
             ├─ 创建新会话
             ├─ 会话A (12条, 2小时前)
             ├─ 会话B (3条, 昨天)
             └─ ...
```

### 3. 会话上下文管理算法

**问题：** 单会话消息过多时如何截断，保留最有效的上下文

```javascript
// sessions/context-manager.js
export class ContextManager {
  constructor(options = {}) {
    this.maxTokens = options.maxTokens || 4000;
    this.maxMessages = options.maxMessages || 20;
    this.preserveFirst = options.preserveFirst || 1; // 保留首条用户意图
  }

  /**
   * 智能截断消息历史
   * 策略：保留最近消息 + 关键早期消息
   */
  async buildContext(sessionManager, sessionId, userInput) {
    // 获取全部消息（按时间倒序，方便截断）
    const allMessages = await sessionManager.getMessages(sessionId, {
      order: 'desc'
    });

    if (allMessages.length <= this.maxMessages) {
      return this.formatMessages(allMessages.reverse());
    }

    // 需要截断
    const recentMessages = allMessages.slice(0, this.maxMessages - this.preserveFirst);
    const preservedMessages = [];

    // 保留首条用户消息（建立初始上下文）
    const firstUserMsg = allMessages.find(m => m.role === 'user');
    if (firstUserMsg && !recentMessages.includes(firstUserMsg)) {
      preservedMessages.push(firstUserMsg);
      // 也保留AI的首条回复（任务目标确认）
      const firstIdx = allMessages.indexOf(firstUserMsg);
      if (firstIdx > 0 && allMessages[firstIdx - 1]?.role === 'assistant') {
        preservedMessages.push(allMessages[firstIdx - 1]);
      }
    }

    // 合并：保留的早期消息 + 最近消息
    const selected = [...preservedMessages, ...recentMessages];
    selected.sort((a, b) => a.createdAt - b.createdAt);

    return this.formatMessages(selected);
  }

  formatMessages(messages) {
    return messages.map(m => ({
      role: m.role,
      content: m.content
    }));
  }
}
```

### 4. chat.js 主程序流程

```javascript
#!/usr/bin/env node
import * as p from '@clack/prompts';
import pc from 'picocolors';
import { SessionManager } from './sessions/manager.js';
import { SessionLoader } from './sessions/loader.js';
import { ContextManager } from './sessions/context-manager.js';
import { SessionAgent } from './core/session-agent.js';
// ... 其他导入

async function main() {
  p.intro(pc.cyan('coqi-claw Chat'));

  // 1. 初始化（自动检测/创建数据库）
  const sessionManager = new SessionManager();
  await sessionManager.initialize();

  // 2. 智能选择会话
  const loader = new SessionLoader(sessionManager);
  const sessionId = await loader.selectOnStartup();

  // 3. 创建或加载会话
  let currentSessionId;
  if (sessionId) {
    currentSessionId = sessionId;
    console.log(pc.gray(`已加载会话`));
  } else {
    const session = await sessionManager.createSession();
    currentSessionId = session.id;
    console.log(pc.gray(`已创建新会话: ${session.id.slice(0, 8)}...`));
  }

  // 4. 初始化 Agent 和上下文管理器
  const agent = new Agent(skillManager, llmClient);
  const contextManager = new ContextManager();

  // 5. REPL 循环
  while (true) {
    const input = await p.text({ message: '>' });
    if (p.isCancel(input) || input === '/exit') break;

    // 命令处理...

    // 6. 智能构建上下文并执行
    const spinner = p.spinner();
    spinner.start('思考中...');

    const history = await contextManager.buildContext(
      sessionManager, currentSessionId, input
    );

    const response = await agent.runWithHistory(input, history);

    // 7. 保存消息
    await sessionManager.addMessage(currentSessionId, 'user', input);
    await sessionManager.addMessage(currentSessionId, 'assistant', response);

    spinner.stop();
    console.log(formatResponse(response));
  }

  p.outro(pc.green('再见！'));
}
```

### 5. 个性化助手系统

**设计目标：** 让助手有身份（名称、性格、专业范围），并记住用户名字，实现更自然的对话体验。

**数据库表扩展：**

```sql
-- 用户表（支持多用户，目前默认单用户）
CREATE TABLE users (
    id TEXT PRIMARY KEY DEFAULT 'default',
    name TEXT DEFAULT NULL,                  -- 用户名字：张三
    role TEXT DEFAULT NULL,                  -- 用户角色：软件工程师
    preferences TEXT DEFAULT NULL,           -- JSON: 偏好设置
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL
);

-- 助手配置表（支持多助手角色切换）
CREATE TABLE assistants (
    id TEXT PRIMARY KEY,                     -- 助手ID: default, coder, analyst
    name TEXT NOT NULL,                      -- 助手名称：CoQi
    personality TEXT DEFAULT NULL,           -- 性格描述：严谨、幽默、耐心
    expertise TEXT DEFAULT NULL,             -- 专业范围：数据分析、代码编写
    system_prompt_template TEXT DEFAULT NULL,-- 系统提示词模板
    is_default BOOLEAN DEFAULT 0,
    created_at INTEGER NOT NULL
);

-- 会话表扩展外键
ALTER TABLE sessions ADD COLUMN user_id TEXT DEFAULT 'default';
ALTER TABLE sessions ADD COLUMN assistant_id TEXT DEFAULT 'default';
```

**预设助手角色：**

```javascript
const DEFAULT_ASSISTANTS = [
  {
    id: 'default',
    name: 'CoQi',
    personality: '专业、高效、注重实用性',
    expertise: '通用任务处理、文件操作、数据分析、代码编写',
    is_default: true
  },
  {
    id: 'coder',
    name: 'CodeMaster',
    personality: '严谨、注重代码质量、善于解释复杂概念',
    expertise: '代码审查、重构建议、算法优化、技术方案设计'
  },
  {
    id: 'analyst',
    name: 'DataWhiz',
    personality: '细致、数据敏感、善于发现规律',
    expertise: '数据清洗、统计分析、可视化建议、报告生成'
  },
  {
    id: 'writer',
    name: 'WordSmith',
    personality: '富有创意、表达流畅、注重逻辑结构',
    expertise: '文案撰写、文档整理、翻译润色、内容总结'
  }
];
```

**动态系统提示词生成：**

```javascript
// core/prompt-builder.js
export function buildPersonalizedPrompt(basePrompt, options) {
  const { user, assistant, skills } = options;

  const sections = [
    // 1. 基础身份定位
    `你是 ${assistant.name}，${assistant.personality || '一位专业的AI助手'}。`,

    // 2. 专业能力
    assistant.expertise ? `你擅长：${assistant.expertise}。` : '',

    // 3. 用户信息（如果有）
    user.name ? `你正在与 ${user.name}${user.role ? `（${user.role}）` : ''} 对话。` : '',

    // 4. 用户偏好（如果有）
    user.preferences?.communicationStyle
      ? `请以 ${user.preferences.communicationStyle} 的风格交流。`
      : '',

    // 5. 原始系统提示（技能、工具等）
    basePrompt
  ];

  return sections.filter(Boolean).join('\n\n');
}
```

**首次启动配置流程：**

```javascript
// chat.js 启动时检测
async function setupProfile(sessionManager) {
  let user = sessionManager.getUser('default');

  if (!user?.name) {
    console.log(pc.cyan('👋 首次使用，让我们简单设置一下：\n'));

    const name = await p.text({
      message: '请问怎么称呼您？',
      placeholder: '您的名字'
    });

    const role = await p.text({
      message: '您的职业/角色（可选）',
      placeholder: '如：软件工程师、产品经理'
    });

    // 选择助手
    const assistants = sessionManager.listAssistants();
    const assistantId = await p.select({
      message: '选择助手风格',
      options: assistants.map(a => ({
        value: a.id,
        label: `${a.name}: ${a.expertise.slice(0, 30)}...`
      }))
    });

    // 保存配置
    sessionManager.updateUser('default', { name, role, assistant_id: assistantId });

    const assistant = assistants.find(a => a.id === assistantId);
    console.log(pc.green(`\n✓ 已保存配置！${name}，我是${assistant.name}，很高兴为您服务！\n`));
  }

  return { user, assistant: sessionManager.getAssistant(user.assistant_id) };
}
```

**使用示例：**

```
$ npm run chat

┌  CoQi Chat
│
◇  请问怎么称呼您？
│  张三
│
◇  您的职业/角色（可选）
│  数据分析师
│
◇  选择助手风格
│  ● CoQi: 通用任务处理、文件操作、数据分析...
│  ○ CodeMaster: 代码审查、重构建议、算法优化...
│  ○ DataWhiz: 数据清洗、统计分析、可视化建议...
│
│  ✓ 已保存配置！张三，我是CoQi，很高兴为您服务！
│
> 帮我分析这个销售数据

[CoQi会根据张三的数据分析师身份，直接给出专业的分析思路]
```

**扩展命令：**

```
> /whoami              # 显示当前用户和助手信息
> /setname 李四        # 修改名字
> /setrole PM          # 修改角色
> /switch-assistant    # 切换助手风格
> /profile             # 查看完整配置
```

---

## 实施计划

### 阶段1：核心重构与会话存储（1-2周）

**任务清单：**
1. **重构 Agent 类**
   - 提取 `_executeLoop()` 方法
   - 实现 `runWithHistory()` 方法
   - 确保 `run()` 方法行为完全不变

2. **实现 SQLite 存储层**
   - SessionManager：自动检测/创建数据库
   - 数据表设计和创建
   - CRUD 操作实现

3. **实现智能会话加载**
   - SessionLoader 算法
   - 启动交互选择

4. **实现上下文管理**
   - ContextManager 截断策略

5. **创建 chat.js 基础入口**
   - @clack/prompts 集成
   - 基础命令（/new, /exit）

**关键文件：**
- `src/core/agent.js`（修改）
- `src/sessions/manager.js`（新增）
- `src/sessions/loader.js`（新增）
- `src/sessions/context-manager.js`（新增）
- `src/core/session-agent.js`（新增）
- `src/chat.js`（新增）

**新增依赖：**
```json
{
  "dependencies": {
    "@clack/prompts": "^0.7.0",
    "picocolors": "^1.0.0",
    "better-sqlite3": "^9.4.0",
    "uuid": "^9.0.0"
  }
}
```

### 阶段2：交互功能完善（1周）

1. 完整命令集（/list, /switch, /rename, /clear, /save）
2. 响应格式化（Markdown、代码高亮）
3. 会话标题自动生成（基于首条消息）
4. 错误处理和恢复

### 阶段3：高级功能（可选）

1. 流式输出支持
2. 会话导出/导入
3. 自动归档策略

---

## 文件变更清单

**新增文件（8个）：**
- `src/chat.js` - 多轮会话入口
- `src/core/session-agent.js` - 会话感知Agent包装器
- `src/core/prompt-builder.js` - 动态个性化提示词生成
- `src/sessions/manager.js` - SQLite会话管理
- `src/sessions/loader.js` - 智能会话加载算法
- `src/sessions/context-manager.js` - 上下文截断策略
- `src/chat/commands.js` - 命令处理器
- `src/chat/formatter.js` - 响应格式化

**修改文件（3个）：**
- `src/core/agent.js` - 重构支持两种模式
- `src/utils/config.js` - 添加会话配置
- `package.json` - 添加依赖

---

## 技术决策总结

| 决策项 | 选定方案 | 理由 |
|--------|---------|------|
| 存储方案 | SQLite 唯一 | 简化逻辑，better-sqlite3同步API |
| 会话加载 | 智能算法 + 交互选择 | 最近活跃优先，兼顾用户体验 |
| 上下文管理 | 智能截断（保留首尾） | 平衡上下文完整性和Token限制 |
| 数据库位置 | `./data/sessions.db` | 标准位置，易于备份 |
| 自动创建 | 首次启动自动初始化 | 零配置体验 |
| 个性化系统 | 用户配置 + 助手角色 | 记住用户身份，助手有专业定位 |
| 助手角色 | 4种预设（可扩展） | 覆盖常见场景：通用、编程、数据、写作 |
| 提示词生成 | 动态拼接 | 根据用户和助手属性实时构建系统提示 |

---

*最后更新：2026-03-27*
*版本：v2.3 - 完整方案（智能会话 + 个性化助手）*
