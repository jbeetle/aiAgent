# DLP 脱敏破坏 JSON 合法性 —— Bug 修复交接文档

> **用途**：本文档总结一次线上崩溃的根因分析与修复方案，供其他存在同类问题
> （DLP/数据脱敏 + JSON 解析）的项目直接参考。已修复版本：coqi-claw（2026-08-05）。

## 1. 问题现象

线上部署（SEA 打包的 `server.jsc`，Tauri 桌面壳内嵌）在对话第 5 轮迭代时崩溃：

```
Unhandled error. ({ error: SyntaxError: Bad escaped character in JSON at position 75 (line 1 column 76)
  at JSON.parse (<anonymous>)
  at AgentExecutor.execute (...server.jsc:1:8966210)
  at async Agent2.runWithHistory (...)
  at async handleChat (...), iteration: 5 })
```

特征信号：

- 错误类型是 `SyntaxError: Bad escaped character in JSON`（V8 对 `\` + 非法转义字符的报错），
  偶发 `Unterminated string in JSON` / `Unexpected end of JSON input`；
- 发生在 Agent 迭代循环中，通常 ≥2 轮（工具调用后）；
- 崩溃点附近的代码是 `JSON.parse(...)`，且**入参经过某种"脱敏/替换/过滤"处理**。

## 2. 根因

崩溃代码模式（两处相同）：

```javascript
// ❌ 错误写法：脱敏正则直接跑在 JSON 转义文本上
const redactedArgs = JSON.parse(
  redactSecrets(JSON.stringify(tc.arguments || {}))
);
```

`JSON.stringify` 输出的 JSON 文本中，字符串内容含转义序列（`\n`、`\\`、`\"`、`\uXXXX` 等）。
**脱敏正则（带 `\b` 词边界、贪婪捕获、尾部可选引号）作用于这段文本时，会破坏转义序列**，
产生三种失效模式：

### 2.1 转义拆分 → `Bad escaped character`（本次线上报错）

敏感值紧跟在转义序列之后时，正则开头的 `\b` 词边界会匹配到 `\`（非单词字符）与
后面的字母/数字（单词字符）之间，导致匹配从转义序列"中间"开始：

```
输入（stringify 后）:  {"cmd":"echo secret\nuser@corp.com"}
email 模式匹配起点:   \b 匹配于 "\" 与 "u" 之间 → 从 "user@corp.com" 开始匹配
替换后:               {"cmd":"echo secret\[REDACTED:email]"}
                                     ↑ 孤立反斜杠 + "[" → Bad escaped character
```

同样的机制适用于 `\\`（双反斜杠后的单词）、`\uXXXX` 后的字母数字等一切转义序列。
复现条件：同一字符串内**先出现一个触发脱敏的关键词**（如 `secret`/`password`，触发提前退出
检测通过），**紧接着是换行/转义后的敏感值**（邮箱、手机号、IP、卡号等）。

最小复现（Node.js + 本项目 DLP 配置）：

```javascript
const json = JSON.stringify({ cmd: 'echo secret\nuser@corp.com' });
JSON.parse(redactSecrets(json));
// SyntaxError: Bad escaped character in JSON at position 20
```

### 2.2 吞掉闭合引号 → `Unterminated string` / 结构损坏

形如 `(?<=key\s*[=:]\s*['"]?)([^\s'"]{6,128})['"]?` 的模式，尾部 `['"]?` 会消费掉
JSON 字符串的**闭合引号**：

```
输入:     {"token":"secret123"}
匹配:     secret123"（含闭合引号）
替换后:   {"token":"[REDACTED:generic_api_token}   ← 字符串未闭合
```

最小复现：`JSON.parse(redactSecrets(JSON.stringify({ token: 'secret123' })))`。

### 2.3 键名被误脱敏 → 语义损坏（不崩溃但错误）

`\b[A-Z]{6}[A-Z0-9]{2}...` 类模式（如证券标识符 CUSIP/SWIFT 检测）在 `/gi` 标志下会把
键名本身（`PASSWORD`、`password1`、`somepassword` 等）当敏感码替换，键名丢失或语义错乱。

## 3. 修复方案

**核心原则：脱敏正则只作用于"纯文本字符串值"，绝不作用于 JSON 转义文本。
JSON 的转义统一交给 `JSON.stringify` 负责。**

做法：深度遍历参数对象，把每个字符串值放进 `key: value` 的纯文本里脱敏
（保留键名上下文，让 `password=` / `token:"` 这类依赖前缀的模式仍然生效），
然后取回脱敏后的值。由于不再有 JSON 转义参与，三种失效模式全部消除。

```javascript
import { redactSecrets } from "../security/dlp.js";

/**
 * 脱敏单个字符串参数值（带键名上下文）。
 * 重建 "key: value" 纯文本（不含 JSON 转义）再脱敏：password/token 类
 * 模式依赖在文本中看到 "password="/"token":" 前缀，键名不可缺失。
 * 所有模式的匹配部分都不包含分隔符 ": "（lookbehind 不消耗文本），
 * 因此取第一个分隔符之后的内容即为脱敏后的值；若键名本身被 \b 类模式
 * 误匹配（如 PASSWORD 命中 swift_bic），该部分也会被丢弃，不影响取值。
 */
function redactValueWithKey(key, value) {
  const text = `${key}: ${value}`;
  const redacted = redactSecrets(text);
  const sep = redacted.indexOf(": ");
  if (sep === -1) return value; // 理论不可达，防御
  return redacted.substring(sep + 2);
}

/**
 * 对工具参数做值级 DLP 脱敏。
 * 不能直接在 JSON.stringify 后的转义文本上跑脱敏正则：转义序列（\n、\\、\" 等）
 * 会被正则的 \b 边界或贪婪捕获拆开，留下孤立反斜杠导致 JSON.parse 报
 * "Bad escaped character"；password/token 类模式尾部的 ['"]? 还会吞掉
 * JSON 字符串的闭合引号。改为深度遍历参数值、仅对字符串值脱敏，
 * 由调用方 JSON.stringify 统一转义，保证 JSON 永远合法。
 */
function redactArgsDeep(args, key = null) {
  if (typeof args === "string") {
    return key !== null ? redactValueWithKey(key, args) : redactSecrets(args);
  }
  if (Array.isArray(args)) {
    return args.map((item) => redactArgsDeep(item, key));
  }
  if (args && typeof args === "object") {
    const out = {};
    for (const [k, value] of Object.entries(args)) {
      out[k] = redactArgsDeep(value, k);
    }
    return out;
  }
  return args;
}
```

调用点替换（原两处 `JSON.parse(redactSecrets(JSON.stringify(...)))`）：

```javascript
// ✅ 修复后：直接拿对象，不经过 stringify→redact→parse
const redactedArgs = redactArgsDeep(tc.arguments || {});
this.emit("tool_call", { id: tc.id, name: tc.name, arguments: redactedArgs });
```

## 4. 修复效果验证

| 输入参数 | 旧代码 | 新代码 |
|----------|--------|--------|
| `{cmd: 'echo secret\nuser@corp.com'}` | ❌ Bad escaped character | ✅ `[REDACTED:email]`，JSON 合法 |
| `{token: 'secret123'}` | ❌ Unterminated string | ✅ `[REDACTED:generic_api_token]` |
| `{password: 'hunter2'}` | 键名被 swift_bic 误脱敏 | ✅ `{"password":"[REDACTED:password]"}` |
| `{path: 'D:\\data\\2024\\q1.xlsx'}` | ✅（偶然） | ✅ 原样保留 |

回归测试要点（见 `test/test-executor-dlp.js`）：

1. mock LLM 返回携带触发用例的工具调用 → 断言 `execute()` 不抛错、事件参数可
   `JSON.stringify`、敏感原文不泄露、脱敏标记存在；
2. 覆盖事件发送与分析落库两条调用路径；
3. 对旧代码该测试必然失败（已验证：失败报错与线上完全一致）。

## 5. 其他项目自查清单

按以下顺序排查是否存在同类问题：

1. **grep 调用模式**：
   ```bash
   grep -rn "redactSecrets(JSON.stringify\|JSON.parse(redact\|\.replace(.*JSON.stringify" src/
   ```
   凡是对 `JSON.stringify` 输出做正则替换后再 `JSON.parse` 的代码都是高危点。
2. **检查脱敏/替换正则本身**（即使调用点已修复，供未来新增调用点参考）：
   - 以 `\b` 开头或包含 `\b` 的模式 → 会在转义序列与单词字符之间产生边界；
   - 尾部 `['"]?`、`\s*$` 之类"可选消费" → 会吞 JSON 闭合引号；
   - `/gi` 标志 + 大写字母模式 → 会把键名（`PASSWORD` 等）误当敏感内容。
3. **边界用例回归**：值里含换行（`\n`）、Windows 路径（`\\`）、引号（`\"`）、
   邮箱紧跟在换行后、`token`/`password`/`api_key` 键 + 普通值、纯数字/布尔参数。
4. **关键词提前退出（keyword gate）的影响**：若脱敏入口有"无关键词即跳过"的优化，
   改为按值检测后，键值对脱敏（`password=` 前缀模式）依赖键名上下文——务必保留
   `key: value` 重建逻辑，否则 `{password:'hunter2'}` 这类最关键的脱敏会静默失效。
5. **部署形态**：若发布为打包产物（SEA/单文件/二进制），修复后必须重新构建并
   重新分发，否则线上行为不变。

## 6. 相关文件（coqi-claw 仓库）

| 文件 | 说明 |
|------|------|
| `src/core/agent-executor.js` | 修复点：`redactArgsDeep` / `redactValueWithKey`，替换 2 处调用 |
| `src/security/dlp.js` | 脱敏引擎（未改动，原理见 §2/§5） |
| `config/dlp-policy.json` | 脱敏模式配置（未改动） |
| `test/test-executor-dlp.js` | 新增回归测试，3 用例全过 |

## 7. 已知遗留问题（本次未处理）

`test/test-dlp.js` 有 4 个预先存在的失败（与本次修复无关，master 上即存在）：
新增的 CUSIP/SWIFT/BIC 等金融标识符模式（`ae15c05` 提交）在 `/gi` 下误匹配普通
文本（如 `somepassword=longvalue`、`the password is secret123`）。属过度脱敏
（安全方向正确、语义有损），建议后续收紧这些模式，但不影响本次崩溃修复。
