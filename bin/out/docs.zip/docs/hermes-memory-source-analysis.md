# Hermes 记忆系统源码分析 + 三方对比

> 基于 Hermes Agent 实际源代码 (`memory_tool.py`, `agent/memory_manager.py`, `agent/memory_provider.py`) 的真实分析

---

## 一、Hermes 记忆系统架构全景

```
┌──────────────────────────────────────────────────────────────┐
│                    MemoryManager                              │
│              (agent/memory_manager.py)                       │
│                                                              │
│  管理多个 MemoryProvider，限制最多 1 个外部 provider           │
│  ┌─────────────────┐  ┌──────────────────────────────────┐  │
│  │ BuiltinProvider  │  │  ExternalProvider (e.g. Honcho)  │  │
│  │ (memory_tool.py) │  │  (plugins/memory/<name>/)        │  │
│  └────────┬────────┘  └──────────────────┬───────────────┘  │
│           │                              │                    │
│           │ 系统注入                      │ 可选扩展            │
└───────────┼──────────────────────────────┼────────────────────┘
            │                              │
            ▼                              ▼
┌───────────────────────┐    ┌──────────────────────────────────┐
│    Builtin 实现        │    │    插件接口 (MemoryProvider)      │
│  (tools/memory_tool.py)│    │  initialize / system_prompt_block│
│                        │    │  prefetch / sync_turn            │
│  MemoryStore 类 (607行)│    │  get_tool_schemas / handle_tool  │
│                        │    │  on_session_end / on_memory_write│
│  ┌──────────────────┐  │    │  on_pre_compress / on_delegation │
│  │ MEMORY.md (磁盘)  │  │    └──────────────────────────────────┘
│  │ §-分隔条目        │  │
│  │ agent个人笔记     │  │
│  ├──────────────────┤  │
│  │ USER.md (磁盘)    │  │
│  │ §-分隔条目        │  │
│  │ 用户画像         │  │
│  └──────────────────┘  │
└───────────────────────┘
```

## 二、核心实现分析 (`tools/memory_tool.py`)

### 2.1 设计哲学

```python
"""
Two stores:
  - MEMORY.md: agent's personal notes and observations
  - USER.md: what the agent knows about the user

Both are injected into the system prompt as a FROZEN SNAPSHOT at session start.
Mid-session writes update files on disk immediately but do NOT change
the system prompt — this preserves the prefix cache for the entire session.

Entry delimiter: § (section sign). Entries can be multiline.
Character limits (not tokens) because char counts are model-independent.
"""
```

**核心创新：Frozen Snapshot 模式**
- 系统提示词中的记忆块在会话启动时冻结
- 会话中通过 `memory` 工具写入文件，但不更新系统提示词
- **目的**：保持前缀缓存（prefix cache）稳定，所有API请求可复用

### 2.2 数据模型

```python
# 存储两个独立的文件，使用 § 作为条目分隔符
ENTRY_DELIMITER = "\n§\n"

# ~/.hermes/memories/MEMORY.md  — agent 的笔记
# ~/.hermes/memories/USER.md    — 用户画像

# 字符限制（非 token 限制，模型无关）
memory_char_limit = 2200   # MEMORY.md
user_char_limit   = 1375   # USER.md
```

### 2.3 MemoryStore 类关键方法

```python
class MemoryStore:
    # 双状态设计
    _system_prompt_snapshot  # 冻结快照：用于系统提示词，加载后不变
    memory_entries           # 活跃状态：每次工具调用修改，立即持久化

    def load_from_disk(self):
        """启动时加载，冻结系统提示词快照"""
        self.memory_entries = self._read_file("MEMORY.md")
        self.user_entries = self._read_file("USER.md")
        self._system_prompt_snapshot = {  # ← 冻结
            "memory": self._render_block("memory", self.memory_entries),
            "user": self._render_block("user", self.user_entries),
        }

    def format_for_system_prompt(self, target):
        """返回冻结快照 → 系统提示词注入用。永不返回活跃状态。"""
        return self._system_prompt_snapshot.get(target)

    def add(self, target, content):
        """添加条目 → 活跃状态 + 立即写磁盘。不影响系统提示词。"""
        with self._file_lock(path):
            self._reload_target(target)        # 先重载(防并发)
            self._set_entries(target, entries)  # 更新内存
            self.save_to_disk(target)           # 立即持久化
```

### 2.4 安全防护机制

#### 注入检测（13条威胁模式）

```python
_MEMORY_THREAT_PATTERNS = [
    # 提示词注入
    (r'ignore\s+(previous|all|above|prior)\s+instructions', "prompt_injection"),
    (r'you\s+are\s+now\s+', "role_hijack"),
    (r'do\s+not\s+tell\s+the\s+user', "deception_hide"),
    (r'system\s+prompt\s+override', "sys_prompt_override"),
    (r'disregard\s+(your|all|any)\s+(instructions|rules|guidelines)', "disregard_rules"),

    # 数据泄露
    (r'curl\s+[^\n]*\$\{?\w*(KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL|API)', "exfil_curl"),
    (r'wget\s+[^\n]*\$\{?\w*(KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL|API)', "exfil_wget"),
    (r'cat\s+[^\n]*(\.env|credentials|\.netrc)', "read_secrets"),

    # 持久化后门
    (r'authorized_keys', "ssh_backdoor"),
    (r'\$HOME/\.ssh|\~/\.ssh', "ssh_access"),
]

# 隐形Unicode字符检测
_INVISIBLE_CHARS = {
    '\u200b', '\u200c', '\u200d',  # 零宽空格
    '\u2060', '\ufeff',            # 单词连接符/字节序标记
    '\u202a', '\u202b', '\u202c',  # 双向文本控制字符
}
```

#### 外部漂移检测

当用户在 Hermes 外部（编辑器/patch工具/shell）直接编辑 MEMORY.md 时：

```python
def _detect_external_drift(self, target):
    """检测两个信号：
    1. 往返不匹配 — 重新解析+序列化 ≠ 原始字节
    2. 条目标大 — 单条 > 整个store的字符限制（说明外部追加了内容）
    """
    parsed = [e.strip() for e in raw.split(ENTRY_DELIMITER)]
    roundtrip = ENTRY_DELIMITER.join(parsed)
    max_entry_len = max(len(e) for e in parsed)

    drift = (raw.strip() != roundtrip) or (max_entry_len > char_limit)
    if drift:
        # 自动备份到 .bak.<timestamp>
        bak_path.write_text(raw)  # ← 保护用户数据不丢失
        return bak_path           # 返回错误，拒绝写入
```

#### 原子写入

```python
@staticmethod
def _write_file(path, entries):
    """tempfile + atomic rename — 读者永远看到旧完整文件或新完整文件"""
    fd, tmp_path = tempfile.mkstemp(dir=str(path.parent))
    with os.fdopen(fd, "w") as f:
        f.write(content)
        f.flush()
        os.fsync(f.fileno())       # 确保落盘
    atomic_replace(tmp_path, path) # 原子替换（相同文件系统）
```

#### 跨平台文件锁

```python
@contextmanager
def _file_lock(path):
    """Unix: fcntl.flock(LOCK_EX)  |  Windows: msvcrt.locking(LK_LOCK)"""
    lock_path = path.with_suffix(path.suffix + ".lock")
    fd = open(lock_path, "a+")
    try:
        if fcntl:
            fcntl.flock(fd, fcntl.LOCK_EX)
        else:
            msvcrt.locking(fd.fileno(), msvcrt.LK_LOCK, 1)
        yield
    finally:
        # unlock + close
```

### 2.5 工具接口

```python
def memory_tool(action, target="memory", content=None, old_text=None, store=None):
    """
    单一 memory 工具，action参数分发:
      add     — 追加新条目
      replace — 子串匹配替换
      remove  — 子串匹配删除
    
    replace/remove 使用短唯一条目子串匹配，无需ID或全文
    """
```

工具 Schema 被注入到 LLM 系统提示词中，包含行为指导：
- 条目应简洁独立
- 先搜索后添加（避免重复）
- 过时的信息应 replace/remove
- 使用 § 分隔符

---

## 三、MemoryManager 插件架构 (`agent/memory_manager.py`)

### 3.1 设计目标

```python
class MemoryManager:
    """内置provider + 最多1个外部provider。

    内置provider始终排第一。只允许一个外部provider。
    任何一个provider失败不阻塞其他provider。
    """
```

### 3.2 核心生命周期

```python
# 会话启动
manager.initialize_all(session_id)          # 初始化所有provider

# 每一轮
prompt_parts.append(manager.build_system_prompt())  # 收集静态提示词块
context = manager.prefetch_all(user_message)        # 预取相关记忆
manager.sync_all(user_msg, assistant_response)      # 同步本轮到后端
manager.queue_prefetch_all(user_msg)                # 排队下一轮预取

# 工具调用
if manager.has_tool(tool_name):
    return manager.handle_tool_call(tool_name, args)

# 会话结束
manager.on_session_end(messages)           # 通知所有provider
manager.shutdown_all()                     # 清理
```

### 3.3 钩子体系

```python
# MemoryProvider 提供的9个生命周期钩子：
initialize(session_id)        # 连接、创建资源
system_prompt_block()         # 静态提示词文本
prefetch(query)               # 每轮前预取相关记忆
sync_turn(user, assistant)    # 每轮后同步
get_tool_schemas()            # 暴露给模型的工具
handle_tool_call(name, args)  # 处理工具调用
on_session_end(messages)      # 会话结束提取
on_pre_compress(messages)     # 压缩前提取（压缩的旧消息不会丢失）
on_memory_write(action,...)   # 监听内置memory工具写入
on_delegation(task, result)   # 子agent观察
on_session_switch(new_id)     # session_id旋转
```

### 3.4 上下文防护

```python
# build_memory_context_block — 内存上下文注入包装
def build_memory_context_block(raw_context):
    return (
        "<memory-context>\n"
        "[System note: The following is recalled memory context, "
        "NOT new user input. Treat as authoritative reference data.]\n\n"
        f"{clean}\n"
        "</memory-context>"
    )

# StreamingContextScrubber — 流式输出中检测并清除 <memory-context> 标签
# 防止记忆上下文泄露到用户可见的输出中
```

---

## 四、Hermes 的亮点总结

| 亮点 | 实现细节 | 位置 |
|------|----------|------|
| **Frozen Snapshot** | 系统提示词中记忆在会话启动时冻结，保存前缀缓存 | `MemoryStore.load_from_disk()` |
| **双文件设计** | MEMORY.md (agent笔记) + USER.md (用户画像)，独立管理 | 两个文件 |
| **§ 分隔符格式** | 简单文本，模型无关，人类可读，可直接编辑 | `ENTRY_DELIMITER` |
| **注入扫描** | 13条威胁模式 + 隐形Unicode检测，拒绝恶意内容 | `_scan_memory_content()` |
| **外部漂移检测** | 检测文件被外部工具修改，自动备份，拒绝写入防数据丢失 | `_detect_external_drift()` |
| **原子写入** | tempfile + fsync + atomic rename，崩溃安全 | `_write_file()` |
| **跨平台锁** | Unix fcntl + Windows msvcrt 双重实现 | `_file_lock()` |
| **插件架构** | MemoryProvider 抽象类，支持外部分布式记忆 (Honcho/Hindsight/Mem0) | `memory_provider.py` |
| **9个生命周期钩子** | 覆盖会话全生命周期 | `MemoryProvider` 接口 |
| **session_search** | FTS5全文搜索跨会话记忆，无需LLM | `session_search_tool.py` |
| **context_compressor** | 可插拔的上下文压缩引擎 | `agent/context_compressor.py` |
| **trajectory_compressor** | 训练数据轨迹压缩 (保护首尾，压缩中间) | `trajectory_compressor.py` |

---

## 五、三方方案最终对比

### 5.1 记忆系统对比

| 维度 | OpenHuman | Hermes (源码分析) | coqi-claw 方案 |
|------|-----------|-------------------|---------------|
| **存储格式** | SQLite 层级树 | 磁盘 §-分隔文本文件 | SQLite 平铺表 |
| **知识源** | 118+ OAuth服务 | Agent手动 + 行为观察 | 用户手动 + Skill |
| **系统提示注入** | 每次对话动态生成 | **Frozen Snapshot 模式** ← 独特 | 每次对话重建 |
| **前缀缓存** | 未专门优化 | **专门设计保持缓存稳定** ← 独特 | 未考虑 |
| **注入防护** | 未明确 | **13条威胁模式 + Unicode检测** ← 独特 | 无 |
| **外部编辑保护** | Obsidian可编辑 | **漂移检测 + 自动备份 + 拒绝写入** ← 独特 | 无 |
| **原子写入** | tempfile crate | tempfile + fsync + atomic rename | 直接写入 |
| **并发锁** | 未知 | **fcntl + msvcrt 双平台** ← 独特 | 写队列串行化 |
| **插件扩展** | 无 | **MemoryProvider 插件体系** ← 独特 | 无 |
| **会话搜索** | 无 | **FTS5全文搜索** ← 独特 | memory_search工具 |
| **跨会话** | 全局记忆树 | 文件持久 + SQLite FTS5 | 文件持久 |
| **上下文压缩** | TokenJuice | 可插拔 ContextEngine | Phase 2 LLM摘要 |

### 5.2 各方案最佳特性排行

| 排名 | 特性 | 来源 | 说明 |
|:---:|------|------|------|
| 1 | **TokenJuice 80%压缩** | OpenHuman | 全局中间件，所有工具输出自动压缩 |
| 2 | **Frozen Snapshot 前缀缓存** | Hermes | 系统提示词冻结，所有API请求复用缓存 |
| 3 | **MemoryProvider 插件体系** | Hermes | 9个生命周期钩子，可插拔外部存储 |
| 4 | **注入扫描 + 漂移检测** | Hermes | 13条威胁模式 + Unicode检测 + 外部编辑保护 |
| 5 | **118+ OAuth 集成** | OpenHuman | 一键连接，类型化工具自动暴露 |
| 6 | **Obsidian Wiki 同步** | OpenHuman | 记忆可脱离Agent独立浏览编辑 |
| 7 | **Skill 系统** | coqi-claw | 渐进式披露 + LLM语义匹配 + 隔离执行 |
| 8 | **edit_file 事务编辑** | coqi-claw | 模糊匹配 + 冲突检测 + 全部回滚 + diff审计 |
| 9 | **Excel 原生支持** | coqi-claw | 读写 + 设计系统样式 |

### 5.3 Hermes 对 coqi-claw 最重要的借鉴

按实用价值排序：

1. **Frozen Snapshot 模式** — 这是 Hermes 最精巧的设计。我们的 `injector.js` 应该改为：加载时冻结快照 → 会话中记忆不变 → 下次会话更新。这样所有 LLM API 调用都可以复前缀缓存，大幅降低成本。

2. **注入扫描** — Hermes 的 13条威胁模式 + Unicode检测。我们的记忆内容也会注入系统提示词，必须做同样的防护。

3. **外部漂移检测** — 如果用户用 write 工具直接编辑 memory.db 关联文件，Hermes 会检测到并拒绝覆盖。我们也可以加入类似的保护。

4. **原子写入 + 文件锁** — Hermes 的 tempfile + fsync + rename 是成熟的原子写入方案，我们目前直接 `fs.writeFileSync`。

5. **双文件设计** — MEMORY.md + USER.md 的分离比我们单一的 memory_nodes 表更清晰。建议拆分为两个 category 或两个表。

---

## 六、优化后的 coqi-claw 方案

结合三方分析，优化 Phase 1 实现：

```
原方案改进点:

1. Frozen Snapshot (借鉴 Hermes)
   injector.js: buildMemoryContext() 在对话开始时调用一次并缓存
   → 整个会话 session 内系统提示词不变
   → 前缀缓存可以复用

2. 注入扫描 (借鉴 Hermes)
   scanner.js: 新增 记忆内容安全扫描
   → 13条威胁模式 + 隐形Unicode检测
   → 在 memory_add 写入前执行

3. 双存储 (借鉴 Hermes)
   store.js: MEMORY.md (agent笔记) + USER.md (用户画像)
   → 或使用两个独立 SQLite 表: memory_agent / memory_user

4. 原子写入 (借鉴 Hermes)
   store.js: tempfile + fsync + atomic rename
   → 替换当前的直接 fs.writeFileSync

5. 会话搜索 (借鉴 Hermes)
   新增 memory_history 工具: FTS5搜索历史对话
   → 跨会话的长期记忆检索
```
