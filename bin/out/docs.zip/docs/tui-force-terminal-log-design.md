# TUI 模式下特定日志绕过终端静音方案

> 状态：已评审，可落地  
> 关联文件：`src/utils/logger.js`、`src/skills/manager.js`、`src/tui/processor.js`

## 问题背景

在 chat/TUI 模式下，`src/tui/processor.js:200-203` 会在调用 Agent 之前执行 `logger.muteTerminal()`，运行结束后再 `logger.unmuteTerminal()`。其目的是避免 `[INFO]`、`[DEBUG]` 等日志干扰 spinner / 流式输出界面。

但这也导致一些有价值的日志在 TUI 里看不见，例如 `src/skills/manager.js:309` 的：

```
[INFO] LLM matched 1 skill(s)
```

在 `cli.js` 单轮模式下没有静音，所以能看到；在 `chat.js` 模式下被吞掉。本方案在保持 TUI 其他日志静音的前提下，只对特定日志放行。

## 推荐方案：Metadata 标记放行

在 `src/utils/logger.js` 中引入一个内部标记键，当某条日志的 meta 里包含该标记且为 `true` 时，`PrettyStream` 即使在 `_muted` 状态下也仍然输出这条日志。该标记会在格式化时被剥离，不会出现在终端或文件日志里。

### 关键常量

```js
export const FORCE_TERMINAL_KEY = '__coqi_force_terminal__';
```

该常量从 `src/utils/logger.js` 导出，供需要强制输出的调用点使用。

---

## 实现步骤

### 1. `src/utils/logger.js`

#### 1.1 导出标记常量

在文件顶部增加：

```js
export const FORCE_TERMINAL_KEY = '__coqi_force_terminal__';
```

#### 1.2 修改 `formatLogEntry()`

将标记键从对象中提前解构出来，使其不进入 `rest`，从而不进入 `metaStr`：

```js
function formatLogEntry(obj) {
  const levelName = obj.levelLabel || PINO_LEVELS[obj.level] || 'INFO';
  const d = new Date(obj.time);
  const pad = (n, len = 2) => String(n).padStart(len, '0');
  const ts = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ` +
    `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}.${pad(d.getMilliseconds(), 3)}`;
  const msg = obj.msg || '';

  // eslint-disable-next-line no-unused-vars
  const {
    level,
    time,
    msg: _msg,
    levelLabel,
    [FORCE_TERMINAL_KEY]: _forceTerminal,
    err,
    hostname,
    pid,
    ...rest
  } = obj;
  let metaStr = '';
  if (Object.keys(rest).length > 0) {
    metaStr = ` ${JSON.stringify(rest)}`;
  }

  return {ts, levelName, msg, metaStr, err};
}
```

#### 1.3 修改 `PrettyStream._write()`

先解析 JSON，再根据标记决定是否放行；静音状态下解析失败的 chunk 继续丢弃，保持原行为：

```js
class PrettyStream extends Writable {
  constructor() {
    super();
    this._muted = false;
  }

  _write(chunk, encoding, callback) {
    let obj;
    try {
      obj = JSON.parse(chunk.toString());
    } catch {
      if (!this._muted) {
        process.stderr.write(chunk);
      }
      callback();
      return;
    }

    if (this._muted && obj[FORCE_TERMINAL_KEY] !== true) {
      callback();
      return;
    }

    try {
      const {err, ...fields} = formatLogEntry(obj);
      console.error(toColorLine(fields));
      if (err && err.stack) {
        console.error(err.stack);
      }
    } catch {
      process.stderr.write(chunk);
    }
    callback();
  }
}
```

### 2. `src/skills/manager.js`

#### 2.1 引入标记常量

```js
import {logger, FORCE_TERMINAL_KEY} from "../utils/logger.js";
```

#### 2.2 对目标日志加标记

```js
const matched = this.getSkillsByNames(result.relevantSkills);

logger.info(`LLM matched ${matched.length} skill(s)`, {
  [FORCE_TERMINAL_KEY]: true,
  skills: matched.map((s) => s.name),
  relevantTools: result.relevantTools,
  confidence: result.confidence,
  reasoning: result.reasoning,
  followContext: result.followContext,
});
```

### 3. `src/tui/processor.js`

无需改动。`logger.muteTerminal()` / `logger.unmuteTerminal()` 保持原样即可。

---

## 考虑过但暂不采用的方案

### 方案 B：新增 `logger.infoTui()` 等包装方法

优点：调用点更易发现，不需要导入常量。  
缺点：只是方案 A 的语法糖，增加了 API 表面积；当前只有一个调用点需要放行，过早抽象不划算。未来若出现多个强制输出点，可再统一封装。

### 方案 C：单独开一条不被静音的 stream

优点：绕过逻辑完全隔离在 stream 路由中。  
缺点：需要重构 pino multistream 结构，路由逻辑复杂，回归风险更高。

---

## 边界条件与行为约定

| 场景 | 行为 | 说明 |
|------|------|------|
| `LOG_LEVEL=warn` | 强制日志仍不显示 | 标记只绕过“终端静音”，不绕过日志级别过滤。 |
| `LOG_FILE=true` | 文件日志中不会出现标记 | `formatLogEntry()` 已将其从 `metaStr` 剥离。 |
| TUI spinner 期间 | 放行日志输出到 `stderr` | 可能与 `@clack/prompts` 的 spinner 输出交错，属于可见性的合理折中。 |
| CLI 模式 | 无影响 | CLI 未静音，标记无感透传。 |
| Web 模式 | 无影响 | Web 不调用 `muteTerminal()`。 |
| 键名冲突 | 风险极低 | `__coqi_force_terminal__` 是双下划线内部标记，正常业务数据不会使用。 |
| `logger.success` | 可共存 | `levelLabel: 'SUCCESS'` 和 `FORCE_TERMINAL_KEY` 可同时存在，互不干扰。 |

---

## 必须注意的实现细节

1. **解析失败且处于静音状态时，要继续丢弃 chunk**  
   否则会把不可解析的原始数据打到 TUI 上，破坏界面。

2. **所有分支都必须调用 `callback()`**  
   否则 Node.js stream backpressure 会卡死。

3. **标记必须从文件日志里也剥离**  
   由于 `DailyRotateStream` 和固定文件流都复用 `formatLogEntry()`，只要在该函数里把 `[FORCE_TERMINAL_KEY]` 从 `rest` 中提前解构即可。

---

## 验证清单

### 1. 语法检查

```bash
node --check src/utils/logger.js
node --check src/skills/manager.js
```

### 2. 最小冒烟脚本

```js
import { logger, FORCE_TERMINAL_KEY } from './src/utils/logger.js';

logger.muteTerminal();
logger.info('should be hidden');
logger.info('should be visible', { [FORCE_TERMINAL_KEY]: true, foo: 'bar' });
logger.unmuteTerminal();
logger.info('visible again');
```

预期：
- `should be hidden` 不出现
- `should be visible` 出现，且元数据里不含 `__coqi_force_terminal__`
- `visible again` 出现

### 3. TUI 端到端验证

```bash
npm run chat
```

输入一条会触发技能匹配的查询，确认：
- spinner 期间仍然打印 `LLM matched N skill(s)` 及其 metadata
- 其他 `[INFO]` / `[DEBUG]` 日志仍被隐藏

### 4. 文件日志验证

```bash
LOG_FILE=true npm run chat
```

检查 `logs/app-YYYY-MM-DD.log`，确认没有 `__coqi_force_terminal__` 字符串残留。

---

## 落地结论

按本方案实施：

- 改动最小（2 个文件，核心逻辑 10 行左右）
- 向后兼容（未使用标记的日志行为完全不变）
- 不污染文件日志
- 不破坏 TUI 静音机制
- 符合项目“无 lint，用 `node --check` 验证”的约束

可直接进入代码实现。
