# coqi-claw 企业级安全边界增强方案

## 背景与目标

coqi-claw 当前缺乏企业应用所需的安全边界。关键问题包括：

1. **文件系统无隔离**：`read`/`write`/`exec`/`archive` 可访问 OS 用户权限下的任意路径（`/etc/passwd`、`~/.ssh`、`.env` 等）。
2. **命令执行警告不阻断**：`security.js` 中大量危险模式仅记录日志，不阻止执行（`rm -rf /home`、`&&` 链式命令、反引号替换、`sudo` 等均未阻断）。
3. **网络无 egress 控制**：`web_fetch`/`http_request`/`download` 可访问任意 URL，存在 SSRF 风险（内网 IP、localhost、云元数据 `169.254.169.254`）。
4. **无 DLP 保护**：`.env` 中的 API key、密码等可被工具读取后原样送入 LLM 上下文。
5. **Archive 无校验**：`archive.js` 存在 ZipSlip 风险，且可压缩/解压任意路径。

本方案通过四阶段改造，为 Agent 增加可配置的安全沙箱、网络策略和数据防泄漏能力。

---

## 阶段一：文件系统沙箱（最高优先级）

新建 `src/utils/path-sandbox.js`，提供统一的路径校验能力：

- [x] **默认允许范围**：`getBaseDir()`（项目根） + `process.cwd()`。
- [x] **可扩展**：通过 `SANDBOX_PATHS` 环境变量配置额外允许目录（逗号分隔的绝对路径）。支持跨盘符，例如 Agent 在 `C:\A` 而沙箱根目录在 `D:\B`。
- [x] **遍历防护**：拒绝包含 `..` 逃逸、绝对路径超出允许根目录。
- [x] **符号链接**：**不解析符号链接**（不做 `realpath`），仅对传入路径做规范化校验，以提升 Windows 下性能并避免时序攻击。
- [x] **沙箱内无文件名黑名单**：`.env` 等文件如果在 `SANDBOX_PATHS` 或默认允许范围内，工具可读可写；沙箱只负责边界隔离，不干涉沙箱内文件内容。
- [x] **模式**：`SANDBOX_MODE` = `enforce`（默认）/`warn`/`off`。

**Windows 优化**：
- [x] 路径比较前统一转换为小写（`toLowerCase()`）。
- [x] 统一使用反斜杠 `\` 作为分隔符，并确保根目录末尾带 `\`，防止前缀误匹配（如 `D:\Backup` 不会匹配 `D:\Back`）。
- [x] 跨盘符保护：如果目标路径盘符与任一允许根目录盘符不同，直接拒绝。

**需要修改的工具**：
- [x] `src/tools/read.js`：校验 `args.path`
- [x] `src/tools/write.js`：校验 `args.path`
- [x] `src/tools/list.js`：校验 `args.path`
- [x] `src/tools/glob.js`：校验 `args.cwd`
- [x] `src/tools/search.js`：校验 `args.path`
- [x] `src/tools/exec.js`：校验 `args.cwd`
- [x] `src/tools/archive.js`：校验 `args.source` 和 `args.destination`

### 阶段一附：沙箱目录布局规范（约定层）

新建 `src/utils/sandbox-layout.js`，在 `cli.js`/`chat.js` 启动时自动创建以下标准子目录：

| 目录 | 用途 |
|------|------|
| `user/` | 用户上传的原始数据 |
| `output/` | Agent 生成的结果文件（报告、图表等） |
| `temp/` | 工作过程中的临时文件和缓存 |
| `database/` | 知识库、公共参考数据 |
| `logs/` | 运行日志（可选） |

**实现方式**：
- [x] `getSandboxBaseDir()`：优先取 `SANDBOX_PATHS` 第一项作为沙箱根目录；未配置时回退 `getBaseDir()`（项目根）。
- [x] `ensureSandboxLayout(baseDir)`：自动 `mkdirSync` 上述目录，默认使用 `getSandboxBaseDir()`。
- [x] `src/core/prompt-builder.js` 注入目录规范说明，根据 `SANDBOX_MODE` 动态调整：
  - `enforce`：**"文件操作须在以下目录内进行"**（硬约束）
  - `warn`：**"建议将文件存放在以下目录"**（软引导）
  - `off`：完全不注入约束提示词（语义与拦截一致）
- [ ] 沙箱**不拦截** Agent 写入非标准目录，只通过提示工程引导；必要时在 `formatToolResultForLLM()` 中加入路径提醒。

---

## 阶段二：命令执行硬化（高优先级）

> ⚠️ **注意**：`exec` 工具存在**架构级绕过向量**，即使完成本阶段所有硬化改造，仍无法通过纯代码方式完全杜绝。详见文末 [已知限制与绕过向量](#已知限制与绕过向量) 章节。

重构 `src/tools/security.js`，从「警告优先」改为「阻断优先」：

- [x] 将现有 `dangerousPatterns`（`rm -rf`、`rm -f`、`>` 覆盖重要文件、`mv`、`Remove-Item`、`Move-Item`）从仅警告改为**直接抛出 fatal `Errors.security()`**。
- [x] 新增阻断规则：`sudo`、`su`、`doas`、命令链式操作符（`&&`、`;`、`||`）、命令替换（`$(...)`、反引号 `` ` ``）、路径遍历（`../`）。
- [x] `EXEC_MODE=strict` 白名单模式：`EXEC_ALLOWED_COMMANDS` 中列出的命令前缀才允许执行。

### 实现细节

**`blockedPatterns`（统一阻断）**：约 28 个 pattern，涵盖 Linux/Windows/PowerShell 系统命令、递归删除、文件覆盖、移动/重命名、提权、命令替换、路径遍历等。

**命令链例外机制**（避免误伤 python/node 内联代码）：

| 命令前缀 | `&&` | `;` | `\|\|` |
|---------|------|-----|--------|
| `python` / `node` | **放行**（内联 `and`/`or` 逻辑） | **放行**（`-c`/`-e` 引号内分号） | **仅警告** |
| 其他 shell 命令 | 阻断 | 阻断 | 阻断 |

**清理冗余**：`rm -rf /` 和 `rm -rf //` 旧 pattern 合并入统一的 `/rm\s+-rf/i`；删除 `rm -rf / ` 独自尾随空格 variant；删除 `..$` 和 `~/` 独自遍历（已被 `/rm\s+-rf/i` 覆盖）。

**注意**：`security.js` 的阻断规则**独立于 `SANDBOX_MODE`** 运行——`SANDBOX_MODE=off` 时路径越界不拦截，但危险命令（`sudo`/`rm -rf` 等）**始终被阻断**。

**修改文件**：`src/tools/security.js`（已完成）、`src/tools/exec.js`（沙箱已接入）

---

## 阶段三：网络出向控制（高优先级）

新建 `src/utils/network-policy.js`，在 `web_fetch`、`http_request`、`download` 发起请求前校验 URL：

- [x] **默认阻断**：私有 IP 段（`10.0.0.0/8`、`172.16.0.0/12`、`192.168.0.0/16`、`127.0.0.0/8`）、IPv6 本地地址（`::1`、`fc00::/7`、`fe80::/10`）、`169.254.169.254/32`（云元数据）、`localhost` / `*.local`。
- [x] **模式**：`blocklist`（默认）或 `allowlist`（仅允许 `allowedDomains` 中的域名）。
- [x] 阻断时抛出 `Errors.security()` 并 `fatal=true`（即时终止 Agent 循环）。
- [x] **配置外置化**：`config/network-policy.json`（JSON 格式，便于后续更新）。

**配置文件结构**：
```json
{
  "mode": "blocklist",
  "blockedIpRanges": ["10.0.0.0/8", "172.16.0.0/12", ...],
  "blockedIpv6Ranges": ["::1/128", "fc00::/7", ...],
  "blockedHostnames": ["localhost", "*.local"],
  "allowedDomains": []
}
```

**修改文件**：`src/tools/web-fetch.js`、`src/tools/http-request.js`、`src/tools/download.js`（均已接入）

---

## 阶段四：DLP 脱敏 + Archive 安全（中优先级）

### 4a. DLP/PII 脱敏

新建 `src/utils/dlp.js`，提供轻量级正则脱敏：

- [x] API key（`sk-...`、`AKIA...`、`pk_...`、`rk_...`）
- [x] Bearer Token / JWT（`Bearer eyJ...` 格式及 bare JWT，需 `eyJ` 前缀防止误匹配 IP）
- [x] 密码/Token 常见格式（`password=...`、`DB_PASSWORD=...`、`secret=...`、`pwd=...`）
  - 使用 lookbehind 只替换 value 部分，保留 key 名称（如 `DB_PASSWORD=[REDACTED:password]`）
  - `(?<![a-zA-Z])` 防止 `somepassword=xxx` 误匹配
- [x] 信用卡号（16位，支持 dash/space 分隔）
- [x] 私有 IP 地址（`10.x.x.x`、`172.16.x.x`、`192.168.x.x`）
- [x] **邮箱地址不脱敏**（用户明确：办公场景需要保留邮箱供 LLM 理解收件人信息）

- [x] 在 `src/utils/message-utils.js` 的 `formatToolResultForLLM()` 中，于返回前调用 `redactSecrets()`，作为所有工具结果进入 LLM 上下文的统一拦截点。

脱敏格式：`[REDACTED:${category}]`，类别包括：`api_key`、`aws_key`、`bearer_token`、`password`、`credit_card`、`ip`。

配置项：
- [x] `DLP_REDACTION`（默认 `true`，设为 `false` 禁用脱敏）
- [x] `DLP_SENSITIVE_PATTERNS`（可选额外正则）
- [x] 提前退出优化：文本不含敏感关键字时跳过正则匹配
- [x] 性能优化：预计算 lowercase 关键字列表
- [x] **配置外置化**：`config/dlp-policy.json`（patterns 和 keywords 可配置，便于维护）

**配置文件**：`config/dlp-policy.json`
```json
{
  "enabled": true,
  "patterns": [
    { "pattern": "\\b(sk[-_][a-zA-Z0-9]{20,64})\\b", "category": "api_key" },
    ...
  ],
  "keywords": ["sk-", "AKIA", "Bearer", ...],
  "redactionFormat": "[REDACTED:${category}]"
}
```

**导出函数**：
- `redactSecrets(text, extraPatterns?)` → `string`（脱敏后文本）
- `redactSecretsWithStats(text, extraPatterns?)` → `{text, counts, total}`（含统计信息，便于审计）
- `reloadConfig()` → `Object`（热更新配置）
- `getConfig()` → `Object`（获取当前配置）

**测试覆盖**：`test/test-dlp.js`（41 个测试用例，覆盖全部模式 + 边界情况）

### 4b. Archive 安全

修改 `src/tools/archive.js`：

- [x] **ZipSlip 防护**：解压时校验每个 entry 的解析路径必须落在 `destination` 目录内，拒绝 `..` 和绝对路径。
- [x] 增加 `ARCHIVE_MAX_ENTRIES`（默认 10000）和 `ARCHIVE_MAX_UNCOMPRESSED_SIZE`（默认 500MB）限制，防止 zip bomb。

---

## 阶段五：Fatal Security 错误即时终止（已实现）

### 设计目标

Agent 执行循环对所有 `ToolError(type='security')` 一视同仁——只格式化后加入消息历史，LLM 继续迭代。对「环境级阻断」场景（如沙箱越界），无论换什么参数都必然失败，但循环继续浪费 API 调用甚至寻找绕过。

**目标**：区分「环境级致命错误」和「参数级可重试错误」，前者即时终止循环。

### Fatal 分类标准

> `fatal` = 错误根源与环境相关，与本次参数值无关 → 换参数必然同样失败

| 场景 | fatal | reason 常量 | 所属工具 |
|------|-------|-------------|---------|
| 路径沙箱越界 | ✅ | `sandbox_blocked` | path-sandbox.js |
| 危险命令模式 | ✅ | `dangerous_command` | security.js |
| ZipSlip | ✅ | `zip_slip` | archive.js |
| ZIP 条目数超限 | ✅ | `zip_bomb_entries` | archive.js |
| ZIP 解压大小超限 | ✅ | `zip_bomb_size` | archive.js |

### 实现机制

#### 1. `errors.js` — Fatal 推断

```javascript
// 新增 FatalSecurityReasons 常量
export const FatalSecurityReasons = [
  'sandbox_blocked', 'dangerous_command', 'zip_slip',
  'zip_bomb_entries', 'zip_bomb_size',
];

// Errors.security() 自动推断 fatal
security: (command, reason, metadata = {}) => {
  const fatal = FatalSecurityReasons.includes(metadata.reason);
  return new ToolError(ErrorTypes.SECURITY, ..., { command, fatal, ...metadata });
}

// ToolError 新增 fatal getter
get fatal() { return this.metadata?.fatal === true; }
```

#### 2. `agent-executor.js` — Fatal 检测与即时终止

三处关键修改：

- **`executeSingleTool` catch 块**：对 `ToolError` 透传原始 `metadata`（含 `fatal`/`reason`），而非 `getErrorInfo()` 的兜底包装。
- **execute 循环 fatal 检测**：在 `executeToolCalls` 返回后、加入消息历史前，检测 fatal 错误并即时 `return`，终止 Agent 循环。
- **`buildToolResponse`**：非 fatal security 错误附加引导提示 `"(安全策略限制，请尝试其他方式达成目标)"`。

```javascript
// execute 循环中 fatal 检测
for (const result of toolResults) {
  if (result.error && result.errorInfo?.type === 'security' && result.errorInfo?.metadata?.fatal) {
    // 仍将已执行工具的 response 加入历史（用于事后审计）
    for (const r of toolResults) {
      if (r !== result && !r.error) messages.push(this.buildToolResponse(r));
    }
    messages.push(this.buildToolResponse(result));
    this.emit('abort', { iteration: iteration + 1, reason: 'security_fatal' });
    return `[Security Error] ${errorMsg}\n\n此操作被安全策略永久阻断，Agent 已终止执行。`;
  }
}
```

### SANDBOX_MODE=off 兼容性

`SANDBOX_MODE=off` 时，`validatePath()` 直接 return，`sandbox_blocked` 错误永不触发，Agent 行为与无沙箱完全一致。`dangerous_command`/`zip_slip`/`zip_bomb_*` 等独立安全防线不受沙箱开关影响。

| Fatal Reason | `SANDBOX_MODE=off` 时是否触发 |
|-------------|-------------------------------|
| `sandbox_blocked` | **不触发**（`validatePath` 跳过） |
| `dangerous_command` | **仍触发**（独立安全防线） |
| `zip_slip` / `zip_bomb_entries` / `zip_bomb_size` | **仍触发**（独立安全防线） |

---

## 新增配置项（`src/utils/config.js`）

```javascript
- [x] `sandboxPaths`
- [x] `sandboxMode`
- [x] `execMode`
- [x] `execAllowedCommands`
- [x] `networkMode`
- [x] `allowedUrls`
- [x] `blockedIpRanges`
- [x] `dlpRedaction`
- [x] `dlpSensitivePatterns`
- [x] `archiveMaxEntries`
- [x] `archiveMaxUncompressedSize`
```

---

## 关键文件清单

| 文件 | 变更内容 | 状态 |
|------|---------|------|
| `src/utils/config.js` | 新增全部安全配置项 | ✅ 已完成 |
| `src/utils/path-sandbox.js` | **新建**：路径沙箱校验 | ✅ 已完成 |
| `src/utils/sandbox-layout.js` | **新建**：沙箱子目录自动创建 | ✅ 已完成 |
| `src/utils/network-policy.js` | **新建**：URL 出向策略 | ✅ 已完成 |
| `src/utils/dlp.js` | **新建**：PII/Secrets 脱敏，支持配置外置化 | ✅ 已完成 |
| `src/utils/message-utils.js` | 在 `formatToolResultForLLM()` 中接入 DLP | ✅ 已完成 |
| `src/tools/security.js` | 危险模式从警告改为阻断；新增命令链/提权/命令替换/路径遍历阻断；实现EXEC_MODE=strict；python/node内联代码例外逻辑 | ✅ 已完成 |
| `src/tools/exec.js` | 接入沙箱和硬化后的安全校验 | ✅ 已完成 |
| `src/tools/read.js` | 接入沙箱校验 | ✅ 已完成 |
| `src/tools/write.js` | 接入沙箱校验 | ✅ 已完成 |
| `src/tools/list.js` | 接入沙箱校验 | ✅ 已完成 |
| `src/tools/glob.js` | 接入沙箱校验 | ✅ 已完成 |
| `src/tools/search.js` | 接入沙箱校验 | ✅ 已完成 |
| `src/core/agent-executor.js` | Fatal security 检测、即时终止、ToolError metadata 透传、非 fatal 引导提示 | ✅ 已完成 |
| `src/tools/archive.js` | 接入沙箱校验、ZipSlip 防护、zip bomb 限制 | ✅ 已完成 |
| `src/tools/web-fetch.js` | 接入网络策略 | ✅ 已完成 |
| `src/tools/http-request.js` | 接入网络策略 | ✅ 已完成 |
| `src/tools/download.js` | 接入沙箱校验 + 网络策略 | ✅ 已完成 |
| `config/network-policy.json` | **新建**：网络策略配置（CIDR、hostname 阻断列表） | ✅ 已完成 |
| `config/dlp-policy.json` | **新建**：DLP 脱敏配置（patterns、keywords） | ✅ 已完成 |
| `test/test-dlp.js` | **新建**：DLP 单元测试（41 个用例） | ✅ 已完成 |

---

## 已知限制与绕过向量

### `exec` 工具的架构级绕过

`exec` 工具通过 `child_process.exec` 生成子进程，子进程拥有与 Agent 相同的 OS 用户权限。这意味着：

1. **命令参数绕过**（✅ 已修复）：直接通过 `python script.py "C:\\outside\\file.txt"` 传递的外部路径，现已被 `validateCommandPathArguments()` 拦截。
2. **脚本内嵌绕过**（⚠️ **已知未修复**）：Agent 可以先通过 `write` 在沙箱内生成脚本（如 `temp/reader.py`），在脚本中硬编码外部路径（`C:/tmp5/daily-report.pdf`），再通过 `exec` 执行该脚本。由于脚本执行时不再经过 Node.js 路径校验，可成功读取沙箱外文件。

**实测复现路径**（2026-04-16）：
```
用户请求：阅读 C:\tmp5\daily-report.pdf
→ exec "python summarize_pdf.py C:\tmp5\daily-report.pdf" 
  → 被 validateCommandPathArguments() 拦截 ✅
→ write temp/reader.py （脚本内硬编码 C:/tmp5/daily-report.pdf）
→ exec "python temp/reader.py"
  → 脚本子进程直接读取外部 PDF ✅ 绕过成功
```

**影响评估**：
- 这是**应用级沙箱的固有局限**，任何允许子进程执行的环境都难以在纯 Node.js 层面完全杜绝。
- 只要 `write` + `exec` 同时存在，Agent 总能构造出绕过沙箱的子进程执行链。

#### 缓解方案（按优先级）

1. **禁用 `exec` 工具（推荐，高安全场景）**
   通过 `ENABLED_TOOLS` 环境变量移除 `exec`：
   ```bash
   ENABLED_TOOLS=read,write,list,glob,search,archive,download,web_fetch,http_request,time,chrome_nav,chrome_interact,chrome_extract,chrome_env,clipboard,system_info
   ```
   禁用 `exec` 后，skill 脚本中依赖命令行的功能将无法使用，但核心文件操作和浏览器自动化仍可正常工作。

2. **OS 级隔离（推荐，生产部署）**
   将 Agent 或 `exec` 子进程放入更低权限的运行环境中：
   - **容器化**：Docker / Podman 运行，挂载只读卷限制宿主机访问范围。
   - **Windows Sandbox**：适用于 Windows 桌面场景，重启后自动回滚。
   - **专用低权限用户**：以非管理员、无家目录敏感文件的 OS 用户运行 Agent。

3. **严格白名单模式（中等效果）**
   配置 `EXEC_MODE=strict` + `EXEC_ALLOWED_COMMANDS=dir,node,python`：
   - 无法阻止已允许命令（如 `python`）执行恶意脚本，但能增加一部分操作门槛。
   - 对 write + exec 绕过无实质效果。

4. **限制脚本写入（不推荐）**
   通过 `write` 工具禁止写入 `.py`、`.js`、`.sh`、`.bat`、`.ps1` 等可执行文件扩展名。
   - **副作用**：会破坏大量正常 skill 工作流（如 `henry-pdf-tools` 依赖 Python 脚本），因此**暂不实施**。

#### 结论

- **✅ 已生效**：`read`/`write`/`list`/`glob`/`search`/`archive`/`download`/`exec` 直接参数的沙箱拦截均正常工作。
- **⚠️ 未根治**：`exec` 结合 `write` 的脚本内嵌绕过需要 **OS 级隔离** 或 **禁用 exec** 才能彻底解决。纯应用层代码改造无法完全消除该风险。

---

## 验证策略

| 模块 | 验证项 | 状态 |
|------|--------|------|
| **沙箱** | `read('/etc/passwd')`、`write('/tmp/x', '')`、`exec('ls', '/etc')`、`list('../../')` 均被阻断 | ✅ 已通过 `test/test-path-sandbox.js` |
| **沙箱目录布局** | `SANDBOX_PATHS=C:\clawSandbox` 时，`ensureSandboxLayout()` 在 `C:\clawSandbox` 而非项目根下创建 `user/output/temp` 等子目录；提示词正确注入；`off` 模式不注入 | ✅ 已验证 |
| **命令执行** | `sudo`、`rm -rf /home`、`echo x && rm -rf /`、`echo $(whoami)`、``echo `whoami` `` 均被阻断；`python -c "import os; print(1)"`/`node -e "require('fs'); console.log(1)"` 等内联分号正确放行；`EXEC_MODE=strict` 白名单生效 | ✅ 已验证 |
| **网络** | `http://127.0.0.1`、`http://169.254.169.254`、`http://192.168.1.1`、`http://localhost`、`http://test.local` 均被阻断；公网 URL 正常通过 | ✅ 已完成（`config/network-policy.json`） |
| **DLP** | `API_KEY=sk-xxx`、`DB_PASSWORD=xxx`、`Card: 4532-...-0366`、`192.168.1.100` 等均被脱敏为 `[REDACTED:...]`；邮箱（`henry@163.com`）不脱敏；`DLP_REDACTION=false` 时跳过脱敏；配置外置化到 `config/dlp-policy.json` | ✅ 已完成（`test/test-dlp.js`，41 个用例全部通过） |
| **Archive** | 带 `../../evil.txt` 的恶意 zip 解压被阻断；超大 zip（条目 > 10000）被阻断 | ✅ 已实现，需补充自动化测试 |
| **Fatal Security** | sandbox_blocked / dangerous_command / zip_slip / zip_bomb_* 返回 `fatal=true`，Agent 循环即时终止；非 fatal security 错误附加引导提示；`SANDBOX_MODE=off` 时 sandbox_blocked 不触发 | ✅ 已验证逻辑，集成测试待补充 |
